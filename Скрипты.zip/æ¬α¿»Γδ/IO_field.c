#ifndef _LOGIN_C
#define _LOGIN_C

#include "\\hpm31-13.ca.sbrf.ru\main_pools\commons.h"

int Siebel_SWECount_var;



void logout()
{
	unsigned int n = lr_get_debug_message();
	lr_set_debug_message(n, LR_SWITCH_OFF);

	// ���� �����

	web_set_timeout("STEP",		"1000");
  web_set_timeout("CONNECT",	"1000");
  web_set_timeout("RECEIVE",	"1000");

	web_url("start.swe_22", 
		"URL={Host}start.swe?SWECmd=Logoff&SWETS={SiebelTimeStamp}&SWEPreLd=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("pkmslogout", 
		"URL=https://{Domain}/pkmslogout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);	
		
	web_set_timeout("STEP",		"300");
    web_set_timeout("CONNECT",	"300");
    web_set_timeout("RECEIVE",	"300");
		
	lr_set_debug_message(n, LR_SWITCH_ON);
}

void login()
{
	double trans_time;
	unsigned int n = lr_get_debug_message();

	Siebel_SWECount_var = 2;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_set_max_html_param_len("100240");
	web_cache_cleanup();
	web_cleanup_cookies();
	
	web_set_timeout("STEP",		"400");
  web_set_timeout("CONNECT",	"400");
  web_set_timeout("RECEIVE",	"400");
	
	startTransaction("Login");

	lr_output_message(lr_eval_string("������������:{Login_USER}"));

	logout();
			
	//web_set_sockets_option("SSL_VERSION", "TLS1.1");
		web_add_cookie("username={Login_USER}; DOMAIN={Domain}");
		web_add_cookie("sudir-domain=; DOMAIN={Domain}");
	
	web_url("cort", 
		"URL={Host}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		LAST);
			
	reg_error();
	web_submit_data("pkmslogin.form", 
		"Action=https://{Domain}/pkmslogin.form", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=domain", "Value=", ENDITEM, 
		"Name=username", "Value={Login_USER}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=login-form-type", "Value=pwd", ENDITEM, 
		LAST);
	check_error();

	web_url("start.swe", 
		"URL={Host}start.swe?SWECmd=Start&SWEHo={Domain}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param("Siebel_SWEACn2", "LB=SWEACn=", "RB=&", "Ord=1", "Search=Body", "RelFrameId=1", LAST);
	
	web_url("start.swe_2", 
		"URL={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
	
	web_url("start.swe_3", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);
		
	web_reg_save_param("SRN", "LB=SRN`", "RB=`", "Ord=1", "Search=All", LAST);
	web_reg_save_param("Siebel_SWEVLC", "LB/IC=`cks`", "RB/IC=`", "Ord=1", "Search=Body", "RelFrameId=1", LAST);

	web_url("start.swe_4", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe._sweapp&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("blank.htm", 
		"URL={Host}blank.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_5", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe._swecdawksp&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_6", 
		"URL={Host}start.swe?SWECmd=GotoPostedAction&SWEACn={Siebel_SWEACn2}&SWEDIC=true&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=&SWECS=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_7", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWERT=5&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_8", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweappmenu&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_9", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweviewbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_10", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swethreadbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_11", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swescrnbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_12", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_13", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent._sweview&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_14", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Web Engine Client Preferences", ENDITEM, 
		"Name=SWEMethod", "Value=SetClientCapability", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0``3``cpf`Mobile=false`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();
		
	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_15", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=PrepareGlobalMenu", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`4`0``3``Name`Siebel Financial Services`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_16", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=BatchCanInvoke", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`21`0``3``#0``#1``#2``#3``#4``#5``#6``#7``#8``#9``#10``#11``#12``#13``#14``#15``#16``menuname`Siebel Financial Services`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();
	
	reg_error();	//����������� ������ getdateforlogin(); � �������� �� reg_error()
	web_submit_data("start.swe_18", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SWECmd", "Value=GotoView", ENDITEM, 
		"Name=SWEView", "Value=SBRF Home Page In Work View", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEKeepContext", "Value=1", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		LAST);
	check_error();

	web_url("start.swe_19", 
		"URL={Host}start.swe?SWECmd=GetViewLayout&SWEView=FINS%20Home%20Page%20View&SWEVI=&SWEVLC={Siebel_SWEVLC}&SWEApplet=undefined&LayoutIdentifier=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_set_debug_message(n, LR_SWITCH_ON);
	
	endTransaction(10, "Login","Status", LR_AUTO); 

	lr_save_int(0, "fail_check");
}


void loginSRCC()
{
	double trans_time;
	unsigned int n = lr_get_debug_message();

	Siebel_SWECount_var = 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_set_max_html_param_len("100240");
	web_cache_cleanup();
	web_cleanup_cookies();
	
	web_set_timeout("STEP",		"400");
	web_set_timeout("CONNECT",	"400");
	web_set_timeout("RECEIVE",	"400");
	
	startTransaction("Login");

	lr_output_message(lr_eval_string("������������:{Login_USER}"));

	vuser_end();
			
	//web_set_sockets_option("SSL_VERSION", "TLS1.1");
	web_add_cookie("username={Login_USER}; DOMAIN={Domain}");
	web_add_cookie("sudir-domain=; DOMAIN={Domain}");
	
	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("sr_oui", 
		"URL={Host}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		LAST);

//	web_add_cookie("username={Login_USER}; DOMAIN={Domain}");
//
//	web_add_cookie("sudir-domain=; DOMAIN={Domain}");
//
//	web_add_cookie("ipaddrs=10.82.46.106; DOMAIN={Domain}");

	reg_error();
	web_submit_data("pkmslogin.form", 
		"Action=https://{Domain}/pkmslogin.form", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=domain", "Value=", ENDITEM, 
		"Name=username", "Value={Login_USER}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=login-form-type", "Value=pwd", ENDITEM, 
		LAST);
	check_error();

	web_url("start.swe", 
		"URL={Host}start.swe?SWECmd=Start&SWEHo={Domain}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		LAST);

	/* Registering parameter(s) from source task id 5022
	// {Siebel_SWEACn4} = "31790"
	// */

	web_reg_save_param("Siebel_SWEACn4", "LB=SWEACn=", "RB=&", "Ord=1", "Search=Body", "RelFrameId=1", LAST);

	web_url("start.swe_2", 
		"URL={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Start&SWEHo={Domain}", 
		"Snapshot=t70.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	/* Registering parameter(s) from source task id 6032
	// {Siebel_SWEACn} = "31790"
	// */

	web_reg_save_param("Siebel_SWEACn", "LB/IC=&SWEACn=", "RB/IC=&", "Ord=1", "Search=Body", "RelFrameId=1", LAST);

	web_url("start.swe_3", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn4}&SWEC={Siebel_SWECount}&SWEFrame=top._swe&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		LAST);

	web_url("blank.htm", 
		"URL={Host}blank.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t72.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_reg_save_param("Siebel_SWEVLC", "LB/IC=`cks`", "RB/IC=`", "Ord=1", "Search=Body", "RelFrameId=1", LAST);
	
	web_reg_save_param("SRN",  "LB=SRN`",  "RB=`",  "Ord=1",  "Search=All",  LAST);
	
	web_url("start.swe_4", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn}&SWEC={Siebel_SWECount}&SWEFrame=top._swe._sweapp&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t73.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("start.swe_5", 
		"URL={Host}start.swe?SWECmd=GotoPostedAction&SWEACn={Siebel_SWEACn}&SWEDIC=true&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=&SWECS=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t74.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_url("start.swe_6", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn}&SWERT=5&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t75.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var -= 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_url("start.swe_7", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweviewbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t76.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_revert_auto_header("X-Requested-With");
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_url("start.swe_8", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweappmenu&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var -= 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_revert_auto_header("X-Requested-With");

	web_url("start.swe_9", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swethreadbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_url("start.swe_10", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient.CTIToolbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t79.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var -= 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_url("start.swe_11", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swescrnbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_revert_auto_header("X-Requested-With");
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_url("start.swe_12", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("start.swe_13", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent._sweview&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		LAST);

	web_save_timestamp_param("SiebelTimeStamp", LAST);
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	reg_error();
	web_submit_data("start.swe_14", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=PrepareGlobalMenu", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`4`0``3``Name`SBRF SR`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	web_save_timestamp_param("SiebelTimeStamp", LAST);

	web_revert_auto_header("X-Requested-With");

	reg_error();
	web_submit_data("start.swe_15", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Web Engine Client Preferences", ENDITEM, 
		"Name=SWEMethod", "Value=SetClientCapability", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0``3``cpf`Mobile=false`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_save_timestamp_param("SiebelTimeStamp", LAST);

	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	reg_error();
	web_submit_data("start.swe_16", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=BatchCanInvoke", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`22`0``3``#0``#1``#2``#3``#4``#5``#6``#7``#8``#9``#10``#11``#12``#13``#14``#15``#16``#17``menuname`SBRF SR`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	Siebel_SWECount_var -= 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_revert_auto_header("X-Requested-With");

	web_url("start.swe_17", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn}&SWEC={Siebel_SWECount}&SWEFrame=_swepage&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t86.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var += 2;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_save_timestamp_param("SiebelTimeStamp", LAST);

	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_submit_data("start.swe_18", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWEBS", "Value=1", ENDITEM, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Message Bar", ENDITEM, 
		"Name=SWEMethod", "Value=UpdatePrefMsg", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`2`0``3``SWEBS`1`IsInitiated`FALSE`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);

	web_save_timestamp_param("SiebelTimeStamp", LAST);

	web_submit_data("start.swe_19", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t88.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEMethod", "Value=GetProfileAttr", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0`GetProfileAttr`3``attrName`SBRF Short Name`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_save_timestamp_param("SiebelTimeStamp",	LAST);

	web_revert_auto_header("X-Requested-With");
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_submit_data("start.swe_20", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t89.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEMethod", "Value=GetProfileAttr", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0`GetProfileAttr`3``attrName`SBRF Job Title`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_save_timestamp_param("SiebelTimeStamp", LAST);

	web_submit_data("start.swe_21", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t90.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SWEMethod", "Value=ShellUIInit", ENDITEM, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Communications Client", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=Host", "Value=CAB-WAD-0001780.ca.sbrf.ru", ENDITEM, 
		"Name=Addr", "Value=10.82.46.106", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);

	web_save_timestamp_param("SiebelTimeStamp", LAST);

	web_submit_data("start.swe_22", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t91.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEMethod", "Value=GetProfileAttr", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0`GetProfileAttr`3``attrName`SBRF Employee Profile Name`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_save_timestamp_param("SiebelTimeStamp", LAST);

	web_revert_auto_header("X-Requested-With");

	web_submit_data("start.swe_23", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t92.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Workflow Process Manager", ENDITEM, 
		"Name=SWEMethod", "Value=RunProcess", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`4`0``3``ProcessName`SBRF EAI Query`Integration Object Name`SBRF HeatMap List Of Values Relationship`Search Specification`([SBRF HeatMap List Of Values Relationship.Parent Type] = 'SBRF_HEATMAP_ACCESS' AND [SBRF HeatMap List Of Values Relationship.Parent Name] = 'User' AND [SBRF HeatMap List Of Values Relationship.Type] = 'SBRF_HEATMAP_ACCESS'  AND [SBRF HeatMap List Of Values Relationship.Description] = '{Login_USER}' AND [SBRF HeatMap List Of Values Relationship.Active] = "
		"'Y') OR ([SBRF HeatMap List Of Values Relationship.Parent Type] = 'SBRF_HEATMAP_ACCESS' AND [SBRF HeatMap List Of Values Relationship.Parent Name] = 'Role' AND [SBRF HeatMap List Of Values Relationship.Type] = 'SBRF_HEATMAP_ACCESS'  AND [SBRF HeatMap List Of Values Relationship.Description] = '%u0410%u0434%u043c%u0438%u043d%u0438%u0441%u0442%u0440%u0430%u0442%u043e%u0440 %u041e%u0431%u0440%u0430%u0449%u0435%u043d%u0438%u0439' AND [SBRF HeatMap List Of Values Relationship.Active] = 'Y')`UTC "
		"Canonical`N`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);

	Siebel_SWECount_var += 1;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");
	web_save_timestamp_param("SiebelTimeStamp", LAST);

	web_add_header("X-Requested-With", "XMLHttpRequest");
/*
	web_submit_data("start.swe_24", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t93.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SWECmd", "Value=WaitForCmd", ENDITEM, 
		"Name=SWEService", "Value=Communications Client", ENDITEM, 
		"Name=refID", "Value=1", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	*/
	waitforcmd("Login","SBRF Ready","true");

	endTransaction(10, "Login","Status", LR_AUTO); 
	
	lr_save_int(0, "fail_check");
	
}



void loginSR()
{
	double trans_time;
	unsigned int n = lr_get_debug_message();
	
	Siebel_SWECount_var = 2;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_set_max_html_param_len("100240");
	web_cache_cleanup();
	web_cleanup_cookies();

	startTransaction("Login");
	lr_output_message(lr_eval_string("������������:{Login_USER}"));

	logout();

	// web_set_sockets_option("SSL_VERSION", "TLS1.1");
	web_add_cookie("username={Login_USER}; DOMAIN={Domain}");
	web_add_cookie("sudir-domain=; DOMAIN={Domain}");

	web_url("cort", 
		"URL={Host}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		LAST);
			
	reg_error();
	web_submit_data("pkmslogin.form", 
		"Action=https://{Domain}/pkmslogin.form", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=domain", "Value=", ENDITEM, 
		"Name=username", "Value={Login_USER}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=login-form-type", "Value=pwd", ENDITEM, 
		LAST);
	check_error();

	web_url("start.swe", 
		"URL={Host}start.swe?SWECmd=Start&SWEHo={Domain}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param("Siebel_SWEACn2", "LB=SWEACn=", "RB=&", "Ord=1", "Search=Body", "RelFrameId=1", LAST);

	web_url("start.swe_2", 
		"URL={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
	
	web_url("start.swe_3", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);
		
	web_url("blank.htm", 
		"URL={Host}blank.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
	
	web_reg_save_param("SRN", "LB=SRN`", "RB=`", "Ord=1", "Search=All", LAST);
	web_reg_save_param("Siebel_SWEVLC", "LB/IC=`cks`", "RB/IC=`", "Ord=1", "Search=Body", "RelFrameId=1", LAST);

	web_url("start.swe_4", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe._sweapp&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_5", 
		"URL={Host}start.swe?SWECmd=GotoPostedAction&SWEACn={Siebel_SWEACn2}&SWEDIC=true&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=&SWECS=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_6", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWERT=5&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_7", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweviewbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_8", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweappmenu&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_9", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swethreadbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_10", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swescrnbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_11", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_12", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent._sweview&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

//	web_url("start.swe_13", 
//		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent._sweview&SWEBID=-1&SRN=&SWETS=", 
//		"TargetFrame=", 
//		"Resource=0", 
//		"RecContentType=text/html", 
//		"Snapshot=t17.inf", 
//		"Mode=HTML", 
//		LAST);

	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_14", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Web Engine Client Preferences", ENDITEM, 
		"Name=SWEMethod", "Value=SetClientCapability", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0``3``cpf`Mobile=false`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_15", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=PrepareGlobalMenu", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`4`0``3``Name`SBRF SR`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_16", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=BatchCanInvoke", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`22`0``3``#0``#1``#2``#3``#4``#5``#6``#7``#8``#9``#10``#11``#12``#13``#14``#15``#16``#17``menuname`SBRF SR`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();
			
	reg_error();
	web_submit_data("start.swe_18", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SWECmd", "Value=GotoView", ENDITEM, 
		"Name=SWEView", "Value=FINS Home Page View", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEKeepContext", "Value=1", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		LAST);
	check_error();
	
	web_url("start.swe_19", 
		"URL={Host}start.swe?SWECmd=GetViewLayout&SWEView=FINS%20Home%20Page%20View&SWEVI=&SWEVLC={Siebel_SWEVLC}&SWEApplet=undefined&LayoutIdentifier=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_set_debug_message(n, LR_SWITCH_ON);

	endTransaction(10, "Login","Status", LR_AUTO); 
	

	lr_save_int(0, "fail_check");
}

void logoutCC()
{
	unsigned int n = lr_get_debug_message();
	lr_set_debug_message(n, LR_SWITCH_OFF);

	/*���� �����*/

	web_set_timeout("STEP","300");//300  7200
  web_set_timeout("CONNECT","300");//300  1000
  web_set_timeout("RECEIVE","300");//300  7200 

	web_url("start.swe_20", 
		"URL={Host}start.swe?SWECmd=Logoff&SWETS={SiebelTimeStamp}&SWEPreLd=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		LAST);

	web_url("pkmslogout", 
		"URL=https://{Domain}/pkmslogout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);	
		
	web_set_timeout("STEP","300");
  web_set_timeout("CONNECT","300");
  web_set_timeout("RECEIVE","300");
		
	lr_set_debug_message(n, LR_SWITCH_ON);
}

void loginCC()
{
	// ���������� ��� ������ ����������
	double trans_time;
	unsigned int n = lr_get_debug_message();
	
	Siebel_SWECount_var = 2;
	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_set_max_html_param_len("100240");
	web_cache_cleanup();
	web_cleanup_cookies();

	startTransaction("Login");

	lr_output_message(lr_eval_string("������������:{Login_USER}"));

	logoutCC();
		
	

	// LOGIN

	web_add_cookie("username={Login_USER}; DOMAIN={Domain}");
	web_add_cookie("sudir-domain=; DOMAIN={Domain}");
	
	web_url("cort", 
		"URL={Host}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		LAST);
	
	reg_error();
	web_submit_data("pkmslogin.form", 
		"Action=https://{Domain}/pkmslogin.form?token=Unknown", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={Login_USER}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=login-form-type", "Value=pwd", ENDITEM, 
		LAST);
	check_error();

	web_url("start.swe", 
		"URL={Host}start.swe?SWECmd=Start&SWEHo={Domain}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param("Siebel_SWEACn2", "LB=SWEACn=", "RB=&", "Ord=1", "Search=Body", "RelFrameId=1", LAST);

	web_url("start.swe_2", 
		"URL={Host}start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param("Siebel_SWEVLC", "LB/IC=`cks`", "RB/IC=`", "Ord=1", "Search=Body", "RelFrameId=1", LAST);
	web_reg_save_param("SRN", "LB=SRN`", "RB=`", "Ord=1", "Search=All", LAST);

	web_url("start.swe_4", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe._sweapp&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("blank.htm", 
		"URL={Host}blank.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_5", 
		"URL={Host}start.swe?SWECmd=GotoPostedAction&SWEACn={Siebel_SWEACn2}&SWEDIC=true&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=&SWECS=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);
	
	web_url("start.swe_6", 
		"URL={Host}start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWERT=5&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_7", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swethreadbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_8", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweviewbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_9", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweappmenu&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_10", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swescrnbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_11", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_12", 
		"URL={Host}start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent._sweview&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_save_timestamp_param("SiebelTimeStamp", LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
 	web_submit_data("start.swe_13", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Web Engine Client Preferences", ENDITEM, 
		"Name=SWEMethod", "Value=SetClientCapability", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0``3``cpf`Mobile=false`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
 	web_submit_data("start.swe_14", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=PrepareGlobalMenu", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`4`0``3``Name`SBRF CC OUI`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
 	web_submit_data("start.swe_15", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=BatchCanInvoke", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`21`0``3``#0``#1``#2``#3``#4``#5``#6``#7``#8``#9``#10``#11``#12``#13``#14``#15``#16``#17``#18``#19``menuname`SBRF CC OUI`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	web_save_timestamp_param("SiebelTimeStamp",	LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_17", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SWECmd", "Value=GotoView", ENDITEM, 
		"Name=SWEView", "Value=SBRF CC OUI Home Page View", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEKeepContext", "Value=1", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		LAST);
	check_error();

	web_url("start.swe_18", 
		"URL={Host}start.swe?SWECmd=GetViewLayout&SWEView=SBRF%20CC%20OUI%20Home%20Page%20View&SWEVI=&SWEVLC={Siebel_SWEVLC}&SWEApplet=undefined&LayoutIdentifier=SBRF+CC+Interaction+List+Applet+-+Home+OUI_Edit+List_Edit+List__-1SBRF+CC+Widget+Form+Applet+OUI_Edit_Edit__-1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);
	
	web_reg_save_param("SBRF Ready", "LB=command name=\"EnableControl\" control=\"SBRF Ready\" value=\"",  "RB=\"", "Ord=1", "NOTFOUND=Warning",  LAST);

	reg_error();
	web_submit_data("start.swe_22", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SWEMethod", "Value=ShellUIInit", ENDITEM, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Communications Client", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWEActiveApplet", "Value=SBRF CC Widget Form Applet OUI", ENDITEM, 
		"Name=SWEActiveView", "Value=SBRF CC OUI Home Page View", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();
		
	web_save_timestamp_param("SiebelTimeStamp", LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_23", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEMethod", "Value=GetProfileAttr", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0`GetProfileAttr`3``attrName`First Name`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWEActiveApplet", "Value=SBRF CC Widget Form Applet OUI", ENDITEM, 
		"Name=SWEActiveView", "Value=SBRF CC OUI Home Page View", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	web_save_timestamp_param("SiebelTimeStamp", LAST);
	web_reg_save_param("Siebel_SWECount", "LB=SWEC`", "RB=`", "Ord=1", LAST);

	reg_error();
	web_submit_data("start.swe_24", 
		"Action={Host}start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEMethod", "Value=GetProfileAttr", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0`GetProfileAttr`3``attrName`Last Name`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWEActiveApplet", "Value=SBRF CC Widget Form Applet OUI", ENDITEM, 
		"Name=SWEActiveView", "Value=SBRF CC OUI Home Page View", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
	check_error();

	endTransaction(10, "Login","Status", LR_AUTO); 
	
	lr_save_int(0, "fail_check");
}

void reg_error()
{
    reg_error_old();
	getdate(); 
}

void reg_error_old()
{
  web_reg_save_param("ErrorMessage", "LB=`ErrMsg`", "RB=`", "Ord=1", "NotFound=WARNING", LAST);
	web_reg_save_param("ErrorMessage2", "LB=^ErrMsg^", "RB=^", "Ord=1", "NotFound=WARNING", LAST);
	web_reg_find("Text=The server you are trying to access is either busy", "SaveCount=Busy_Count", LAST); 
}

void check_error()
{
	check_error_old();
	
	if (strcmp(lr_eval_string("{Sim}"),"`")==0) createparamforfields(); 
	else {
		lr_save_string(lr_eval_string("{AppletDom}"),"Applet");
		lr_save_string(lr_eval_string("{ViewDom}"),"View");
		lr_save_string(lr_eval_string("{HeaderDom}"),"Header");
		lr_save_string(lr_eval_string("{TypeAppletsDom}"),"TypeApplets");
		lr_save_string(lr_eval_string("{flagforheaderDom}"),"flagforheader");
		lr_save_string(lr_eval_string("{applets1Dom}"),"applets1");
		lr_save_string(lr_eval_string("{viewsDom}"),"views");
		lr_save_string(lr_eval_string("{fieldsnamesDom}"),"fieldsnames");
		lr_save_string(lr_eval_string("{stringsDom}"),"strings");
		lr_save_string(lr_eval_string("{fnDom}"),"fn");
		lr_save_string(lr_eval_string("{dnDom}"),"dn");
		lr_save_string(lr_eval_string("{fieldsDom}"),"fields");
		lr_save_string(lr_eval_string("{fieldmethodDom}"),"fieldmethod");
		lr_save_string(lr_eval_string("{fieldnamemethodDom}"),"fieldnamemethod");
		createparamforfields();
	}
//	lr_output_message("===Sim = %s",lr_eval_string("{Sim}"));
	/*
	if ((strlen(lr_eval_string("{ErrorMessage}")) != 0))
		{
			endCurrentTransaction(lr_eval_string("{ErrorMessage}"), LR_FAIL);
			lr_output_message( lr_eval_string("Error:{ErrorMessage}") );
			lr_fail_trans_with_error( lr_eval_string("Error:{ErrorMessage}") );
		
			
			lr_save_int(1, "fail_check");
			lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_AUTO);
			// logout();
			// web_cache_cleanup();
			// web_cleanup_cookies();
			// login();
						
	}
	
	if (atoi(lr_eval_string("{Busy_Count}"))>0)
	{
		
		endCurrentTransaction(lr_eval_string("{ErrorMessage}"), LR_FAIL);
		
		lr_fail_trans_with_error(lr_eval_string("{Host}: The server you are trying to access is either busy"));		
		
		startTransaction("Server busy");
		 logout();
			web_cache_cleanup();
			web_cleanup_cookies();
		//sleep(60000);
		 //login();	 
		 endTransaction(10, "Server busy","Server busy", LR_AUTO); 
	 lr_exit(LR_EXIT_VUSER, LR_FAIL);	
	//lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_AUTO);
	}
	*/
} 

void check_error_old()
{
	int HttpRetCode;
	HttpRetCode = web_get_int_property(HTTP_INFO_RETURN_CODE);
//	lr_output_message("HttpRetCode %d",HttpRetCode);
	
	if (strlen(lr_eval_string("{ErrorMessage}")) != 0)
		{
			endCurrentTransaction(lr_eval_string("{ErrorMessage}"), LR_FAIL);
			lr_output_message( lr_eval_string("Error:{ErrorMessage}") );
			lr_fail_trans_with_error( lr_eval_string("Error:{ErrorMessage}") );
			
			lr_save_int(1, "fail_check");
			lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_AUTO);
			// logout();
			// web_cache_cleanup();
			// web_cleanup_cookies();
			// login();
	}

	if (strlen(lr_eval_string("{ErrorMessage2}")) != 0)
		{
			endCurrentTransaction(lr_eval_string("{ErrorMessage2}"), LR_FAIL);
			lr_output_message( lr_eval_string("Error:{ErrorMessage2}") );
			lr_fail_trans_with_error( lr_eval_string("Error:{ErrorMessage2}") );
			
			lr_save_int(1, "fail_check");
			lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_AUTO);
			// logout();
			// web_cache_cleanup();
			// web_cleanup_cookies();
			// login();
	}
	
	if ((HttpRetCode==504) || (HttpRetCode==408))
		{
			endCurrentTransaction(lr_eval_string("Timeout"), LR_FAIL);
			lr_output_message( lr_eval_string("Error:Timeout") );
			lr_fail_trans_with_error( lr_eval_string("Error:Timeout") );
			
			lr_save_int(1, "fail_check");
			lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_AUTO);
			// logout();
			// web_cache_cleanup();
			// web_cleanup_cookies();
			// login();
	}
	
	if (atoi(lr_eval_string("{Busy_Count}"))>0)
	{
		
		endCurrentTransaction(lr_eval_string("{ErrorMessage}"), LR_FAIL);
		
		lr_fail_trans_with_error(lr_eval_string("{Host}: The server you are trying to access is either busy"));		
		
		startTransaction("Server busy");
		logout();
		web_cache_cleanup();
		web_cleanup_cookies();
		//sleep(60000);
		//login();	 
		endTransaction(10, "Server busy","Server busy", LR_AUTO); 
		lr_exit(LR_EXIT_VUSER, LR_FAIL);	
		//lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_AUTO);
	}
	
	
} 

int getcounter() {
	return atoi(lr_eval_string("{fieldscouner}"));
}

void inccounter() {
	int a;
	char st[100];
	a=getcounter()+1;
	sprintf(st,"%d",a);
	lr_save_string(st,"fieldscouner");
}

void getdateforlogin() {
	start_waste();
	
	lr_save_string("0","fieldscouner");
	lr_save_string("","Applet");
	lr_save_string("","View");
	web_reg_save_param("Header", "LB=^v^", "RB=^","Ord=1","Search=Body", "Notfound=warning", LAST);
	web_reg_save_param("View", "LB=^View^", "RB=^","Ord=1","Notfound=warning", LAST);
	web_reg_save_param("Applet", "LB=&SWEApplet=", "RB=^","Ord=1", "Notfound=warning", LAST);

	end_waste();
}

void getdate() {
	start_waste();
	
	lr_save_string("","Applet");
	lr_save_string("","View");
	lr_save_string("","AppletDom");
	lr_save_string("","ViewDom");
		
	web_reg_save_param_regexp("ParamName=Sim", "RegExp=@0(.)","Ordinal=1","Notfound=warning", LAST);

	web_reg_save_param("Header", "LB=`v`", "RB=`","Ord=1","Search=Body", "Notfound=warning", LAST);
	web_reg_save_param("TypeApplets", "LB=`Status`", "RB=`","Ord=1","Search=Body", "Notfound=warning", LAST);
		
	web_reg_save_param_regexp ("ParamName=flagforheader","RegExp=`v`.*?`(.*?)`.*?`","Ordinal=1","Notfound=warning",LAST);

	/*web_reg_save_param_regexp ("ParamName=applets","RegExp=`cud`(.(?!([c][u][d])))*?`ObjectName`(([^`](?!([c][u][d])))*?)`(.(?!([c][u][d])))*?`sp`(.(?!([c][u][d])))*?`","Group=3","Ordinal=all","Notfound=warning",LAST);*/

	web_reg_save_param_regexp ("ParamName=applets1","RegExp=(`cud`.*?`ObjectName`.*?`.*?`sp`.*?`)","Ordinal=all","Notfound=warning",LAST);

	web_reg_save_param_regexp ("ParamName=views","RegExp=`cud`.*?`ObjectName`.*?`.*?`sp`.*?`.*?`SWEView`(.*?)`","Ordinal=all","Notfound=warning",LAST);

	/*web_reg_save_param_regexp ("ParamName=fieldsnames", "RegExp=`cud`(.(?!([c][u][d])))*?`ObjectName`(.(?!([c][u][d])))*?`sp`(([^`](?!([c][u][d])))*?)`",	"Group=5","Ordinal=all","Notfound=warning",	LAST);*/

	web_reg_save_param_regexp ("ParamName=fieldsnames","RegExp=`cud`.*?`ObjectName`.*?`.*?`sp`(.*?)`","Ordinal=all","Notfound=warning",LAST);	

	web_reg_save_param_regexp ("ParamName=strings","RegExp=`sp`(.*?`dn`.*?`fn`.*?`)","Ordinal=All","Notfound=warning",LAST );


	web_reg_save_param_regexp ("ParamName=fn","RegExp=`sp`.*?`dn`.*?`fn`(.*?)`","Ordinal=All","Notfound=warning",LAST );

	web_reg_save_param_regexp ("ParamName=dn","RegExp=`sp`.*?`dn`(.*?)`fn`.*?`","Ordinal=All","Notfound=warning",LAST );

	web_reg_save_param_regexp ("ParamName=fields","RegExp=`sp`(.*?)`.*?`dn`.*?`fn`.*?`","Ordinal=All","Notfound=warning",LAST );

	web_reg_save_param_regexp ("ParamName=fieldmethod","RegExp=`SWEField`.*?`.*?`SWEMethod`(.*?)`","Ordinal=all","Notfound=warning",LAST);

	web_reg_save_param_regexp ("ParamName=fieldnamemethod","RegExp=`SWEField`(.*?)`.*?`SWEMethod`.*?`","Ordinal=all","Notfound=warning",LAST);

	web_reg_save_param("View", "LB=`View`", "RB=`","Ord=1","Notfound=warning", LAST);
	web_reg_save_param("Applet", "LB=&SWEApplet=", "RB=`","Ord=1", "Notfound=warning", LAST);
	
	web_reg_save_param("HeaderDom", "LB=^v^", "RB=^","Ord=1","Search=Body", "Notfound=warning", LAST);
	web_reg_save_param("TypeAppletsDom", "LB=^Status^", "RB=^","Ord=1","Search=Body", "Notfound=warning", LAST);
	
	web_reg_save_param_regexp ("ParamName=flagforheaderDom","RegExp=^v^.*?^(.*?)^.*?^","Ordinal=1","Notfound=warning",LAST);
		
	web_reg_save_param_regexp ("ParamName=applets1Dom","RegExp=(^cud^.*?^ObjectName^.*?^.*?^sp^.*?^)","Ordinal=all","Notfound=warning",LAST);
	
	web_reg_save_param_regexp ("ParamName=viewsDom","RegExp=^cud^.*?^ObjectName^.*?^.*?^sp^.*?^.*?^SWEView^(.*?)^","Ordinal=all","Notfound=warning",LAST);
	
	web_reg_save_param_regexp ("ParamName=fieldsnamesDom","RegExp=^cud^.*?^ObjectName^.*?^.*?^sp^(.*?)^","Ordinal=all","Notfound=warning",LAST);	
	
	web_reg_save_param_regexp ("ParamName=stringsDom","RegExp=^sp^(.*?^dn^.*?^fn^.*?^)","Ordinal=All","Notfound=warning",LAST );
	
	web_reg_save_param_regexp ("ParamName=fnDom","RegExp=^sp^.*?^dn^.*?^fn^(.*?)^","Ordinal=All","Notfound=warning",LAST );
	
	web_reg_save_param_regexp ("ParamName=dnDom","RegExp=^sp^.*?^dn^(.*?)^fn^.*?^","Ordinal=All","Notfound=warning",LAST );
	
	web_reg_save_param_regexp ("ParamName=fieldsDom","RegExp=^sp^(.*?)^.*?^dn^.*?^fn^.*?^","Ordinal=All","Notfound=warning",LAST );
	
	web_reg_save_param_regexp ("ParamName=fieldmethodDom","RegExp=^SWEField^.*?^.*?^SWEMethod^(.*?)^","Ordinal=all","Notfound=warning",LAST);
	
	web_reg_save_param_regexp ("ParamName=fieldnamemethodDom","RegExp=^SWEField^(.*?)^.*?^SWEMethod^.*?^","Ordinal=all","Notfound=warning",LAST);
	
	web_reg_save_param("ViewDom", "LB=^View^", "RB=^","Ord=1","Notfound=warning", LAST);
	web_reg_save_param("AppletDom", "LB=&SWEApplet=", "RB=^","Ord=1", "Notfound=warning", LAST);
	
	end_waste();
}

void getelemfromstring(char *temp, char *name) {
	char st[1000],st1[1000];
	int n,i,f=0,k=0,z,kol=0,kl=1,j;
	n=strlen(temp);
	for (i=0;i<n;i++) {
		if (temp[i]>='0' && temp[i]<='9') {
			kol=kol*10+temp[i]-48;
		}
		if (temp[i]=='*') {
			for (j=0;j<kol;j++) {
				st[j]=temp[i+1+j];
			}
			st[kol]='\0';
			sprintf(st1,"%s_%d",name,getcounter());
			inccounter();
			i=i+kol;
			kol=0;
			kl++;
			lr_save_string(st,st1);
		}
	}
}

void createparamforfields() {
	int i,k,kl1,num,kl,a,f,*m,kl2=1,j,kl3,z=1,y=1,flag=0,ii;
	int *m1;
	char st[1000],*temp,s[1000],s2[500],s1[1000],st1[1000],*temp1,*c,*b,status[10]="NewPopup";
	
	start_waste();
	//long file;
	//file=fopen ("output.txt","a");
	temp=lr_paramarr_idx("views",1);
	lr_save_string(lr_eval_string("{applets1_count}"),"applets_count");
	for (i=1;i<=lr_paramarr_len("applets1");i++) {
		sprintf(st,"applets_%d",i);
		if (strcmp(lr_eval_string("{Sim}"),"`")==0)	lr_save_param_regexp(lr_paramarr_idx("applets1",i), strlen(lr_paramarr_idx("applets1",i)), "RegExp=`ObjectName`(.*?)`", "Ordinal=All", "ResultParam=applets2", LAST);
			else lr_save_param_regexp(lr_paramarr_idx("applets1",i), strlen(lr_paramarr_idx("applets1",i)), "RegExp=^ObjectName^(.*?)^", "Ordinal=All", "ResultParam=applets2", LAST);
		lr_save_string(lr_paramarr_idx("applets2",lr_paramarr_len("applets2")),st);
	}
	for (i=1;i<=lr_paramarr_len("applets");i++) {
		temp1=lr_paramarr_idx("applets",i);
		sprintf(s,"{%s_%s}",temp,temp1);
		if (lr_eval_string(s)[0]!='1' || strcmp(lr_eval_string("{TypeApplets}"),status)==0) {
			flag=1;
			//sprintf(s,"%s_%s",temp,temp1);
			//lr_save_string("1",s);
		}
	}
	temp1=lr_paramarr_idx("applets",kl2);
	sprintf(s2,"{%s_%s}",temp,temp1);
if (lr_eval_string("{Header}")[0] && (lr_eval_string("{flagforheader}")[0]=='0' || lr_eval_string("{flagforheader}")[0]=='2' || lr_eval_string("{flagforheader}")[0]=='1') || getcounter()==0) {
		lr_save_string(lr_eval_string("{Header}"),temp);
		getelemfromstring(lr_eval_string("{Header}"),"namefield");
	}
	if (flag==1) {
	//	m1=(int *)calloc(lr_paramarr_len("fieldmethod"),lr_paramarr_len,sizeof(int));
		m=(int *)calloc(getcounter(),sizeof(int));
		//lr_output_message("%d",getcounter());
		for (i=1;i<=lr_paramarr_len("fields");i++) {
			for (ii=1;ii<=lr_paramarr_len("fieldsnames");ii++) {
				if (strcmp(lr_paramarr_idx("fieldsnames",ii),lr_paramarr_idx("fields",i))==0) {
					//lr_output_message("%s %s",lr_paramarr_idx("fieldsnames",kl2+1),lr_paramarr_idx("fields",i));
					z=0;
					kl2++;
					temp=lr_paramarr_idx("views",1);
					temp1=lr_paramarr_idx("applets",ii);
					for (j=0;j<getcounter();j++) {
						m[j]=0;
					}
					sprintf(s2,"{%s_%s}",temp,temp1);
				}
			}
			if (lr_eval_string(s2)[0]!='1' || strcmp(lr_eval_string("{TypeApplets}"),status)==0) {
				f=0;
				c=lr_paramarr_idx("fields",i);
				for (j=1;j<=lr_paramarr_len("fieldmethod");j++) {
					b=lr_paramarr_idx("fieldnamemethod",j);
					if (strcmp(c,b)==0) {
						if (z==0) {
							z=1;
							y=j;
						}
						f=j;
						break;
					}
				}
				if (f==0) {
					if (lr_paramarr_idx("namefield",atoi(lr_paramarr_idx("fn",i)))[0]) {
						kl=atoi(lr_paramarr_idx("fn",i));
						sprintf(s,"{%s_%d}","namefield",kl);
						sprintf(st,"%s_%s_%s_%d",temp,temp1,lr_eval_string(s),m[kl]);
						//lr_error_message ("%s;%s;%s_%d;%s;%s_%s_%s_%d",temp,temp1,lr_eval_string(s),m[kl],lr_paramarr_idx("fields",i),temp,temp1,lr_eval_string(s),m[kl]);
						if (kl>getcounter()) {
							lr_output_message("��������� ����� ..... � ���-�� �������� �����������. ���� ����� � �������, ���� ����� � ����");
							lr_save_int(1, "fail_check");
							endCurrentTransaction(lr_eval_string("liberror"), LR_FAIL);
							lr_exit(LR_EXIT_VUSER, LR_FAIL);
						}
						m[kl]++;
					} else {
						kl=atoi(lr_paramarr_idx("dn",i));
						sprintf(s,"{%s_%d}","namefield",kl);
						sprintf(st,"%s_%s_%s_%d",temp,temp1,lr_eval_string(s),m[kl]);
						//lr_error_message ("%s;%s;%s_%d;%s;%s_%s_%s_%d",temp,temp1,lr_eval_string(s),m[kl],lr_paramarr_idx("fields",i),temp,temp1,lr_eval_string(s),m[kl]);
						if (kl>getcounter()) {
							lr_output_message("��������� ����� ..... � ���-�� �������� �����������. ���� ����� � �������, ���� ����� � ����");
							lr_save_int(1, "fail_check");
							endCurrentTransaction(lr_eval_string("liberror"), LR_FAIL);
							lr_exit(LR_EXIT_VUSER, LR_FAIL);
						}
						m[kl]++;
					}
				} else {
					kl3=0;
					for (j=y;j<f;j++) {
						if (strcmp(lr_paramarr_idx("fieldmethod",j),lr_paramarr_idx("fieldmethod",f))==0) {
							kl3++;
						}
					}
					sprintf(s,"{%s_%d}","fieldmethod",f);
					sprintf(st,"%s_%s_%s_%d",temp,temp1,lr_eval_string(s),kl3);
					//lr_error_message ("%s;%s;%s_%d;%s;%s_%s_%s_%d",temp,temp1,lr_eval_string(s),kl3,lr_paramarr_idx("fields",i),temp,temp1,lr_eval_string(s),kl3);
				}
				sprintf(st1,"%s_%s_%s",temp,temp1,lr_paramarr_idx("fields",i));
				lr_save_string(lr_paramarr_idx("fields",i),st);
				lr_save_string(st,st1);
				//lr_output_message ("%s %s",lr_paramarr_idx("fields",i),st);
			}
		}
		free(m);
	}
	for (i=1;i<=lr_paramarr_len("applets");i++) {
		temp1=lr_paramarr_idx("applets",i);
		sprintf(s,"{%s_%s}",temp,temp1);
		if (lr_eval_string(s)[0]!='1' || strcmp(lr_eval_string("{TypeApplets}"),status)==0) {
			//flag=1;
			sprintf(s,"%s_%s",temp,temp1);
			lr_save_string("1",s);
		}
	}
	if (getcounter()>2000) lr_output_message("%d",getcounter()); 
	//lr_output_message("%d",getcounter());
	end_waste();
}

void createparamforfieldsflag(int mainflag) {
	int i,k,kl1,num,kl,a,f,*m,kl2=1,j,kl3,z=1,y=1,flag=0,ii;
	int *m1;
	char st[1000],*temp,s[1000],s2[500],s1[1000],st1[1000],*temp1,*c,*b,status[10]="NewPopup";
	
	start_waste();
	
	//long file;
	//file=fopen ("output.txt","a");
	temp=lr_paramarr_idx("views",1);
	lr_save_string(lr_eval_string("{applets1_count}"),"applets_count");
	for (i=1;i<=lr_paramarr_len("applets1");i++) {
		sprintf(st,"applets_%d",i);
		lr_save_param_regexp(lr_paramarr_idx("applets1",i), strlen(lr_paramarr_idx("applets1",i)), "RegExp=`ObjectName`(.*?)`", "Ordinal=All", "ResultParam=applets2", LAST);
		lr_save_string(lr_paramarr_idx("applets2",lr_paramarr_len("applets2")),st);
	}
	flag=mainflag;
	for (i=1;i<=lr_paramarr_len("applets");i++) {
		temp1=lr_paramarr_idx("applets",i);
		sprintf(s,"{%s_%s}",temp,temp1);
		if (lr_eval_string(s)[0]!='1' || strcmp(lr_eval_string("{TypeApplets}"),status)==0) {
			flag=1;
			//sprintf(s,"%s_%s",temp,temp1);
			//lr_save_string("1",s);
		}
	}
	temp1=lr_paramarr_idx("applets",kl2);
	sprintf(s2,"{%s_%s}",temp,temp1);
if (lr_eval_string("{Header}")[0] && (lr_eval_string("{flagforheader}")[0]=='0' || lr_eval_string("{flagforheader}")[0]=='2') || getcounter()==0) {
		lr_save_string(lr_eval_string("{Header}"),temp);
		getelemfromstring(lr_eval_string("{Header}"),"namefield");
	}
	if (flag==1) {
	//	m1=(int *)calloc(lr_paramarr_len("fieldmethod"),lr_paramarr_len,sizeof(int));
		m=(int *)calloc(getcounter(),sizeof(int));
		//lr_output_message("%d",getcounter());
		for (i=1;i<=lr_paramarr_len("fields");i++) {
			for (ii=1;ii<=lr_paramarr_len("fieldsnames");ii++) {
				if (strcmp(lr_paramarr_idx("fieldsnames",ii),lr_paramarr_idx("fields",i))==0) {
					//lr_output_message("%s %s",lr_paramarr_idx("fieldsnames",kl2+1),lr_paramarr_idx("fields",i));
					z=0;
					kl2++;
					temp=lr_paramarr_idx("views",1);
					temp1=lr_paramarr_idx("applets",ii);
					for (j=0;j<getcounter();j++) {
						m[j]=0;
					}
					sprintf(s2,"{%s_%s}",temp,temp1);
				}
			}
			if (mainflag==1 || lr_eval_string(s2)[0]!='1' || strcmp(lr_eval_string("{TypeApplets}"),status)==0) {
				f=0;
				c=lr_paramarr_idx("fields",i);
				for (j=1;j<=lr_paramarr_len("fieldmethod");j++) {
					b=lr_paramarr_idx("fieldnamemethod",j);
					if (strcmp(c,b)==0) {
						if (z==0) {
							z=1;
							y=j;
						}
						f=j;
						break;
					}
				}
				if (f==0) {
					if (lr_paramarr_idx("namefield",atoi(lr_paramarr_idx("fn",i)))[0]) {
						kl=atoi(lr_paramarr_idx("fn",i));
						sprintf(s,"{%s_%d}","namefield",kl);
						sprintf(st,"%s_%s_%s_%d",temp,temp1,lr_eval_string(s),m[kl]);
						//lr_error_message ("%s;%s;%s_%d;%s;%s_%s_%s_%d",temp,temp1,lr_eval_string(s),m[kl],lr_paramarr_idx("fields",i),temp,temp1,lr_eval_string(s),m[kl]);
						if (kl>getcounter()) {
							lr_output_message("��������� ����� ..... � ���-�� �������� �����������. ���� ����� � �������, ���� ����� � ����");
							lr_save_int(1, "fail_check");
							endCurrentTransaction(lr_eval_string("liberror"), LR_FAIL);
							lr_exit(LR_EXIT_VUSER, LR_FAIL);
						}
						m[kl]++;
					} else {
						kl=atoi(lr_paramarr_idx("dn",i));
						sprintf(s,"{%s_%d}","namefield",kl);
						sprintf(st,"%s_%s_%s_%d",temp,temp1,lr_eval_string(s),m[kl]);
						//lr_error_message ("%s;%s;%s_%d;%s;%s_%s_%s_%d",temp,temp1,lr_eval_string(s),m[kl],lr_paramarr_idx("fields",i),temp,temp1,lr_eval_string(s),m[kl]);
						if (kl>getcounter()) {
							lr_output_message("��������� ����� ..... � ���-�� �������� �����������. ���� ����� � �������, ���� ����� � ����");
							lr_save_int(1, "fail_check");
							endCurrentTransaction(lr_eval_string("liberror"), LR_FAIL);
							lr_exit(LR_EXIT_VUSER, LR_FAIL);
						}
						m[kl]++;
					}
				} else {
					kl3=0;
					for (j=y;j<f;j++) {
						if (strcmp(lr_paramarr_idx("fieldmethod",j),lr_paramarr_idx("fieldmethod",f))==0) {
							kl3++;
						}
					}
					sprintf(s,"{%s_%d}","fieldmethod",f);
					sprintf(st,"%s_%s_%s_%d",temp,temp1,lr_eval_string(s),kl3);
					//lr_error_message ("%s;%s;%s_%d;%s;%s_%s_%s_%d",temp,temp1,lr_eval_string(s),kl3,lr_paramarr_idx("fields",i),temp,temp1,lr_eval_string(s),kl3);
				}
				sprintf(st1,"%s_%s_%s",temp,temp1,lr_paramarr_idx("fields",i));
				lr_save_string(lr_paramarr_idx("fields",i),st);
				lr_save_string(st,st1);
				//lr_output_message ("%s %s",lr_paramarr_idx("fields",i),st);
			}
		}
		if (getcounter()>2000) lr_output_message("%d",getcounter()); 
		//lr_output_message("%d",getcounter()); 
		free(m);
	}
	for (i=1;i<=lr_paramarr_len("applets");i++) {
		temp1=lr_paramarr_idx("applets",i);
		sprintf(s,"{%s_%s}",temp,temp1);
		if (lr_eval_string(s)[0]!='1' || strcmp(lr_eval_string("{TypeApplets}"),status)==0) {
			//flag=1;
			sprintf(s,"%s_%s",temp,temp1);
			lr_save_string("1",s);
		}
	}
	end_waste();
}

void getparamsfield(char *view,char *applet,char *field) {
	char st[1000];
	sprintf(st,"{%s_%s_%s}",view,applet,field);
	lr_output_message("%s %s %s  -  %s",view,applet,field,lr_eval_string(st));	
}


#endif