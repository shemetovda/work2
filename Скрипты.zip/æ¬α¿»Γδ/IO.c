#ifndef _LOGIN_C
#define _LOGIN_C

int Siebel_SWECount_var;


void login()
{
	
	double trans_time;

	
	
	
	unsigned int n = lr_get_debug_message();
	lr_set_debug_message(n, LR_SWITCH_OFF);
	
web_set_max_html_param_len("100240");
	web_cache_cleanup();
	web_cleanup_cookies();
	//lr_start_transaction("�����������");
	startTransaction("�����������");
	lr_output_message(lr_eval_string("������������:{Login_USER}"));
	web_set_timeout("STEP","1000");
    web_set_timeout("CONNECT","1000");
    web_set_timeout("RECEIVE","1000");
///////////////////


/* LOGOUT */
	
	lr_set_debug_message(n, LR_SWITCH_OFF);

	/*���� �����*/

	Siebel_SWECount_var += 1;

	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_save_timestamp_param("SiebelTimeStamp", 
		LAST);

	web_url("start.swe_22", 
		"URL={Host}/start.swe?SWECmd=Logoff&SWETS={SiebelTimeStamp}&SWEPreLd=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("pkmslogout", 
		"URL=https://{Domain}/pkmslogout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);	
		
		
	web_set_timeout("STEP","300");
    web_set_timeout("CONNECT","300");
    web_set_timeout("RECEIVE","300");
		
		
		/* LOGIN */
		
				
	lr_set_debug_message(n, LR_SWITCH_ON);

	
	//	web_set_sockets_option("SSL_VERSION", "TLS1.1");
		web_add_cookie("username={Login_USER}; DOMAIN={Domain}");
		web_add_cookie("sudir-domain=; DOMAIN={Domain}");

		// web_reg_find(
		//	"SaveCount=sudirTitle",
		//    "Text=<title>���� � �������</title>",
		//    LAST);

		
	
		web_url("cort", 
			"URL={Host}/", 
			"TargetFrame=", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=", 
			"Snapshot=t1.inf", 
			"Mode=HTML", 
			EXTRARES, 
			LAST);
	
			
		// if (atoi(lr_eval_string("{sudirTitle}")) == 0) {
		//	lr_error_message("�� ������� ������� �������� ����� �����");
		//	//continue;
		//}

////////////////
lr_start_transaction("Test");

reg_error();
	web_submit_data("pkmslogin.form", 
		"Action=https://{Domain}/pkmslogin.form", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		//"Referer={Host}/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=domain", "Value=", ENDITEM, 
		"Name=username", "Value={Login_USER}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=login-form-type", "Value=pwd", ENDITEM, 
		LAST);
		check_error();


	web_url("start.swe", 
		"URL={Host}/start.swe?SWECmd=Start&SWEHo={Domain}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);


	web_reg_save_param("Siebel_SWEACn2", 
		"LB=SWEACn=", 
		"RB=&", 
		"Ord=1", 
		"Search=Body", 
		"RelFrameId=1", 
		LAST);
		
	
	
	web_url("start.swe_2", 
		"URL={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Start&SWEHo={Domain}", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
	

	Siebel_SWECount_var =2;

	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_url("start.swe_3", 
		"URL={Host}/start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);
		
		web_reg_save_param("SRN", 
		 "LB=SRN`", 
		 "RB=`", 
		 "Ord=1", 
		 "Search=All", 
		 LAST);
		 
		 	web_reg_save_param("Siebel_SWEVLC", 
		"LB/IC=`cks`", 
		"RB/IC=`", 
		"Ord=1", 
		"Search=Body", 
		"RelFrameId=1", 
		LAST);

	web_url("start.swe_4", 
		"URL={Host}/start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe._sweapp&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("blank.htm", 
		"URL={Host}/blank.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_5", 
		"URL={Host}/start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=top._swe._swecdawksp&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_6", 
		"URL={Host}/start.swe?SWECmd=GotoPostedAction&SWEACn={Siebel_SWEACn2}&SWEDIC=true&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=&SWECS=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_7", 
		"URL={Host}/start.swe?SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWERT=5&SWEC={Siebel_SWECount}&SWEFrame=_sweclient&SRN=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_8", 
		"URL={Host}/start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweappmenu&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var += 1;

	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_url("start.swe_9", 
		"URL={Host}/start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._sweviewbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_10", 
		"URL={Host}/start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swethreadbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_11", 
		"URL={Host}/start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn=&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swescrnbar&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var += 1;

	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_url("start.swe_12", 
		"URL={Host}/start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("start.swe_13", 
		"URL={Host}/start.swe?SWENeedContext=false&SWECmd=GetCachedFrame&SWEACn={Siebel_SWEACn2}&SWEC={Siebel_SWECount}&SWEFrame=_sweclient._swecontent._sweview&SWEBID=-1&SRN=&SWETS=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	Siebel_SWECount_var += 1;

	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_save_timestamp_param("SiebelTimeStamp", 
		LAST);

	
		reg_error();
	web_submit_data("start.swe_14", 
		"Action={Host}/start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=Web Engine Client Preferences", ENDITEM, 
		"Name=SWEMethod", "Value=SetClientCapability", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`1`0``3``cpf`Mobile=false`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
		check_error();
		

	web_save_timestamp_param("SiebelTimeStamp", 
		LAST);


		reg_error();
	web_submit_data("start.swe_15", 
		"Action={Host}/start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=PrepareGlobalMenu", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`4`0``3``Name`Siebel Financial Services`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
		check_error();


	Siebel_SWECount_var += 1;

	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_save_timestamp_param("SiebelTimeStamp", 
		LAST);

	
		reg_error();
	web_submit_data("start.swe_16", 
		"Action={Host}/start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=SWECmd", "Value=InvokeMethod", ENDITEM, 
		"Name=SWEService", "Value=SWE Command Manager", ENDITEM, 
		"Name=SWEMethod", "Value=BatchCanInvoke", ENDITEM, 
		"Name=SWEIPS", "Value=@0`0`21`0``3``#0``#1``#2``#3``#4``#5``#6``#7``#8``#9``#10``#11``#12``#13``#14``#15``#16``menuname`Siebel Financial Services`menuparenttype`Name`SWEJI`false`SWEDIC`true`", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SWETS", "Value={SiebelTimeStamp}", ENDITEM, 
		LAST);
		check_error();
			


	
		reg_error();
	web_submit_data("start.swe_18", 
		"Action={Host}/start.swe", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SWECmd", "Value=GotoView", ENDITEM, 
		"Name=SWEView", "Value=FINS Home Page View", ENDITEM, 
		"Name=SWEC", "Value={Siebel_SWECount}", ENDITEM, 
		"Name=SRN", "Value={SRN}", ENDITEM, 
		"Name=SWEKeepContext", "Value=1", ENDITEM, 
		"Name=SWERPC", "Value=1", ENDITEM, 
		LAST);
		check_error();
			
		
///////////////////////
	web_url("start.swe_19", 
		"URL={Host}/start.swe?SWECmd=GetViewLayout&SWEView=FINS%20Home%20Page%20View&SWEVI=&SWEVLC={Siebel_SWEVLC}&SWEApplet=undefined&LayoutIdentifier=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_set_debug_message(n, LR_SWITCH_ON);
	//lr_end_transaction("�����������", LR_AUTO);
	endTransaction(10, "�����������","Status", LR_AUTO); 
//			trans_time = lr_get_transaction_duration ("OUI_UC_001"); 
//lr_output_message("������������: %s , ���������� OUI_UC_001 ����������� �� %f sec",lr_eval_string("{Login_USER}"),trans_time);
lr_end_transaction("Test", LR_AUTO);
lr_save_int(0, "fail_check");
	
}

void logout()
{

	unsigned int n = lr_get_debug_message();
	lr_set_debug_message(n, LR_SWITCH_OFF);

	/*���� �����*/

	Siebel_SWECount_var += 1;

	lr_save_int(Siebel_SWECount_var, "Siebel_SWECount");

	web_save_timestamp_param("SiebelTimeStamp", 
		LAST);

	web_url("start.swe_22", 
		"URL={Host}/start.swe?SWECmd=Logoff&SWETS={SiebelTimeStamp}&SWEPreLd=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={Host}/start.swe?SWECmd=Login&SWEPL=1&SRN=&SWETS=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("pkmslogout", 
		"URL=https://{Domain}/pkmslogout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);	
		
		
	web_set_timeout("STEP","300");
    web_set_timeout("CONNECT","300");
    web_set_timeout("RECEIVE","300");
		
		
	lr_set_debug_message(n, LR_SWITCH_ON);
	
}

//char *lr_transaction_name;

void reg_error()
{
    web_reg_save_param("ErrorMessage",
    "LB=`ErrMsg`",
    "RB=`",
    "Ord=1",
    "NotFound=WARNING",
    LAST);
	
	web_reg_find("Text=The server you are trying to access is either busy",
         "SaveCount=Busy_Count",
     LAST);   	
}

void check_error()
{
	if ((strlen(lr_eval_string("{ErrorMessage}")) != 0))
		{
			/*��������� ������*/
			
			//lr_output_message( lr_transaction_name );
			endCurrentTransaction(lr_eval_string("{ErrorMessage}"), LR_FAIL);
			lr_output_message( lr_eval_string("Error:{ErrorMessage}") );
			lr_fail_trans_with_error( lr_eval_string("Error:{ErrorMessage}") );
			
			/*�� ����� �����*/
			
			/*��� ����
			endTransaction(10, lr_transaction_name, lr_eval_string("{ErrorMessage}"), LR_FAIL);
			lr_output_message( lr_eval_string("Error:{ErrorMessage}") );
			lr_fail_trans_with_error( lr_eval_string("Error:{ErrorMessage}") );
			*/
			
			
			lr_save_int(1, "fail_check");
			lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_AUTO);
			// logout();
			// web_cache_cleanup();
			// web_cleanup_cookies();
			// login();
			
			
	}
	
	if (atoi(lr_eval_string("{Busy_Count}"))>0)
	{
		
		endCurrentTransaction(lr_eval_string("{ErrorMessage}"), LR_FAIL);
		
		lr_fail_trans_with_error(lr_eval_string("{Host}: The server you are trying to access is either busy"));		
		
		startTransaction("Server busy");
		 logout();
			web_cache_cleanup();
			web_cleanup_cookies();
		//sleep(60000);
		 //login();	 
		 endTransaction(10, "Server busy","Server busy", LR_AUTO); 
	 lr_exit(LR_EXIT_VUSER, LR_FAIL);	
	//lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_AUTO);
	}
} 


#endif