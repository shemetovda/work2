//--генератор ИНН ЮЛ
char * inn_ul_generator(){
    
    int iter,rand_num=0,rand_num_mem,sum,n10;
    char rand_num_char[9];
    char* inn_inn_ul = (char *) malloc(sizeof(char)*10);
    sprintf(rand_num_char, "%d%d%d", rand()%10+10, rand()%8990+1000, rand()%890+100);
    rand_num=atoi(rand_num_char);
    rand_num_mem=rand_num;
    sum=(rand_num%10)*8;rand_num=rand_num/10;
    sum+=(rand_num%10)*6;rand_num=rand_num/10;
    sum+=(rand_num%10)*4;rand_num=rand_num/10;
    sum+=(rand_num%10)*9;rand_num=rand_num/10;
    sum+=(rand_num%10)*5;rand_num=rand_num/10;
    sum+=(rand_num%10)*3;rand_num=rand_num/10;
    sum+=(rand_num%10)*10;rand_num=rand_num/10;
    sum+=(rand_num%10)*4;rand_num=rand_num/10;
    sum+=(rand_num%10)*2;rand_num=rand_num/10;
    n10=(sum%11)%10;
    sprintf(inn_inn_ul, "%d%d", rand_num_mem, n10);
    return inn_inn_ul;    
}
//--генератор ИНН ЮЛ