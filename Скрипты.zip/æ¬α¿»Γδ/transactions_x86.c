#ifndef _TRANSACTIONS_C
#define _TRANSACTIONS_C

#include "\\hpm31-13.ca.sbrf.ru\main_pools\commons_x86.h"

double 	time_elapsed = 0,
		duration = 0,
		waste = 0;
char Transaction_Name[100] = "error_out_transaction";
merc_timer_handle_t timer;

void start_waste()
{
	timer = lr_start_timer();
}

void end_waste()
{
	time_elapsed = lr_end_timer(timer);
	waste += time_elapsed;
	timer = 0;
}

void think_time(int i)
{
	lr_think_time(i);
}

//**************** Start Transaction *****************/
void startTransaction(char *name)
{
	waste=0;
	strcpy(Transaction_Name,name);
	lr_start_transaction(name);
}

//**************** End Transaction *****************/
void endTransactionNoSla(char *name, char *message, int status) 
{
	char d[20]=""; //temp for duration
	char transaction[100];
	int i=0;
	
	if(strcmp(name,"error_out_transaction") == 0){
		return;
	}
	
	duration=lr_get_transaction_duration(name)-lr_get_transaction_wasted_time(name)-lr_get_transaction_think_time(name)-waste;
	//replace ',' with '.'
	sprintf(d,"%lf",duration);
    for(i=0; d[i]; i++)
        if (d[i] == ',')
            d[i] = '.';   
	lr_save_string(d,"Duration");
	
// not sure if needed
//	if (duration>16900){	
//		name=lr_eval_string("error_out_transaction");
//	}	

	
	if (status==LR_AUTO){
		status = lr_get_transaction_status(name);
	}
	lr_save_int(status,"status_transaction");	
	
	lr_end_transaction(name, status);  

	lr_save_string(name,"TransactionName"); // transfer to temp to process
	strcpy(transaction,lr_eval_string("{TransactionName}"));
	//replace whitespaces
    for(i=0; transaction[i]; i++)
        if (transaction[i] == ' ')
            transaction[i] = '_';   
	
	lr_continue_on_error(LR_ON_ERROR_CONTINUE);
	
	//encode UTF-8
	lr_convert_string_encoding("CRMK",LR_ENC_SYSTEM_LOCALE,LR_ENC_UTF8 , "Module");
	lr_convert_string_encoding(transaction, LR_ENC_SYSTEM_LOCALE,LR_ENC_UTF8 , "TransactionName");
	lr_save_string(lr_eval_string("{Module}"),"Module");
	lr_save_string(lr_eval_string("{TransactionName}"),"TransactionName");
	
	sendMetric(); // parameters are transferred through global space(LR parameters)
	
	// set default transaction
	strcpy(Transaction_Name,"error_out_transaction");

	lr_continue_on_error(LR_ON_ERROR_NO_OPTIONS);
}

void endTransaction(int sla, char *name, char *message, int status){ //sla - obsolete 
	endTransactionNoSla(name, message, status);
}

void endCurrentTransaction(char *message, int status){
	char curTransaction[100]; // copy to temporary buffer for safety
	strcpy(curTransaction,Transaction_Name);
	endTransactionNoSla(curTransaction, message, status);
}

// parameters are transferred through global space
void sendMetric(){ 
	lr_start_transaction("Grafana");
	
	//web_set_timeout("RECEIVE","5");
	//web_save_timestamp_param("TimeStamp", LAST);
	web_custom_request("Grafana", 
		"Method=POST",
		"URL=http://tv-alm-12r2-031.ca.sbrf.ru:8286/write",
		//"Body=LRTransaction,Module={Module},TransactionName={TransactionName},Status={status_transaction} value={Duration} {TimeStamp}000000",
		"Body=LRTransaction,Module={Module},TransactionName={TransactionName},Status={status_transaction} value={Duration}",
		LAST );	
		
		
		/* ������� ����� ������� ������*/
		/*
			web_submit_data("sendToInflux", 
		"Action=http://sbt-oaar-344:9080/influxreport-0.17.0/sendToInflux", 
		"Method=POST", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=message", "Value=LRTransaction,Module={Module},TransactionName={TransactionName},Status={status_transaction} value={Duration}", ENDITEM, 
		LAST);
		*/
		
		
	lr_end_transaction("Grafana", LR_AUTO);  
	
	web_set_timeout("RECEIVE","300");
	//web_set_sockets_option("CLOSE_KEEPALIVE_CONNECTIONS", "1");
}

void checkSLA(
    int dThreshold, //The duration threshold, in seconds
    char *sTranName,     //The name of the transaction
    char *message    //Some identifier that's useful to your context
) {
	
    double dTranDuration; //The duration of the transaction
    int        iVUserId;            //The current vuser ID
 
    //Get transaction duration
    dTranDuration = lr_get_transaction_duration(sTranName);
 
    //If equal to or above threshold, format and report an error
    if(dTranDuration >= dThreshold) {
        lr_whoami(&iVUserId, NULL, NULL);
        lr_save_datetime("%d/%m/%y %H:%M:%S", DATE_NOW, "p_checkSLA_date_time");
 
        lr_error_message(
            "���������� SLA: %s; %s; %.2f; %s",
            sTranName,
            lr_eval_string("{p_checkSLA_date_time}"),
            dTranDuration,
            message);
    }	

}

#endif
