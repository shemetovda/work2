#ifndef _COMMONS_H
#define _COMMONS_H



//transactions.c
void start_waste();
void end_waste();
void think_time(int i);
void startTransaction(char *name);
void endTransactionNoSla(char *name, char *message, int status);
void endTransaction(int sla, char *name, char *message, int status); // obsolete
void endCurrentTransaction(char *message, int status);
void sendMetric();
void checkSLA();

//IO_field.c
void login();
void logout();
void loginCC();
void logoutCC();
void reg_error();
void reg_error_old();
void check_error();
void check_error_old();
int getcounter();
void inccounter();
void getdateforlogin();
void getdate();
void getelemfromstring(char *temp, char *name);
void createparamforfields();
void createparamforfieldsflag(int mainflag);
void getparamsfield(char *view,char *applet,char *field);

#include "\\hpm31-13.ca.sbrf.ru\main_pools\transactions.c"
#include "\\hpm31-13.ca.sbrf.ru\main_pools\IO_field.c"


#endif