select distinct cci.person_uid from cx_cont_info cci, s_contact sc where sc.cust_value_cd='�������' and cci.row_id=sc.row_id  
and rownum < 301
