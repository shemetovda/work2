create table shem1 as select cci.person_uid from cx_cont_info cci where /*cci.email is not null and*/ length(cci.person_uid)=18 and rownum < 16100001
create table shem2 as select cci.person_uid from cx_cont_info cci where /*cci.email is not null and*/ length(cci.person_uid)=18 and rownum < 21100001

select /*+ parallel (s 4) */ cci.person_uid from shem2 cci where cci.person_uid not in (select person_uid from shem1)

drop table shem1;
drop table shem2;
