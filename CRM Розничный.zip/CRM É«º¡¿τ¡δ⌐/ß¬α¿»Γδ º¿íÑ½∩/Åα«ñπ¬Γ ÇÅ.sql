select * from s_prod_int spi where spi.row_id='1-5Q228LE'
--1-OE39AXW
--1-5Q228LE
