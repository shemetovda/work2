select sc.u,sc.login from siebel.s_contact sc;
select * from siebel.s_asset;
select * from siebel.s_ps_credential;
