select /*+parallel(128)*/
  to_char(a.created, 'DD.MM.YYYY hh24') || ':00' as "Time",
  a.process_name,a.description/*,
  count(*)*/
   from siebel.cx_message_log a
  where a.process_name like '%TPIN%'
/*    and lower(a.description) like '%%'*/
    and a.created between
        to_date('28.07.2016 00:00:00', 'dd.mm.yyyy hh24:mi:ss') and
        to_date('28.07.2016 23:59:59', 'dd.mm.yyyy hh24:mi:ss')
  group by to_char(a.created, 'DD.MM.YYYY hh24') || ':00', process_name,a.description
  order by 1, 2;  
  
  
select  /*+parallel(128)*/
  to_char(a.created, 'DD.MM.YYYY hh24') || ':00' as "Time",
  a.process_name,a.description
  from siebel.cx_msg_log_urgt a
 where a.process_name like '%WZ05%'
  and a.created between
        to_date('02.08.2016 00:00:00', 'dd.mm.yyyy hh24:mi:ss') and
        to_date('02.08.2016 23:59:59', 'dd.mm.yyyy hh24:mi:ss')
  /*group by to_char(a.created, 'DD.MM.YYYY hh24') || ':00', process_name,a.description,a.xml_message*/
  order by 1, 2;  
