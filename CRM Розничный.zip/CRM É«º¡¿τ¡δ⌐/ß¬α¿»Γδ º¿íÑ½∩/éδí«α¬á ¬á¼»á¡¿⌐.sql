select * from s_camp_con scc where scc.src_id='1-OE39BB9'
