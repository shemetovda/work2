select 'UPDATE V_NPS_DATA SET CRM_MEMBER_ID = ''' || NPS_DATA.ROW_ID || 
       ''', CRM_CAMPAIGN_ID = ''' || NPS_DATA.SRC_ID || 
       ''', CRM_CHANNEL_ID = ''' || CM_TREAT.MEDIA_TYPE_CD || 
       ''', CRM_WAVE_LAUNCH_DT = CAST(''' || TO_CHAR(CM_WAVE.LAUNCHED_TS, 'DD.MM.YYYY') || 
       ''' AS DATE FORMAT ''DD.MM.YYYY''), EVENT_DATE = CAST(''' || TO_CHAR(CM_WAVE.LAUNCHED_TS, 'DD.MM.YYYY') || 
       ''' AS DATE FORMAT ''DD.MM.YYYY''), CRM_ALERT_MEMBER_ID = ''' || NPS_DATA.CM_ALERT_ID || 
       ''', CRM_ALERT_CAMPAIGN_ID = ''' || CM_ALERT.SRC_ID || 
       ''', CRM_ALERT_CHANNEL_ID = ''' || CM_ALERT_TREAT.MEDIA_TYPE_CD ||
       ''', CRM_ALERT_MEMBER_STATUS = ''' || CM_ALERT.STAT_CD || 
       ''', CRM_ALERT_MEMBER_STATUS_DET = ''' || CM_ALERT.X_DETAIL_RESULT || 
       ''', CRM_ALERT_APPL_NUM = ''' || CM_ALERT_APPEAL.APP_NUM || 
       ''', CRM_NPS_REPLY1 = ''' || reply12.q1 || 
       ''', CRM_NPS_REPLY2 = ''' || reply12.q2 || 
       ''' WHERE EVENT_ID = ''' || NPS_DATA.EVENT_ID || ''';'
  FROM 
       SIEBEL.S_DMND_CRTN_PRG CM_TREAT, -- ��������� ��� ��
       SIEBEL.S_CAMP_LD_WAVE CM_WAVE, -- ����� ��� ��
       SIEBEL.S_CAMP_CON CM_ALERT, -- �� �����
       SIEBEL.S_DMND_CRTN_PRG CM_ALERT_TREAT, -- ��������� ��� �� �����
       SIEBEL.S_CAMP_LD_WAVE CM_ALERT_WAVE, -- ����� ��� �� �����
       SIEBEL.S_EVT_ACT_X CM_ALERT_ACT,   -- ���������� �� ������
       SIEBEL.CX_APPEAL CM_ALERT_APPEAL,   -- ��������� �� ������
       (
       select par_row_id,
              max(decode(question_num, 1, answer, null)) q1,
              max(decode(question_num, 2, answer, null)) q2,
              max(LAST_UPD) LAST_UPD
         from SIEBEL.cx_nps_data_qa
       group by par_row_id
       ) reply12, -- ������ �� ������ 2 �������
       (SELECT
        LAST_NPS.event_id,
        LAST_NPS.last_upd,
        JOIN_NPS.ROW_ID,
        JOIN_NPS.CM_ALERT_ID, 
        JOIN_NPS.WAVE_ID, 
        JOIN_NPS.DCP_ID, 
        JOIN_NPS.SRC_ID, 
        JOIN_NPS.CM_ALERT_DCP_ID, 
        JOIN_NPS.CM_ALERT_WAVE_ID
        from 
        (select event_id, max(last_upd) as last_upd, lastCM from (
                       select 
                                 row_id,
                                 first_value(row_id) over (partition by event_id order by last_upd desc) as lastCM,
                                 event_id,
                                 last_upd
                       from SIEBEL.cx_nps_data where (last_upd > sysdate - 20) and (src_id='1-OE6VZQ8'))--id �������� 
                       group by event_id, lastCM) LAST_NPS,
        SIEBEL.CX_NPS_DATA JOIN_NPS                
        where 
        LAST_NPS.LASTCM = JOIN_NPS.ROW_ID) NPS_DATA
WHERE NPS_DATA.DCP_ID = CM_TREAT.ROW_ID
   AND NPS_DATA.WAVE_ID = CM_WAVE.ROW_ID
   AND NPS_DATA.CM_ALERT_ID = CM_ALERT.ROW_ID(+)
   AND NPS_DATA.CM_ALERT_DCP_ID = CM_ALERT_TREAT.ROW_ID(+)
   AND NPS_DATA.CM_ALERT_WAVE_ID = CM_ALERT_WAVE.ROW_ID(+)
   AND NPS_DATA.ROW_ID = reply12.par_row_id(+)
   AND NPS_DATA.CM_ALERT_ID = CM_ALERT_ACT.SBRF_CAMP_CON_ID (+)
   AND CM_ALERT_ACT.PAR_ROW_ID = CM_ALERT_APPEAL.ACTION_ID (+);
