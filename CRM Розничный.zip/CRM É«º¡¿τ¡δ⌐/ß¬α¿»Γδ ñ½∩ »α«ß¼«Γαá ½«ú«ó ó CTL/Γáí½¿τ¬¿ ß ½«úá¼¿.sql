select * from ctl_system_log order by log_date desc;

select * from ctl_pri cp where cp.pri_id=632926;
select * from ctl_pr cpr where cpr.pr_id=1523;
select * from ctl_wf cw where cw.pr_id=1560;

select * from ctl_task_log ct where ct.pri_id=632926;

select * from CTL_PR_PARAMS cp where cp.pr_id=1560;
