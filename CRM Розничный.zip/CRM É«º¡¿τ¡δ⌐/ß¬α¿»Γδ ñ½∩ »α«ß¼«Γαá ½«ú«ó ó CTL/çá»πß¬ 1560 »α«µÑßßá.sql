begin 
  ctl_init_pr.init_any_pr_load_id(p_pr_id => 1560); 
end;
