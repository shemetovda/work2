shutdown immediate;
startup mount;
flashback database to restore point RP8;
alter database open resetlogs;
exit;
