. .profile.11204.crmrmir
sqlplus / as sysdba  @flashback.sql
