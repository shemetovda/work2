#!/usr/bin/bash

echo "-> stop siebsrvr"
. /crm/siebel/81/siebsrvr/siebenv.sh
stop_server all

