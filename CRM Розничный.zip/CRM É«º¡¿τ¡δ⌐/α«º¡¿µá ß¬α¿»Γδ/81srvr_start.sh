#!/usr/bin/bash

. /crm/siebel/81/siebsrvr/siebenv.sh
start_server all

 sleep 300
# nohup /export/home/siebel/scripts/crmnt1_rcvrMT.sh &

# extra
 nohup /export/home/siebel/scripts/crmnt1_rcvrMT_Urgent.sh &