# Агент мониторинга MQ

## Документация

* Агент мониторинга MQ: http://confluence.ca.sbrf.ru/pages/viewpage.action?pageId=92381753
