#!/usr/bin/perl

use strict;
use warnings;

my $database = 'CRMKx86';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=${database}&precision=s";

my $payload='';

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

#open my $checkls_proc, 'ls /crm/siebel/siebsrvr/enterprises/CRMC_LT/andarta8/log| wc -l |';

while (1) {

    open my $checkls_proc, 'ls /crm/siebel/siebsrvr/enterprises/CRMC_LT/andarta8/log| wc -l |' or die "can't fork ls! $!";

    my $checkls = <$checkls_proc>;
    $checkls=~ s/\n/ /g;
    $checkls=~ s/\s\s+//g;
    $checkls=~ s/\s//g;

	my $time = time();
	
    print "$checkls\n";
	
    if ($checkls =~ /(\d+)/)
    {    
        $payload = 'checkls,host=' . $host 
					 . ',type=perl'		
					 .' count=' . $1
					 . ' ' . $time . "\n";
            
        print "$payload\n";
    }

    send_with_curl($destination, $payload);
    $payload='';

    print "delay 5 seconds\n";

    sleep 5;
}


sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}