#!/usr/bin/perl

use strict;
use warnings;

my $database = 'CRMK';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=CRMK&precision=s";

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

open my $mem_proc, ' ps -efo pid:6,rss:20,comm |egrep  "siebmtshmw" |' or die "can't fork dlstat! $!";

while(1){
	my $payload = "";
	while (my $string = <$mem_proc>) {

		my @string = split ' ', $string;

		my $time = time();

		print "@string\n";

		my $data = 'siebmtshmw,machine=' . $host
					. ',type=perl'
					. ',pid=' . $string[0]
					. ' '
					. 'size=' . $string[1] . 'i'
					. ' ' . $time . "\n";

		$payload .=$data;
	}
	send_with_curl($destination, $payload);
	
	sleep 300;
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
