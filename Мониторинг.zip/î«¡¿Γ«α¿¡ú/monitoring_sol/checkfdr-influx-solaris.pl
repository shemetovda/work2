#!/usr/bin/perl

use strict;
use warnings;

my $database = 'CRMK';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=${database}&precision=s";

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

while(1) {

	open my $checkfdr_proc, "cd /siebel/siebel81/crm/siebsrvr/bin && /usr/bin/find *.fdr -cmin -5 |" or die "can't fork find! $!";;

	my $count = 0;
	while (my $checkfdr = <$checkfdr_proc>) {
			
		#print "-- " . $count . " -- " . $checkfdr;
		$count += 1;

	}
	
	my $time = time();

	my $payload = 'FDR_files,machine=' . $host
				. ',type=perl'
				. ' '
				. 'value=' . $count 
				. ' ' . $time . "\n";

	send_with_curl($destination, $payload);
		
	sleep 300;
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
