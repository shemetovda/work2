#!/usr/bin/perl

# Tested on m6 (Solaris 11.2)
# Tested on m7 (Solaris 11.3)

use strict;
use warnings;

my $database = 'CRMK';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=${database}&precision=s";

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

my $dg = $ARGV[0] or die "need to provide dg! $!";

open my $vxstat_proc, "/usr/sbin/vxstat -i 5 -S -g $dg -uk |" or die "can't fork vxstat! $!";

while (my $vxstat = <$vxstat_proc>) {
    next unless $vxstat =~ /^vol/;

    $vxstat =~ s/\n//g;
    $vxstat =~ s/\s+/ /g;
    $vxstat =~ s/(\d+)k/$1/g;
    my @vxstat = split ' ', $vxstat;

    # we don't need aggregate values:
    next if $vxstat[2] > 100_000_000;

    my $time = time();

    my $payload = 'vxstat,machine=' . $host
                . ',type=perl'
                . ',lv=' . $vxstat[1]
                . ' '

                . 'read_iops=' . $vxstat[2] . 'i'
                . ',write_iops=' . $vxstat[3] . 'i'
                . ',read_kb=' . $vxstat[4] . 'i'
                . ',write_kb=' . $vxstat[5] . 'i'
                . ',read_latency_ms=' . $vxstat[6]
                . ',write_latency_ms=' . $vxstat[7]
                . ' ' . $time . "\n";

    send_with_curl($destination, $payload);
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
