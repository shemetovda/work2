#!/usr/bin/perl

use strict;
use warnings;

#my $curl_path = '/usr/bin/curl';

my $destination = 'http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=CRMK&precision=s';
my $wget_path = '/usr/sfw/bin/wget';
my $payload = '';
my $host = `hostname`;
$host =~ s/\n//g;

while (1){

open my $tasks_proc, '. /siebel/siebel81/crm/siebsrvr/siebenv.sh;srvrmgr /g crmgwnt /e CRM_NT /u SADMIN /p ktybdtw /c \'list comp show CC_ALIAS,CP_NUM_RUN_TASKS,CP_MAX_TASKS,SV_NAME,CT_ALIAS,CP_DISP_RUN_STATE\' |' or die "can't fork mdb! $!";

while (my $tasks = <$tasks_proc>) {

    $tasks =~ s/\n/ /g;
    $tasks =~ s/\s\s+/_/g;
    $tasks =~ s/\s//g;

    #print "$tasks \n";

    if ($tasks =~ /(\w\S+)_(\d+)_(\d+)_(\w\S+)_(\w\S+)_(\w\S+)_/)
    {
        #print "$1 $2 $3 $4 $5\n";
        
        $payload = $payload . 'CRMK_TasksMonitor,host=' .$4. ',type=' .$5. ',component=' . $1 . ',status=' .$6. ' RunTask=' . $2 .',RunTaskPrecent='. $2/$3*100 ."\n";
            
        
    }
}

send_with_wget($destination, $payload);
#print "$payload\n";

$payload='';

sleep 300;
}


sub send_with_wget {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    # my $rc = system("$curl_path -i -XPOST '$destination' --data-binary '$payload'");
    my $rc = system("$wget_path -nv -O /dev/null --post-data '$payload' \"$destination\"");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}