#!/usr/bin/perl

use strict;
use warnings;

my $database = 'CRMK';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=CRMK&precision=s";

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

open my $dlstat_proc, '/usr/sbin/dlstat show-link 5 -T d -uR |' or die "can't fork dlstat! $!";

while (my $dlstat = <$dlstat_proc>) {
    next if $dlstat =~ /--/;                # sum for all ports
    next if $dlstat =~ /\d{2}:\d{2}:\d{2}/; # date (we'll take it from perl)
    next if $dlstat =~ /IPKTS/;             # headers

    $dlstat =~ s/\n//g;
    $dlstat =~ s/\s+/ /g;
    my @dlstat = split ' ', $dlstat;

    # we don't need aggregate values:
    next if $dlstat[2] > 100_000_000;

    my $time = time();

    print "@dlstat\n";

    # for (my $i = 0; $i<$#dlstat; ++$i) {
    #     print "$i => $dlstat[$i]\n";
    # }

    my $payload = 'dlstat,machine=' . $host
                . ',type=perl'
                . ',link=' . $dlstat[0]
                . ' '

                . 'ipkts=' . $dlstat[1] . 'i'
                . ',rbytes=' . $dlstat[2] . 'i'
                . ',opkts=' . $dlstat[3] . 'i'
                . ',obytes=' . $dlstat[4] . 'i'
                . ' ' . $time . "\n";

    # print "$payload";
    send_with_curl($destination, $payload);
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("$curl_path -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
