#!/usr/bin/perl

use strict;
use warnings;

my $database = 'CRMK';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=CRMK&precision=s";

my $curl_path = '/usr/bin/curl';
my $payload = '';
my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

while (1) {

open my $memstat_proc, 'echo ::memstat | mdb -k |' or die "can't fork mdb! $!";

while (my $memstat = <$memstat_proc>) {
    #next unless $memstat =~ /^\s*\d/;
    

    $memstat =~ s/\n/ /g;
    $memstat =~ s/\s\s+/_/g;
    $memstat =~ s/\s//g;

    if ($memstat =~ /(\w\S+)_(\d+)_(\d\S+)_(\d+)/)
    {
        #print "$1 $2 $3 $4\n";
        
        $payload = $payload . 'MemStat,host=' . $host 
                    .',PageSummaryPages=' . $1 
                    .' value=' . $2 ."\n"
                    #. 'MemStat,host=' . $host 
                    #.',PageSummaryMB=' . $1 
                    #.' value=' . $3 ."\n"
                    . 'MemStat,host=' . $host 
                    . ',PageSummaryTot=' . $1 
                    .' value=' . $4 ."\n";
            
        #print $payload;
        
    }
}

send_with_curl($destination, $payload);
$payload='';

print "delay 300 seconds\n";

sleep 300;
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
