#!/bin/bash

# add something like this to crontab
# 0,5,10,15,20,25,30,35,40,45,50,55 * * * * /export/home/oracle/fedunov/influx/check-influx-solaris.sh

user=siebelro
SCRIPTS_HOME=/export/home/siebelro/admin/scripts
MAINT_FILE=$SCRIPTS_HOME/check_influx.disabled
LOGGER="logger -t check_influx.sh"

scripts[0]="memstat-influx-solaris11.pl"
scripts[1]="dlstat-influx-solaris11-si.pl"
scripts[2]="vmstat-influx-solaris11.pl"
scripts[3]="vxstat-influx-solaris.pl crmcnt_dg"
scripts[4]="checkfdr-influx-solaris.pl"
scripts[5]="checkmem-siebmtshmw-influx-solaris.pl"
#scripts[5]="vxstat-influx-solaris.pl xggdg"
#scripts[6]="ts-influx-solaris11.pl"
#scripts[7]="fra-influx-solaris11.pl"


if [ -f $MAINT_FILE ]; then
    echo "Script has been shutdown for maintenace mode (remove $MAINT_FILE) to re-enable automatic restarting."
#    echo "Script has been shutdown for maintenace mode (remove $MAINT_FILE) to re-enable automatic restarting." | $LOGGER
    exit 0;
fi

pushd $SCRIPTS_HOME >/dev/null

idx=${#scripts[*]}
for (( d=0 ; d<=idx-1 ; d=d+1 ))
do

    script=${scripts[d]};

    if ! pgrep -fu $user "$script" > /dev/null
    then
	echo "Script <$script> appears to be down. Attempting to start!"
#	echo "Script <$script> appears to be down. Attempting to start!" | $LOGGER
#	echo "> nohup ./$script < /dev/null > /dev/null 2>&1 &"
	nohup ./$script < /dev/null > /dev/null 2>&1 &
        rc=$?
        echo "Script <$script> started with RETVAL=$rc"
#        echo "Script <$script> started with RETVAL=$rc" | $LOGGER
    else
        echo "Script <$script> is alive"
#        echo "Script <$script> is alive" | $LOGGER
    fi
done

popd > /dev/null
