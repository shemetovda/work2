#!/usr/bin/env perl

# Tested on rhel 6.4
# Tested on rhel 6.5

use strict;
use warnings;

my $database = 'CRMKx86';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=${database}&precision=s";

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;

my $df_path = q(/bin/df -k);

while (1) {
    my $payload = call_df();
    send_with_curl($destination, $payload);
    # print $payload . "\n";
    sleep(20);
}

sub call_df {
    my @result = `$df_path`;
    my $payload = '';

    for my $line (@result) {
        next unless $line =~ /^\s*(?:\/|tmpfs)/;

        my $time = time();

        if(my ($filesystem, $kbytes, $used, $free, $percent_used, $mounted_on) = $line
            =~ /^(.+?)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)%\s+(.+)/) {

            $payload = $payload
                . 'df,machine=' . $host
                . ",type=perl,filesystem=$filesystem,mounted_on=$mounted_on"
                . ' '

                . 'total_kb=' . $kbytes . 'i'
                . ',used_kb=' . $used . 'i'
                . ',free_kb=' . $free . 'i'
                . ',percent_used=' . $percent_used . 'i'
                . ' ' . $time . "\n";
        }
    }

    return $payload;
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
