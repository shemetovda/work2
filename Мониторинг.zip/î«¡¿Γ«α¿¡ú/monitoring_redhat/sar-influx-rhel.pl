#!/usr/bin/env perl

# Tested on rhel 6.4

use strict;
use warnings;

my $database = 'CRMKx86';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=${database}&precision=s";

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

open my $sar_proc, 'LC_TIME=POSIX /usr/bin/sar -n DEV 5 |' or die "can't fork sar! $!";

while (my $sar = <$sar_proc>) {
    next if $sar =~ /^$/;
    next if $sar =~ /^Linux/;
    next if $sar =~ /^Average/;
    next if $sar =~ /IFACE/;

    $sar =~ s/\n//g;
    $sar =~ s/\s+/ /g;
    $sar =~ s/,/./g;
    my @sar = split ' ', $sar;
    my $time = time();

    #for (my $i = 0; $i < $#sar + 1; ++$i) {
    #    print "$i => $sar[$i]\n";
    #}

    # With the DEV keyword, statistics from the network  devices  are  reported.
    # The following values are displayed:

    # IFACE
    #        Name of the network interface for which statistics are reported.

    # rxpck/s
    #        Total number of packets received per second.

    # txpck/s
    #        Total number of packets transmitted per second.

    # rxkB/s
    #        Total number of kilobytes received per second.

    # txkB/s
    #        Total number of kilobytes transmitted per second.

    # rxcmp/s
    #        Number of compressed packets received per second (for cslip etc.).

    # txcmp/s
    #        Number of compressed packets transmitted per second.

    # rxmcst/s
    #        Number of multicast packets received per second.

    my $payload = 'sar,machine=' . $host
                . ',type=perl'
                . ',iface=' . $sar[1]
                . ' '

                . 'rxpcks=' . $sar[2]
                . ',txpcks=' . $sar[3]
                . ',rxkbs=' . $sar[4]
                . ',txkbs=' . $sar[5]

                . ' ' . $time . "\n";

    # print "$payload";
    send_with_curl($destination, $payload);
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
