#!/bin/bash
killall perl
/home/siebelro/admin/scripts/check-influx.sh


