#!/usr/bin/env perl

# Tested on rhel 6.4

use strict;
use warnings;

my $database = 'CRMKx86';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=${database}&precision=s";

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

open my $sar_proc, 'LC_TIME=POSIX /usr/bin/sar -dp 5 |' or die "can't fork sar! $!";

while (my $sar = <$sar_proc>) {
    next if $sar =~ /^$/;
    next if $sar =~ /^Linux/;
    next if $sar =~ /^Average/;
    next if $sar =~ /DEV/;

    $sar =~ s/\n//g;
    $sar =~ s/\s+/ /g;
    $sar =~ s/,/./g;
    my @sar = split ' ', $sar;
    my $time = time();

    # for (my $i = 0; $i < $#sar + 1; ++$i) {
    #    print "$i => $sar[$i]\n";
    # }

    # tps
    #        Indicate the number of transfers per second that were issued to the
    #        device.  Multiple logical requests can be combined  into  a  single
    #        I/O request to the device. A transfer is of indeterminate size.

    # rd_sec/s
    #        Number of sectors read from the device. The size of a sector is 512
    #        bytes.

    # wr_sec/s
    #        Number of sectors written to the device. The size of  a  sector  is
    #        512 bytes.

    # avgrq-sz
    #        The  average  size (in sectors) of the requests that were issued to
    #        the device.

    # avgqu-sz
    #        The average queue length of the requests that were  issued  to  the
    #        device.

    # await
    #        The  average  time (in milliseconds) for I/O requests issued to the
    #        device to be served. This includes the time spent by  the  requests
    #        in queue and the time spent servicing them.

    # svctm
    #        The  average  service  time (in milliseconds) for I/O requests that
    #        were issued to the device. Warning! Do not  trust  this  field  any
    #        more. This field will be removed in a future sysstat version.

    # %util
    #        Percentage of elapsed time during which I/O requests were issued to
    #        the device (bandwidth utilization for the device).  Device  satura‐
    #        tion occurs when this value is close to 100%.

    # 0 => 14:12:28
    # (+) 1 => DEV
    # (+) 2 => tps
    # (+) 3 => rd_sec/s
    # (+) 4 => wr_sec/s
    # 5 => avgrq-sz
    # (+) 6 => avgqu-sz
    # (+) 7 => await
    # 8 => svctm
    # (+) 9 => %util

    my $payload = 'sar-disk,machine=' . $host
                . ',type=perl'
                . ',device=' . $sar[1]
                . ' '

                . 'tps=' . $sar[2]
                . ',read_bytes=' . ($sar[3] * 512)
                . ',write_bytes=' . ($sar[4] * 512)
                . ',avgqu-sz=' . $sar[6]
                . ',await_ms=' . $sar[7]
                . ',util_percent=' . $sar[9]

                . ' ' . $time . "\n";

    #print "$payload";
    send_with_curl($destination, $payload);
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
