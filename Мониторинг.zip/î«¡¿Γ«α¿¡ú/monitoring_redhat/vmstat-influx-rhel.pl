#!/usr/bin/env perl

# Tested on rhel 6.4

use strict;
use warnings;

my $database = 'CRMKx86';
my $username = 'test';
my $password = 'test';
my $destination = "http://sbt-oabs-406.ca.sbrf.ru:8086/write?db=${database}&precision=s";

my $curl_path = '/usr/bin/curl';

my $host = `hostname`;
$host =~ s/\n//g;
$host = lc($host);

my $totalmem = `cat /proc/meminfo | grep MemTotal`;
$totalmem =~ s/\D//g;

open my $vmstat_proc, '/usr/bin/vmstat -SK 5 |' or die "can't fork vmstat! $!";

while (my $vmstat = <$vmstat_proc>) {
    next unless $vmstat =~ /^\s*\d/;

    $vmstat =~ s/\n//g;
    $vmstat =~ s/\s+/ /g;
    my @vmstat = split ' ', $vmstat;
    my $time = time();

    #for (my $i = 0; $i < $#vmstat + 1; ++$i) {
    #    print "$i => $vmstat[$i]\n";
    #}

    my $payload = 'vmstat,machine=' . $host
                . ',type=perl '

                . 'load=' . (100 - $vmstat[14]) #. 'i'
                . ',sys=' . $vmstat[13] #. 'i'
                . ',usr=' . $vmstat[12] #. 'i'
                . ',wio=' . $vmstat[15] #. 'i'

                . ',procs_r=' . $vmstat[0] #. 'i' # The number of runnable processes (running or waiting for run time).
                . ',procs_b=' . $vmstat[1] #. 'i' # The number of processes in uninterruptible sleep.

                . ',usedkb=' . ($totalmem - $vmstat[3] - $vmstat[4] - $vmstat[5]) #. 'i'
                . ',buffkb=' . $vmstat[4] #. 'i'
                . ',cachekb=' . $vmstat[5] #. 'i'
                . ',usedperc=' . (($totalmem - $vmstat[3] - $vmstat[4] - $vmstat[5]) / $totalmem * 100);

                #. ' ' . $time . "\n";

    #print "$payload";
    send_with_curl($destination, $payload);
}

sub send_with_curl {
    my $destination = shift or die "no destination";
    my $payload = shift or die "no payload";

    print STDERR "Sending $payload...\n";
    my $rc = system("${curl_path} -i -u ${username}:${password} -XPOST '${destination}' --data-binary '${payload}'");

    if ($rc != 0) {
        print STDERR "Curl returned $rc, exiting...\n";
        exit $rc;
    }
}
