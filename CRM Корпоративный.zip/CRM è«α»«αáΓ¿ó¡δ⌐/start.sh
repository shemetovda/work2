#!/bin/bash
$ ./startup.sh
sleep 10s
$ ./shutdown.sh
