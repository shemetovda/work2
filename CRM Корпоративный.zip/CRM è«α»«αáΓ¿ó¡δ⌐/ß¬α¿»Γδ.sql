--INT_1011_WATERFALL 
SELECT /*+parallel(128)*/ org.row_id 
FROM siebel.S_ACCNT_POSTN ap, siebel.S_USER u, S_POSTN p, s_org_ext org, siebel.S_EMP_PER ep 
WHERE p.row_id = ap.position_id  
AND u.row_id = p.pr_emp_id  
and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID 
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
and org.X_SBRF_CLIENT_FLG='Y'  
and org.CLIENT_FLG='Y' 
and org.OU_TYPE_CD='Юр. лицо'  
and org.INT_ORG_FLG='N'  
and org.CUST_STAT_CD = 'Активна' 
AND ROWNUM < 3001 

--INT_1031_CIB
select t1.row_id as OpptyId,t3.X_ESA_ID as ContactESAId 
from siebel.S_OPTY t1, siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t1.PR_DEPT_OU_ID=t2.PARTY_ID and t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.row_id=t1.PR_DEPT_OU_ID and t4.X_SBRF_CLIENT_FLG='Y' -- Организации банка 
and ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 

--INT_1032_CIB
select t4.row_id as AccountId,t3.X_ESA_ID as ContactESAId 
from siebel.S_OPTY t1, siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t1.PR_DEPT_OU_ID=t2.PARTY_ID and t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.row_id=t1.PR_DEPT_OU_ID and t4.X_SBRF_CLIENT_FLG='Y' -- Организации банка 
and ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
group by t4.row_id,t3.X_ESA_ID 

--INT_1033_CIB
//select /*+parallel(t2,512)*/ t1.row_id 
//from siebel.S_ORG_EXT t1, siebel.S_ACCNT_POSTN t2 
//where t1.row_id=t2.OU_EXT_ID and t1.X_SBRF_CLIENT_FLG='Y' and t1.INT_ORG_FLG='N' and t1.OU_TYPE_CD='Юр. лицо' and t1.CUST_STAT_CD='Активна' 
//group by t1.row_id 
//having count(*)>0 and count(*)<50 

--INT_1035_CIB
select t3.X_ESA_ID as ContactESAId 
from siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.X_SBRF_CLIENT_FLG='Y' and t4.row_id=t2.PARTY_ID -- Организации банка 
group by t3.X_ESA_ID 
having count(*)>0 and count(*)<50 

PositionId пул рандомных id басов. Вытаскивал вручную через пользователей. Тег нужен для авторизации в системе 
select p.row_id as PositionId 
from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 

--INT_1036-01_CIB
select t1.row_id as OpptyId,t3.X_ESA_ID as ContactESAId 
from siebel.S_OPTY t1, siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t1.PR_DEPT_OU_ID=t2.PARTY_ID and t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1031%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.row_id=t1.PR_DEPT_OU_ID and t4.X_SBRF_CLIENT_FLG='Y' -- Организации банка 
and ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
and t1.row_id in ( 
select t5.PAR_ROW_ID 
from siebel.S_OPTY_XM t5 
where t5.TYPE='EFS Roadmap') 

--INT_1038-01_CIB
select t1.row_id as OpptyId,t3.X_ESA_ID as ContactESAId 
from siebel.S_OPTY t1, siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t1.PR_DEPT_OU_ID=t2.PARTY_ID and t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.row_id=t1.PR_DEPT_OU_ID and t4.X_SBRF_CLIENT_FLG='Y' -- Организации банка 
and ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
and t1.row_id in (select t5.PAR_ROW_ID 
from siebel.CX_OPTY_LOG_XM t5) -- Проверка на логи изменения 

--INT_1039_CIB
PositionId пул рандомных id басов. Вытаскивал вручную через пользователей. Тег нужен для авторизации в системе 
select p.row_id as PositionId 
from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 

select to_char(t1.END_DATE+2,'yyyy-mm-dd') as EndDate,to_char(t1.START_DATE-2,'yyyy-mm-dd') as BeginDate 
from siebel.CX_CAMPAIGN t1 

--INT_1042_CIB
//select /*+parallel(t1,16)*/ t1.PR_HELD_POSTN_ID as EmployeePositionId 
//from siebel.S_CONTACT t1,siebel.S_CONTACT_XM t2, siebel.S_EMP_PER t3  
//where t1.row_id=t2.PAR_ROW_ID and t1.EMP_FLG='Y' and t2.TYPE='User System' and t2.NAME='CRM Корпоративный' and t3.EMP_STAT_CD<>'Terminated' and t3.row_id=t1.row_id 

--INT_1043_CIB

--INT_1083_WATERFALL
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
and b.ATTrib_07='Нерезидент, работает в РФ' and a.CUST_STAT_CD = 'Активна' 

select /*+parallel(lp,32)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	 

--INT_1084_WATERFALL
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
and b.ATTrib_07='Нерезидент, работает в РФ' and a.CUST_STAT_CD = 'Активна' 

select /*+parallel(lp,32)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	 

--INT_1085-01_WATERFALL

--INT_1086_WATERFALL
select us.LOGIN as Login 
from siebel.cx_lead lead, siebel.s_postn pos, siebel.s_user us 
where lead.pr_postn_id = pos.row_id and pos.pr_emp_id <> '0-1' and pos.pr_emp_id <> 'No Match Row Id' 
and pos.pr_emp_id = us.row_id 
and rownum <= 10000 
group by us.LOGIN 

--INT_1092_EasyDeal
//-- !Черновик! Запрос по сделкам в статусе Закрыта 
//	select  
//	u.login as Login 
//	, o.row_id as DealId 
//	,o.modification_num as DealStatus 
//	,oe.row_id Organization_Row_Id 
//	from siebel.S_OPTY o 
//	,siebel.S_ORG_EXT oe 
//	,siebel.s_postn p 
//	,siebel.s_user u  
//	where oe.par_row_id = o.PR_DEPT_OU_ID  
//	and oe.PR_POSTN_ID = p.PAR_ROW_ID  
//	and p.PR_EMP_ID = u.PAR_ROW_ID  
//	and oe.PR_POSTN_ID = p.PAR_ROW_ID  
//	and p.PR_EMP_ID = u.PAR_ROW_ID /*and o.X_OPTY_NAME LIKE 'OUI_UC_281%'*/ 
//	AND ROWNUM < 10001 
//	and oe.X_SBRF_CLIENT_FLG = 'Y' 
//	-- AND u.login like 'KM_P044%' 
//	-- AND u.login IN ('KM_P044_18661', 'KM_P044_18662', 'KM_P044_18663' 
//	-- , 'KM_P044_18664', 'KM_P044_18665', 'KM_P044_18666', 'KM_P044_18667' 
//	-- , 'KM_P044_18668', 'KM_P044_18669', 'KM_P044_18670') 
//	AND o.Opty_cd = 'КК' 
//	AND o.CLOSED_FLG='N' 
//	AND o.modification_num=6 

--INT_1147_WATERFALL
//select /*+parallel(oe,512)*/ distinct oe.row_id, b.login 
// from siebel.S_ORG_EXT oe, siebel.S_EVT_ACT ea, s_user b, siebel.S_EMP_PER ep, siebel.S_ACCNT_POSTN ap 
// where 1=1 
// and ea.owner_per_id = b.row_id 
// and ea.TARGET_OU_ID=oe.row_id  
// and ea.owner_per_id is not null 
// and oe.X_SBRF_CLIENT_FLG='Y' 
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N'  
// and oe.cust_stat_cd='Активна'  
// and ea.Evt_Stat_Cd in ('Запланирована','В работе') 
// and ea.TEMPLATE_FLG='N'  
// and b.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
// and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID 

--INT_1148_WATERFALL
//SELECT /*+parallel(128)*/ distinct u.LOGIN, org.row_id 
//FROM siebel.s_org_ext org, siebel.S_POSTN p, siebel.S_USER u, siebel.CX_LD_PROD_OFFR t, siebel.S_ACCNT_POSTN ap, siebel.S_EMP_PER ep 
//WHERE 1=1 
//and org.pr_postn_id = p.row_id 
//and org.row_id = ap.OU_EXT_ID  
//and org.pr_postn_id = ap.POSITION_ID 
//and u.row_id = ep.row_id  
//and ep.EMP_STAT_CD <> 'Terminated' 
//and p.pr_emp_id = u.row_id 
//and t.account_id = org.row_id 
//and t.product_id is not null 
//and rownum < 301 

--INT_494_EFSKMKB
//	select /*+parallel(ap,512)*/u.login 
//from siebel.S_ACCNT_POSTN ap join siebel.S_ORG_EXT oe on (oe.row_id=ap.OU_EXT_ID and oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо' and oe.INT_ORG_FLG='N'),siebel.S_PARTY p,siebel.S_POSTN pos,siebel.S_USER u 
//where ap.POSITION_ID=p.row_id and pos.row_id=p.row_id and u.PAR_ROW_ID=pos.PR_EMP_ID 
//group by u.login 

--INT_495_EFSKMKB
//	select DISTINCT t3.login, t1.OU_EXT_ID 
// from siebel.S_ACCNT_POSTN t1 
// left outer join siebel.s_postn t2 
// on t2.row_id = t1.POSITION_ID 
// left outer join siebel.S_USER t3 
// on t3.row_id = t2.PR_EMP_ID 
// where POSITION_ID in (select PR_HELD_POSTN_ID 
// from siebel.S_user t1 
// left outer join siebel.S_CONTACT t2 
// on t2.par_row_id = t1.row_id 
// ) 
// AND ROWNUM < 1001 

--INT_496_EFSKMKB
// select t3.login 
// from siebel.S_ACCNT_POSTN t1 
// left outer join siebel.s_postn t2 
// on t2.row_id = t1.POSITION_ID 
// left outer join siebel.S_USER t3 
// on t3.row_id = t2.PR_EMP_ID 
// where POSITION_ID in (select PR_HELD_POSTN_ID 
// from siebel.S_user t1 
// left outer join siebel.S_CONTACT t2 
// on t2.par_row_id = t1.row_id) 
// GROUP BY t3.login 
// having count(t3.login) >= 2 

--INT_497_EFSKMKB
// SELECT /*+parallel(128)*/ DISTINCT t3.login, t1.con_id 
// from siebel.S_POSTN_CON t1  
// left outer join siebel.s_postn t2  
// on t2.row_id = t1.postn_id  
// left outer join siebel.S_USER t3  
// on t3.row_id = t2.PR_EMP_ID  
// left outer join siebel.S_PARTY t4  
// on t3.row_id = t4.row_id  

--INT_501_EFSKMKB
//select a.EVT_STAT_CD, a.OWNER_PER_ID, b.login, count(*)  
//from siebel.S_EVT_ACT a, siebel.S_USER b 
//where a.owner_per_id=b.row_id 
// and a.EVT_STAT_CD='Р—Р°РїР»Р°РЅРёСЂРѕРІР°РЅР°' 
//group by a.EVT_STAT_CD, a.OWNER_PER_ID, b.login  
//having count(*) >30 and count(*) < 120; 

--INT_502_EFSKMKB
//select /*+parallel(512)*/ t2.login, t1.ACTIVITY_ID  
//from siebel.S_ACT_EMP t1, siebel.S_USER t2, siebel.S_CONTACT t3  
//where t2.row_id = t1.EMP_ID  
//and t3.par_row_id = t2.row_id  
//and t2.LOGIN not in ('SADMIN') 
//and rownum < 5001  

--INT_688_CIB
//select /*+parallel(512)*/ 
//distinct 
//ps.row_id PositionId 
//from siebel.S_OPTY o, 
//siebel.S_OPTY_POSTN op, 
//s_postn ps, 
//s_user u, 
//siebel.S_ORG_EXT oe, 
//siebel.S_ACCNT_POSTN ap, 
//siebel.S_EMP_PER ep 
//where 1=1 
//and o.row_id=op.OPTY_ID  
//and o.PR_POSTN_ID = ps.row_id  
//and u.row_id = ps.pr_emp_id 
//and oe.par_row_id = o.PR_DEPT_OU_ID 
//and ap.OU_EXT_ID=oe.row_id  
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.CLIENT_FLG='Y' 
//and oe.OU_TYPE_CD='Юр. лицо'  
//and oe.INT_ORG_FLG='N'  
//and oe.CUST_STAT_CD = 'Активна' 

--INT_690_CIB
//select /*+parallel(ap,512)*/ p.row_id,t.row_id,lov.val,t.created_by,ap.cvrg_role_cd,lov.DESC_TEXT 
//from siebel.s_evt_act t,  
//siebel.s_org_ext o, 
//siebel.S_USER u, 
//siebel.S_CONTACT t3, 
//S_POSTN p, 
//S_ACCNT_POSTN ap, 
//siebel.S_LST_OF_VAL lov,  
//siebel.S_EMP_PER ep 
//where t.target_ou_id = o.row_id 
//and u.row_id = t.OWNER_PER_ID 
//and t3.par_row_id = u.row_id  
//and u.row_id = p.pr_emp_id 
//and o.row_id = ap.OU_EXT_ID and o.pr_postn_id = ap.POSITION_ID 
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and lov.VAL=t.TODO_CD  
//and lov.DESC_TEXT='Bank' 
//and lov.val in ('Задача','Актуализация данных') 
//and lov.ACTIVE_FLG = 'Y'  
//AND lov.TYPE = 'TODO_TYPE' 
//and t.Evt_Stat_Cd in ('Запланирована','В работе') 
//and t.TEMPLATE_FLG='N'  
//and rownum < 2001 

--INT_691_CIB
//select /*+parallel(512)*/ 
//distinct 
//ps.row_id PositionId, 
//o.row_id 
//from siebel.S_OPTY o, 
//siebel.S_OPTY_POSTN op, 
//s_postn ps, 
//s_user u, 
//siebel.S_ORG_EXT oe, 
//siebel.S_ACCNT_POSTN ap, 
//siebel.S_EMP_PER ep 
//where 1=1 
//and o.row_id=op.OPTY_ID  
//and o.PR_POSTN_ID = ps.row_id  
//and u.row_id = ps.pr_emp_id 
//and oe.par_row_id = o.PR_DEPT_OU_ID 
//and ap.OU_EXT_ID=oe.row_id  
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and ps.x_pos_type_id is not null 
//and oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.CLIENT_FLG='Y' 
//and oe.OU_TYPE_CD='Юр. лицо'  
//and oe.INT_ORG_FLG='N'  
//and oe.CUST_STAT_CD = 'Активна' 
//and o.SECURE_FLG='N'  
//and op.role_cd='Главный КМ сделки' 
//and rownum < 2001 

--INT_698_EFSKMKB
select /*+parallel(512)*/ 
//distinct 
//ps.row_id PositionId 
//from siebel.S_OPTY o, 
//siebel.S_OPTY_POSTN op, 
//s_postn ps, 
//s_user u, 
//siebel.S_ORG_EXT oe, 
//siebel.S_ACCNT_POSTN ap, 
//siebel.S_EMP_PER ep 
//where 1=1 
//and o.row_id=op.OPTY_ID  
//and o.PR_POSTN_ID = ps.row_id  
//and u.row_id = ps.pr_emp_id 
//and oe.par_row_id = o.PR_DEPT_OU_ID 
//and ap.OU_EXT_ID=oe.row_id  
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.CLIENT_FLG='Y' 
//and oe.OU_TYPE_CD='Юр. лицо'  
//and oe.INT_ORG_FLG='N'  
//and oe.CUST_STAT_CD = 'Активна' 

--INT_707_CIB
//select /*+parallel(512)*/ b.row_id, orgx.SBRF_INN 
//from siebel.S_ACCNT_POSTN ap,siebel.S_ORG_EXT oe, siebel.S_ORG_EXT_X orgx, siebel.s_user c,siebel.s_postn b, siebel.S_EMP_PER ep 
//where oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.OU_TYPE_CD='Юр. лицо'  
//and oe.active_flg = 'Y' 
//and oe.x_sbrf_client_flg = 'Y' 
//and oe.cust_stat_cd in ('Закреплена') 
//and ap.cvrg_role_cd='Клиентский менеджер'  
//and ap.OU_EXT_ID=oe.row_id  
//and oe.ROW_ID = orgx.row_id  
//and b.PR_EMP_ID = c.row_id  
//and b.row_id = oe.PR_POSTN_ID 
//and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID 
//and c.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and b.row_id <> '0-5220' 

--INT_806_CIB
//select /*+parallel(c,512)*/c.pr_postn_id 
//from siebel.S_CONTACT c 
//where c.owner_login like'KM_%' 
//group by c.pr_postn_id; 

--INT_807_CIB
//	AccountID 
//	select /*+parallel(pr,512)*/oe.row_id 
//from siebel.S_ORG_EXT oe,siebel.S_PARTY_PER pr 
//where oe.INT_ORG_FLG='N' and oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо' and pr.PARTY_ID=oe.row_id 
//group by oe.row_id 
//	PositionId 
//select * 
//from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
//where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 


//select /*+parallel(oe,512)*/ap.POSITION_ID,oe.row_idze 
//from siebel.S_ORG_EXT oe,siebel.S_ACCNT_POSTN ap,siebel.S_USER u,siebel.S_POSTN p 
//where oe.INT_ORG_FLG='N' and oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо' and ap.OU_EXT_ID=oe.row_id and ap.cvrg_role_cd='Клиентский менеджер' and ap.POSITION_ID=p.row_id and u.PAR_ROW_ID=p.pr_emp_id and u.Login like 'BAS_P041_%' 

//Исправленный селект ,закоментил u.login и добавил ограничение по количеству записей 
//select Position_id,Account_Id,role from( 
//select ap.POSITION_ID,oe.row_id as Account_Id,ap.cvrg_role_cd as role 
//from siebel.S_ORG_EXT oe,siebel.S_ACCNT_POSTN ap,siebel.S_USER u,siebel.S_POSTN p,siebel.S_PARTY party 
//where oe.INT_ORG_FLG='N'  
//and oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.OU_TYPE_CD='Юр. лицо'  
//and ap.OU_EXT_ID=oe.row_id 
//and party.row_id=oe.row_id --связка с организациями 
//and oe.CUST_STAT_CD = 'Активна' 
//and party.PARTY_TYPE_CD<>'Suspect' 
//and party.PARTY_TYPE_CD='Organization' 
//and (ap.cvrg_role_cd='Клиентский менеджер' OR ap.cvrg_role_cd='Куратор ЦА')  
//and ap.POSITION_ID=p.row_id 
//and oe.PR_POSTN_ID = ap.POSITION_ID  
//and u.PAR_ROW_ID=p.pr_emp_id)  
//--and u.Login like 'BAS_P041_%' 
//where rownum <=260 

--INT_817_CIB
//select /*+parallel(128)*/ distinct p.row_id PositionId,t.TODO_CD ActionType,t.x_sbrf_send_outlook,o.row_id CRMId 
//from siebel.s_evt_act t,  
//siebel.s_org_ext o, 
//siebel.S_USER u, 
//siebel.S_CONTACT t3, 
//S_POSTN p 
//where t.target_ou_id = o.row_id 
//and u.row_id = t.OWNER_PER_ID 
//and t3.par_row_id = u.row_id  
//and u.row_id = p.pr_emp_id 
//and o.x_sbrf_client_flg = 'Y' 
//and o.INT_ORG_FLG='N' 
//and o.OU_TYPE_CD='Юр. лицо'  
//and o.CLIENT_FLG='Y' 
//and t.TEMPLATE_FLG='N' 
//and u.login like 'KM_P%' 
//and t.x_sbrf_send_outlook is not null 
//and o.CUST_STAT_CD = 'Активна' 

--INT_819_CIB
//PositionId пул рандомных id басов с задачами, где бас является главным. Вытаскивал вручную через пользователей. 
//select /*+parallel(ea,512)*/ ea.owner_postn_id 
//from siebel.S_EVT_ACT ea 
//where ea.todo_cd='Задача' and ea.TEMPLATE_FLG='N' and ea.OPTY_ID is null and ea.owner_postn_id is not null 

--INT_820_CIB
//select o.row_id,p.row_id 
//from siebel.s_evt_act t,  
//siebel.s_org_ext o, 
//siebel.S_USER u, 
//siebel.S_CONTACT t3, 
//S_POSTN p 
//where t.target_ou_id = o.row_id 
//and u.row_id = t.OWNER_PER_ID 
//and t3.par_row_id = u.row_id  
//and u.row_id = p.pr_emp_id 
//and o.x_sbrf_client_flg = 'Y' 
//and o.INT_ORG_FLG='N' 
//and o.OU_TYPE_CD='Юр. лицо'  
//and o.CLIENT_FLG='Y' 
//and t.TEMPLATE_FLG='N' 
//and u.login like 'KM_P%' 
//and t.TODO_CD='Задача' 
//and o.CUST_STAT_CD = 'Активна'; 

--INT_821_CIB
//PositionId пул рандомных id басов. Вытаскивал вручную через пользователей. 
//	select * 
//from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
//where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 
//OpptyId пул рандомных id сделок. Вытаскивал вручную 
//	select /*+parallel(ea,512)*/ ea.OPTY_ID 
//	from siebel.S_EVT_ACT ea 
//	where ea.todo_cd='Задача' and ea.TEMPLATE_FLG='N' and ea.OPTY_ID is not null and ea.owner_postn_id is not null 
//	group by ea.OPTY_ID 
//	having count(*)<100 

--INT_822_CIB
//PositionId пул рандомных id басов. Вытаскивал вручную через пользователей. 
//select * 
//from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
//where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 
//ContactCRMId список контактов, на которые ссылаюстся сделки. 
//	select /*+parallel(ea,512)*/ ac.CON_ID 
//from siebel.S_EVT_ACT ea,siebel.S_ACT_CONTACT ac 
//where ea.todo_cd='Задача' and ea.TEMPLATE_FLG='N' and ea.OPTY_ID is null and ac.ACTIVITY_ID=ea.row_id 
//group by ac.CON_ID 

--INT_851_EFSKMKB
//select /*+parallel(128)*/ DISTINCT c.login, org2.ATTRIB_46 
//from (select a.PR_POSTN_ID ownr, count(1) as cnt from siebel.S_ORG_EXT a group by a.PR_POSTN_ID HAVING COUNT(PR_POSTN_ID)>=300) sq1, 
//siebel.s_postn b, 
//siebel.s_user c, 
//s_org_ext org1, 
//s_org_ext_x org2, 
//siebel.S_EMP_PER ep 
//WHERE 1=1 
//and sq1.ownr = b.row_id  
//and b.PR_EMP_ID = c.row_id  
//and sq1.ownr = org1.PR_POSTN_ID 
//and org1.row_id = org2.row_id 
//and c.row_id = ep.row_id  
//and ep.EMP_STAT_CD <> 'Terminated' 
//and org2.ATTRIB_46 IS NOT NULL 
//and c.LOGIN not in ('SADMIN') 
//and rownum < 2001 

--INT_852_EFSKMKB
//SELECT /*+parallel(128)*/ u.LOGIN, org.row_id 
//FROM siebel.S_ACCNT_POSTN ap, siebel.S_USER u, S_POSTN p, s_org_ext org, siebel.S_EMP_PER ep 
//WHERE p.row_id = ap.position_id  
//AND u.row_id = p.pr_emp_id  
//and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID 
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//AND ROWNUM < 3001 

--INT_854_EFSKMKB
// Логины и ПП 
//select t3.login, t4.row_id 
// from siebel.CX_LEAD_POSTN t1 
// left outer join siebel.s_postn t2 on t2.row_id = t1.postn_id 
// left outer join siebel.S_USER t3 on t3.row_id = t2.PR_EMP_ID 
// left outer join siebel.cx_lead t4 on t4.row_id=t1.lead_id 
// WHERE ROWNUM < 3001 AND t3.login LIKE 'KM%' 

--INT_855_EFSKMKB
//--855 (ID контакта + логин пользователя у которого контакты) 
//SELECT /*+parallel(128)*/ t1.con_id, t3.login 
// from siebel.S_POSTN_CON t1  
// left outer join siebel.s_postn t2  
// on t2.row_id = t1.postn_id  
// left outer join siebel.S_USER t3  
// on t3.row_id = t2.PR_EMP_ID  
// left outer join siebel.S_PARTY t4  
// on t3.row_id = t4.row_id  
// WHERE t3.login like 'KM_P%' 
// AND ROWNUM < 3001 

--INT_857_EFSKMKB
//--857 (Позиция из администрирования позиций + сделка)  
//SELECT p.row_id AS position, l.row_id AS DEAL, t3.login 
//FROM S_OPTY l  
//left outer join s_POSTN p  
// ON l.PR_POSTN_ID = p.row_id  
//left outer join siebel.S_USER t3  
// on t3.row_id = p.PR_EMP_ID  
//WHERE t3.login LIKE '%KM_P%' 
//AND ROWNUM < 3001 

--INT_859_EFSKMKB
//	Запрос на получение сделок с экрана Администрирование сделок банка (OpptyId). 
//	select o.row_id,t1.ROLE_CD 
//	from siebel.s_opty o, siebel.S_OPTY_POSTN t1 
//	where o.row_id in 
//	(select ea.opty_id 
//	from SIEBEL.S_EVT_ACT ea 
//	) and o.SECURE_FLG = 'Y' and o.row_id=t1.OPTY_ID and t1.ROLE_CD is not null 

// Вытягивал данные этим запросом 25.04.2018 
//select /*+parallel(op,512)*/ o.row_id, count(1) as cnt 
// from SIEBEL.S_EVT_ACT ea, siebel.S_OPTY_POSTN op, siebel.S_LST_OF_VAL lov, siebel.s_opty o/*, siebel.S_STG ss*/ ,siebel.S_SALES_METHOD sm 
// where ea.OPTY_ID = op.OPTY_ID and ea.TODO_CD = lov.VAL and op.opty_id = o.row_id /*and ss.row_id = o.CURR_STG_ID*/ and o.SALES_METHOD_ID = sm.ROW_ID 
// and ea.TODO_CD <> 'Approval Action' and ea.TEMPLATE_FLG='N'  
// and lov.DESC_TEXT = 'Bank' and o.INACTIVE_FLG = 'N' 
// /*and ss.name = '01.Ввод данных'*/ and sm.name = 'Универсальный' 
// and o.pr_dept_ou_id <> 'IgnoreId' 
// and rownum < 25000 
// group by o.row_id 
// order by count(1) desc;  

--INT_862_CC
select ea.owner_login 
from siebel.S_EVT_ACT ea, siebel.s_user u, siebel.S_EMP_PER ep 
where ea.TODO_CD='Кампания продаж' 
and u.par_row_id = ep.par_row_id  
and ep.EMP_STAT_CD <> 'Terminated' 
and (ea.TEMPLATE_FLG='N' or ea.TEMPLATE_FLG is null)  
and ea.OPTY_ID is null and ea.evt_priority_cd<>'Закрыта'  
and ea.evt_priority_cd<>'Отменена' 
and u.login=ea.owner_login 
group by ea.owner_login

--INT_863_CC
 // используем пул 868 

--INT_864_CC
select u.login,count(*) 
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l, siebel.S_EMP_PER ep 
where lp.POSTN_ID=p.row_id  
and u.par_row_id = ep.par_row_id  
and ep.EMP_STAT_CD <> 'Terminated'  
and p.PR_EMP_ID=u.row_id  
and lp.LEAD_ID=l.row_id  
--and l.stage='00 Инициация' 
group by u.login

--INT_865_CC
//Логин не указан в докментации, поэтому берется любой пользователь 
//id организаций (AccountId) 
// select /*+parallel(ea,512)*/ oe.row_id 
// from siebel.CX_LD_PROD_OFFR lpo,siebel.S_ORG_EXT oe 
// where lpo.account_id=oe.row_id and oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо' and oe.INT_ORG_FLG='N' and  
// lpo.lead_id is null and (lpo.STATUS='Новое предложение' or lpo.STATUS='Подтвержден интерес к продукту' or lpo.status='Клиент проинформирован') 

--INT_866_CC
//SELECT /*+parallel(128)*/ distinct u.LOGIN, org.row_id 
//FROM siebel.s_org_ext org, siebel.S_POSTN p, siebel.S_USER u, siebel.CX_LD_PROD_OFFR t, siebel.S_ACCNT_POSTN ap, siebel.S_EMP_PER ep 
//WHERE 1=1 
//and org.pr_postn_id = p.row_id 
//and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID 
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and p.pr_emp_id = u.row_id 
//and t.account_id = org.row_id 
//and t.product_id is not null  

--INT_867_CC
//select p.row_id,p.PARTY_TYPE_CD,count(*) 
//from siebel.S_PARTY p,siebel.S_ORG_EXT oe,siebel.S_PARTY_PER pp,siebel.S_PARTY p1,siebel.S_CONTACT c 
//where p.row_id=oe.row_id  
//and oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.INT_ORG_FLG='N'  
//and oe.OU_TYPE_CD='Юр. лицо'  
//and pp.party_id=p.row_id  
//and pp.person_id=p1.row_id  
//and p1.row_id=c.row_id  
//and c.PRIV_FLG='N'  
//--and p.PARTY_TYPE_CD<>'Suspect' 
//--and p.PARTY_TYPE_CD='SB Account' 
//group by p.row_id,p.PARTY_TYPE_CD 

--INT_868_CC
//SELECT /*+parallel(128)*/ distinct u.LOGIN, org.row_id 
//FROM siebel.s_org_ext org, siebel.S_POSTN p, siebel.S_USER u, siebel.CX_LD_PROD_OFFR t, siebel.S_ACCNT_POSTN ap, siebel.S_EMP_PER ep 
//WHERE 1=1 
//and org.pr_postn_id = p.row_id 
//and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID 
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and p.pr_emp_id = u.row_id 
//and t.account_id = org.row_id 
//and t.product_id is not null  
//and org.X_SBRF_CLIENT_FLG='Y'  
//and org.CLIENT_FLG='Y' 
//and org.OU_TYPE_CD='Юр. лицо'  
//and org.INT_ORG_FLG='N'  
//and org.CUST_STAT_CD = 'Активна' 
//and p.x_km_6_flg = 'N' 
//and t.prod_group_id is not null 
//and ap.client_flg = 'N' 
//and org.created_by <> '0-1' 
//and org.pr_con_id = 'No Match Row Id' 

--INT_870_CC
//---Новый запрос 
// select  
// oe.row_id as AccountCRMId 
// , c.row_id as ContactId 
// from  
// siebel.S_ORG_EXT oe 
// , siebel.S_PARTY_PER po 
// , siebel.S_CONTACT c 
// , siebel.S_PARTY p 
// , siebel.S_ACCNT_POSTN ap 
// where 
// c.row_id=p.row_id 
// and oe.row_id = po.PARTY_ID  
// and c.ROW_ID = po.PERSON_ID 
// and oe.PR_POSTN_ID = ap.POSITION_ID  
// and ap.ou_ext_id = oe.par_row_id  
// and c.EMP_FLG= 'N'  
// and PRIV_FLG = 'N' 
// and oe.CUST_STAT_CD = 'Активна' 
// and oe.X_SBRF_CLIENT_FLG='Y'  
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N' 
// and C.X_SBRF_FI_VIP_FLAG = 'N'  
// and rownum<2500 

--INT_871_CC
//select 
// distinct p.row_id as AccountId 
//from  
// siebel.S_PARTY p 
// , siebel.S_ORG_EXT oe 
// , siebel.S_ACCNT_POSTN ap 
//where  
// p.row_id=oe.row_id 
// and oe.CUST_STAT_CD = 'Активна' 
// and oe.X_SBRF_CLIENT_FLG='Y'  
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N' 
// and p.PARTY_TYPE_CD='Organization' 
// and oe.PR_POSTN_ID = ap.POSITION_ID  
// and ap.ou_ext_id = oe.par_row_id 
// and rownum <=2000; 

--INT_872_CC
// select  
// oe.row_id as AccountCRMId 
// , c.row_id as ContactId 
// from  
// siebel.S_ORG_EXT oe 
// , siebel.S_PARTY_PER po 
// , siebel.S_CONTACT c 
// , siebel.S_PARTY p 
// , siebel.S_ACCNT_POSTN ap 
// where 
// c.row_id=p.row_id 
// and oe.row_id = po.PARTY_ID  
// and c.ROW_ID = po.PERSON_ID 
// and oe.PR_POSTN_ID = ap.POSITION_ID  
// and ap.ou_ext_id = oe.par_row_id  
// and c.EMP_FLG= 'N'  
// and PRIV_FLG = 'N' 
// and oe.CUST_STAT_CD = 'Активна' 
// and oe.X_SBRF_CLIENT_FLG='Y'  
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N' 
// and C.X_SBRF_FI_VIP_FLAG = 'N'  
// and rownum<2500 

--INT_874_CC
//SELECT /*+parallel(128)*/ distinct u.LOGIN, org.row_id AccountId,pi.row_id MDMId 
//FROM s_org_ext org, S_POSTN p, siebel.S_USER u, siebel.CX_LD_PROD_OFFR t,S_PROD_INT pi 
//WHERE 1=1 
//and org.pr_postn_id = p.row_id  
//and p.pr_emp_id = u.row_id 
//and t.account_id = org.row_id 
//and pi.row_id = t.product_id 
//and org.x_sbrf_client_flg = 'Y' 
//and org.INT_ORG_FLG='N' 
//and org.OU_TYPE_CD='Юр. лицо'  
//and org.CLIENT_FLG='Y' 
//and org.CUST_STAT_CD = 'Активна' 
//and t.source in ('АИСТ КМ ЦКР') 

--INT_876_CC
// используем пул 868 

--INT_877_CC
//Запрос на получение списка организаций(AccountId) и логинов(Login) 
//select /*+parallel(ac,512)*/ u.LOGIN as Login,org.ROW_ID as Account --DISTINCT cvrg_role_cd 
//from siebel.S_ACCNT_POSTN ac, siebel.S_ORG_EXT org,siebel.s_user u, siebel.S_POSTN po 
//where ac.OU_EXT_ID = org.row_id and po.PAR_ROW_ID=ac.POSITION_ID and po.PR_EMP_ID = u.PAR_ROW_ID and org.X_SBRF_CLIENT_FLG = 'Y' and org.OU_TYPE_CD='Юр. лицо' and org.INT_ORG_FLG='N' 
// and org.cust_stat_cd = 'Активна' and ac.cvrg_role_cd = 'Клиентский менеджер' 

--INT_878_CC
//Запрос на получение списка сотрудников	 
//select u.login 
//from siebel.s_user u, siebel.s_contact c 
//where u.par_row_id = c.par_row_id and c.emp_flg = 'Y' 

--INT_879_CC
//Запрос на получение списка организаций(AccountId) у которых есть обращения 
//select /*+parallel(sr,512)*/sr.CST_OU_ID as AccountId 
//from siebel.S_SRV_REQ sr, siebel.S_SRV_REQ1_FNXM re 
//where sr.TEMPLATE_FLG <> 'Y' 
// and sr.row_id = re.PAR_ROW_ID and re.TYPE='Org Account Address' and sr.SR_STAT_ID = 'Ввод данных' and sr.CST_OU_ID IS NOT NULL 

--INT_880_CC
//Запрос на получение организаций (AccountId) и контактов (ContactId) 
//select /*+parallel(po,512)*/oe.row_id, c.row_id 
//from siebel.S_ORG_EXT oe,siebel.S_PARTY_PER po, siebel.S_CONTACT c 
//where oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD = 'Юр. лицо' and oe.INT_ORG_FLG='N'  
//and C.X_SBRF_FI_VIP_FLAG = 'N' and c.EMP_FLG= 'N' and PRIV_FLG = 'N' 
//and oe.row_id = po.PARTY_ID and c.ROW_ID = po.PERSON_ID 

--INT_881_CC
select distinct p.row_id 
from siebel.S_PARTY p,siebel.S_ORG_EXT oe,siebel.S_PARTY_PER po, siebel.S_CONTACT c, siebel.S_ACCNT_POSTN ap  
where p.row_id=oe.row_id  
and oe.X_SBRF_CLIENT_FLG='Y'  
and oe.OU_TYPE_CD='Юр. лицо'  
and oe.INT_ORG_FLG='N'  
and C.X_SBRF_FI_VIP_FLAG = 'N'  
and c.EMP_FLG= 'N'  
and PRIV_FLG = 'N' 
and oe.row_id = po.PARTY_ID  
and c.ROW_ID = po.PERSON_ID 
and p.PARTY_TYPE_CD='Organization' 
and oe.PR_POSTN_ID = ap.POSITION_ID  
and ap.ou_ext_id = oe.par_row_id 
and p.row_id in(  
select drr.PAR_PARTY_ID  
from siebel.S_DYNHR_RPT_REL drr  
group by drr.PAR_PARTY_ID)

--INT_882_CC
// Запрос выполняет поиск ИНН организаций  
//select orgx.SBRF_INN 
//from siebel.S_ORG_EXT org, siebel.S_ORG_EXT_X orgx 
//where org.X_SBRF_CLIENT_FLG='Y' and org.OU_TYPE_CD='Юр. лицо' and org.INT_ORG_FLG='N' and org.CUST_STAT_CD <> 'Архив' and org.ROW_ID = orgx.row_id 

--INT_896_CIB
//--896 PositionID(Администрирование оргструктуры - Позиции - Администрирование позиций) + HoldingID 
//select distinct (p.row_id),o.row_id, u.login 
//from siebel.s_evt_act t,  
//siebel.s_org_ext o, 
//siebel.S_USER u, 
//siebel.S_CONTACT t3, 
//S_POSTN p 
//where t.target_ou_id = o.row_id 
//and u.row_id = t.OWNER_PER_ID 
//and t3.par_row_id = u.row_id  
//and u.row_id = p.pr_emp_id 
//and o.x_sbrf_client_flg = 'Y' 
//and o.INT_ORG_FLG='N' 
//and o.OU_TYPE_CD='•олдинг'  
//and o.CLIENT_FLG='Y' 
//and t.TEMPLATE_FLG='N' 
///*and u.login like '%@SB.SBRF.RU'*/ 
///*and t.TODO_CD='‡адача'*/ 
//and o.CUST_STAT_CD = 'Ђктивна' 
///*and p.row_id = '1-1M8JJ-18'*/ 
//and p.db_last_upd_src = 'ScriptingService_PreInvokeMethod' 

--INT_897_CIB
select /*+parallel(512)*/ 
//distinct 
//ps.row_id PositionId, 
//o.row_id OpptyId,  
//count(*)  
//from siebel.S_OPTY o, 
//siebel.S_OPTY_POSTN op, 
//s_postn ps, 
//s_user u, 
//siebel.S_ORG_EXT oe, 
//siebel.S_ACCNT_POSTN ap, 
//siebel.S_EMP_PER ep 
//where 1=1 
//and o.row_id=op.OPTY_ID  
//and o.PR_POSTN_ID = ps.row_id  
//and u.row_id = ps.pr_emp_id 
//and oe.par_row_id = o.PR_DEPT_OU_ID 
//and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID 
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and o.X_EKP_FLAG='N' and o.X_PA_FLG='N' 
//and o.pr_ou_addr_id <> 'No Match Row Id' 
//and ps.row_id not in ('0-5220') 
//group by ps.row_id,o.row_id 
//having count(*) between 4 and 50 

--INT_925_QR
//	select oe.row_id 
//	from siebel.S_ORG_EXT oe 
//	where oe.OU_TYPE_CD='Юр. лицо' and oe.INT_ORG_FLG='N' and oe.X_SBRF_CLIENT_FLG='Y' and oe.X_MDM_ID is null 

--INT_933_WATERFALL
// Запрос на получение Позиций и Сделок 
//select /*+parallel(oe,512)*/oe.PR_POSTN_ID, o.row_id 
//from siebel.S_OPTY o, siebel.S_ORG_EXT oe 
//where oe.par_row_id = o.PR_DEPT_OU_ID and o.SECURE_FLG ='N' 

--INT_934_QR
// Запрос на получение Позиций и Сделок 
//select /*+parallel(oe,512)*/oe.PR_POSTN_ID, o.row_id 
//from siebel.S_OPTY o, siebel.S_ORG_EXT oe 
//where oe.par_row_id = o.PR_DEPT_OU_ID and o.SECURE_FLG ='N' 

--INT_935_QR
// Запрос на получение Позиций и Сделок 
//select /*+parallel(oe,512)*/oe.PR_POSTN_ID, o.row_id 
//from siebel.S_OPTY o, siebel.S_ORG_EXT oe 
//where oe.par_row_id = o.PR_DEPT_OU_ID and o.SECURE_FLG ='N' 

--INT_938-01_QR, INT_938-02_QR
//Запрос на получение организаций (AccountId) и позиций (PositionId) 
//select /*+parallel(oe,512)*/distinct oe.row_id, oe.PR_POSTN_ID 
//from siebel.S_OPTY o, siebel.S_ORG_EXT oe  
//where oe.PAR_ROW_ID = o.PR_DEPT_OU_ID and o.SECURE_FLG ='N' 

--INT_977_QR
SELECT  
// T1.ROW_ID Id, --Id 
// T2.SR_ID Номер_ПСФ, --Номер ПСФ 
// T1.CREATED Time1, --Время создания ПСФ в системе 
// T3.CREATED Time2, --Время создания записи на экране «Комментарии» 
// (T3.CREATED - T1.CREATED)*24*60*60 Time3 --Интервал между Time1 и Time2 
//FROM 
// SIEBEL.S_SRV_REQ T1 
// JOIN SIEBEL.S_SRV_REQ_X T2 ON T1.ROW_ID = T2.ROW_ID 
// JOIN SIEBEL.CX_PSF_THM_LOG T3 ON T1.ROW_ID = T3.PAR_ROW_ID 
//WHERE 
// T3.THEME_SOURCE = 'ML' AND T2.BIG_DESC LIKE 'НТ_ПСФ_ML'; 
 
SELECT 'OUI_UC_977-01' as "TransactionName",count(*) as "transCount",avg((T3.CREATED - T1.CREATED)*24*60*60) as "percentile", '0' as "failCount" 
FROM SIEBEL.S_SRV_REQ T1 
JOIN SIEBEL.S_SRV_REQ_X T2 ON T1.ROW_ID = T2.ROW_ID 
JOIN SIEBEL.CX_PSF_THM_LOG T3 ON T1.ROW_ID = T3.PAR_ROW_ID 
WHERE T3.THEME_SOURCE = 'ML' AND T2.BIG_DESC LIKE 'НТ_ПСФ_ML' 
AND T1.CREATED BETWEEN to_date('%%startTime%%', 'yyyy-mm-dd hh24:mi:ss')-3/24 and to_date('%%endTime%%', 'yyyy-mm-dd hh24:mi:ss')-3/24; 


--INT_979_QR
//--OUI_UC_979 
//select /*+parallel(oe,512)*/ o.row_id 
//from siebel.S_OPTY o, siebel.s_stg stg 
//where o.sales_method_id = stg.sales_method_id 
//AND stg.NAME = 'Детальный анализ' 

--INT_980_QR
//select /*+parallel(po,512)*/ oe.row_id, oe.X_MDM_ID/*,cx.row_id,cx.status*/ 
//from siebel.S_ORG_EXT oe, siebel.cx_rating cx 
//where cx.object_id = oe.par_row_id and  
//oe.X_SBRF_CLIENT_FLG = 'Y' and  
//oe.INT_ORG_FLG = 'N' and  
//(cx.status = 'Актуальный' or cx.status='Подтверждение Рук.андеррайтера') 

--INT_981_QR
//	select /*+parallel(po,512)*/oe.row_id/*,cx.row_id,cx.status*/ 
//	from siebel.S_ORG_EXT oe, siebel.cx_rating cx 
//	where cx.object_id = oe.par_row_id and  
//	oe.X_SBRF_CLIENT_FLG = 'Y' and  
//	oe.INT_ORG_FLG = 'N' and  
//	(cx.status = 'Актуальный' or cx.status='Подтверждение Рук.андеррайтера') 

--INT_982_QR
// select /*+parallel(oe,512)*/ oe.row_id 
//from siebel.S_ORG_EXT oe 
//where oe.INT_ORG_FLG='N' and oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо'  
// 
//select g.row_id 
//from siebel.CX_GSZ g 
// 
//select cg.row_id 
//from siebel.CX_CNSLD_GROUP cg 

--INT_983_QR
select distinct oe.row_id, da.name  
from siebel.S_ORG_EXT oe,  
siebel.S_PARTY p, 
siebel.S_ACCNT_POSTN ap, 
siebel.S_ACCNT_AGR_CUT aac, 
siebel.S_DOC_AGREE da 
where oe.PR_POSTN_ID = ap.POSITION_ID and  
ap.ou_ext_id = oe.par_row_id and 
p.row_id=oe.row_id and 
oe.row_id = aac.accnt_id and 
aac.agree_id = da.row_id and 
oe.X_SBRF_CLIENT_FLG = 'Y' and  
oe.INT_ORG_FLG = 'N'  
and oe.CUST_STAT_CD = 'Активна' 
and oe.X_SBRF_CLIENT_FLG='Y'  
and oe.OU_TYPE_CD='Юр. лицо'  
and oe.INT_ORG_FLG='N' 
and oe.X_MDM_ID is not null 
and p.PARTY_TYPE_CD='Organization' 
and da.AGREE_CD = 'Service Level Agreement' 
and da.CONTRACT_FLG = 'N' 

--INT_994_WATERFALL
//	Метки 
//select row_id, name, category 
//from siebel.CX_TAGS 

//Список организаций 
//select row_id 
//from siebel.S_ORG_EXT  
//where OU_TYPE_CD='Юр. лицо' and INT_ORG_FLG='N' and cust_stat_cd <> 'Архив' and X_SBRF_CLIENT_FLG='Y'

--INT_996-01_WATERFALL, INT_996-02_WATERFALL
//select /*+parallel(512)*/ 
//distinct 
//ps.row_id, 
//oe.row_id  
//from siebel.S_OPTY o, 
//siebel.S_OPTY_POSTN op, 
//s_postn ps, 
//s_user u, 
//siebel.S_ORG_EXT oe, 
//siebel.S_ACCNT_POSTN ap, 
//siebel.S_EMP_PER ep 
//where 1=1 
//and o.row_id=op.OPTY_ID  
//and o.PR_POSTN_ID = ps.row_id  
//and u.row_id = ps.pr_emp_id 
//and oe.par_row_id = o.PR_DEPT_OU_ID 
//and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID 
//and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated' 
//and oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.CLIENT_FLG='Y' 
//and oe.OU_TYPE_CD='Юр. лицо'  
//and oe.INT_ORG_FLG='N'  
//and oe.CUST_STAT_CD = 'Активна'  
//and ps.row_id not in ('0-5220') 

--OUI_UC_1010-01
//select u.login  
//from siebel.S_CONTACT c, siebel.s_user u,siebel.S_EMP_PER ep 
//where c.par_row_id = u.par_row_id and c.EMP_FLG = 'Y' and ep.par_row_id = u.par_row_id and ep.EMP_STAT_CD <> 'Terminated'; 

--OUI_UC_1010-02
//select /*+parallel(ea,512)*/ea.row_id, u.login--ea.row_id,ea.NAME 
//from siebel.S_EVT_ACT ea, siebel.s_user u 
//where ea.OWNER_PER_ID = u.par_row_id and (ea.TEMPLATE_FLG='N' or ea.TEMPLATE_FLG is null) and ea.OPTY_ID is null  
//and ea.NAME LIKE 'UC1010_%' and u.login <>'0001_PANCHENKOAV@PVB.SBRF.RU'; 

--OUI_UC_1011
SELECT /*+parallel(t1,512)*/ t1.row_id 
FROM siebel.S_ORG_EXT t1 
WHERE t1.CUST_STAT_CD = 'Активна' 
AND t1.X_SBRF_CLIENT_FLG = 'Y' and t1.INT_ORG_FLG = 'N' 

--OUI_UC_1013
select /*+parallel(lp,512)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID 

выводит список id организаций 
SELECT /*+parallel(t1,512)*/ t1.row_id 
FROM siebel.S_ORG_EXT t1 
WHERE t1.CUST_STAT_CD = 'Активна' 
AND t1.X_SBRF_CLIENT_FLG = 'Y' and t1.INT_ORG_FLG = 'N' 
AND t1.OU_TYPE_CD = 'Юр. лицо' OR t1.OU_TYPE_CD = 'ИП' OR t1.OU_TYPE_CD = 'Филиал' OR t1.OU_TYPE_CD ='Холдинг' 

--OUI_UC_1022
//--OUI_UC_1022 
//select /*+parallel(oe,512)*/ u.login, o.row_id 
//from siebel.S_OPTY o, siebel.S_ORG_EXT oe,siebel.s_postn p, siebel.s_user u  
//where oe.par_row_id = o.PR_DEPT_OU_ID and oe.PR_POSTN_ID = p.PAR_ROW_ID and p.PR_EMP_ID = u.PAR_ROW_ID  
//and oe.PR_POSTN_ID = p.PAR_ROW_ID and p.PR_EMP_ID = u.PAR_ROW_ID /*and o.X_OPTY_NAME LIKE 'OUI_UC_281%'*/ 
//AND ROWNUM < 10001 
//AND u.login IN ('KM_P044_18661', 'KM_P044_18662', 'KM_P044_18663', 'KM_P044_18664', 'KM_P044_18665', 'KM_P044_18666', 'KM_P044_18667', 'KM_P044_18668', 'KM_P044_18669', 'KM_P044_18670') 
//AND o.Opty_cd = 'КК' 


//SELECT 
// o.ROW_ID AS OpptyId 
//FROM SIEBEL.S_OPTY o 
// JOIN SIEBEL.S_SALES_METHOD sM ON sM.ROW_ID = o.SALES_METHOD_ID 
// JOIN SIEBEL.S_OPTY_X oX ON oX.ROW_ID = o.ROW_ID 
//WHERE sM.NAME = 'Простые сделки' 
// AND oX.X_INT_STATUS IS NULL and rownum <= 301; 

--OUI_UC_1025
select /*+parallel(oe,512)*/ oe.row_id 
from siebel.S_ORG_EXT oe 
where oe.INT_ORG_FLG='N' and oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо' 

--OUI_UC_1026
//select /*+parallel(512)*/ a.row_id 
//from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
//where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and a.X_SBRF_CLIENT_FLG = 'Y' 
//and a.CUST_STAT_CD = 'Активна' and a.OU_TYPE_CD='Юр. лицо' 
//and b.sbrf_inn is not null and b.sbrf_kpp is not null 	 

--OUI_UC_1028
// Сдкелки генерил интеграцией UC_1026 

// Запрос на получение id сделок, где суть сделки = 'К7М. Финансирование текущей деятельности' 

//select /*+parallel(oe,512)*/o.row_id as Opty , oe.row_id as Account, oe.PR_POSTN_ID as Position 
//from siebel.S_OPTY o, siebel.S_ORG_EXT oe 
//where oe.par_row_id = o.PR_DEPT_OU_ID and o.SECURE_FLG ='N' and oe.X_SBRF_CLIENT_FLG = 'Y' and oe.INT_ORG_FLG = 'N'  
//and X_OPTY_NAME = 'К7М. Финансирование текущей деятельности'  

--OUI_UC_1029
//select /*+parallel(512)*/ 
//distinct 
//ps.row_id PositionId, 
//o.row_id OpptyCRMId, 
//oe.row_id AccountId, 
//pi.name OpptyCore, 
//sm.row_id SaleMethod, 
//pi.x_ckpit_id ProductName, 
//st.sales_method_id SalesStage, 
//o.modification_num ModId, 
//u.login 
//from siebel.S_OPTY o, 
//siebel.S_OPTY_POSTN op, 
//siebel.S_PARTY p, 
//siebel.S_SALES_METHOD sm, 
//s_postn ps, 
//s_user u, 
//siebel.S_ORG_EXT oe, 
//siebel.S_STG st, 
//s_prod_int pi 
//where 1=1 
//and o.row_id=op.OPTY_ID 
//and op.POSITION_ID=p.row_id  
//and sm.ROW_ID=o.SALES_METHOD_ID 
//and o.PR_POSTN_ID = ps.row_id  
//and u.row_id = ps.pr_emp_id 
//and oe.par_row_id = o.PR_DEPT_OU_ID 
//and sm.row_id = st.sales_method_id 
//and pi.row_id = o.pr_prod_id 
//and o.NEW_LOAN_FLG='N'  
//and o.X_EKP_FLAG='N'  
//and o.X_PA_FLG='N'  
//and sm.row_id in ('1-3H5AJMT','1-3H5AJLZ','1-3H5AJMF','1-3H5AJN9')  
//and oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.CLIENT_FLG='Y' 
//and oe.OU_TYPE_CD='Юр. лицо'  
//and oe.INT_ORG_FLG='N'  
//and oe.CUST_STAT_CD = 'Активна' 
//and o.SECURE_FLG='N'  
//and (o.pr_postn_id=op.POSITION_ID or op.ROLE_CD='Главный КМ сделки' or op.ROLE_CD='КМ, участник сделки')  
//and rownum < 3001 

--OUI_UC_1031
select t1.row_id as OpptyId,t3.X_ESA_ID as ContactESAId 
from siebel.S_OPTY t1, siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t1.PR_DEPT_OU_ID=t2.PARTY_ID and t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.row_id=t1.PR_DEPT_OU_ID and t4.X_SBRF_CLIENT_FLG='Y' -- Организации банка 
and ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 

--OUI_UC_1032
select t4.row_id as AccountId,t3.X_ESA_ID as ContactESAId 
from siebel.S_OPTY t1, siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t1.PR_DEPT_OU_ID=t2.PARTY_ID and t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.row_id=t1.PR_DEPT_OU_ID and t4.X_SBRF_CLIENT_FLG='Y' -- Организации банка 
and ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
group by t4.row_id,t3.X_ESA_ID 

--OUI_UC_1033
//select /*+parallel(t2,512)*/ t1.row_id 
//from siebel.S_ORG_EXT t1, siebel.S_ACCNT_POSTN t2 
//where t1.row_id=t2.OU_EXT_ID and t1.X_SBRF_CLIENT_FLG='Y' and t1.INT_ORG_FLG='N' and t1.OU_TYPE_CD='Юр. лицо' and t1.CUST_STAT_CD='Активна' 
//group by t1.row_id 
//having count(*)>0 and count(*)<50 

--OUI_UC_1034
select t3.row_id as ContactId,t3.X_ESA_ID as ContactESAId 
from siebel.S_CONTACT_X t3 
where t3.X_ESA_ID like 'OUI_UC_1%' 

--OUI_UC_1035
select t3.X_ESA_ID as ContactESAId 
from siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.X_SBRF_CLIENT_FLG='Y' and t4.row_id=t2.PARTY_ID -- Организации банка 
group by t3.X_ESA_ID 
having count(*)>0 and count(*)<50 

PositionId пул рандомных id басов. Вытаскивал вручную через пользователей. Тег нужен для авторизации в системе 
select p.row_id as PositionId 
from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 

--OUI_UC_1036-01
select t1.row_id as OpptyId,t3.X_ESA_ID as ContactESAId 
from siebel.S_OPTY t1, siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t1.PR_DEPT_OU_ID=t2.PARTY_ID and t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1031%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.row_id=t1.PR_DEPT_OU_ID and t4.X_SBRF_CLIENT_FLG='Y' -- Организации банка 
and ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
and t1.row_id in ( 
select t5.PAR_ROW_ID 
from siebel.S_OPTY_XM t5 
where t5.TYPE='EFS Roadmap') 

--OUI_UC_1036-02
select t1.row_id as OpptyId,t1.PR_POSTN_ID as PositionId 
from siebel.S_OPTY t1 
where ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
and t1.row_id in ( 
select t5.PAR_ROW_ID 
from siebel.S_OPTY_XM t5 
where t5.TYPE='EFS Roadmap') 

--OUI_UC_1037-01
select t1.row_id as OpptyId,t1.PR_POSTN_ID as PositionId,t5.row_id as Id 
from siebel.S_OPTY t1,siebel.S_OPTY_XM t5 
where ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
and t1.row_id=t5.PAR_ROW_ID and t5.TYPE='EFS Roadmap' 

--OUI_UC_1037-02
select t1.row_id as OpptyId,t1.PR_POSTN_ID as PositionId 
from siebel.S_OPTY t1, siebel.S_STG t2 
where ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
and t2.ROW_ID=t1.CURR_STG_ID and t2.NAME='01.Ввод данных' 
and t1.row_id not in ( 
select t5.PAR_ROW_ID 
from siebel.S_OPTY_XM t5 
where t5.TYPE='EFS Roadmap') 

--OUI_UC_1038-01
select t1.row_id as OpptyId,t3.X_ESA_ID as ContactESAId 
from siebel.S_OPTY t1, siebel.S_PARTY_PER t2, siebel.S_CONTACT_X t3, siebel.S_ORG_EXT t4 
where t1.PR_DEPT_OU_ID=t2.PARTY_ID and t2.PERSON_ID=t3.row_id and t3.X_ESA_ID like 'OUI_UC_1%' and t2.X_UFS_AUTH_FLG='Y' --Контакты без ограничений 
and t4.row_id=t1.PR_DEPT_OU_ID and t4.X_SBRF_CLIENT_FLG='Y' -- Организации банка 
and ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
and t1.row_id in (select t5.PAR_ROW_ID 
from siebel.CX_OPTY_LOG_XM t5) -- Проверка на логи изменения 

--OUI_UC_1038-02
//select /*+parallel(t1,32)*/ t1.row_id as OpptyId,t1.PR_POSTN_ID as PositionId 
//from siebel.S_OPTY t1 
//where ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
//or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
//and t1.row_id in (select t5.PAR_ROW_ID 
// from siebel.CX_OPTY_LOG_XM t5) -- Проверка на логи изменения 

--OUI_UC_1039
--PositionId пул рандомных id басов. Вытаскивал вручную через пользователей. Тег нужен для авторизации в системе 
select p.row_id as PositionId 
from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 

select to_char(t1.END_DATE+2,'yyyy-mm-dd') as EndDate,to_char(t1.START_DATE-2,'yyyy-mm-dd') as BeginDate 
from siebel.CX_CAMPAIGN t1 

--OUI_UC_1040
//select t1.row_id as OpptyId,t1.PR_POSTN_ID as PositionId,t1.SALES_METHOD_ID as MethodId,t1.CURR_STG_ID as StageId 
//from siebel.s_opty t1, siebel.s_org_ext t2 
//where ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --Стандартные сделки 
//or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --КК сделки 
//and t1.PR_DEPT_OU_ID=t2.row_id 

--OUI_UC_1041-01
//PositionId пул рандомных id басов. Вытаскивал вручную через пользователей. Тег нужен для авторизации в системе 
//select p.row_id as PositionId 
//from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
//where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 
// 
// 
//select /*+parallel(t1,32)*/ t1.row_id as AccountId 
//from siebel.S_ORG_EXT t1, siebel.S_ORG_EXT2_FNX t2 
//where t1.X_SBRF_CLIENT_FLG='Y' and t1.INT_ORG_FLG='N' and t1.OU_TYPE_CD='Юр. лицо' and t1.CUST_STAT_CD='Активна' and t2.ATTRIB_03='Крупнейшие' and t2.row_id=t1.row_id 
// 
// 
//Id продукта взять статичный из аплета, т.к связь для вытягивая очень тяжелая 

--OUI_UC_1041-02
//select t1.row_id OpptyCRMId,t1.PR_DEPT_OU_ID AccountId,t1.PR_POSTN_ID PositionId 
//from siebel.S_OPTY t1,S_REVN t, S_STG s 
//where t1.new_loan_flg = 'Y' 
//and t1.x_pa_flg = 'N' 
//and t1.x_ekp_flag = 'N' 
//and t1.opty_cd = 'КК' 
//and t.opty_id = t1.row_id 
//and s.row_id = t1.CURR_STG_ID 
//and s.name like '%02.Анализ сделки%' 
// 
//Генерация скриптом по созданию сделок КК 
//Id продукта взять статичный из аплета, т.к связь для вытягивая очень тяжелая 
//Нужен интерфейс для mod id  

--OUI_UC_1042
//PositionId пул рандомных id басов. Вытаскивал вручную через пользователей. Тег нужен для авторизации в системе 
//select p.row_id as PositionId 
//from siebel.S_PARTY p,siebel.S_USER u,siebel.S_CONTACT c 
//where p.row_id=c.PR_HELD_POSTN_ID and c.row_id=u.row_id and u.LOGIN like 'BAS_P041_%' 
// 
//select /*+parallel(t1,16)*/ t1.PR_HELD_POSTN_ID as EmployeePositionId 
//from siebel.S_CONTACT t1,siebel.S_CONTACT_XM t2, siebel.S_EMP_PER t3  
//where t1.row_id=t2.PAR_ROW_ID and t1.EMP_FLG='Y' and t2.TYPE='User System' and t2.NAME='CRM Корпоративный' and t3.EMP_STAT_CD<>'Terminated' and t3.row_id=t1.row_id 

--OUI_UC_1043

--OUI_UC_1044
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07, b.ATTrib_34 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null  
and a.CUST_STAT_CD = 'Активна'  
and a.OU_TYPE_CD = 'Юр. лицо' 

--OUI_UC_1045
--Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
and b.ATTrib_07='Нерезидент, работает в РФ' and a.CUST_STAT_CD = 'Активна' 

select /*+parallel(lp,512)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	

--OUI_UC_1046
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
--and b.ATTrib_07='Нерезидент, работает в РФ'  
and a.CUST_STAT_CD = 'Активна'

--OUI_UC_1047
select /*+parallel(c,512)*/ c.row_id 
from siebel.S_CONTACT c 
where c.X_SBRF_FI_VIP_FLAG = 'N' and EMP_FLG = 'N'

--OUI_UC_1048
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id--, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07, b.ATTrib_34 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID  
and b.sbrf_inn is not null and b.sbrf_kpp is not null 
--and b.ATTrib_07='Нерезидент, работает в РФ'  
and a.CUST_STAT_CD = 'Активна'  
and a.OU_TYPE_CD = 'Юр. лицо' 
--and b.ATTrib_34 <> 'Краткое наименование компании' 

select /*+parallel(lp,512)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	

--OUI_UC_1049
//select t1.row_id, t3.row_id 
//from siebel.S_ORG_EXT t1, siebel.S_PARTY_PER t2, siebel.S_contact t3 
//where t1.row_id = t2.PARTY_ID and t3.row_id=t2.PERSON_ID 
//and t3.last_name like 'LastNameUC1048_%' 

--OUI_UC_1050
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
and b.ATTrib_07='Нерезидент, работает в РФ' and a.CUST_STAT_CD = 'Активна' 

select /*+parallel(lp,512)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	 


//Запрос выводит внутрибанковские задачи 
select * 
from siebel.S_EVT_ACT a, siebel.S_LST_OF_VAL b 
where a.TODO_CD=b.VAL and b.DESC_TEXT = 'Bank'  
and a.TEMPLATE_FLG ='N' 

--OUI_UC_1051
select t1.login,count(*) 
from SIEBEL.S_EVT_ACT T7, SIEBEL.S_LST_OF_VAL T2,siebel.s_user t1,siebel.s_contact t3,siebel.s_postn t5 
where T7.TARGET_OU_ID IS NULL AND T2.DESC_TEXT IN ('Client','Bank') AND T7.TODO_CD = T2.VAL AND T2.ACTIVE_FLG = 'Y' AND T2.TYPE = 'TODO_TYPE' and T7.OWNER_POSTN_ID = t3.PR_HELD_POSTN_ID and t3.par_row_id=t1.row_id 
and t3.PR_HELD_POSTN_ID=t5.row_id and T5.OU_ID != '0-R9NH' and t7.created>='01.01.2017' and t7.created<='01.04.2017' 
group by t1.login	 

select u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
group by u.LOGIN,l.ACCOUNT_ID	 

--OUI_UC_1052
//select /*+parallel(512)*/ a.row_id, b.sbrf_inn,b.sbrf_kpp , u.LOGIN 
//from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b, siebel.S_ACCNT_POSTN sap, siebel.S_POSTN p, siebel.S_USER u, siebel.S_PARTY_PER su 
//where a.row_id=b.PAR_ROW_ID AND a.row_id = sap.OU_EXT_ID AND p.row_id= sap.POSITION_ID AND u.row_id = su.PERSON_ID AND u.row_id = su.PERSON_ID  
//AND p.row_id = su.PARTY_ID 
//and a.INT_ORG_FLG='N' and b.sbrf_inn is not null and b.sbrf_kpp is not null 
//and a.CUST_STAT_CD = 'Активна' 
//--and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  

--OUI_UC_1053
//SELECT /*+parallel(128)*/ u.LOGIN, org.row_id 
// FROM siebel.S_ACCNT_POSTN ap, siebel.S_USER u, S_POSTN p, s_org_ext org 
// WHERE p.row_id = ap.position_id  
// AND u.row_id = p.pr_emp_id  
// AND ap.OU_EXT_ID = org.ROW_ID  
// AND ROWNUM < 3001 

--OUI_UC_1056
// SELECT /*+parallel(128)*/ DISTINCT t3.login, t1.con_id 
// from siebel.S_POSTN_CON t1  
// left outer join siebel.s_postn t2  
// on t2.row_id = t1.postn_id  
// left outer join siebel.S_USER t3  
// on t3.row_id = t2.PR_EMP_ID  
// left outer join siebel.S_PARTY t4  
// on t3.row_id = t4.row_id  

--OUI_UC_1058
//select /*+parallel(512)*/ a.row_id, b.sbrf_inn,b.sbrf_kpp , u.LOGIN 
//from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b, siebel.S_ACCNT_POSTN sap, siebel.S_POSTN p, siebel.S_USER u, siebel.S_PARTY_PER su 
//where a.row_id=b.PAR_ROW_ID AND a.row_id = sap.OU_EXT_ID AND p.row_id= sap.POSITION_ID AND u.row_id = su.PERSON_ID AND u.row_id = su.PERSON_ID  
//AND p.row_id = su.PARTY_ID 
//and a.INT_ORG_FLG='N' and b.sbrf_inn is not null and b.sbrf_kpp is not null 
//and a.CUST_STAT_CD = 'Активна' 
//--and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  

--OUI_UC_1059
//select t1.row_id, t3.row_id 
//from siebel.S_ORG_EXT t1, siebel.S_PARTY_PER t2, siebel.S_contact t3 
//where t1.row_id = t2.PARTY_ID and t3.row_id=t2.PERSON_ID 
//and t3.last_name like 'LastNameUC1058_%' 
// 
//select * 
//from siebel.s_contact 
//where last_name like 'LastNameUC1058_%' 

--OUI_UC_1060
select soe.row_id  
from siebel.s_org_ext soe 
where soe.int_org_flg = 'N' and soe.X_SBRF_CLIENT_FLG = 'Y'

--OUI_UC_1061
select su.login, soe.row_id, soe.name, soe.x_name_lat, ssr.row_id 
from siebel.s_org_ext soe 
inner join siebel.s_accnt_postn sap on soe.row_id = sap.ou_ext_id  
inner join siebel.s_postn spo on spo.row_id = sap.position_id 
inner join siebel.s_user su on spo.pr_emp_id = su.row_id and (su.login like 'KM_P0%' or su.login like 'BAS_P041%' or su.login like 'IPOK_P160%')  
inner join siebel.s_srv_req ssr on ssr.cst_ou_id = soe.row_id and soe.X_SBRF_CLIENT_FLG = 'Y' and soe.int_org_flg = 'N' 

--OUI_UC_1062-01
//select a.row_id, b.sbrf_inn,a.Name 
//from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
//where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and a.name like 'OUI_UC1062_1_%' 

--OUI_UC_1062-02
//select a.row_id, a.Name, b.sbrf_inn 
//from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
//where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and a.name like 'OUI_UC1062_1_%' 

--OUI_UC_1066
//select /*+parallel(ap,512)*/distinct oe.row_id,ap.POSITION_ID --lpo.row_id 
//from siebel.S_ORG_EXT oe,siebel.CX_LD_PROD_OFFR lpo,siebel.S_ACCNT_POSTN ap,siebel.CX_LEAD l, siebel.S_ORG_EXT_X b 
//where oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо' and oe.INT_ORG_FLG='N' and l.ACCOUNT_ID=oe.row_id and ap.OU_EXT_ID=oe.row_id  
//and oe.row_id=b.PAR_ROW_ID  
//and ap.cvrg_role_cd='Клиентский менеджер' 
//and oe.INT_ORG_FLG='N'  
//and oe.cust_stat_cd<>'Архив' and l.ROW_ID=lpo.LEAD_ID and lpo.PROD_GROUP_ID is not null 
//--and l.stage='05 ПП Закрыта. Открыта Сделка.' 

--OUI_UC_1067
select su.login 
from siebel.s_user su 
where su.login like 'KM_P044_%' 

--OUI_UC_1068
//Select /*+parallel(512)*/t1.row_id, t3.login 
//from siebel.S_SRV_REQ t1, siebel.CX_SR_EMP t2, siebel.S_User t3 
//where t1.row_id=t2.SR_ID and t3.row_id=t2.EMP_ID 
//and t1.PAR_SR_ID IS NULL 
//and (t3.login like 'BAS_P041_%' or t3.login like 'KM_P044_%')  

--OUI_UC_1069
select distinct soe.row_id , soe.name 
from siebel.s_org_ext soe 
inner join siebel.s_srv_req ssr on ssr.cst_ou_id = soe.row_id and soe.X_SBRF_CLIENT_FLG = 'Y' and soe.int_org_flg = 'N' 

--OUI_UC_1074
//select soex.sbrf_inn, soex.sbrf_kpp 
//from siebel.S_ORG_EXT_X soex 
//JOIN siebel.s_org_ext soe on soex.row_id = soe.row_id 
//where soe.INT_ORG_FLG='N' and soe.active_flg = 'Y' and soex.sbrf_inn is not null and soex.sbrf_kpp is not null 

--OUI_UC_1075
//	select soex.sbrf_inn, soex.sbrf_kpp 
//from siebel.S_ORG_EXT_X soex 
//JOIN siebel.s_org_ext soe on soex.row_id = soe.row_id 
//where soe.INT_ORG_FLG='N' and soe.active_flg = 'Y' and soex.sbrf_inn is not null and soex.sbrf_kpp is not null 

--OUI_UC_1079
Select for pool: select 
soex.sbrf_inn AS inn, soex.sbrf_kpp AS kpp 
from siebel.s_org_ext_x soex JOIN siebel.s_org_ext soe on soex.row_id = soe.row_id 
where 1 = 1  
and soex.sbrf_inn is not null  
and soex.sbrf_kpp is not null  
and rownum < 10001 

--OUI_UC_1080

--OUI_UC_1083
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
and b.ATTrib_07='Нерезидент, работает в РФ' and a.CUST_STAT_CD = 'Активна' 

select /*+parallel(lp,32)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	 

--OUI_UC_1084
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
and b.ATTrib_07='Нерезидент, работает в РФ' and a.CUST_STAT_CD = 'Активна' 

select /*+parallel(lp,32)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	 

--OUI_UC_1085-01

--OUI_UC_1085-02
select c.row_id as ContactId,c.LAST_NAME as LastName,c.FST_NAME as FirstName, u.login AS LOGIN  
from siebel.S_CONTACT c  
inner join siebel.S_POSTN_CON pc on pc.CON_ID=c.row_id  
inner join siebel.S_POSTN p on p.row_id=pc.POSTN_ID  
inner join siebel.S_USER u on u.row_id=p.PR_EMP_ID  
where c.PRIV_FLG='N' and c.EMP_FLG = 'N'  
AND u.LOGIN != 'SADMIN' 

--OUI_UC_1086
select us.LOGIN as Login 
from siebel.cx_lead lead, siebel.s_postn pos, siebel.s_user us 
where lead.pr_postn_id = pos.row_id and pos.pr_emp_id <> '0-1' and pos.pr_emp_id <> 'No Match Row Id' 
and pos.pr_emp_id = us.row_id 
and rownum <= 10000 
group by us.LOGIN 

--OUI_UC_1087
select SOEX.sbrf_INN from siebel.s_org_ext SOE, siebel.s_org_ext_x SOEX 
WHERE SOE.ROW_ID = SOEX.ROW_ID and SOEX.sbrf_INN is not null 

--OUI_UC_1090
-- поиск Id организации, Id сделки и Id продукта 
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
and b.ATTrib_07='Нерезидент, работает в РФ' and a.CUST_STAT_CD = 'Активна' 

select /*+parallel(lp,32)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	

--OUI_UC_1091
Запрос для поиска данных: 
select o.row_id 
,oe.row_id 
,o.PR_PROD_ID 
--,op.POSITION_ID,PR_DEPT_OU_ID,o.SALES_METHOD_ID,o.CURR_STG_ID,sm.name,op.ROLE_CD 
from siebel.S_OPTY o 
,siebel.S_PARTY p 
,siebel.S_OPTY_POSTN op 
,siebel.S_SALES_METHOD sm 
, siebel.S_ORG_EXT oe 
where oe.par_row_id = o.PR_DEPT_OU_ID  
and o.SECURE_FLG='N'  
and o.row_id=op.OPTY_ID  
and op.POSITION_ID=p.row_id 
and (o.pr_postn_id=op.POSITION_ID )  
and o.NEW_LOAN_FLG='N' 
and o.X_EKP_FLAG='N' 
and o.X_PA_FLG='N' 
and sm.ROW_ID=o.SALES_METHOD_ID  
and oe.X_SBRF_CLIENT_FLG = 'Y' 
and oe.INT_ORG_FLG = 'N' 


Дополнительно: 
Запрос на получение организаций (AccountId) 
select /*+parallel(512)*/ a.row_id, a.Name, b.sbrf_inn,b.sbrf_kpp, b.ATTrib_07 
from siebel.S_ORG_EXT a, siebel.S_ORG_EXT_X b 
where a.INT_ORG_FLG='N' and a.row_id=b.PAR_ROW_ID and b.sbrf_inn is not null and b.sbrf_kpp is not null 
and b.ATTrib_07='Нерезидент, работает в РФ' and a.CUST_STAT_CD = 'Активна' 

select /*+parallel(lp,32)*/u.LOGIN,l.ACCOUNT_ID  
from siebel.CX_LEAD_POSTN lp,siebel.S_POSTN p,siebel.S_USER u,siebel.CX_LEAD l  
where lp.POSTN_ID=p.row_id and u.PAR_ROW_ID=p.PR_EMP_ID  
and (u.login like 'BAS_P041_%' or u.login like 'KM_P044_%')  
and l.row_id=lp.LEAD_ID  
and l.stage like '00%'  
group by u.LOGIN,l.ACCOUNT_ID	 

--OUI_UC_1092
//	--Запрос по Participant с ФизЛицом: 
//	select  
//	oe.row_id as ParticipantId_Ul 
//	,c.row_id as ParticipantId_Fl 
//	from  
//	siebel.S_ORG_EXT oe 
//	,siebel.S_PARTY_PER pp 
//	,siebel.S_CONTACT c 
//	where oe.X_SBRF_CLIENT_FLG='Y'  
//	and oe.OU_TYPE_CD='Юр. лицо'  
//	and oe.INT_ORG_FLG='N'  
//	and pp.party_id=oe.row_id  
//	and pp.person_id=c.row_id  
//	and c.PRIV_FLG='N' 
//	and rownum<1000 
 
//	--Запрос по Participant: 
//	select  
//	oe.row_id as ParticipantId_Ul 
//	from  
//	siebel.S_ORG_EXT oe 
//	where oe.X_SBRF_CLIENT_FLG='Y'  
//	and oe.OU_TYPE_CD='Юр. лицо'  
//	and oe.INT_ORG_FLG='N'  
//	and rownum<1000 

//	--Запрос поиска Простых сделок (Login можно подставлять любой, судя по всему) 
//	SELECT  
//	o.row_id as DealId 
//	FROM SIEBEL.S_OPTY O, 
//	SIEBEL.S_SALES_METHOD SM, 
//	SIEBEL.S_STG ST 
//	WHERE O.SALES_METHOD_ID = SM.ROW_ID 
//	AND O.CURR_STG_ID = ST.ROW_ID 
//	AND SM.NAME = 'Простые сделки' 
//	AND ST.NAME = 'Ввод данных' 
//	AND PR_PROD_ID is null 
//	and rownum<1000 

--OUI_UC_1101

--OUI_UC_1102

--OUI_UC_1104
//SELECT m.*, 
// k.user_Id, 
// k.km, 
// k.dep_name 
//FROM iskra.ATB_VW_KSB_E2E_MAIN m 
//JOIN iskra.atb_km_rkm k 
//ON k.rkm_user_Id=m.rkm 
//AND k.q =m.date_ksb 
//AND m.segm =K.SEGMENT 
//логины из искры 

//select DISTINCT U.LOGIN from siebel.ISKRA_SALES_PLANS S 
//join siebel.S_USER U on U.row_ID = S.USER_ID  

--OUI_UC_1105
//	-- Запрос для тегов AccountInfo 
//	select  
//	--	oe.row_id 
//	--	, oe.Name 
//	oe_x.sbrf_inn as INN 
//	,oe_x.sbrf_kpp as KPP 
//	from  
//	siebel.S_ORG_EXT oe 
//	, siebel.S_ORG_EXT_X oe_x 
//	where oe.INT_ORG_FLG='N'  
//	and oe.row_id=oe_x.PAR_ROW_ID 
//	and oe_x.sbrf_inn is not null  
//	and oe_x.sbrf_kpp is not null 
//	and oe.CUST_STAT_CD = 'Активна' 
//	and rownum<1500 

--OUI_UC_1106

--OUI_UC_1108
select c.login, a.row_id 

from siebel.S_ORG_EXT a, siebel.s_postn b, siebel.s_user c 

where a.PR_POSTN_ID = b.row_id 
and b.PR_EMP_ID = c.row_id 
--and a.cust_stat_cd = 'Закреплена' 
and c.login like 'KM%' --любые логины 
and ROWNUM < 3001; 

--OUI_UC_1110
select soe.row_id 
from siebel.s_org_ext soe, siebel.s_org_ext_x soex 
where soe.row_id = soex.row_id and soe.INT_ORG_FLG='N' 

--OUI_UC_1111
select t1.row_id 
from siebel.S_ORG_EXT t1 
where t1.INT_ORG_FLG='N' 

--OUI_UC_1114
select x_integration_id 
from siebel.s_srv_req req  
where req.sr_cat_type_cd='ПСФ' 
and sr_stat_id in ('На распределении', 'Очередь на маршрутизацию') 
and rownum <= 5000

--OUI_UC_1116-01
//	--Поиск организации + сделки + продукта 
//select 
// distinct p.row_id as AccountId,prod.row_id as productId, deal.row_id as DealId,prod.revn_stat_cd 
//from  
// siebel.S_PARTY p 
// , siebel.S_ORG_EXT oe 
// , siebel.S_ACCNT_POSTN ap 
// , siebel.S_opty deal 
// --, siebel.S_PROD_INT prod 
// ,siebel.S_REVN prod 
//where  
// p.row_id=oe.row_id 
// and oe.CUST_STAT_CD = 'Активна' 
// and oe.X_SBRF_CLIENT_FLG='Y'  
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N' 
// and p.PARTY_TYPE_CD='Organization' 
// and oe.PR_POSTN_ID = ap.POSITION_ID  
// and ap.ou_ext_id = oe.par_row_id 
// and p.row_id = deal.PR_DEPT_OU_ID 
// and deal.row_id = prod.OPTY_ID 
// and prod.revn_stat_cd in('Запрошен', 'Изменение условий','Действующий') 
// and prod.OPTY_ID is not null 
// and prod.row_id is not null 
// and prod.prod_id is not null 

--OUI_UC_1116-02
//	----Поиск организации + сделки + продукта 
//select 
// distinct p.row_id as AccountId,prod.row_id as productId, deal.row_id as DealId,prod.revn_stat_cd 
//from  
// siebel.S_PARTY p 
// , siebel.S_ORG_EXT oe 
// , siebel.S_ACCNT_POSTN ap 
// , siebel.S_opty deal 
// --, siebel.S_PROD_INT prod 
// ,siebel.S_REVN prod 
//where  
// p.row_id=oe.row_id 
// and oe.CUST_STAT_CD = 'Активна' 
// and oe.X_SBRF_CLIENT_FLG='Y'  
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N' 
// and p.PARTY_TYPE_CD='Organization' 
// and oe.PR_POSTN_ID = ap.POSITION_ID  
// and ap.ou_ext_id = oe.par_row_id 
// and p.row_id = deal.PR_DEPT_OU_ID 
// and deal.row_id = prod.OPTY_ID 
// and prod.revn_stat_cd in('Запрошен', 'Изменение условий','Действующий') 
// and prod.OPTY_ID is not null 
// and prod.row_id is not null 
// and prod.prod_id is not null 
// and rownum <=17500; 

--OUI_UC_1116-03
//	--Поиск рейтинга: 
//	select  
//	r.row_id as RatingId 
//	, r.Object_id as ObjectId 
//	from siebel.CX_RATING r 
//	where  
//	status='Актуальный' 
//	and rownum<17500 

--OUI_UC_1117
select 
soex.sbrf_inn as AccountINN 
, soex.sbrf_kpp as AccountKPP 
, oe.X_MDM_ID as MDMId 
from  
siebel.S_ORG_EXT oe 
, siebel.S_ORG_EXT_X soex 
--Дополнено таблицей 
, siebel.S_ORG_EXT2_FNX oef  
WHERE  
oe.row_id=soex.PAR_ROW_ID 
and oe.row_id = oef.row_id 
and soex.sbrf_inn is not null 
and soex.sbrf_kpp is not null 
and oe.X_SBRF_CLIENT_FLG='Y'  
and oe.OU_TYPE_CD = 'Юр. лицо'  
and oe.INT_ORG_FLG='N'  
and oe.CUST_STAT_CD = 'Активна'  
and oe.X_SBRF_CLIENT_FLG='Y'  
and oe.X_MDM_ID is not null 
--Дополнено 
and oe.x_kind_activity <> 'Банковская деятельность' 
and oef.attrib_03 is not null  
and rownum<15000

--OUI_UC_1121
//	--Запрос на получение организаций ИНН, КПП и id сделки + проверки 
//	select  
//	opt.row_id as DealId 
//	,extx.sbrf_inn as AccountINN 
//	, extx.sbrf_kpp as AccountKPP 
//	, cosx.SBRF_SBBOL_ID as ApplicationNumber 
//	--, stg.name as stagename 
//	--, sm.Name as salesmethod 
//	--, opt.closed_flg 
//	from siebel.s_opty opt 
//	inner join siebel.CX_OPTY_SBBOL_X cosx 
//	on cosx.par_row_id=opt.row_id 
//	inner join siebel.s_org_ext ext 
//	on opt.PR_DEPT_OU_ID=ext.par_row_id 
//	inner join siebel.s_org_ext_x extx 
//	on extx.par_row_id=ext.par_row_id 
//	inner join siebel.s_stg stg 
//	on stg.row_id=opt.curr_stg_id 
//	LEFT JOIN SIEBEL.S_SALES_METHOD sm  
//	ON opt.SALES_METHOD_ID = sm.ROW_ID 
//	where 
//	extx.sbrf_inn is not null 
//	and extx.sbrf_kpp is not null 
//	and ext.X_SBRF_CLIENT_FLG='Y'  
//	and ext.OU_TYPE_CD = 'Юр. лицо'  
//	and ext.INT_ORG_FLG='N'  
//	and ext.CUST_STAT_CD = 'Активна'  
//	and ext.X_SBRF_CLIENT_FLG='Y' 
//	and sm.Name='Кредитный конвейер' 

--OUI_UC_1122
select row_id 
from siebel.CX_COMPLIANCE 

--OUI_UC_1123
select  
soex.sbrf_inn as AccountINN 
--, soex.sbrf_kpp as AccountKPP 
--, oe.X_MDM_ID as MDMId 
from  
siebel.S_ORG_EXT oe 
, siebel.S_ORG_EXT_X soex 
WHERE  
oe.row_id=soex.PAR_ROW_ID 
and soex.sbrf_inn is not null 
and soex.sbrf_kpp is not null 
and oe.X_SBRF_CLIENT_FLG='Y'  
and oe.OU_TYPE_CD = 'Юр. лицо'  
and oe.INT_ORG_FLG='N'  
and oe.CUST_STAT_CD = 'Активна'  
and oe.X_SBRF_CLIENT_FLG='Y'  
and oe.X_MDM_ID is not null 
and rownum <= 250 

--OUI_UC_1124
//select /*+parallel(lpo,512)*/ distinct oe.row_id as Account, lpo.row_id as PP, oe.PR_POSTN_ID as Position  
//from siebel.S_ORG_EXT oe, siebel.CX_LD_PROD_OFFR lpo,siebel.S_ACCNT_POSTN po,siebel.S_POSTN p 
//where oe.X_SBRF_CLIENT_FLG = 'Y' and oe.INT_ORG_FLG = 'N' and oe.row_id=lpo.ACCOUNT_ID and po.POSITION_ID = p.row_id and po.OU_EXT_ID = oe.row_id  
//and oe.CUST_STAT_CD = 'Активна'; 

//запрос на продукты с заполненным полем -категория продукта 
//select t1.row_id 
//from siebel.S_PROD_INT_X t1 
//where t1.ATTRIB_04 is not null 

--OUI_UC_1129
SELECT 
u.LOGIN AS CrmLogin 
FROM SIEBEL.ISKRA_POTENTIALS p 
JOIN SIEBEL.S_USER u ON p.USER_ID = u.ROW_ID OR p.RKM = u.ROW_ID 

--OUI_UC_1130
SELECT 
ROW_ID AS AccountId 
FROM SIEBEL.S_ORG_EXT 
WHERE INT_ORG_FLG = 'N' 

--OUI_UC_1131
SELECT 
max(OU_EXT_ID) AS AccountId, 
u.LOGIN AS Login 
FROM SIEBEL.S_ACCNT_POSTN accPos 
JOIN SIEBEL.S_CONTACT c ON c.PR_HELD_POSTN_ID = accPos.POSITION_ID 
JOIN SIEBEL.S_USER u ON u.ROW_ID = c.ROW_ID 
GROUP BY u.LOGIN 

--OUI_UC_1132
SELECT  
o.PR_POSTN_ID AS PositionId, 
o.ROW_ID AS OpptyId 
FROM SIEBEL.S_OPTY o 
JOIN SIEBEL.S_SALES_METHOD sM ON sM.ROW_ID = o.SALES_METHOD_ID 
JOIN SIEBEL.S_OPTY_X oX ON oX.ROW_ID = o.ROW_ID 
WHERE  
sM.NAME = 'Простые сделки' 
and o.x_opty_name like 'UC1132%' 
AND oX.X_INT_STATUS IS NULL  

--OUI_UC_1133
select RQUID from SIEBEL.CX_MSH_REGISTRY;

--INT_UC_1147
//select /*+parallel(oe,512)*/ distinct oe.row_id, b.login 
//	from siebel.S_ORG_EXT oe, siebel.S_EVT_ACT ea, s_user b 
//  
//	where 1=1 
// and ea.owner_per_id = b.row_id 
// and ea.TARGET_OU_ID=oe.row_id  
// and ea.owner_per_id is not null 
// and oe.X_SBRF_CLIENT_FLG='Y' 
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N'  
// and oe.cust_stat_cd='Активна'  
// and ea.TODO_CD<>'Мероприятие'  
// and (ea.TEMPLATE_FLG='N' or ea.TEMPLATE_FLG is null)  
///* and ea.OPTY_ID is null */ 
// and ea.EVT_STAT_CD in ('Запланирована', 'В работе') 
// and b.login not in ('SBBOL', 'SADMIN') 

--INT_UC_1158
// SELECT /*+parallel(128)*/ u.LOGIN, org.row_id, org.name 
// FROM siebel.S_USER u, S_POSTN p, s_org_ext org, S_PER_RESP resp, s_resp r 
// WHERE 1=1 
// AND u.row_id = p.pr_emp_id 
// and org.pr_postn_id = p.row_id 
// and u.row_id = resp.per_id 
// and r.row_id = resp.resp_id 
// and r.name = 'SBRF KRB_SRB 3 04 KM MMB' 
//	and org.CUST_STAT_CD = 'Активна' 
// and org.OU_TYPE_CD='Юр. лицо'  
// and org.X_SBRF_CLIENT_FLG='Y'  
// and org.INT_ORG_FLG='N' 

--OUI_UC_151
// Запрос для получения данных 
//select MDMID ,MGVersion,KM_ID,Login,Tab_KM from( 
//select m.MDM_id as MDMID ,m.VERSION as MGVersion,m.CM_ID as KM_ID,u.login as Login, u.X_SRC_EMP_ID as Tab_KM--, c.FST_NAME,c.LAST_NAME,c. 
//from siebel.S_USER u,siebel.CX_MG m,siebel.S_CONTACT c  
//where m.CM_ID = u.ROW_ID and u.X_SRC_CD <> 'Siebel CRM БПС' and u.row_id = c.par_row_id and m.version between 0 and 1) 
//where rownum<=5415 

--OUI_UC_152
// Запрос для получения данных 
//select /*+parallel(m,512)*/ m.MDM_id,m.VERSION,m.CM_ID,u.login,u.X_SRC_EMP_ID--, c.FST_NAME,c.LAST_NAME,c. 
//from siebel.S_USER u,siebel.CX_MG m,siebel.S_CONTACT c  
//where m.CM_ID = u.ROW_ID and u.X_SRC_CD <> 'Siebel CRM БПС' and u.row_id = c.par_row_id 

--OUI_UC_343
//	select /*+parallel(oe,512)*/ oex.SBRF_INN,oex.SBRF_KPP 
//from siebel.S_ORG_EXT oe,siebel.S_ORG_EXT_X oex 
//where oe.INT_ORG_FLG='N' and oe.X_SBRF_CLIENT_FLG='Y'  
//and oe.OU_TYPE_CD='Юр. лицо' and oex.row_id=oe.row_id and oex.ATTRIB_07='Резидент' 
//and oex.SBRF_KPP is not null 

--OUI_UC_499
//	SELECT LOGIN, "OrgId" 
// FROM (SELECT u.LOGIN, ap.OU_EXT_ID "OrgId", COUNT(ap.OU_EXT_ID) OVER (PARTITION BY ap.position_id) cnt 
// FROM siebel.S_ACCNT_POSTN ap, siebel.S_USER u, S_POSTN p 
// WHERE p.row_id = ap.position_id AND u.row_id = p.pr_emp_id AND u.login LIKE 'L0D%') 

--OUI_UC_500-01
//	select t3.login 
// from siebel.S_POSTN_CON t1 
// left outer join siebel.s_postn t2 
// on t2.row_id = t1.postn_id 
// left outer join siebel.S_USER t3 
// on t3.row_id = t2.PR_EMP_ID 
// where t2.row_id in (select POSTN_ID 
// from siebel.S_POSTN_CON 
// group by POSTN_ID 
// having count(CON_ID) >= 100) 
// and t3.login like 'L0D%' 

--OUI_UC_500-02
//SELECT distinct (t1.row_id), t1.modification_num, t4.login  
//from siebel.s_party t1, siebel.S_POSTN_CON t2, siebel.s_postn t3, siebel.s_user t4  
//where t1.row_id = t2.con_id  
//and t3.row_id = t2.postn_id  
//AND t3.PR_EMP_ID = t4.row_id 
//and t1.modification_num = 0  
//and t4.login not in ('SADMIN') 
//AND ROWNUM < 10001  

--OUI_UC_503-02
//select /*+parallel(oe,512)*/*--p.row_id 
//from siebel.S_PARTY p,siebel.S_ORG_EXT oe 
//where p.row_id=oe.row_id and oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо' and oe.INT_ORG_FLG='N' 
// 
//select /*+parallel(ea,512)*/ ea.row_id,ea.owner_login 
//from siebel.S_EVT_ACT ea 
//where (ea.TEMPLATE_FLG='N' or ea.TEMPLATE_FLG is null) and ea.OPTY_ID is null and ea.TODO_CD<>'Event' and evt_stat_cd='Запланирована' 

--OUI_UC_504-02
//select l.ROW_ID,u.LOGIN,l.ACCOUNT_ID 
//from siebel.CX_LEAD l, 
// siebel.CX_LEAD_POSTN lp, 
// siebel.S_POSTN p, 
// siebel.S_USER u, 
// siebel.S_ORG_EXT oe, 
//  
// siebel.S_PARTY par, 
// siebel.S_ACCNT_POSTN ap 
//  
//where l.row_id=lp.lead_id 
// and lp.POSTN_ID=p.row_id  
// and lp.ROLE='Клиентский менеджер' 
// and p.PR_EMP_ID=u.PAR_ROW_ID 
// and u.LOGIN not in ('SADMIN') 
// and l.ACCOUNT_ID = oe.ROW_ID 
// and oe.X_SBRF_CLIENT_FLG='Y'  
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N' 
//  
// and par.row_id=oe.row_id 
// and oe.CUST_STAT_CD = 'Активна' 
// and par.PARTY_TYPE_CD='Organization' 
// and oe.PR_POSTN_ID = ap.POSITION_ID  
// and ap.ou_ext_id = oe.par_row_id 
// and rownum < 8700; 

--OUI_UC_530
//	SELECT o.row_id 
//FROM SIEBEL.S_OPTY O 
//where o.OPTY_CD='СБЛ' and o.INACTIVE_FLG='N' 

--OUI_UC_685, OUI_UC_686
//select /*+parallel(p,512)*/  
//from siebel.S_POSTN p,siebel.S_EMP_PER ep 
//where ep.PAR_ROW_ID=p.PR_EMP_ID and ep.EMP_STAT_CD<>'Terminated' and p.name like 'BAS_P041_%' 

--OUI_UC_687
select /*+parallel(p,512)*/ * 
//from siebel.S_POSTN p,siebel.S_EMP_PER ep 
//where ep.PAR_ROW_ID=p.PR_EMP_ID and ep.EMP_STAT_CD<>'Terminated' and p.name like 'BAS_P041_%' 

//select /*+parallel(p,512)*/* 
//from siebel.S_CONTACT c,siebel.S_PARTY p 
//where c.X_SBRF_FI_VIP_FLAG='N' and c.EMP_FLG='N' and c.PRIV_FLG='N' and p.PARTY_TYPE_CD<>'Suspect' and p.row_id=c.row_id 

--OUI_UC_688
//select /*+parallel(ap,512)*/ ap.POSITION_ID 
//from siebel.S_ACCNT_POSTN ap,siebel.S_ORG_EXT oe 
//where oe.X_SBRF_CLIENT_FLG='Y' and oe.OU_TYPE_CD='Юр. лицо' and oe.INT_ORG_FLG='N' and ap.OU_EXT_ID=oe.row_id and oe.cust_stat_cd<>'Архив' and ap.cvrg_role_cd='Клиентский менеджер' 
//group by ap.POSITION_ID 
//having count(*)<100 

--OUI_UC_689
//select ap.POSITION_ID as position,oe.par_row_id as AccountID 
//from  
//siebel.S_ACCNT_POSTN ap, 
//siebel.S_ORG_EXT oe, 
//siebel.S_PARTY p 
//where  
// p.row_id=oe.row_id 
// and oe.CUST_STAT_CD = 'Активна' 
// and oe.X_SBRF_CLIENT_FLG='Y'  
// and oe.OU_TYPE_CD='Юр. лицо'  
// and oe.INT_ORG_FLG='N' 
// and p.PARTY_TYPE_CD='Organization' 
// and oe.PR_POSTN_ID = ap.POSITION_ID  
// and ap.ou_ext_id = oe.par_row_id 
// and ap.cvrg_role_cd='Клиентский менеджер' 
// and rownum<=5000 

--


--OUI_UC_998-01, OUI_UC_998-02