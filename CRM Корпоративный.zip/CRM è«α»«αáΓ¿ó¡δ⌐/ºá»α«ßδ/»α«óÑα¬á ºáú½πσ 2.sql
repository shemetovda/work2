select s.*,
       (s.reply_time - s.request_time) * 3600 * 24 delta_sec,
       min((s.reply_time - s.request_time) * 3600 * 24) over() min_delta_sec,
       max((s.reply_time - s.request_time) * 3600 * 24) over() max_delta_sec,
       round(avg((s.reply_time - s.request_time) * 3600 * 24) over(), 2) avg_delta_sec
  from (select q.name,
               i.seq_num,
               i.queue_ref_val RQUID,
               i.queued_ts + 3 / 24 reply_time,
               case q.name
                 when '2017-02-16.BPM.EKP.UpdateLegalLoanApplicationRs' then
                  (select ii.queued_ts
                     from siebel.s_eai_queue_itm ii
                    where ii.queue_ref_val = i.queue_ref_val
                      and ii.row_id <> i.row_id)
                 else
                  null
               end + 3 / 24 request_time
          from siebel.s_eai_queue q
         inner join siebel.s_eai_queue_itm i
            on i.queue_id = q.row_id
         where q.name like '2017-02-16.BPM.EKP.UpdateLegalLoanApplicationR%'
           and i.queued_ts between
               to_date('16.02.2017 12:30:00', 'dd.mm.yyyy HH24:mi:ss') and
               to_date('16.02.2017 20:00:00', 'dd.mm.yyyy HH24:mi:ss')) s
order by 2, 1
