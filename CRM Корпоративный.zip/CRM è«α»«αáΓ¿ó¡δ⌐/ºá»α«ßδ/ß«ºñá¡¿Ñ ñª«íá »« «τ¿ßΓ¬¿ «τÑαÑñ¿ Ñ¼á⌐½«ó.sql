create or replace procedure siebel.clear_queue as
begin
  update siebel.s_apsrvr_req SET STATUS = 'SUCCEEDED' WHERE STATUS = 'QUEUED' and created > sysdate - 1;
end;

declare
  job_no number;
begin
  dbms_job.submit(job       => job_no,
                  next_date => sysdate,
                  interval  => 'sysdate + 1 / (24 * 12)',
                  what      => 'clear_queue;');
  dbms_output.put_line(to_char(job_no));
end;
