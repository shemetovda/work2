delete from s_srm_request where row_id in (
select a.row_id from s_srm_request a 
left join s_srm_action b on a.action_id = b.row_id
where b.display_name = 'Communications Outbound Manager'
and a.status = 'QUEUED')
