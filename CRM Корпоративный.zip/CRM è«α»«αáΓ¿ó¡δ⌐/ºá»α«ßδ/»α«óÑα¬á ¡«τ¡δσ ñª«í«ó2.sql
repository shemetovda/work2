select s.SCHED_START_DT, c.DISPLAY_NAME, s.* From siebel.S_SRM_REQUEST s
left join siebel.S_SRM_ACTION c
on s.ACTION_ID = c.ROW_ID
where (SCHED_START_DT is not null and SCHED_START_DT >= sysdate+21/24 and SCHED_START_DT < to_date('28.07.2018', 'dd.mm.yyyy'))
order by s.SCHED_START_DT 
