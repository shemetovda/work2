select c.name,c.media_type_cd,p.name,pp.value from S_CM_PROF p,S_CM_PROF_PARM pp,S_CM_CNCTR c
where pp.cm_prof_id = p.row_id
and p.name in ('Default SMTP Profile')
and c.media_type_cd = 'Email'
and c.row_id = p.cm_cnctr_id
