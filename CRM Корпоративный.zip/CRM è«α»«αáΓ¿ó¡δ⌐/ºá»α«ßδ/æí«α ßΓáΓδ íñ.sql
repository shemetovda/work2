--���� ����� ��
begin 
  DBMS_STATS.GATHER_SCHEMA_STATS(ownname => 'SIEBEL' , estimate_percent => 30, granularity => 'ALL', method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE, no_invalidate =>false, force=>TRUE); 
end; 
/ 
