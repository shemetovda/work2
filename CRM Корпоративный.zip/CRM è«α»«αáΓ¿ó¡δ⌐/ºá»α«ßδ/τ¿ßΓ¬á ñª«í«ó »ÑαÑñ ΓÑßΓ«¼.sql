UPDATE SIEBEL.S_SRM_REQUEST
SET STATUS = 'CANCELED'
/*select * from SIEBEL.S_SRM_REQUEST*/
       WHERE ROW_ID <> PAR_REQ_ID AND
       STATUS IN ('QUEUED','ACTIVE') and 
       PAR_REQ_ID not in (SELECT T2.ROW_ID PAR_ID
                          FROM siebel.S_SRM_REQUEST T1, siebel.S_SRM_REQUEST T2
                          WHERE T1.STATUS IN ('QUEUED','ACTIVE') 
                          and T2.STATUS IN ('QUEUED','ACTIVE')
                         AND T1.REQ_TYPE_CD='RPT_INSTANCE'     
                          AND T1.PAR_REQ_ID = T2.ROW_ID);
commit;

update S_SRM_REQUEST
      set SCHED_START_DT = sysdate-3/24
/*select * from S_SRM_REQUEST*/
    where REQ_TYPE_CD = 'RPT_INSTANCE'
      and SCHED_START_DT < sysdate-3/24
      and status IN ('QUEUED', 'ACTIVE');
commit;
