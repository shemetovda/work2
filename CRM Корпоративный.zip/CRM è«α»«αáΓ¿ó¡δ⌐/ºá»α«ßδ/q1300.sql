select 'INT_1300_QR' as "TransactionName",
count(*)  as "transCount",
avg(c.datestamp_rq - b.created)*24*60*60 as "percentile",
'0' as "failCount"
from siebel.s_eai_queue a, siebel.S_EAI_QUEUE_ITM b, mlinterface.psf_class_predict c
where a.row_id = b.QUEUE_ID
and a.name like '%PSF.GetFileECM'
and b.queue_ref_val = c.tfs_rquid
and c.datestamp_rq > sysdate -1
and b.comments is null



select v.rquid from siebel.cx_oper_queue v where /*v.created > sysdate -1 and*/ v.status = 'SENDRQ' and v.operation = 'PSFMLAttach'



select * from mlinterface.psf_Class_predict v where v.datestamp_rq > sysdate -1 order by v.datestamp_rq desc
