SELECT 
d.uc AS "UseCase", d.plan_3 AS "����", a.s1 AS "����",d.sla AS "SLA", a.s2 AS "Average", a.s3 AS "90 Percent",
d.plan_4 AS "����", b.b1 AS "����",d.sla AS "SLA", b.b2 AS "Average", b.b3 AS "90 Percent",
d.plan_5 AS "����", c.c1 AS "����",d.sla AS "SLA", c.c2 AS "Average", c.c3 AS "90 Percent"
FROM 
(select /*+parallel(32)*/
uc,
count(*) s1,
trunc(avg(l), 4) s2,
trunc(percentile_disc(.90) within group(order by l), 4) s3
  from (select uc,
               sysdate +
               (to_timestamp(rs.time) - to_timestamp(rq.time)) * 24 * 60 * 60 -
               sysdate as l
          from crmr.mq_request_crmk  rq,  crmr.mq_response_crmk rs
         where 1 = 1
           and rq.JMSMessageID = rs.JMSCorrelationID
           and rq.time between
               to_date('08-08-2017 17:00:00', 'dd.mm.yyyy hh24:mi:ss') and
               to_date('08-08-2017 18:00:00', 'dd.mm.yyyy hh24:mi:ss'))
group by uc
UNION
select /*+parallel(32)*/
uc,
count(*),
trunc(avg(l), 4),
trunc(percentile_disc(.90) within group(order by l), 4)
  from (select uc,
               sysdate +
               (to_timestamp(rs.time) - to_timestamp(rq.time)) * 24 * 60 * 60 -
               sysdate as l
          from crmr.mq_request_crmk  rq,  crmr.mq_response_crmk rs
         where 1 = 1
           and rq.rquid = rs.rquid
           and rq.time between
               to_date('08-08-2017 17:00:00', 'dd.mm.yyyy hh24:mi:ss') and
               to_date('08-08-2017 18:00:00', 'dd.mm.yyyy hh24:mi:ss'))
group by uc
) a,
(select /*+parallel(32)*/
uc,
count(*) b1,
trunc(avg(l), 4) b2,
trunc(percentile_disc(.90) within group(order by l), 4) b3
  from (select uc,
               sysdate +
               (to_timestamp(rs.time) - to_timestamp(rq.time)) * 24 * 60 * 60 -
               sysdate as l
          from crmr.mq_request_crmk  rq,  crmr.mq_response_crmk rs
         where 1 = 1
           and rq.JMSMessageID = rs.JMSCorrelationID
           and rq.time between
               to_date('08-08-2017 19:00:00', 'dd.mm.yyyy hh24:mi:ss') and
               to_date('08-08-2017 20:00:00', 'dd.mm.yyyy hh24:mi:ss'))
group by uc
UNION
select /*+parallel(32)*/
uc,
count(*),
trunc(avg(l), 4),
trunc(percentile_disc(.90) within group(order by l), 4)
  from (select uc,
               sysdate +
               (to_timestamp(rs.time) - to_timestamp(rq.time)) * 24 * 60 * 60 -
               sysdate as l
          from crmr.mq_request_crmk  rq,  crmr.mq_response_crmk rs
         where 1 = 1
           and rq.rquid = rs.rquid
           and rq.time between
               to_date('08-08-2017 19:00:00', 'dd.mm.yyyy hh24:mi:ss') and
               to_date('08-08-2017 20:00:00', 'dd.mm.yyyy hh24:mi:ss'))
group by uc
) b,
(select /*+parallel(32)*/
uc,
count(*) c1,
trunc(avg(l), 4) c2,
trunc(percentile_disc(.90) within group(order by l), 4) c3
  from (select uc,
               sysdate +
               (to_timestamp(rs.time) - to_timestamp(rq.time)) * 24 * 60 * 60 -
               sysdate as l
          from crmr.mq_request_crmk  rq,  crmr.mq_response_crmk rs
         where 1 = 1
           and rq.JMSMessageID = rs.JMSCorrelationID
           and rq.time between
               to_date('08-08-2017 22:00:00', 'dd.mm.yyyy hh24:mi:ss') and
               to_date('08-08-2017 23:00:00', 'dd.mm.yyyy hh24:mi:ss'))
group by uc
UNION
select /*+parallel(32)*/
uc,
count(*),
trunc(avg(l), 4),
trunc(percentile_disc(.90) within group(order by l), 4)
  from (select uc,
               sysdate +
               (to_timestamp(rs.time) - to_timestamp(rq.time)) * 24 * 60 * 60 -
               sysdate as l
          from crmr.mq_request_crmk  rq,  crmr.mq_response_crmk rs
         where 1 = 1
           and rq.rquid = rs.rquid
           and rq.time between
               to_date('08-08-2017 22:00:00', 'dd.mm.yyyy hh24:mi:ss') and
               to_date('08-08-2017 23:00:00', 'dd.mm.yyyy hh24:mi:ss'))
group by uc
) c,
crmr.OUI_UC d
WHERE 
d.uc=b.uc (+)
AND d.uc=c.uc (+)
AND d.uc=a.uc (+)
ORDER BY d.uc
