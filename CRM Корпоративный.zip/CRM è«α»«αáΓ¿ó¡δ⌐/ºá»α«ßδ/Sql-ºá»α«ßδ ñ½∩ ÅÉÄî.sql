--1
SELECT TRUNC(CREATED, 'hh'), COUNT(*)
FROM siebel.S_EVT_ACT s
WHERE TODO_CD = '������'
AND CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(CREATED, 'hh');
--2
SELECT TRUNC(a.CREATED, 'hh') as date_created, COUNT(*)
FROM siebel.S_ORG_EXT a
WHERE 
a.CREATED >= TRUNC(SYSDATE - 183) and 
a.int_org_flg = 'N' and
a.created_by <> '0-1'
GROUP BY TRUNC(a.CREATED, 'hh')
order by date_created DESC;
--3
SELECT TRUNC(p.CREATED, 'hh'), COUNT(*)
FROM siebel.S_PARTY_PER p, siebel.S_USER u
WHERE p.CREATED >= TRUNC(SYSDATE - 28)
AND p.CREATED < TRUNC(SYSDATE - 183)
AND u.ROW_ID = p.CREATED_BY
AND u.LOGIN NOT IN 'SADMIN'
GROUP BY TRUNC(p.CREATED, 'hh');
--4
SELECT TRUNC(CREATED, 'hh'), COUNT(*) 
FROM siebel.CX_MON_CRIT 
WHERE CREATED >= TRUNC(SYSDATE - 183) 
GROUP BY TRUNC(CREATED, 'hh');
--5
SELECT TRUNC(s.CREATED, 'hh'),COUNT(*) 
FROM siebel.S_OPTY_POSTN s, siebel.s_user u 
WHERE s.POSITION_ID IS NOT NULL 
AND s.CREATED >= TRUNC(SYSDATE - 183) 
AND u.row_id= s.created_by 
AND u.login NOT IN 'SADMIN' 
GROUP BY TRUNC(s.CREATED, 'hh');
--6
SELECT TRUNC(T11.CREATED, 'hh'), COUNT(*)  
FROM SIEBEL.CX_RATING T11 
LEFT JOIN SIEBEL.CX_RATING_MODEL T6 ON T11.MODEL_ID = T6.ROW_ID  
WHERE T11.POSTN_ID IS NOT NULL  
AND T11.CREATED >= TRUNC(SYSDATE - 183)  
GROUP BY TRUNC(T11.CREATED, 'hh');
--7
SELECT TRUNC(LAST_UPD, 'hh'), COUNT(*)  
FROM siebel.S_ORG_EXT_X
WHERE ATTRIB_46 IS NOT NULL 
AND MODIFICATION_NUM > 0 
AND LAST_UPD >= TRUNC(SYSDATE-183) 
GROUP BY TRUNC(LAST_UPD, 'hh');
--8
SELECT TRUNC(a.CREATED, 'hh'),COUNT(*)
FROM siebel.S_ACCNT_POSTN a
WHERE 
a.POSITION_ID IS NOT NULL and
a.CREATED >= TRUNC(SYSDATE - 183) and
a.created_by <> '0-1' and
a.db_last_upd_src = 'User'
GROUP BY TRUNC(a.CREATED, 'hh');
--9
SELECT TRUNC(CREATED, 'hh'), COUNT(*)
FROM siebel.S_OPTY_CON
WHERE CREATED >= TRUNC(SYSDATE - 183) 
GROUP BY TRUNC(CREATED, 'hh');
--10
SELECT TRUNC(CREATED, 'hh'), COUNT(*)
FROM siebel.CX_MONITORING
WHERE CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(CREATED, 'hh');
--11
/*+USE_NL(a s)*/ 
SELECT TRUNC(p.CREATED, 'hh'), COUNT(*)  
FROM siebel.S_REVN p 
LEFT JOIN siebel.S_OPTY s ON p.OPTY_ID = s.ROW_ID
WHERE p.CREATED >= TRUNC(SYSDATE - 183)
AND s.OPTY_CD = '��'
GROUP BY TRUNC(p.CREATED, 'hh');
--12
SELECT TRUNC(CREATED, 'hh'), COUNT(*)  
FROM siebel.S_EVT_ACT
WHERE CREATED >= TRUNC(SYSDATE - 183) 
AND S_EVT_ACT.TEMPLATE_FLG='P'
GROUP BY TRUNC(CREATED, 'hh');
--13
SELECT TRUNC(CREATED, 'hh'), COUNT(*)
FROM siebel.S_ACT_CONTACT
WHERE ACTIVITY_ID IN (
SELECT t1.row_id FROM siebel.s_evt_act t1
LEFT JOIN siebel.s_opty t2 ON t1.opty_id = t2.row_id
LEFT JOIN siebel.S_OPTY_POSTN t3 ON t3.opty_id = t1.opty_id
WHERE ((t1.TEMPLATE_FLG <> 'Y' 
AND t1.TEMPLATE_FLG <> 'P') OR t1.TEMPLATE_FLG IS NULL) 
AND (t1.OPTY_ID IS NULL OR t2.SECURE_FLG = 'N' OR t3.opty_id IS NOT NULL) 
AND TODO_CD <> '�������� �����������')
AND CON_ID IN (
SELECT row_id FROM siebel.S_CONTACT
WHERE priv_flg = 'N' 
AND X_SBRF_FI_VIP_FLAG = 'N' 
AND EMP_FLG = 'N')
AND CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(CREATED, 'hh');
--14
SELECT  TRUNC(CREATED, 'hh'), COUNT(*) 
FROM siebel.S_NOTE_OPTY
WHERE SRC_ROW_ID IN (SELECT row_id FROM siebel.s_opty)
AND CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(CREATED, 'hh');
--15
SELECT  TRUNC(CREATED, 'hh'), COUNT(*)
FROM siebel.CX_COP_RATE
WHERE par_row_id IN (
SELECT t1.row_id
FROM siebel.s_party t1 
LEFT JOIN siebel.s_org_ext t2 ON t1.row_id = t2.row_id
WHERE t1.party_type_cd = 'Organization' 
AND t2.INT_ORG_FLG = 'N')
AND TYPE = 'Actual Rate'
AND CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(CREATED, 'hh');
--16
SELECT TRUNC(CREATED, 'hh'), COUNT(*) 
FROM siebel.S_CON_ADDR
WHERE ACCNT_ID IN (
SELECT t1.row_id
FROM siebel.s_party t1 
LEFT JOIN siebel.s_org_ext t2 ON t1.row_id = t2.row_id
WHERE t1.party_type_cd = 'Organization' 
AND t2.INT_ORG_FLG = 'N')
AND CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(CREATED, 'hh');
--17
SELECT TRUNC(t1.CREATED, 'hh'), COUNT(*)
FROM siebel.S_FN_OFFR_COLT t1
WHERE t1.OPTYPRD_ID IN (
SELECT t2.row_id
FROM siebel.s_revn t2
WHERE t2.TYPE_CD <> 'Loan Offer' 
AND row_id IN (
SELECT DISTINCT OPTY_PRD_ID
FROM siebel.S_OPTYPRD_ORG
WHERE OU_ID IN (
SELECT DISTINCT PR_DEPT_OU_ID
FROM siebel.s_opty
WHERE NEW_LOAN_FLG = 'Y'
AND X_EKP_FLAG = 'N'
AND OPTY_CD = '��'))) 
AND t1.CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(t1.CREATED, 'hh');
--18
SELECT TRUNC(t1.CREATED, 'hh'), COUNT(*)
FROM siebel.S_EVT_ACT t1
LEFT JOIN siebel.S_TMPL_PLANITEM t2 ON t1.TMPL_PLANITEM_ID = t2.ROW_ID
WHERE t1.X_MON_ID IN (
SELECT row_id
FROM siebel.cx_monitoring
WHERE CALC_PROBL_GROUP IN ('������ ����', '������� ����'))
AND t1.TEMPLATE_FLG = 'P'
AND t2.X_MON_BLOCK = '���������' 
AND t1.CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(t1.CREATED, 'hh');
--19
SELECT TRUNC(CREATED, 'hh'), COUNT(*)  
FROM siebel.CX_RAT_POSTN a
WHERE CREATED >= TRUNC(SYSDATE - 183) and 
a.created_by <> '0-1'
GROUP BY TRUNC(CREATED, 'hh');
--20
SELECT TRUNC(CREATED, 'hh'),COUNT(*) 
FROM siebel.s_evt_act
WHERE opty_id IN (
SELECT  t1.row_id
FROM siebel.S_OPTY t1 
LEFT JOIN siebel.S_SALES_METHOD t2 ON t1.sales_method_id = t2.row_id
WHERE t2.name = '���������')      
AND CREATED >= TRUNC(SYSDATE - 183)
AND S_EVT_ACT.CREDIT_ACT_CD IS NOT NULL
GROUP BY TRUNC(CREATED, 'hh');
--21
SELECT TRUNC(CREATED, 'hh'),COUNT(*) 
FROM siebel.S_SRC 
WHERE SUB_TYPE='PAREVENT' 
AND CREATED >= TRUNC(SYSDATE - 183) 
GROUP BY TRUNC(CREATED, 'hh');
--22
/*+USE_NL(g e)*/ 
SELECT TRUNC(g.CREATED, 'hh'),COUNT(*) 
FROM siebel.S_SRC_GOAL g 
LEFT JOIN siebel.S_SRC e ON e.ROW_ID = g.SRC_ID
WHERE g.GOAL_TYPE_CD='Goal' 
AND e.SUB_TYPE = 'EVENT'
AND g.CREATED >= TRUNC(SYSDATE - 183) 
GROUP BY TRUNC(g.CREATED, 'hh');
--23
SELECT TRUNC(CREATED, 'hh'),COUNT(*) 
FROM siebel.S_SRC 
WHERE SUB_TYPE='EVENT' 
AND CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(CREATED, 'hh');
--24
SELECT TRUNC(c.CREATED, 'hh'),COUNT(*) 
FROM siebel.CX_LOAD_BAL_CC c 
WHERE c.created >= TRUNC(SYSDATE - 183) 
GROUP BY TRUNC(c.CREATED, 'hh');
--25
SELECT TRUNC(a.CREATED, 'hh'), COUNT(*)
FROM siebel.CX_OPTY_PART a
WHERE a.created >= TRUNC(SYSDATE - 183)
AND a.type = 'Account GSL'
AND a.ACCOUNT_ID IN
(SELECT s.row_id
FROM siebel.S_PARTY s
WHERE s.party_type_cd = 'Organization')
AND a.opty_id IN (SELECT b.row_id
FROM siebel.s_opty b
WHERE b.OPTY_CD = '��'
AND b.X_EKP_FLAG = 'N'
and b.NEW_LOAN_FLG = 'Y'
and b.INACTIVE_FLG = 'N')
GROUP BY TRUNC(a.CREATED, 'hh');
--26
/*+USE_NL(REVN OPTY s)*/ 
SELECT TRUNC(REVN.CREATED, 'hh'),COUNT(*) 
FROM siebel.S_REVN REVN
JOIN siebel.S_OPTYPRD_ORG OPTY  ON OPTY.opty_prd_id=REVN.row_id 
JOIN siebel.S_OPTY s ON revn.OPTY_ID = s.ROW_ID
WHERE REVN.TYPE_CD<>'Loan Offer' 
AND OPTY.status_cd IS NULL 
AND s.OPTY_CD = '��'
AND REVN.CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(REVN.CREATED, 'hh');
--27
SELECT TRUNC(CREATED, 'hh'),COUNT(*)  
FROM siebel.S_OPTY_POSTN
WHERE OPTY_ID IN (
SELECT row_id
FROM siebel.S_OPTY
WHERE INACTIVE_FLG = 'N'
AND OPTY_CD = '���' )
AND CREATED >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(CREATED, 'hh');
--28
SELECT TRUNC(a.CREATED, 'hh'), COUNT(*)
FROM SIEBEL.S_EVT_ACT a, SIEBEL.S_EVT_ACT_X ax
WHERE a.ROW_ID = ax.PAR_ROW_ID
AND a.TODO_CD = '������ �� ������� �������'
AND a.CREATED >= TRUNC(SYSDATE - 183)
AND ax.RESULT IS NOT NULL
GROUP BY TRUNC(a.CREATED, 'hh');
--29
SELECT TRUNC(ox.ATTRIB_28, 'hh'),COUNT(*)
FROM SIEBEL.S_OPTY o, SIEBEL.S_OPTY_X ox
WHERE o.ROW_ID = ox.PAR_ROW_ID
AND o.X_EKP_FLAG = 'Y'
AND ox.ATTRIB_28 IS NOT NULL
AND ox.ATTRIB_28 >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(ox.ATTRIB_28, 'hh');
--30
SELECT TRUNC(a.TODO_ACTL_END_DT, 'hh'), COUNT(*)
FROM SIEBEL.S_EVT_ACT a, SIEBEL.S_EVT_ACT_X ax
WHERE a.ROW_ID = ax.PAR_ROW_ID
AND a.TODO_CD = '������' /* �� ������ ��� ������� ����� */
AND a.EVT_STAT_CD = '�������'
AND a.TODO_ACTL_END_DT >= TRUNC(SYSDATE - 183)
AND ax.RESULT IS NOT NULL
AND ax.DECISION IS NOT NULL
GROUP BY TRUNC(a.TODO_ACTL_END_DT, 'hh');
--31
SELECT TRUNC(op.CREATED, 'hh'), COUNT(*)
FROM  SIEBEL.S_OPTY_POSTN op
WHERE op.CREATED >= TRUNC(SYSDATE - 183)
AND op.ROLE_CD = '�������� �� ���. ������'
GROUP BY TRUNC(op.CREATED, 'hh');
--32
SELECT TRUNC(CREATED, 'hh'), COUNT(*)
FROM SIEBEL.S_AUDIT_ITEM
WHERE CREATED >= TRUNC(SYSDATE - 183)
AND BUSCOMP_NAME = 'SBRF Lead Product Offer'
AND OPERATION_CD = 'Delete'
GROUP BY TRUNC(CREATED, 'hh');  
--33
SELECT TRUNC(s.created, 'hh'),COUNT(*)
FROM siebel.S_DOC_AGREE s, siebel.CX_PROVISION c
WHERE s.row_id = c.row_id
AND s.created >= TRUNC(SYSDATE - 183)
AND s.agree_cd='Service Level Agreement'
AND c.type_cd = '���������'
GROUP BY TRUNC(s.created, 'hh');
--34
SELECT TRUNC(a.created, 'hh'), COUNT(*)
FROM siebel.S_PER_COMM_ADDR A, siebel.S_CONTACT C
WHERE A.PER_ID = C.ROW_ID
AND A.comm_medium_cd = 'Phone'
AND A.created >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC( A.created, 'hh');
--35
SELECT TRUNC(sp.created, 'hh'), COUNT(*)
FROM siebel.S_DOC_AGREE s, S_AGREE_POSTN sp
WHERE s.ROW_ID = sp.AGREE_ID
AND sp.created >= TRUNC(SYSDATE - 183)
AND s.agree_cd='Service Level Agreement'
GROUP BY TRUNC(sp.created, 'hh');
--36
SELECT TRUNC(sp.created, 'hh'), COUNT(*)
FROM siebel.S_DOC_AGREE s, siebel.CX_AGREE_X b, S_AGREE_POSTN sp
WHERE s.ROW_ID = sp.AGREE_ID
AND sp.created >= TRUNC(SYSDATE - 183)
AND b.row_id=s.row_id
AND b.x_sbrf_agr_type='��������� �������'
GROUP BY TRUNC(sp.created, 'hh');
--37
SELECT TRUNC(a.created, 'hh'), COUNT(*)
FROM siebel.CX_MONITORING m, siebel.S_EVT_ACT a, siebel.s_lst_of_val v
WHERE m.row_id = a.x_mon_id
AND a.todo_cd = v.val
AND v.active_flg ='Y'
AND v.type ='TODO_TYPE'
AND v.desc_text='Client'
AND a.created >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(a.created, 'hh');
--38-1
--�������� ��������
SELECT TRUNC(a.CREATED, 'hh'), COUNT(*)
FROM  siebel.S_EVT_ACT a
WHERE a.TEMPLATE_FLG = 'P' and
a.CREATED >= TRUNC(SYSDATE - 183) 
GROUP BY TRUNC(a.CREATED, 'hh');
--38-2
--�������� �������� � ������� �� ����� 3 ����� � ���
select trunc(aa.created, 'hh'), count(1) from (
select b.row_id as temp_id, count(1)  from siebel.s_evt_act b 
left join siebel.s_evt_act c on c.par_evt_id = b.row_id 
where b.template_flg = 'P'
and b.created >= TRUNC(SYSDATE - 183) 
group by b.row_id
having count(1) <4) sq1
left join s_evt_act aa on aa.row_id = sq1.temp_id
group by trunc (aa.created, 'hh')
order by trunc(aa.created, 'hh') DESC;
--39
SELECT TRUNC(a.created, 'hh'), COUNT(*)
FROM siebel.CX_MONITORING m, siebel.S_EVT_ACT a, siebel.s_lst_of_val v
WHERE m.row_id = a.x_mon_id
AND a.todo_cd = v.val
AND v.active_flg ='Y'
AND v.type ='TODO_TYPE'
AND v.desc_text='TODO'
AND a.created >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(a.created, 'hh');
--40
SELECT TRUNC(s.last_upd, 'hh'),COUNT(*)
FROM siebel.S_ORG_EXT s 
WHERE s.X_DIV_STAT_CD = '�����'
AND s.last_upd >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(s.last_upd, 'hh');
--41
SELECT TRUNC(a.CREATED, 'hh'), COUNT(*)
FROM siebel.CX_OPTY_PART a, siebel.S_OPTY b, siebel.S_CONTACT c
WHERE a.CREATED >= TRUNC(SYSDATE - 183)
AND a.type = 'Contact GSL'
AND a.ACCOUNT_ID = c.ROW_ID
AND a.OPTY_ID = b.ROW_ID
AND b.OPTY_CD = '��'
AND b.X_EKP_FLAG = 'N'
AND b.NEW_LOAN_FLG = 'Y'
AND b.INACTIVE_FLG = 'N'
GROUP BY TRUNC(A.CREATED, 'hh');
--42
SELECT TRUNC(o.created, 'hh'),COUNT(*) 
FROM siebel.s_opty o
WHERE o.opty_cd = '���'
AND o.created >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(o.created, 'hh');
