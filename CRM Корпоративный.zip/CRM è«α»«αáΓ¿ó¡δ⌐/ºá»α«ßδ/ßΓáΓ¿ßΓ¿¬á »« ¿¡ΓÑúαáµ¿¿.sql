select * from EX_NT_SERV_LOG r where r.created > sysdate -1
