select srvr_task_id_val, srvr_proc_id_val, srvr_thread_id_val, srvr_end_ts+3/24 srvr_end_ts, srvr_user_name, srvr_comp_name, srvr_status, t.* 
from siebel.s_srm_task_hist t 
where 1=1 
and srvr_proc_id_val = 60962
/*and in ('SBRF PPRB JMS Receiver Multithreaded Async')*/
order by last_upd desc; 



select /*+parallel(512)*/ p.PID, s.USERNAME,s.MACHINE,s.PROGRAM, s.SQL_ID, s.STATE,s.STATUS,s.SERVER, 
t.srvr_end_ts+3/24 srvr_end_ts, t.srvr_comp_name, t.last_upd,t.srvr_host_name,t.srvr_logfile_name,t.srvr_status,t.srvr_task_type
from v$process p,v$session s,siebel.s_srm_task_hist t 
where p.ADDR=s.PADDR
and s.OSUSER='siebel'
/*and s.STATUS = 'ACTIVE'*/
and t.srvr_proc_id_val = p.SPID
order by t.last_upd desc; 
