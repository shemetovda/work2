BEGIN
    DBMS_STATS.GATHER_SCHEMA_STATS(ownname            => 'SIEBEL',
                                   estimate_percent   => DBMS_STATS.AUTO_SAMPLE_SIZE,
                                   granularity        => 'ALL',
                                   method_opt         => 'FOR ALL INDEXED COLUMNS SIZE 254',
                                   degree             => DBMS_STATS.AUTO_DEGREE,
                                   cascade            => TRUE,
                                   no_invalidate      => FALSE);
END;
/ 
