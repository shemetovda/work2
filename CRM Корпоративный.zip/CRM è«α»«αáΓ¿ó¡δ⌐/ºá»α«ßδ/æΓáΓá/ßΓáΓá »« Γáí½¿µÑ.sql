begin
  DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CC_INTERACT"', estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => DBMS_STATS.AUTO_DEGREE,cascade => TRUE,no_invalidate => FALSE);
end;
/
