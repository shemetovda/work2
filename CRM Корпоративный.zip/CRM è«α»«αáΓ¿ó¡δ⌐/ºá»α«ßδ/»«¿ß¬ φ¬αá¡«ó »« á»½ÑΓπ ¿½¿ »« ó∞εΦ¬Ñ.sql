-- ����� ������� �� ������ ��� �� ������
select distinct
    ap.name ������,
    v.name �����,
    symi.string_value �����1,  
    symi_s.string_value �����2
from
    siebel.s_applet ap
    join siebel.s_repository r on ap.repository_id = r.row_id and r.name = 'Siebel Repository'
    left join siebel.s_view_wtmpl_it vit on vit.applet_name = ap.name and ap.repository_id = vit.repository_id and nvl(vit.inactive_flg,'N') = 'N'
    left join siebel.s_view_web_tmpl vt on vit.view_web_tmpl_id = vt.row_id
    left join siebel.s_view v on vt.view_id = v.row_id
    left join siebel.s_screen_view sv on sv.view_name = v.name and sv.repository_id = ap.repository_id and nvl(sv.inactive_flg,'N') = 'N'
    left join siebel.s_sym_str sym on sv.viewbar_text_ref = sym.name
    left join siebel.s_sym_str_intl symi on symi.sym_str_id = sym.row_id and symi.lang_cd = 'RUS'  
    left join siebel.s_screen s on sv.screen_id = s.row_id  
    left join siebel.s_sym_str sym_s on s.viewbar_text_ref = sym_s.name
    left join siebel.s_sym_str_intl symi_s on symi_s.sym_str_id = sym_s.row_id and symi_s.lang_cd = 'RUS'    
    join siebel.s_buscomp bc on bc.name = ap.buscomp_name and ap.repository_id = bc.repository_id
    join siebel.s_field f on f.buscomp_id = bc.row_id
    left join siebel.s_join j on j.name = f.join_name and j.buscomp_id = bc.row_id
    left join siebel.s_control ctrl on ctrl.applet_id = ap.row_id and nvl(ctrl.inactive_flg,'N') = 'N' and ctrl.field_name = f.name   
    left join siebel.s_sym_str sym_c on ctrl.caption_ref = sym_c.name
    left join siebel.s_sym_str_intl symi_c on symi_c.sym_str_id = sym_c.row_id and symi_c.lang_cd = 'RUS'   
    left join siebel.s_list l on l.applet_id = ap.row_id
    left join siebel.s_list_column lst on  lst.list_id = l.row_id and nvl(lst.inactive_flg,'N') = 'N' and lst.field_name = f.name   
    left join siebel.s_sym_str sym_l on lst.display_name_ref = sym_l.name
    left join siebel.s_sym_str_intl symi_l on symi_l.sym_str_id = sym_l.row_id and symi_l.lang_cd = 'RUS' 
     
where
    v.name = 'SBRF SR BeforeClaim List View' -- ������
    /*ap.name = 'SBRF SIS Account List Applet' -- ���� �� ������*/
    and (ctrl.field_name is not null or lst.field_name is not null)
