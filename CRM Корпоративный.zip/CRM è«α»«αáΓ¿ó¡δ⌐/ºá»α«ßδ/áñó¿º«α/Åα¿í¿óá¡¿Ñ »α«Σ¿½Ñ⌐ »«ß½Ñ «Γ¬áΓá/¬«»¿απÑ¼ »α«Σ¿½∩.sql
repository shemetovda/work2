--�������� �������
BEGIN
  DBMS_SQLTUNE.PACK_STGTAB_SQLPROF (  
    profile_name         => 'SYS_SQLPROF_0164d4e5d7910000'
,   staging_table_name   => 'test1'
,   staging_schema_owner => 'sysman' 
);
END;
/

BEGIN
  DBMS_SQLTUNE.PACK_STGTAB_SQLPROF (  
    profile_name         => 'SYS_SQLPROF_0164d4eceea00001'
,   staging_table_name   => 'test1'
,   staging_schema_owner => 'sysman' 
);
END;
/

BEGIN
  DBMS_SQLTUNE.PACK_STGTAB_SQLPROF (  
    profile_name         => 'SYS_SQLPROF_0164d4ffbf700002'
,   staging_table_name   => 'test1'
,   staging_schema_owner => 'sysman' 
);
END;
/ 
