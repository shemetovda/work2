--2
SELECT TRUNC(a.CREATED) as date_created, COUNT(*)
FROM siebel.S_ORG_EXT a
WHERE 
a.CREATED >= TRUNC(SYSDATE - 183) and 
a.int_org_flg = 'N' and
a.created_by <> '0-1'
GROUP BY TRUNC(a.CREATED)
order by date_created DESC;
--8
SELECT TRUNC(a.CREATED),COUNT(*)
FROM siebel.S_ACCNT_POSTN a
WHERE 
a.POSITION_ID IS NOT NULL and
a.CREATED >= TRUNC(SYSDATE - 183) and
a.created_by <> '0-1'
GROUP BY TRUNC(a.CREATED);
--19
SELECT TRUNC(CREATED), COUNT(*)  
FROM siebel.CX_RAT_POSTN a
WHERE CREATED >= TRUNC(SYSDATE - 183) and 
a.created_by <> '0-1'
GROUP BY TRUNC(CREATED);
--38
--�������� ��������
SELECT TRUNC(a.CREATED), COUNT(*)
FROM  siebel.S_EVT_ACT a
WHERE a.TEMPLATE_FLG = 'P' and
a.CREATED >= TRUNC(SYSDATE - 183) 
GROUP BY TRUNC(a.CREATED);

--�������� �������� � ������� �� ����� 3 ����� � ���
select trunc(aa.created), count(1) from (
select b.row_id as temp_id, count(1)  from siebel.s_evt_act b 
left join siebel.s_evt_act c on c.par_evt_id = b.row_id 
where b.template_flg = 'P'
and b.created >= TRUNC(SYSDATE - 183) 
group by b.row_id
having count(1) <4) sq1
left join s_evt_act aa on aa.row_id = sq1.temp_id
group by trunc (aa.created)
order by trunc(aa.created) DESC;
--40
SELECT TRUNC(s.last_upd),COUNT(*)
FROM siebel.S_ORG_EXT s 
WHERE s.X_DIV_STAT_CD = '�����'
AND s.last_upd >= TRUNC(SYSDATE - 183)
GROUP BY TRUNC(s.last_upd);

