--�������� ���� � TESTCRMNTDATA
delete 
from S_PER_RESP a 
where a.resp_id in 
(select b.row_id 
from s_resp b 
where b.name in ('SBRF CC Administrator','Admin RO','Call Center Administrator'))
and a.per_id in (
select c.row_id from s_user c where c.login in ('TESTCRMNTDATA'));
commit;
