select /*+parallel(128)*/ 'InitiateRatingAdjustment',
count(*) as "���������",
to_char(round(avg(max(created) - min(created)), 10)) * 60 * 24 * 60 as "�����"
  from S_EAI_QUEUE_ITM q
where 1 = 1
   and q.x_xml_text like '%InitiateRatingAdjustment%'
   and created between
       to_date('16.02.2017 16:45:00', 'dd.mm.yyyy hh24:mi:ss') and
       to_date('16.02.2017 20:45:00', 'dd.mm.yyyy hh24:mi:ss')
group by q.queue_ref_val
; 
 
select /*+parallel(128)*/ q.queue_ref_val,min(q.created),max(q.created),to_char(round((max(q.created) - min(q.created)), 10)) * 60 * 24 * 60 
  from S_EAI_QUEUE_ITM q
where 1 = 1
   and q.x_xml_text like '%InitiateRatingAdjustment%'
   and created between
       to_date('16.02.2017 16:45:00', 'dd.mm.yyyy hh24:mi:ss') and
       to_date('16.02.2017 20:45:00', 'dd.mm.yyyy hh24:mi:ss')
group by q.queue_ref_val
