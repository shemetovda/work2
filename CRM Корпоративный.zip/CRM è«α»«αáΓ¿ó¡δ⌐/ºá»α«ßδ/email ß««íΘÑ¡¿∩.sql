SELECT count(1) FROM s_apsrvr_req WHERE status IN ('ACTIVE','QUEUED')  and created > sysdate -1
