select  distinct 'select count(1) from ' || a.TABLE_NAME ||';', a.TABLE_NAME/*,a.COLUMN_NAME*/ from ALL_TAB_COLUMNS a 
where lower (a.COLUMN_NAME) like '%mail%'
and a.owner = 'SIEBEL'

select  distinct 'select distinct ' || a.COLUMN_NAME || ' from ' || a.TABLE_NAME ||';', a.TABLE_NAME/*,a.COLUMN_NAME*/ from ALL_TAB_COLUMNS a 
where a.owner = 'SIEBEL'
and lower (a.COLUMN_NAME) like '%mail%'
and a.TABLE_NAME in 
('CX_AGR_CONTACT','CX_CALL_LST_SA','CX_CASH_OBJ_OFF','CX_CB_ACCOUNT_X','CX_CB_ACC_GROUP','CX_CB_CMMT_AT','CX_CB_CONTACT_X','CX_CC_EMP_IMP',
'CX_CC_INTERACT','CX_COMM','CX_LD_PROD_OFFR','CX_LEAD_POSTN','CX_MIGR_POS_DT','CX_MSH_BORR_LOG','CX_MSH_REGISTRY','CX_OPRDRG_C7M_X',
'CX_OPTY_PART','CX_OPTY_SBBOL_X','CX_PR_AGR_BRR_X','CX_QUESTION_X','CX_TXB_EMAILS','EIM_AGREEMENT','EIM_FN_ACCNT4','S_ADDR_PER',
'S_APPLET','S_CALL_LST_ACC','S_CALL_LST_CON','S_CONTACT','S_CONTACT_TNTX','S_CON_ADDR','S_EVT_ACT','S_EVT_ACT_X',
'S_EVT_MAIL','S_OPTY','S_ORG_EXT','S_ORG_EXT_IMPT','S_ORG_EXT_X','S_ORG_PRTNR','S_PARTY_REL','S_SRC','S_SRV_REQ','S_SRV_REQ1_FNXM','S_SRV_REQ_X','S_UCM_ORG_CHILD','S_UCM_ORG_EXT')

select distinct EMAIL from CX_CC_EMP_IMP;
select distinct INITIATOR_EMAIL,EMAIL from CX_LD_PROD_OFFR;
select distinct EMAIL_ADDR from CX_MIGR_POS_DT;
select distinct EMAIL from CX_OPRDRG_C7M_X;
select distinct X_ACCOUNT_EMAIL from CX_OPTY_PART;
select distinct EMAIL_TO,EMAIL_FROM from CX_TXB_EMAILS;
select distinct X_EMAIL_ADDRESS from S_CALL_LST_ACC;
select distinct EMAIL_ADDR,ALT_EMAIL_ADDR from S_CONTACT;
select distinct CONTACT_EMAIL from S_EVT_ACT_X;
select distinct MAIN_EMAIL_ADDR,ALT_EMAIL_ADDR from S_ORG_EXT;
select distinct SR_CONTACT_EMAIL from S_SRV_REQ_X;
select distinct X_EMAIL_ADDRESS from S_UCM_ORG_CHILD;


--NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru

update CX_CC_EMP_IMP set EMAIL = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
--update CX_LD_PROD_OFFR set INITIATOR_EMAIL = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru', EMAIL = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
--update CX_MIGR_POS_DT set EMAIL_ADDR = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
--update CX_OPRDRG_C7M_X set EMAIL = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
--update CX_OPTY_PART set X_ACCOUNT_EMAIL = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
update CX_TXB_EMAILS set EMAIL_TO = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru', EMAIL_FROM = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
update S_CALL_LST_ACC set X_EMAIL_ADDRESS = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
--update S_UCM_ORG_CHILD set X_EMAIL_ADDRESS = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
--update S_CONTACT set EMAIL_ADDR = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru', ALT_EMAIL_ADDR = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
update S_EVT_ACT_X set CONTACT_EMAIL = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
update S_ORG_EXT set MAIN_EMAIL_ADDR = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru', ALT_EMAIL_ADDR = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
--update S_SRV_REQ_X set SR_CONTACT_EMAIL = 'NTSiebelCorpuser@sbt-oaar-347.ca.sbrf.ru';
