--������ FDR 
select /*+  full(sd) parallel (sd, 32)*/
sd.crash_ts,
'_P' || lpad(sd.process_id_val, 6, '0') || '.fdr' as fdr_name,
sd.comp_name,
sd.server_name,
sd.error_msg,
sd.failure_summary
  from s_diag sd      
where sd.server_name in ('h29-ld1', 'pony10', 'crmgwnt', 'p12-ld1')
   /*and sd.error_msg not in ('Internal: Killed by parent','Internal: Error %1 reading a message from the client')*/
   and sd.crash_ts is not null
   and sd.crash_ts > sysdate - 1
order by sd.crash_ts desc;

