#!/usr/bin/bash

echo "-> stop siebsrvr"
. /siebel/siebel81/crm/siebsrvr/siebenv.sh
stop_server all

