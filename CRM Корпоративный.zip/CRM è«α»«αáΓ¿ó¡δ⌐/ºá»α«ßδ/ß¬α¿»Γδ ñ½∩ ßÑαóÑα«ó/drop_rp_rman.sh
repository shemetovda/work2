. .profile.crmrmir
rman target /  @drop_rp.rman
