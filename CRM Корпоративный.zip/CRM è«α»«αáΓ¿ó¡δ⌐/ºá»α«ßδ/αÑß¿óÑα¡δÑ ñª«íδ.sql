select b.DISPLAY_NAME,b.name,a.req_type_cd,a.* from s_srm_request a
left join s_srm_action b on a.action_id = b.row_id
where /*a.req_type_cd in ('RPT_PARENT') --RPT_INSTANCE
and a.status = 'ACTIVE'
and */b.DISPLAY_NAME in ('SBRF IANUA JMS Receiver Multithreaded Async')


select b.DISPLAY_NAME,a.req_type_cd,a.* from s_srm_request a
left join s_srm_action b on a.action_id = b.row_id
where /*a.req_type_cd in ('RPT_PARENT')
and*/ b.NAME like '%SBRFIANUAJMSRcvrAsync%'


--���� ����� ESB.CRM.CC.REQUEST - SBRFIANUAJMSRcvrAsync - SBRF IANUA JMS Receiver Multithreaded Async
UPDATE SIEBEL.S_SRM_REQUEST a
SET STATUS = 'CANCELED', a.db_last_upd_src = 'stop14112018'
select * from SIEBEL.S_SRM_REQUEST a
       WHERE a.action_id in (SELECT b.row_id
                          FROM s_srm_action b
                          WHERE b.DISPLAY_NAME in ('SBRF IANUA JMS Receiver Multithreaded Async'));
