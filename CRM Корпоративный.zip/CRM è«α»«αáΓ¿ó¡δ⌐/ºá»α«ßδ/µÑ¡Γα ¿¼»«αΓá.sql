select row_id, type_cd, start_dt, end_dt from siebel.CX_IMP_CENTER /*where start_dt >= to_timestamp ('27.03.2019','DD.MM.YYYY hh24:mi:ss') and created_by = '1-HLCAIPO';*/
order by start_dt desc
