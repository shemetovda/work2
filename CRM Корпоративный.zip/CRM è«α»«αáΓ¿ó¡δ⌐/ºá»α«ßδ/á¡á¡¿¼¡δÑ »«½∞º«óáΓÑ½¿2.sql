select count(1)
  from siebel.S_SRM_TASK_HIST t
where t.srvr_comp_name = 'FINSObjMgr_oui'
   and t.created > to_date('15.02.2017 10:37:00','dd/mm/yyyy HH24:MI:SS')
   and t.srvr_user_name <> 'siebelshared'
order by 1 desc
;
select *
  from siebel.S_SRM_TASK_HIST t
where t.srvr_comp_name = 'FINSObjMgr_oui'
   and t.created > to_date('15.02.2017 10:37:00','dd/mm/yyyy HH24:MI:SS')
   and t.srvr_user_name <> 'siebelshared'
   and t.srvr_end_ts is not null
order by 1 desc
