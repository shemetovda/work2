select a.name,a.state_cd, b.name,b.status_cd,b.comments,b.start_dt,b.end_dt,b.input_rows,b.error_rows,b.success_rows
from EX_INT_TASK a,EX_INT_PROC_LOG b
where a.row_id=b.task_id
/*and a.row_id = '1-I3F5D1T'*/
order by b.start_dt desc
