  select a.name,a.desc_text,/*count(b.comments)*/b.comments/*,b.x_xml_text*/  /*count(1)*/
  from siebel.s_eai_queue a, siebel.S_EAI_QUEUE_ITM b
  where a.row_id = b.QUEUE_ID
        and name like '2018-11-12%' and name not like '%Rs' 
        and name not like '%MDM%' and name not like '%PPRB%' 
        and name not like '%BPM.EKP%' and name not like '%UPRPA.%' 
        and name not like '%OCR.%'  and name not like '%SBBOL%'
        and name not like '%BPMMB%' and name not like '%SAP%'
        and name not like '%UCP%' and name not like '%SR%'
        and name not like '%SMS%' and name not like '%Site%'
        and name not like '%EKS%' and name not like '%LDB%' and name not like '%LCP%'
        and name not like '%MSH%' and name not like '%AEF%'
        and name not like '%ASKA%' and name not like '%C7M%'
        and name not like '%BPM%' and name not like '%Bfs%' and name not like '%2018-11-12..%'
/*        and name not like '%MRMKompGetProducts.GetClientProducts%'
        and name not like '%MRMCIBUpdateOpptyMap.PutLegalClientOppt%' and name not like '%MRMCIBUpdateContact.PutLegalClientConta%'
        and name not like '%MRMCIBUpdateAction.PutLegalClientManage%' and name not like '%UpdateClientResponce.UpdateComplianceRq%'
        and name not like '%MRMCIBGetSubordinates.GetClientManagerL%' and name not like '%MRMCIBGetOpptyDetails.GetLegalOpportuni%'
        and name not like '%MRMCIBGetOpptyByAccountId.GetLegalOppor%' and name not like '%MRMCIBGetHoldingParticipantsList.GetHo%'
        and name not like '%MRMCIBGetContacts.GetLegalClientContact%' and name not like '%MRMCIBGetContactsByOpptyId.GetLegalClie%'
        and name not like '%MRMCIBGetContactsByAccountId.GetLegalCl%' and name not like '%MRMCIBGetClients.GetLegalClientList%'
        and name not like '%MRMCIBGetClientsByPositionId.GetLegalCl%' and name not like '%MRMCIBGetActionsByHoldingId.GetLegalCli%'
        and name not like '%MRMCIBGetActionsByAccountId.GetLegalCli%' and name not like '%MRMCIBGetActionDetails.GetLegalClientMa%'
        and name not like '%MRMCIBCreateContact.PutLegalClientConta%' and name not like '%MRMCIBCreateAction.PutLegalClientManage%'
         and name not like '%IANUAERMUpdateLead.CreateLegalLeadAppli%'
        and name not like '%IANUAERMUpdateAction.PutLegalClientMana%' and name not like '%IANUAERMGetClientsByLogin.GetLegalClien%'
        and name not like '%IANUAERMGetClientInfo.GetLegalClientPro%' and name not like '%IANUAERMGetActionDetails.GetLegalClient%'
        and name not like '%IANUAERMCreateLead.CreateLegalLeadAppli%' and name not like '%TagList%'
        and name not like '%ERMGetOpptyByPositionId.GetLegalOpportu%' and name not like '%ERMGetOpptyByAccountId%'
        and name not like '%ERMGetManagerSalesPlan.GetManagerSalesP%' and name not like '%ERMGetManagerAssetList.GetManagerSalesP%'
        and name not like '%ERMGetLeadDetails.GetLegalLeadDetails%' and name not like '%ERMGetContactProfile.GetLegalClientCont%'
        and name not like '%ERMGetClients.GetLegalClientList%' and name not like '%ERMGetClientInfoSMB.GetLegalClientProfi%'
        and name not like '%ERMCreateOppty%'  and name not like '%EFSTMTOUpdateLead%'
        and name not like '%EFSTMTOUpdateContact.PutLegal%' and name not like '%EFSTMTOGetContactsByAccountId%'
        and name not like '%EFSCompassUpdateOpptySalary.PutLegalOpp%' and name not like '%EFSCompassUpdateContact.PutLegalClientC%'
         and name not like '%EFSCompassUpdateContact.PutLegalClientC%'*/
        and b.comments is not null
/*group by a.name,a.desc_text*/
/*having count(b.comments) > 100*/
order by 3 desc
