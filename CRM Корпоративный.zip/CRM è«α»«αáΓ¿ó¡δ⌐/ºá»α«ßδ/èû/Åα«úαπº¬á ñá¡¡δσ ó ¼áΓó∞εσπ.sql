begin
dbms_mview.refresh('siebel.sbrf_phone_search_mv');
end;
