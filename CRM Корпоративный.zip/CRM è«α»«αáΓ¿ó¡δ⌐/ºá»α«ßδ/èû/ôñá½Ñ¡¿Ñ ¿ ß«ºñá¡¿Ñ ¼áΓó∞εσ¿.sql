-- Autor: Kharlamova Tatiana
-- Change: CRP-44832, add search for all account
-- Change: CRP-45470, add create index siebel.sbrf_phone_search_mv_idx2
-- Description: Create materialized view for search account by phone for corporate call center

declare
  cnt number  := 0;
begin
    select count(*)
    into cnt
    from all_tables      
    where table_name = 'SBRF_PHONE_SEARCH_MV' AND owner = 'SIEBEL';

    if cnt = 1 then
        execute immediate 'DROP MATERIALIZED VIEW siebel.SBRF_PHONE_SEARCH_MV';
    end if;
exception
    when NO_DATA_FOUND then
        DBMS_OUTPUT.put_line('Error: ' || SQLERRM);
    when others then
        DBMS_OUTPUT.put_line('Error: ' || SQLERRM);
end;
/

create materialized view siebel.sbrf_phone_search_mv
tablespace DATA01 build deferred
refresh on demand complete start with sysdate + 3/24 next sysdate + 1
as
select    
    ph_num phone,
    dt.account_id
from
    (
    -- account phone number
    select
        -- cut phone number before star (delete add number)
        regexp_replace(regexp_substr(adr.addr,'[^*]*'),'\D') ph_num,        
        adr.per_id account_id
    from 
        siebel.s_per_comm_addr adr,
        siebel.s_org_ext oe
    where 
        adr.comm_medium_cd = 'Phone' 
        and adr.per_id = oe.row_id
        and adr.addr is not null
        and oe.int_org_flg = 'N'
    union
    -- account contact phone number 
    select
        regexp_replace(regexp_substr(cnt_phone.ph_num,'[^*]*'),'\D') ph_num,
        pp.party_id account_id
    from
        (
        -- work phone contact
        select 
            cnt.work_ph_num ph_num,
            cnt.row_id contact_id 
        from 
            siebel.s_contact cnt
        where
            cnt.work_ph_num is not null
        union
        -- cell phone contact 
        select 
            cnt.cell_ph_num ph_num,
            cnt.row_id contact_id 
        from 
            siebel.s_contact cnt
        where
            cnt.cell_ph_num is not null
        union
        -- phone from table s_per_comm_addr, for contact
        select
            adr.addr ph_num,
            adr.per_id contact_id 
        from 
            siebel.s_per_comm_addr adr,
            siebel.s_contact cnt
        where 
            adr.comm_medium_cd = 'Phone' 
            and adr.per_id = cnt.row_id
            and adr.addr is not null
        ) cnt_phone,
        siebel.s_party_per pp,
        siebel.s_org_ext oe
    where
        pp.person_id = cnt_phone.contact_id
        and pp.party_id = oe.par_row_id
        and oe.int_org_flg = 'N'
    ) dt;

create index siebel.sbrf_phone_search_mv_idx1 on sbrf_phone_search_mv(phone) tablespace INDX;

create index siebel.sbrf_phone_search_mv_idx2 on sbrf_phone_search_mv(account_id) tablespace INDX;

grant select on siebel.sbrf_phone_search_mv to sse_role;
