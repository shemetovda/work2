select * from CX_CC_PILOT c where c.pilot_name = '��. FCR'
