alter materialized view siebel.sbrf_phone_search_mv refresh on demand;
alter materialized view siebel.sbrf_email_search_mv refresh on demand;
