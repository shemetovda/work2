SELECT distinct t.name, count (1)
FROM SIEBEL.CX_RATING_MODEL T, SIEBEL.CX_RATING c
where c.CREATED >= TRUNC (SYSDATE - 183)  
and c.model_id=t.row_id
and c.postn_id is not null
group by t.name
order by 2 desc
