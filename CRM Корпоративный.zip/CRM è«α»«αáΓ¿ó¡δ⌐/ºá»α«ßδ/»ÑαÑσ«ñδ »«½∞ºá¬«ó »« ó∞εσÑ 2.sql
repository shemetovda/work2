select viewha, max(polz) from  
(SELECT distinct a.ACTION viewha, TRUNC(a.CREATED, 'hh') dat, count(regexp_substr(a.client_info,'[^,]+',1,2)) polz
FROM siebel.cx_pss_sbl a
WHERE a.nav_time is not null
and CREATED >= TRUNC (SYSDATE - 14)
GROUP BY ACTION, TRUNC(CREATED, 'hh'))
group by viewha
order by viewha
