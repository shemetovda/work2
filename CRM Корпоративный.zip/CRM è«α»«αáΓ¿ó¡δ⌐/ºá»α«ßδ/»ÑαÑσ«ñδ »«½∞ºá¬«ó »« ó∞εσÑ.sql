SELECT a.ACTION, TRUNC(a.CREATED, 'hh'), /*count(*)*/ count(regexp_substr(a.client_info,'[^,]+',1,2))
FROM siebel.cx_pss_sbl a
WHERE a.nav_time is not null
and CREATED >= TRUNC (SYSDATE - 14)
GROUP BY ACTION, TRUNC(CREATED, 'hh')
