set pagesize 1000 linesize 32767 long 20000000 longchunksize 20000000 serveroutput on size unlimited
set trimspool on
define out4script='echo off feedback off verify off heading off timing off'
define out4screen='echo on termout on feedback on verify on heading on timing on'
set &out4screen

spool stat_10.log

exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_INT_BU"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_INT_LSX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_INT_MED"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_INT_TNTX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_INT_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_INT_XM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_LIT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_LN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_LN_PROD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_MSG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_MSG_LANG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_MSG_RESP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROD_MSG_VAR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROG_ARG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROG_DEFN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PROJECT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PRTL_ITEM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PRTL_PAGE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PRTL_SCTN_ITM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PS_CONTACT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_QF_TMPL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_QF_TMPL_ITEM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_QTA_ACC_PD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_QUOTA_ACCNT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_REPORT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_REPORT_FIELD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_REPORT_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_REPOUTPT_PSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RESP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RESP_BU"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_REVN"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_REVN_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RT_SVC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RT_SVC_M_ARG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RT_SVC_METH"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RT_SVC_SCRPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RULE_DATATYPE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RULE_TMPL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RULE_TMPL_ARG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_RULE_TMPL_CAT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SALES_ACT"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SALES_METHOD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHED_CAL_HRS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHM_PHASE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHM_PHS_USG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHM_PROC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHM_PROC_VAR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHM_STEP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHMPROC_DBMS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHMST_DBSCPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHMSTEP_FROM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHMSTEP_SCPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCHMSTEP_TO"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCR_MENU_ITEM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCR_MITM_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCR_VIEW_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCREEN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCREEN_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SCREEN_VIEW"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SD_CFG_ITEM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SD_FIELD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SD_FIELD_MAP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SD_TRANSL_MAP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SERVICE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SERVICE_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SERVICE_M_ARG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SERVICE_METH"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SERVICE_SBSYS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SERVICE_SCRPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SERVICE_UPROP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SM_BC_RSTRCT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SM_CATEGORY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SM_STATE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SM_TRANSITION"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SM_TRNS_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SORT_CHAR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SR_REL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_ADM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_CAT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_CTG_FLD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_CTGRY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_CTRESFLD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_DCT_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_DEF"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_DEF_CAT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_DRILLDN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_FILTRFLD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_FLD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_FLD_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_INDEX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_INDX_FLD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_PICKVIEW"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_RESULFLD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_TABLE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCH_VIS_VIEW"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCHENG_FIELD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCHENG_PVIEW"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRCHENG_TABLE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRM_ACT_PARAM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRM_ACTION"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRM_DATA"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRM_REQ_PARAM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRM_REQUEST"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRM_TASK_HIST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRV_ACT"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRV_REQ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRV_REQ_BU"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRV_REQ_LOYX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRV_REQ_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_SRV_REQ1_FNXM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_STATE_MODEL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_STG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);

spool off

exit
