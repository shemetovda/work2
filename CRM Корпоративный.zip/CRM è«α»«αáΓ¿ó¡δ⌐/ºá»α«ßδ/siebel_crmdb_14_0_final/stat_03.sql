set pagesize 1000 linesize 32767 long 20000000 longchunksize 20000000 serveroutput on size unlimited
set trimspool on
define out4script='echo off feedback off verify off heading off timing off'
define out4screen='echo on termout on feedback on verify on heading on timing on'
set &out4screen

spool stat_03.log

exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PARTY"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 64, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PARTY_PER"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 64, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PARTY_REL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 64, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_PARTY_RPT_REL"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 64, cascade => TRUE);
rem exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_OPTY"', estimate_percent => null, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 64, cascade => TRUE);
begin
  sys.dbms_stats.gather_table_stats(ownname => 'SIEBEL'
                                   ,tabname => 'S_OPTY'
                                   ,estimate_percent => null
                                   -- ,method_opt => 'FOR COLUMNS INACTIVE_FLG SIZE SKEWONLY'
                                   ,method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254 FOR COLUMNS SIZE AUTO INACTIVE_FLG'
                                   ,degree => 64
                                   ,granularity => 'ALL'
                                   ,cascade => true
                                   ,no_invalidate => false
                                   ,force => false
                                   );
end;
/

spool off

exit
