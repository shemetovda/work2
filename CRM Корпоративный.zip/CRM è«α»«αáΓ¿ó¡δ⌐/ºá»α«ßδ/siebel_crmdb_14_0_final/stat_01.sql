set pagesize 1000 linesize 32767 long 20000000 longchunksize 20000000 serveroutput on size unlimited
set trimspool on
define out4script='echo off feedback off verify off heading off timing off'
define out4screen='echo on termout on feedback on verify on heading on timing on'
set &out4screen

spool stat_01.log

exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_EVT_ACT"', estimate_percent => null, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 128, cascade => TRUE, no_invalidate => true);

spool off

exit
