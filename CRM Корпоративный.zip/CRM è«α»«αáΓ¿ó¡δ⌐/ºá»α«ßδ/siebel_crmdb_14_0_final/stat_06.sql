set pagesize 1000 linesize 32767 long 20000000 longchunksize 20000000 serveroutput on size unlimited
set trimspool on
define out4script='echo off feedback off verify off heading off timing off'
define out4screen='echo on termout on feedback on verify on heading on timing on'
set &out4screen

spool stat_06.log

exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_PART"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_SBBOL_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_STNDRT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_WGCARDS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PA_QST_ADMIN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PA_QST_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PA_STG_LOG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PART_GSL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PARTY_BENEF"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PARTY_GSZ_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PARTY_SHARE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PER_ORG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PLAN_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_POS_ACCESS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_POSTN_ORG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PRD_CONTRACT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PRD_ORG_LOV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PRD_PROJECT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PRIORITY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROD_OFFER"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROD_OFFR_AT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROD_SM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROD_SUM_LIM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROD_TYPE_MX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROF_CALC_XM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROF_RESP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROFILE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROJ_OPK_IND"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PROMISES"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PRSL_CHCKLST"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PRSPC_CLMGR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_PSS_SBL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_AD"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_AU"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_COEFF"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_GSZ_MIX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_MDL_AD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_MDL_ADV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_MDL_AU"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_MDL_NQD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_MDL_NQDV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_MDL_PER"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_MDL_QD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_NQD"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_PER"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_POSTN"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_QD"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_RAT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RAT_RAT_VAL"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RATE_PROD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RATING"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RATING_MDL_B"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RATING_MODEL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RATING_SIGNL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RATING_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RC_USE_IN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REFERENCE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REG_DOC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REGION"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REJ_ACC_INF"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REQ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REQ_COMMENT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REQ_SERV_INT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REQ_TEAM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REQ_UP_CAT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REQ_UP_SERV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_REQUEST_UP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RET_PL_PAY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RISK_CRIT_XM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ROUTER_PARAM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RTNG_MDL_INT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_RVPS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SANCT_LST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SAS_PARAM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SBBOL_DOC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SBBOL_MSG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SBL_DOCS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SBL_MESSAGES"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SDH_SL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SECT_CLS_COD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SEG_GROUP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SEG_HIST"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SEG_PERIOD"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SEG_REQ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SEGM_IMP_DT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SHRD_AC_ATT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SM_NKPLOV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SMO_MRK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SNL_HST"', estimate_percent => 3, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SR_CLASS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SR_CONCLUSN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SR_EMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SR_EXPERTISE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SR_FN_IDS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SR_IMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SR_SLA"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ST_GUAR_LOG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_STATE_GUARNT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_STG_ACT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_STG_ACT_ARG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_STOPLIST_XM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_STRATEGY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SWIFT_XM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_SYS_REF_INT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_TASK_OBJ_REL"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_TOKEN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_TR_DOC_TMPL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UC_AUDIT_TRL"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UC_LINK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UNIF_ACCNT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UNIV_LOG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UNIV_TMPL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);

spool off

exit
