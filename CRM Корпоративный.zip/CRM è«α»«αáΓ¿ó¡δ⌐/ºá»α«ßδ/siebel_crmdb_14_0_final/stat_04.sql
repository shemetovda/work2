set pagesize 1000 linesize 32767 long 20000000 longchunksize 20000000 serveroutput on size unlimited
set trimspool on
define out4script='echo off feedback off verify off heading off timing off'
define out4screen='echo on termout on feedback on verify on heading on timing on'
set &out4screen

spool stat_04.log

exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ACC_AUTHORTY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ACC_LST_ACT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ACCNT_LEGAL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ACT_ATT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ACT_REP_MSGS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ACT_REPORT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGR_AGR"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGR_CON_ADDR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGR_CONTACT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGR_PLAN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGR_SCR_PAY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGRCON_LEGAL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGREE_CRIT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGREE_LEGAL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGREE_OPTY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AGREE_X"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AM_ADD_PARAM"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_APPL_ROUTER"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_APPLICANT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AUD_FI_NAME"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_AUDIT_ITEM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BANK_ACCOUNT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BANK_REQ_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BANK_RPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BANK_SIGNATR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BANKRUP_DATE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BANKRUP_REQ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BENEF_COMM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BENFR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BNKR_REQ_AGR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BPL_VKO_LOG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BPM_ADD_PAR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_BU_ASSD_LOAD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CALL_LST_ACT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CALL_LST_SA"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CAMPAIGN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_AC_GR_INT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_ACC_ADD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_ACC_IDEN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_ACC_INT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_ACC_OPTY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_ACC_TRUST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_ACCOUNT_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_ACTION"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_ADDRESS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_CON_INFO"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_CONTACT_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_FINATTR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_INDUST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_INTEG_ERR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_OPP_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_OPTY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_OPTY_CON"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_OUT_QUEUE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_PARTY_INT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_PRODUCT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_SBA_IND"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_SBA_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CB_SUB_BANK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CC_ADMIN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CC_EKP_XM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CC_OPTY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CC_OTHER_QST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CC_SEQ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CG_ACCOUNT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CG_ADD_MEMBR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CG_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CHCKLST_TMPL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CLASSIFY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CNSLD_GROUP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_COMM_MSG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_COMP_EMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_COMPETENCE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CONC_EKP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_COP_RATE"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_COURT_SES"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_COVENANT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CR_ADM_LOV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CRIM_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CRIME_CON"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_CRIME_PROC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_DATA_IMPORT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_DIV_REG_INT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_DOC_TYPE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_EIM_COP_RATE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_EIM_SAS_RES"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_EIM_SBRF_SEG"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_EIM_TRIGGER"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_EKP_SEND"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_EMP_SUBST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_EXEC_PROC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_F_IND_IMP_DT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_FIN_INDX_IMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_FK_DOCS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_FKD_DOCS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_FKD_DOCS_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_FKD_PAR_PROD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_FUT_EX_RATE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_GSZ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_GSZ_CRIT_ADM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_GSZ_CRITER"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_GSZ_HST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_GSZ_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_GSZACC_HST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_GSZMEM_INTER"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_GUAR_MEAS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_HIST_FINCORP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);

spool off

exit
