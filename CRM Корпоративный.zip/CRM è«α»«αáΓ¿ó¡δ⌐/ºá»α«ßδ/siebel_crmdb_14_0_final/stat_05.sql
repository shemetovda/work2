set pagesize 1000 linesize 32767 long 20000000 longchunksize 20000000 serveroutput on size unlimited
set trimspool on
define out4script='echo off feedback off verify off heading off timing off'
define out4screen='echo on termout on feedback on verify on heading on timing on'
set &out4screen

spool stat_05.log

exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_IMP_ACR_DTL"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_INS_AGREE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_INT_DIV_PIN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_INT_REQS"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_INT_TASK_ATT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_INTER_REL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_K_RATING"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_KIND_ACTIV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_KPA_RISK_CTG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LD_PROD_OFFR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LEAD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LEAD_COMMENT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LEAD_CONTACT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LEAD_MSG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LEAD_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LEGAL_PROC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LGD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LIMITS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LIQUID_VAL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LIQUIDATION1"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LM_CODE_MAP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LM_CONF"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LM_INTEGR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LM_LIM"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LM_LIM_MX"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LM_LOV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LM_SEND"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LOCK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LOY_CRITERIA"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LST_MGMT_LOG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_LST_TEMPL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_COL_ALLOC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_CONC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_DEF_TERMS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_DISP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_FAC_COLL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_LIM_TYPE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_LM_LIM_MX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_PROD_CONC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_RISK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MB_UPR_HST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MDM_OUT_EVT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MEMB_EFF"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_ACCNT_X"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_ADDR"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_AUDIT_TRL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_COMM_ADDR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_CONTACT_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_LM_REQ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_PARTY"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_PARTY_EMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_PARTY_PER"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_PARTY_REL"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MG_REG_DOC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MIGR_NSL_ORG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MIGRAT_LOG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MKT_COMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_AGRMNT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_BANKRUP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_CRIT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_CRIT_ADM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_CRIT_EFF"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_CRIT_POS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_DEC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_POSTN"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_REC_RATE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MON_RET_PL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MONITORING"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MOT_ATT_REC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MOT_JUDG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MRK_HST"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_MRK_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_APP_DUR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_COMP_T"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_F_CRS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_FACT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_FACT_INT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_GSZ_LIM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IN_A"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IN_CH"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IN_CHCR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IN_CR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IN_CRQA"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IN_DATA"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IN_Q"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IN_RES"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_IND"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_LIM"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_LIM_COND"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_LOV"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_LOV_CHLD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_MKT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_PROJ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_RC_BLOCK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_RISK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_SPLR_CON"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NKP_TRACE"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NSL_CUR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NSL_HIER"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NSL_LIM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NSL_LIM_MX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_NSL_LIM_POS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPER_QUEUE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPK_CONTRACT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_AGR_XM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_ATT_REC"', estimate_percent => 3, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_BU"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_LOG_XM"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_MARK_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_OPTY_MB_GUAR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);

spool off

exit
