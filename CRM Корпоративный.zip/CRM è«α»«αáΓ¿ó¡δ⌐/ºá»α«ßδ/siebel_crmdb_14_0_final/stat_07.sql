set pagesize 1000 linesize 32767 long 20000000 longchunksize 20000000 serveroutput on size unlimited
set trimspool on
define out4script='echo off feedback off verify off heading off timing off'
define out4screen='echo on termout on feedback on verify on heading on timing on'
set &out4screen

spool stat_07.log

exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UNIV_TMPL_FD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UNIV_TMPL_IC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UPDATES"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_UW_TER_PSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_VOTE_RESULTS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_VRP_COMMENTS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_VRP_ORG_TYPE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_VRP_SHIPPED"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_VRP_TAX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_WRTOFF_AGR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_WRTOFF_POS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_WRTOFF_REG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"CX_ZNI_STATUS"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AC_RSRC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AC_RSRC_RESP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACC_VIEW_APPL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACCELERATOR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACCELRTR_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACCNT_AGR_CUT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACCNT_POSTN"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACT_CONTACT"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACT_CONTACT_DELETE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACT_EMP"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACT_EMP_DELETE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACT_ORG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACT_PRDINT"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACTION_ARG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACTION_DEFN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ACTION_DELETE_LOG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ADDR_PER"', estimate_percent => 10, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ADDR_PER_X"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AGREE_POSTN"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APLT_BRSSCRPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APLT_MMI_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APLT_NAVLINK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APLT_TM_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APLT_TM_VAR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APLT_TXT_MSG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APLT_WTI_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APP_KEY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APP_QUERY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APP_VIEW"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APP_VIEW_RESP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_EVT_SVC"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_FIND"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_SCRIPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_TOOLBAR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_UPROP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_WEB_TMPL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_WEBSCRPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_WT_IT_PR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_WT_IT_RX"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_WTMPL_IT"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPL_WTMPL_RX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPLET"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPLET_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPLET_METH_MI"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPLET_RX"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPLET_SCRIPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPLET_TOGGLE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPLET_UPROP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPLICATION"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APPVW_SHRTCUT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_APSRVR_REQ"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_ATTR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_ATTR_COL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_CNDT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_DCMP_COL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_DYN_COMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_GRP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_GRP_BU"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_GRP_OBJ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_IAT_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_ITEM_ATTR"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_ITEM_TYPE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_ITY_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_OBJ_EXT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_OBJECT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_RULE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_RULE_ITEM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_WL_OBJ"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGN_WL_OBJ_COL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASGNRL_RPTRL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASSESS_ATTRIB"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASSESS_ATTVAL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_ASSET_XM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AUDIT_BUSCOMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AUDIT_FIELD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AUDIT_ITEM"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AUDIT_JOIN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AUDIT_LINK"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_AUDIT_READ"', estimate_percent => 30, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BARCODE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BARCODE_ITEM"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BC_BRS_SCRPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BC_ENTRY_TRGT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BC_VIEWMODE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BCDMAP_UPROP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BCODE_ENABLE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BCSTMSG_POSTN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BCSTMSG_USER"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BITMAP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BITMAP_CAT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BITMAP_INTL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BOCOMP"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', degree => 32, cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BR_CONCEPT"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BR_GBL_BINARY"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BR_MDL_BC_FLD"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BR_MDL_BC_REL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BR_MOD_BC_REL"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BR_MODULE"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BR_MODULE_BIN"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);
exec DBMS_STATS.GATHER_TABLE_STATS('"SIEBEL"', '"S_BRDCST_MSG"', estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS SIZE 254', cascade => TRUE);

spool off

exit
