select name, count_message
from (
  select s_eai_queue.name, 
    (select count(1) 
    from (select queue_ref_val, max(status_cd) status
      from siebel.s_eai_queue_itm
      where siebel.s_eai_queue_itm.queue_id = s_eai_queue.row_id
      group by s_eai_queue_itm.queue_ref_val
      having count(1) = 1
      ) aa
      where status = 'Received'
    ) as count_message           
  from siebel.s_eai_queue
  where name like '2018-11-07%' and name not like '%Rs' 
        and name not like '%MDM%' and name not like '%PPRB%' 
        and name not like '%BPM.EKP%' and name not like '%UPRPA.%' 
        and name not like '%OCR.%'  and name not like '%SBBOL%'
        and name not like '%BPMMB%'
  order by s_eai_queue.name desc
  ) tab
