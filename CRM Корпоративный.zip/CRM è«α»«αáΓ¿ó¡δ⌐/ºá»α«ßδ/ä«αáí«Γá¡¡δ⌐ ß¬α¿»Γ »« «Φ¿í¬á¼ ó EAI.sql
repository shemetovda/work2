select a.name,a.desc_text, b.comments,
regexp_substr(dbms_lob.substr(b.x_xml_text,1000),'[^<>]+',1,2)||'.'||regexp_substr(dbms_lob.substr(b.x_xml_text,1000), '<Method>(.+)</Method>',1,1,'n',1) ServiceMetod,
count(b.comments)
from siebel.s_eai_queue a, siebel.S_EAI_QUEUE_ITM b
where a.row_id = b.QUEUE_ID
and b.comments is not null
and name like '2019-07-11%' and name not like '%C7M.CRMtoUM.SendDealNotification%' and name not like '%ERM.RGSOptyToClose%' and name not like '%SMS%' and name not like '%SAP%'
/*and b.comments like '%Access denied%'*/
group by a.name,a.desc_text, b.comments,
regexp_substr(dbms_lob.substr(b.x_xml_text,1000),'[^<>]+',1,2)||'.'||regexp_substr(dbms_lob.substr(b.x_xml_text,1000), '<Method>(.+)</Method>',1,1,'n',1)
order by 5 desc
