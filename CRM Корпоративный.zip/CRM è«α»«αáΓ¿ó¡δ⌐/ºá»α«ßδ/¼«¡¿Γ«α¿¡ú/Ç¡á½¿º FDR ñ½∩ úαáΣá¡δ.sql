--���-�� FDR � ���� ����� 
select /*+  full(sd) parallel (sd, 32)*/
sd.server_name as "server_name",
count(1) as "���-��"
  from s_diag sd,
       s_diag_data sdd,
       (select /*+ full(sd) parallel (sd, 16)*/
         count(sd.row_id) as cnt,
         ora_hash(to_char(substr(regexp_replace(lower(substr(substr(substr(sdd.crash_file_content,
                                                                           InStr(sdd.crash_file_content,
                                                                                 '__') + 2),
                                                                   InStr(substr(sdd.crash_file_content,
                                                                                 InStr(sdd.crash_file_content,
                                                                                       '__') + 2,
                                                                                 length(sdd.crash_file_content) - 1),
                                                                          '__')),
                                                             0,
                                                             3000)),
                                                '/[0-9a-z\/:\.'']+|\+0[a-z]+[0-9]+|\_i\_|\[[\(\) 0-9a-z]+\]',
                                                ''),
                                 0,
                                 250))) as uniqhash,
         to_char(substr(regexp_replace(lower(substr(substr(substr(sdd.crash_file_content,
                                                                  InStr(sdd.crash_file_content,
                                                                        '__') + 2),
                                                           InStr(substr(sdd.crash_file_content,
                                                                        InStr(sdd.crash_file_content,
                                                                              '__') + 2,
                                                                        length(sdd.crash_file_content) - 1),
                                                                 '__')),
                                                    0,
                                                    3000)),
                                       '/[0-9a-z\/:\.'']+|\+0[a-z]+[0-9]+|\_i\_|\[[\(\) 0-9a-z]+\]',
                                       ''),
                        0,
                        250)) as callstack
          from s_diag_data sdd, s_diag sd
         where sdd.par_row_id = sd.row_id
           and sd.created > sysdate - 2
           and sd.server_name not in ('crmapp3', 'crmapp4')
           and sd.comp_name not in
               ('Smart Answer Manager', 'Server Manager')
           and sd.error_msg <> 'Internal: Killed by parent'
        
         group by to_char(substr(regexp_replace(lower(substr(substr(substr(sdd.crash_file_content,
                                                                           InStr(sdd.crash_file_content,
                                                                                 '__') + 2),
                                                                    InStr(substr(sdd.crash_file_content,
                                                                                 InStr(sdd.crash_file_content,
                                                                                       '__') + 2,
                                                                                 length(sdd.crash_file_content) - 1),
                                                                         '__')),
                                                             0,
                                                             3000)),
                                                '/[0-9a-z\/:\.'']+|\+0[a-z]+[0-9]+|\_i\_|\[[\(\) 0-9a-z]+\]',
                                                ''),
                                 0,
                                 250))) un
where sd.row_id = sdd.par_row_id
   and sd.server_name not in ('crmapp3', 'crmapp4')
   and sd.comp_name not in ('Smart Answer Manager', 'Server Manager')
   and sd.error_msg <> 'Internal: Killed by parent'
   and ora_hash(to_char(substr(regexp_replace(lower(substr(substr(substr(sdd.crash_file_content,
                                                                         InStr(sdd.crash_file_content,
                                                                               '__') + 2),
                                                                  InStr(substr(sdd.crash_file_content,
                                                                               InStr(sdd.crash_file_content,
                                                                                     '__') + 2,
                                                                               length(sdd.crash_file_content) - 1),
                                                                        '__')),
                                                           0,
                                                           3000)),
                                              '/[0-9a-z\/:\.'']+|\+0[a-z]+[0-9]+|\_i\_|\[[\(\) 0-9a-z]+\]',
                                              ''),
                               0,
                               250))) = un.uniqhash
   and sd.created > sysdate - 2
group by sd.server_name
order by 2 desc;

