select rowid,a.*  from siebel.s_sys_pref a
/*where \*sys_pref_cd = 'SBRF AEF Mode'*\val='Sync'*/
/*where sys_pref_cd like '%SBRF FIAS Initial DBF Path%'
where sys_pref_cd like '%PSF%'*/
where sys_pref_cd like '%SBRF TXB Dispatcher Id%'
/*
02_MB_BPM_SalesStage_Validate -�����?
SBRF PSF ML Mode - ���
*/

--��
select rowid,a.*  from siebel.CX_CC_SYS_PREF a
select rowid,b.* from CX_CC_PILOT b
