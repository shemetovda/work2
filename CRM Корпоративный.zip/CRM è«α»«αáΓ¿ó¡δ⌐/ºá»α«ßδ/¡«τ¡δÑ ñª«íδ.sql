select ss1.actl_start_dt,ss1.actl_end_dt,sq1.* from (
select 
distinct 
to_number(to_char(rq.sched_start_dt, 'HH24')),
rq.row_id,
act.display_name JOB_NAME
, act.X_RELEASE
, rq.rpt_interval
, rq.rpt_uom
, rq.rpt_type 
, rq.sched_start_dt
, cmp.display_name COMPONENT_NAME 
, rqpwf.param_value WORKFLOW_NAME
, rqpwf.busobj_name WF_BUS_OBJECT
, rqpss.param_value SEARCH_SPEC

from
siebel.S_SRM_REQUEST rq
LEFT JOIN siebel.s_srm_action act ON rq.action_id = act.row_id
LEFT JOIN siebel.s_srm_action cmp ON act.par_action_id = cmp.row_id
LEFT JOIN (select  * from 
          siebel.S_SRM_REQ_PARAM rqp 
          JOIN siebel.S_SRM_ACT_PARAM apwf ON apwf.row_id = rqp.actparam_id and apwf.name = 'Workflow Process Name'
          JOIN siebel.s_wfr_proc wf ON apwf.param_value = wf.proc_name and wf.status_cd = 'COMPLETED'
          ) rqpwf ON rqpwf.req_id = rq.row_id 
LEFT JOIN 
          (select * from 
          siebel.S_SRM_REQ_PARAM rqp1 
          JOIN siebel.S_SRM_ACT_PARAM apsp ON apsp.row_id = rqp1.actparam_id and apsp.name = 'Search Specification'
          )rqpss ON rqpss.req_id = rq.row_id 

where
rq.req_type_cd = 'RPT_PARENT' 
and to_number(to_char(rq.sched_start_dt, 'HH24')) between 19 and 23
) sq1 left join S_SRM_REQUEST ss1 on sq1.row_id = ss1.par_req_id
where ss1.actl_start_dt is not null and ss1.actl_start_dt > to_date('29.11.2017 19:30:30', 'DD.MM.YYYY HH24:MI:SS')
and sq1.rpt_uom = 'DAYS'
/*and sq1.job_name in (
'SBRF IntDivTDel','SBRF Insert Attach Role Template','SBRF Fin Report Action 2 Job Template','SBRF Fin Report Action 4 Job Template',
'SBRF LM MasterData LOV','SBRF Wages Inbox Deactivate','SBRF Update Account Zakrep','SBRF SAS Export Responses Job Template',
'SBRF Birthday Remind Job Template','SBRF SR Days Left Job Template','SBRF Process Archive Positions',
'SBRF Notice SR Matching Expired To Employee Job Template','SBRF Cancel Expired Action','SBRF EASUP Import','SBRF Start Onboarding Monitoring Plane Horizon',
'SBRF Rating Actual Date Job Template','SBRF Update GSZ Limit Status Job Template','SBRF Create Agency List Job Template','SBRF Check Promise of Payment Job Template',
'�������� ������������ �������� �������','SBRF Campaign Finished Job Template','SBRF Writeoff Agreement Exclude Job Template',
'SBRF Monitoring Criterion Reclassification Notification Job Template','SBRF Insurance Agreement Closing Notification Job Template',
'SBRF Send Reclam Date Notification Job Template','SBRF Migration Mobile Telefon Template','SBCB Integration Error Notification Job Template',
'SBRF Claim EIM Import Job Template','SBRF Send Mail Reg Doc To Opty MB VKS','SBRF Priority Read','SBRF Search Timeout Account Migr',
'SBRF SAS Batch Deactivate Activity Job Template','SBRF Cancel Expired Action','SBRF OPER CRMtoSBBOLUpdateServiceRequest Delete','SBRF EASUP Import',
'SBCB Integration Error Delete','SBRF Template Lead Closing','SBRF Account Onboarding Close','SBRF Writeoff Register Create From Offbalance Job Template',
'SBRF Log Updates Job Template','SBRF Create New Account Periods Job Template','SBRF Calculate Monitoring Division Job Template','SBRF Purge Unused UNIV Data Maps',
'SBRF Deactivate UW Audit Inbox','SBRF LM SNL Read','SBRF Strategy Mktg','SBRF EKS Export Job Template','SBRF SAS Clear Interface Job Template','SBRF Wages Inbox Broadcast',
'SBRF GSZ Add Actions Job Template','SBRF SNL Over LimitReadRq Outbound','SBRF EKS Export Job Template','�������� ������������ �������� �������','SBRF EASUP Import',
'SBRF Regenerate Div Structure Job Template','SBRF ECC Send Notification Job Template','SBRF Monitoring Overdue Activity Process Job Template',
'SBRF Deactivate Inbox Task Job Template','SBRF Agreement Writeoff Notification Job Template','SBRF Fin Report Action 3 Job Template','SBRF Fin Report Action 1 Job Template',
'SBRF Employee Add Corp User System Template','SBRF OS Task Run Workflow Job Template','SBRF Editing Service Agreement Stage Job Template','SBRF Update Account Zakrep',
'SBRF FOS Read','SBRF SR Group Importance Job Template','SBCB Run Repeating Batch Jobs','SBRF Account Important Date Job Template','SBRF Execution Proceeding Yellow Overdue Job Template',
'SBRF Lot Agreement Exclude Job Template','SBCB Integration Error Delete','SBRF Account Batch Assignment','SBRF LM MasterData Config','SBRF GSZ Add Actions Job Template',
'SBCB Run Repeating Batch Jobs','SBRF SAS Batch Deactivate Activity Job Template','SBRF SAS Export Responses Job Template','SBRF Rating Actual Date Job Template',
'SBRF Crit Inbox Reminder Job Template','SBRF SMS MFM Request Expired','SBRF SAS Batch Deactivate Activity Job Template','SBRF Notice SR Matching Expired To Manager Job Template',
'SBRF Offer Expire Notify','SBRF Offer Close Send Email','SBCB Integration Error Notification Job Template','SBRF Birthday Remind Job Template','SBRF Close Rep Check Job Template',
'SBRF Notice About Monitoring Date Job Template','SBRF Campaign Closed Job Template','SBRF Predefined Query BIP Delete','SBRF Fin Report Action A Job Template',
'SBRF Rejected Segment Request Job Template','SBRF Process Delayed Segment Request Job Template','SBRF Retail Employee Send Request','SBRF EIM COP Rate Load',
'SBRF Writeoff Register Create To Offbalance Job Template','SBRF Agency List Closing Job Template','SBRF Account Reaccreditation Job Template',
'SBRF Close Overdued Recall Actions Job Template','SBRF NKP Product Set Status Job Template','SBRF SNL Limit Send Message','SBRF Reassign Action Job Template',
'SBRF BPM EKP Outbound Clean','SBRF Birthday Remind Job Template','SBRF Send Mail Reg Doc To Opty MB VKS','SBRF GSZ Set Monitoring N Job Template',
'SBRF Credit Agr Monitoring Date Job Template','SBRF Create CC Job Template','SBRF ICRate Delete Conflict Records Job Template',
'SBRF PA Stage Noncompliance Notification Template','SBRF Crit Inbox Reminder Job Template','SBRF Send Date Notification Job Template',
'SBRF Fin Report Action A Job Template','SBRF MB Facilities Need Distribute Job Template','SBRF Update Account VKO Message Job Template',
'SBRF SAS Batch Activity Import Job Template','SBRF Reassign Action Job Template','Enterprise Integration Mgr','SBRF Search Timeout Account Migr',
'SBRF Priority Read','SBRF SAS Export Responses Job Template','SBRF SAS ORG LOV Export Job Template','SBRF Offer Close Run Batch','SBRF Contact Important Date Job Template'
)*/
