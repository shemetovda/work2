select dt.account_id,count(*)
from SIEBEL.SBRF_PHONE_SEARCH_MV dt
group by dt.account_id
order by count(*) desc 
