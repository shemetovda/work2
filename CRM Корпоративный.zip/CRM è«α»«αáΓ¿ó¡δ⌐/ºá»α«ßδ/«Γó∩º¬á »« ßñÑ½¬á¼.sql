--������� �� �������
update /*+parallel(512)*/ siebel.s_opty
set PR_DEPT_OU_ID = 'IgnoreId'
where PR_DEPT_OU_ID in ('1-1711YT1','1-EO1SQW','1-16VEU9X','1-EO3K0A','1-17D473N','1-EO1SR8','1-16974PH','1-171Q1BW','1-1GK6XV','1-PZ9Y9','1-9GCW08','1-AP5IG7','1-1GKS1X','1-PTYE8','1-PX38C','1-2CAURSX','1-HIRTRF2','1-17D0QSY')

commit; 


select * from siebel.s_opty
where PR_DEPT_OU_ID = 'IgnoreId'
