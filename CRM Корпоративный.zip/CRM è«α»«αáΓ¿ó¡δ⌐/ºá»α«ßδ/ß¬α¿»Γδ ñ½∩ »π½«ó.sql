select distinct (p.row_id),o.row_id,u.login
from siebel.s_evt_act t, 
siebel.s_org_ext o,
siebel.S_USER u,
siebel.S_CONTACT t3,
S_POSTN p
where t.target_ou_id = o.row_id
and u.row_id = t.OWNER_PER_ID
and t3.par_row_id = u.row_id 
and u.row_id = p.pr_emp_id
and o.x_sbrf_client_flg = 'Y'
and o.INT_ORG_FLG='N'
and o.OU_TYPE_CD='�������' 
and o.CLIENT_FLG='Y'
and t.TEMPLATE_FLG='N'
/*and u.login like 'KM_P%'*/
/*and t.TODO_CD='������'*/
and o.CUST_STAT_CD = '�������'

________________________________________________________________________________________________________
select /*+parallel(t1,32)*/t1.PR_POSTN_ID as PositionId, t1.row_id as OpptyId, count(*)  
from siebel.S_OPTY t1,siebel.S_OPTY_CON t2  
where ((t1.NEW_LOAN_FLG='N' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N') --����������� ������  
or (t1.NEW_LOAN_FLG='Y' and t1.X_EKP_FLAG='N' and t1.X_PA_FLG='N')) --�� ������  
and t1.row_id=t2.OPTY_ID  
group by t1.row_id,t1.PR_POSTN_ID  
having count(*)>=4 and count(*)<=50 

________________________________________________________________________________________________________

select /*+parallel(ap,512)*/oe.row_id,contact.row_id
from
siebel.S_EVT_ACT ea,
siebel.s_org_ext oe,
siebel.S_CONTACT contact
where
oe.par_row_id = ea.owner_ou_id
and ea.OWNER_PER_ID = contact.row_id
/*and PR_HELD_POSTN_ID<>'No Match Row Id'*/
/*and ea.OPTY_ID is null*/
/*and contact.pr_held_postn_id = '1-5O5-52' */
and oe.active_flg = 'Y'
and oe.x_sbrf_client_flg = 'Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.CLIENT_FLG='Y' 

________________________________________________________________________________________________________
select /*+parallel(ap,512)*/ ap.POSITION_ID, orgx.SBRF_INN 
from siebel.S_ACCNT_POSTN ap,siebel.S_ORG_EXT oe, siebel.S_ORG_EXT_X orgx,  siebel.s_user c,siebel.s_postn b
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.cust_stat_cd<>'�����' 
and ap.cvrg_role_cd='���������� ��������' 
and ap.OU_EXT_ID=oe.row_id 
and oe.ROW_ID = orgx.row_id 
and b.PR_EMP_ID = c.row_id
and b.row_id = oe.PR_POSTN_ID
________________________________________________________________________________________________________
select ap.POSITION_ID, count(*) 
from 
siebel.S_ACCNT_POSTN ap,
siebel.S_ORG_EXT oe,
siebel.S_POSTN pos
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and ap.OU_EXT_ID=oe.row_id 
and pos.row_id=oe.Pr_postn_id
and oe.cust_stat_cd<>'�����' 
and ap.cvrg_role_cd='���������� ��������'
group by ap.POSITION_ID
having count(*)<100
________________________________________________________________________________________________________
select t1.row_id OpptyCRMId,t1.PR_DEPT_OU_ID AccountId,t1.PR_POSTN_ID PositionId
from siebel.S_OPTY t1,S_REVN t, S_STG s
where /*t1.new_loan_flg = 'Y'
and t1.x_pa_flg = 'N'
and t1.x_ekp_flag = 'N'
and t1.opty_cd = '��'
and*/ t.opty_id = t1.row_id
and s.row_id = t1.CURR_STG_ID
and s.row_id in ('1-BDW3Z2')
________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ u.LOGIN, org.row_id AccountId,pi.row_id MDMId
FROM   s_org_ext org,  S_POSTN p, siebel.S_USER u,  siebel.CX_LD_PROD_OFFR t,S_PROD_INT pi
WHERE   1=1
and org.pr_postn_id = p.row_id           
and p.pr_emp_id = u.row_id
and t.account_id = org.row_id
and pi.row_id = t.product_id
and org.x_sbrf_client_flg = 'Y'
and org.INT_ORG_FLG='N'
and org.OU_TYPE_CD='��. ����' 
and org.CLIENT_FLG='Y'
and org.CUST_STAT_CD = '�������'
and t.source in ('���� �� ���')
and pi.row_id= '1-1GSO'
and org.row_id = '1-12FN8NU'

________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ u.LOGIN, org.row_id AccountId,pi.row_id MDMId,cl.row_id ApplicationCRMId_875
FROM   s_org_ext org,  S_POSTN p, siebel.S_USER u,  siebel.CX_LD_PROD_OFFR t,S_PROD_INT pi,siebel.CX_LEAD cl
WHERE   1=1
and org.pr_postn_id = p.row_id           
and p.pr_emp_id = u.row_id
and t.account_id = org.row_id
and pi.row_id = t.product_id
and org.ROW_ID = cl.ACCOUNT_ID
and org.x_sbrf_client_flg = 'Y'
and org.INT_ORG_FLG='N'
and org.OU_TYPE_CD='��. ����' 
and org.CLIENT_FLG='Y'
and org.CUST_STAT_CD = '�������'
and t.source in ('���� �� ���')
and cl.description = '������������� � 874 �����.'
________________________________________________________________________________________________________
select /*+parallel(ap,512)*/po.POSTN_ID,s.row_id
from s_contact s, siebel.S_POSTN_CON po,siebel.s_postn p
where 
s.row_id = po.CON_ID
and p.row_id = po.postn_id
and s.PRIV_FLG='N' 
and s.EMP_FLG='N' 
and s.X_SBRF_FI_VIP_FLAG='N'
and s.pr_dept_ou_id = 'No Match Row Id'
and rownum < 99
________________________________________________________________________________________________________
select /*+parallel(ap,512)*/ p.row_id,t.row_id,lov.val,t.created_by,ap.cvrg_role_cd,lov.DESC_TEXT
from siebel.s_evt_act t, 
siebel.s_org_ext o,
siebel.S_USER u,
siebel.S_CONTACT t3,
S_POSTN p,
S_ACCNT_POSTN ap,
siebel.S_LST_OF_VAL lov
where t.target_ou_id = o.row_id
and u.row_id = t.OWNER_PER_ID
and t3.par_row_id = u.row_id 
and u.row_id = p.pr_emp_id
and ap.OU_EXT_ID=o.row_id
and lov.VAL=t.TODO_CD 
and lov.DESC_TEXT='Bank'
and lov.val in ('������','������������ ������')
and lov.ACTIVE_FLG = 'Y' 
AND lov.TYPE = 'TODO_TYPE' 
and t.created_by <> '0-1'
and t3.last_upd_by <> '0-1'
and ap.cvrg_role_cd='���������� ��������'
and t.TEMPLATE_FLG='N'
and o.x_sbrf_client_flg = 'Y'
and o.INT_ORG_FLG='N'
and o.OU_TYPE_CD='��. ����' 
and o.CLIENT_FLG='Y'
and ap.CLIENT_FLG='Y'
and o.CUST_STAT_CD = '�������'
and t.evt_stat_cd <> '�������'
________________________________________________________________________________________________________
select /*+parallel(ap,512)*/ b.row_id, orgx.SBRF_INN,oe.cust_stat_cd
from siebel.S_ACCNT_POSTN ap,siebel.S_ORG_EXT oe, siebel.S_ORG_EXT_X orgx,  siebel.s_user c,siebel.s_postn b
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.OU_TYPE_CD='��. ����' 
and oe.active_flg = 'Y'
and oe.x_sbrf_client_flg = 'Y'
and oe.cust_stat_cd in ('����������')
and ap.cvrg_role_cd='���������� ��������' 
and ap.OU_EXT_ID=oe.row_id 
and oe.ROW_ID = orgx.row_id 
and b.PR_EMP_ID = c.row_id 
and b.row_id = oe.PR_POSTN_ID
and ae.emp_id = c.row_id

________________________________________________________________________________________________________


SELECT   /*+parallel(128)*/ distinct u.LOGIN, org.row_id
FROM   s_org_ext org,  S_POSTN p, siebel.S_USER u,  siebel.CX_LD_PROD_OFFR t,S_CONTACT c
WHERE   1=1
and org.pr_postn_id = p.row_id           
and p.pr_emp_id = u.row_id
and t.account_id = org.row_id
and t.product_id is not null
________________________________________________________________________________________________________
select /*+parallel(128)*/ distinct p.row_id PositionId,t.TODO_CD ActionType,t.x_sbrf_send_outlook,o.row_id CRMId
from siebel.s_evt_act t, 
siebel.s_org_ext o,
siebel.S_USER u,
siebel.S_CONTACT t3,
S_POSTN p
where t.target_ou_id = o.row_id
and u.row_id = t.OWNER_PER_ID
and t3.par_row_id = u.row_id 
and u.row_id = p.pr_emp_id
and o.x_sbrf_client_flg = 'Y'
and o.INT_ORG_FLG='N'
and o.OU_TYPE_CD='��. ����' 
and o.CLIENT_FLG='Y'
and t.TEMPLATE_FLG='N'
and u.login like 'KM_P%'
and t.x_sbrf_send_outlook = 'N'
and o.CUST_STAT_CD = '�������'
and t.TODO_CD = '������'
________________________________________________________________________________________________________
select /*+parallel(oe,512)*/oex.SBRF_INN
from siebel.S_ORG_EXT oe,siebel.S_ORG_EXT_X oex
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.cust_stat_cd <> '�����' 
and oe.CUST_STAT_CD = '�������'
and oex.SBRF_INN is not null
and oex.ROW_ID=oe.ROW_ID
and rownum < 501
________________________________________________________________________________________________________
select /*+parallel(512)*/
distinct
ps.row_id PositionId,
o.row_id OpptyCRMId,
oe.row_id AccountId,
pi.name OpptyCore,
sm.row_id SaleMethod,
pi.x_ckpit_id ProductName,
st.sales_method_id SalesStage,
o.modification_num ModId,
u.login

from siebel.S_OPTY o,
siebel.S_OPTY_POSTN op,
siebel.S_PARTY p,
siebel.S_SALES_METHOD sm,
s_postn ps,
s_user u,
siebel.S_ORG_EXT oe,
siebel.S_STG st,
s_prod_int pi

where 1=1
and o.row_id=op.OPTY_ID
and op.POSITION_ID=p.row_id 
and sm.ROW_ID=o.SALES_METHOD_ID
and o.PR_POSTN_ID = ps.row_id 
and u.row_id = ps.pr_emp_id
and oe.par_row_id = o.PR_DEPT_OU_ID
and sm.row_id = st.sales_method_id
and pi.row_id = o.pr_prod_id
and o.NEW_LOAN_FLG='N' 
and o.X_EKP_FLAG='N' 
and o.X_PA_FLG='N' 
and sm.row_id in ('1-3H5AJMT','1-3H5AJLZ','1-3H5AJMF','1-3H5AJN9') 
and oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.CUST_STAT_CD = '�������'
/*and o.row_id = '1-BW3T24V'*/
and o.SECURE_FLG='N'       
and (o.pr_postn_id=op.POSITION_ID or op.ROLE_CD='������� �� ������' or op.ROLE_CD='��, �������� ������')  
and rownum < 3001
________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ u.LOGIN, org.row_id
FROM   siebel.S_ACCNT_POSTN ap, siebel.S_USER u, S_POSTN p, s_org_ext org, siebel.S_EMP_PER ep
WHERE   p.row_id = ap.position_id 
AND u.row_id = p.pr_emp_id 
and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and org.X_SBRF_CLIENT_FLG='Y' 
and org.CLIENT_FLG='Y'
and org.OU_TYPE_CD='��. ����' 
and org.INT_ORG_FLG='N' 
and org.CUST_STAT_CD = '�������'
AND ROWNUM < 3001
________________________________________________________________________________________________________
select /*+parallel(sr,512)*/org.row_id as AccountId
from siebel.S_SRV_REQ sr, siebel.S_SRV_REQ1_FNXM re,siebel.s_org_ext org
where  sr.TEMPLATE_FLG = 'N'
and sr.row_id = re.PAR_ROW_ID  
and re.TYPE='Org Account Address' 
and sr.SR_STAT_ID = '���� ������' 
and sr.CST_OU_ID IS NOT NULL
and sr.CST_OU_ID = org.row_id
/*and org.X_SBRF_CLIENT_FLG='Y' 
and org.CLIENT_FLG='Y'
and org.OU_TYPE_CD='��. ����' 
and org.INT_ORG_FLG='N' */
/*and org.CUST_STAT_CD = '�������'*/
________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ distinct u.LOGIN, org.row_id
FROM   siebel.s_org_ext org,  siebel.S_POSTN p, siebel.S_USER u,  siebel.CX_LD_PROD_OFFR t, siebel.S_ACCNT_POSTN ap, siebel.S_EMP_PER ep
WHERE   1=1
and org.pr_postn_id = p.row_id
and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and p.pr_emp_id = u.row_id
and t.account_id = org.row_id
and t.product_id is not null 
and org.X_SBRF_CLIENT_FLG='Y' 
and org.CLIENT_FLG='Y'
and org.OU_TYPE_CD='��. ����' 
and org.INT_ORG_FLG='N' 
and org.CUST_STAT_CD = '�������'
and p.x_km_6_flg = 'N'
and t.prod_group_id is not null
and ap.client_flg = 'N'
and org.created_by <> '0-1'
/*and org.cl_site_flg = 'X'*/
and org.pr_con_id = 'No Match Row Id'
/*and org.row_id in ('1-76Q51XG','1-2138F0J')*/
________________________________________________________________________________________________________
select /*+parallel(oe,512)*/ distinct ea.row_id, b.login
  from siebel.S_ORG_EXT oe, siebel.S_EVT_ACT ea, s_user b, siebel.S_EMP_PER ep, siebel.S_ACCNT_POSTN ap
   
  where 1=1
  and ea.owner_per_id = b.row_id
  and ea.TARGET_OU_ID=oe.row_id 
  and ea.owner_per_id is not null
  and oe.X_SBRF_CLIENT_FLG='Y'
  and oe.OU_TYPE_CD='��. ����' 
  and oe.INT_ORG_FLG='N' 
  and oe.cust_stat_cd='�������' 
  and ea.Evt_Stat_Cd in ('�������������','� ������')
  and ea.TEMPLATE_FLG='N' 
  and b.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
  and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID
  and b.login not in ('SADMIN')
________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ distinct u.LOGIN,  postncon.con_id,contact.modification_num, count (*)
FROM   siebel.S_USER u, siebel.S_POSTN p, siebel.s_org_ext org, siebel.S_PER_RESP resp, siebel.s_resp r, siebel.S_ACCNT_POSTN ap, siebel.S_EMP_PER ep, S_POSTN_CON postncon, S_contact contact
WHERE   1=1
AND u.row_id = p.pr_emp_id
and postncon.postn_id = p.row_id
and org.pr_postn_id = p.row_id
and postncon.con_id = contact.row_id
and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and u.row_id = resp.per_id
and r.row_id = resp.resp_id
and r.name = 'SBRF KRB_SRB 3 04 KM MMB' 
/*and contact.modification_num = 5*/
group by u.LOGIN,  postncon.con_id,contact.modification_num
________________________________________________________________________________________________________
select distinct oe.row_id
from siebel.s_org_ext oe,siebel.s_srv_req ssr
where ssr.cst_ou_id = oe.row_id 
and oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.CUST_STAT_CD = '�������'
and rownum < 201
________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ u.LOGIN,  org.row_id
FROM   siebel.S_USER u, siebel.S_POSTN p, siebel.s_org_ext org, siebel.S_PER_RESP resp, siebel.s_resp r, siebel.S_ACCNT_POSTN ap, siebel.S_EMP_PER ep
WHERE   1=1
AND u.row_id = p.pr_emp_id
and org.pr_postn_id = p.row_id
and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and u.row_id = resp.per_id
and r.row_id = resp.resp_id
and r.name = 'SBRF KRB_SRB 3 04 KM MMB' 

________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ u.LOGIN,  org.row_id
FROM   siebel.S_USER u, S_POSTN p, s_org_ext org, S_PER_RESP resp, s_resp r
WHERE   1=1
AND u.row_id = p.pr_emp_id
and org.pr_postn_id = p.row_id
and u.row_id = resp.per_id
and r.row_id = resp.resp_id
and r.name = 'SBRF KRB_SRB 3 04 KM MMB'
________________________________________________________________________________________________________
select /*+parallel(128)*/ DISTINCT c.login, org2.ATTRIB_46
from (select a.PR_POSTN_ID ownr, count(1) as cnt from siebel.S_ORG_EXT a  group by a.PR_POSTN_ID HAVING COUNT(PR_POSTN_ID)>=300) sq1,
siebel.s_postn b,
siebel.s_user c,
s_org_ext org1,
s_org_ext_x org2,
siebel.S_EMP_PER ep
WHERE 1=1
and sq1.ownr = b.row_id 
and b.PR_EMP_ID = c.row_id 
and sq1.ownr = org1.PR_POSTN_ID
and org1.row_id = org2.row_id
and c.row_id = ep.row_id 
and ep.EMP_STAT_CD <> 'Terminated'
and org2.ATTRIB_46 IS NOT NULL
and c.LOGIN not in ('SADMIN')
and rownum < 2001
________________________________________________________________________________________________________
select /*+parallel(512)*/
distinct
ps.row_id PositionId,
o.row_id
from siebel.S_OPTY o,
siebel.S_OPTY_POSTN op,
s_postn ps,
s_user u,
siebel.S_ORG_EXT oe,
siebel.S_ACCNT_POSTN ap,
siebel.S_EMP_PER ep
where 1=1
and o.row_id=op.OPTY_ID 
and o.PR_POSTN_ID = ps.row_id 
and u.row_id = ps.pr_emp_id
and oe.par_row_id = o.PR_DEPT_OU_ID
and ap.OU_EXT_ID=oe.row_id 
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
/*and ap.cvrg_role_cd='���������� ��������'
and ps.x_km_6_flg is null*/
and ps.x_pos_type_id is not null
and oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.CUST_STAT_CD = '�������'
and rownum < 2001
________________________________________________________________________________________________________
--614
select /*+parallel(oe,512)*/ oe.row_id
from siebel.S_ORG_EXT oe,siebel.S_ORG_EXT_X oex
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.cust_stat_cd <> '�����' 
and oe.CUST_STAT_CD = '�������'
and oex.SBRF_INN is not null
and oex.ROW_ID=oe.ROW_ID
and rownum < 501
________________________________________________________________________________________________________
--624
select /*+parallel(oe,512)*/oex.SBRF_INN
from siebel.S_ORG_EXT oe,siebel.S_ORG_EXT_X oex
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.cust_stat_cd <> '�����' 
and oe.CUST_STAT_CD = '�������'
and oex.SBRF_INN is not null
and oex.ROW_ID=oe.ROW_ID
and rownum < 501
________________________________________________________________________________________________________
--626
select /*+parallel(oe,512)*/ distinct oe.row_id
from siebel.S_ORG_EXT oe,siebel.S_ORG_EXT_X oex,siebel.S_ACCNT_POSTN ap
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and ap.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.cust_stat_cd <> '�����' 
and oe.CUST_STAT_CD = '�������'
and ap.cvrg_role_cd not in '���������� ��������' 
and ap.OU_EXT_ID=oe.row_id 
and oex.SBRF_INN is not null
and oex.ROW_ID=oe.ROW_ID
and oex.sbrf_km_ek_id is null
and rownum < 201
________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/  distinct u.login, org.row_id
FROM   s_org_ext org,  S_POSTN p, siebel.S_USER u,S_CONTACT c
WHERE   1=1
and org.pr_postn_id = p.row_id           
and p.pr_emp_id = u.row_id
and c.par_row_id = u.row_id
and c.pr_dept_ou_id = 'No Match Row Id'
and org.x_sbrf_client_flg = 'Y'
and org.INT_ORG_FLG='N'
and org.OU_TYPE_CD='��. ����' 
and org.CLIENT_FLG='Y'
and org.CUST_STAT_CD = '�������' 
and rownum < 1001
________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ distinct u.LOGIN,  contact.row_id
FROM   siebel.S_USER u, siebel.S_POSTN p, siebel.s_org_ext org, siebel.S_PER_RESP resp, siebel.s_resp r, siebel.S_ACCNT_POSTN ap, siebel.S_EMP_PER ep, S_POSTN_CON postncon, S_contact contact
WHERE   1=1
AND u.row_id = p.pr_emp_id
and postncon.postn_id = p.row_id
and org.pr_postn_id = p.row_id
and postncon.con_id = contact.row_id
and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and u.row_id = resp.per_id
and r.row_id = resp.resp_id
and r.name = 'SBRF KRB_SRB 3 04 KM MMB' 
and contact.modification_num = 1
________________________________________________________________________________________________________
SELECT   /*+parallel(128)*/ distinct u.LOGIN,  contact.row_id
FROM   siebel.S_USER u, siebel.S_POSTN p, siebel.s_org_ext org, siebel.S_PER_RESP resp, siebel.s_resp r, siebel.S_ACCNT_POSTN ap, siebel.S_EMP_PER ep, S_POSTN_CON postncon, S_contact contact
WHERE   1=1
AND u.row_id = p.pr_emp_id
and postncon.postn_id = p.row_id
and org.pr_postn_id = p.row_id
and postncon.con_id = contact.row_id
and org.row_id = ap.OU_EXT_ID and org.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and u.row_id = resp.per_id
and r.row_id = resp.resp_id
and r.name = 'SBRF KRB_SRB 3 04 KM MMB' 
and contact.modification_num = 1
________________________________________________________________________________________________________
select /*+parallel(512)*/
distinct
ps.row_id PositionId,
o.row_id OpptyId
from siebel.S_OPTY o,
siebel.S_OPTY_POSTN op,
s_postn ps,
s_user u,
siebel.S_ORG_EXT oe,
siebel.S_ACCNT_POSTN ap,
siebel.S_EMP_PER ep
where 1=1
and o.row_id=op.OPTY_ID 
and o.PR_POSTN_ID = ps.row_id 
and u.row_id = ps.pr_emp_id
and oe.par_row_id = o.PR_DEPT_OU_ID
and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
/*and oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.CUST_STAT_CD = '�������' 
and op.role_cd='������� �� ������'*/
and o.SECURE_FLG ='N'
and ps.row_id not in ('0-5220')
group by ps.row_id,o.row_id

________________________________________________________________________________________________________
select /*+parallel(512)*/
distinct
ps.row_id,
oe.row_id 
from siebel.S_OPTY o,
siebel.S_OPTY_POSTN op,
s_postn ps,
s_user u,
siebel.S_ORG_EXT oe,
siebel.S_ACCNT_POSTN ap,
siebel.S_EMP_PER ep
where 1=1
and o.row_id=op.OPTY_ID 
and o.PR_POSTN_ID = ps.row_id 
and u.row_id = ps.pr_emp_id
and oe.par_row_id = o.PR_DEPT_OU_ID
and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.CUST_STAT_CD = '�������' 
/*and op.role_cd='������� �� ������'
and o.SECURE_FLG ='N'
and o.pr_ou_addr_id <> 'No Match Row Id'*/
and ps.row_id not in ('0-5220')


________________________________________________________________________________________________________
select /*+parallel(512)*/ b.row_id, orgx.SBRF_INN
from siebel.S_ACCNT_POSTN ap,siebel.S_ORG_EXT oe, siebel.S_ORG_EXT_X orgx,  siebel.s_user c,siebel.s_postn b, siebel.S_EMP_PER ep
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.OU_TYPE_CD='��. ����' 
and oe.active_flg = 'Y'
and oe.x_sbrf_client_flg = 'Y'
and oe.cust_stat_cd in ('����������')
and ap.cvrg_role_cd='���������� ��������' 
and ap.OU_EXT_ID=oe.row_id 
and oe.ROW_ID = orgx.row_id 
and b.PR_EMP_ID = c.row_id 
and b.row_id = oe.PR_POSTN_ID
and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID
and c.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and b.row_id <> '0-5220'

________________________________________________________________________________________________________
select /*+parallel(512)*/
distinct
ps.row_id PositionId
from siebel.S_OPTY o,
siebel.S_OPTY_POSTN op,
s_postn ps,
s_user u,
siebel.S_ORG_EXT oe,
siebel.S_ACCNT_POSTN ap,
siebel.S_EMP_PER ep
where 1=1
and o.row_id=op.OPTY_ID 
and o.PR_POSTN_ID = ps.row_id 
and u.row_id = ps.pr_emp_id
and oe.par_row_id = o.PR_DEPT_OU_ID
and ap.OU_EXT_ID=oe.row_id 
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.CUST_STAT_CD = '�������'

________________________________________________________________________________________________________
select /*+parallel(ap,512)*/ p.row_id,t.row_id,lov.val,t.created_by,ap.cvrg_role_cd,lov.DESC_TEXT
from siebel.s_evt_act t, 
siebel.s_org_ext o,
siebel.S_USER u,
siebel.S_CONTACT t3,
S_POSTN p,
S_ACCNT_POSTN ap,
siebel.S_LST_OF_VAL lov, 
siebel.S_EMP_PER ep
where t.target_ou_id = o.row_id
and u.row_id = t.OWNER_PER_ID
and t3.par_row_id = u.row_id 
and u.row_id = p.pr_emp_id
and o.row_id = ap.OU_EXT_ID and o.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and lov.VAL=t.TODO_CD 
and lov.DESC_TEXT='Bank'
and lov.val in ('������','������������ ������')
and lov.ACTIVE_FLG = 'Y' 
AND lov.TYPE = 'TODO_TYPE'
and t.Evt_Stat_Cd in ('�������������','� ������')
and t.TEMPLATE_FLG='N'  
and rownum < 2001

________________________________________________________________________________________________________
select t1.row_id,s.name
from siebel.S_OPTY t1, siebel.s_opty_postn op, S_STG s
where 
t1.opty_cd = '���'
and t1.row_id = op.opty_id and t1.pr_postn_id = op.position_id 
and s.row_id = t1.CURR_STG_ID
________________________________________________________________________________________________________
select /*+parallel(ap,512)*/ distinct p.row_id,o.row_id
from siebel.s_evt_act t, 
siebel.s_org_ext o,
siebel.S_USER u,
siebel.S_CONTACT t3,
S_POSTN p,
S_ACCNT_POSTN ap,
siebel.S_EMP_PER ep
where t.target_ou_id = o.row_id
and u.row_id = t.OWNER_PER_ID
and t3.par_row_id = u.row_id 
and u.row_id = p.pr_emp_id
and o.row_id = ap.OU_EXT_ID and o.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and t.Evt_Stat_Cd in ('�������������','� ������')
and o.X_SBRF_CLIENT_FLG='Y' 
and o.CLIENT_FLG='Y'
and o.OU_TYPE_CD='��. ����' 
and o.INT_ORG_FLG='N' 
and o.CUST_STAT_CD = '�������'
and p.row_id <> '0-5220'
________________________________________________________________________________________________________
select /*+parallel(512)*/ c.row_id,c.last_name,c.fst_name,oe.row_id
from siebel.S_ACCNT_POSTN ap,siebel.S_ORG_EXT oe, siebel.S_ORG_EXT_X orgx,  siebel.s_user u,siebel.s_postn b, siebel.S_EMP_PER ep,S_CONTACT c
where oe.X_SBRF_CLIENT_FLG='Y' 
and oe.OU_TYPE_CD='��. ����' 
and oe.active_flg = 'Y'
and oe.x_sbrf_client_flg = 'Y'
and oe.cust_stat_cd in ('����������')
and ap.cvrg_role_cd='���������� ��������' 
and ap.OU_EXT_ID=oe.row_id 
and oe.ROW_ID = orgx.row_id 
and b.PR_EMP_ID = u.row_id 
and b.row_id = oe.PR_POSTN_ID
and c.par_row_id = u.row_id
and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID
and c.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and b.row_id <> '0-5220'
and length (oe.name) < 20
/*and rownum < 501*/
________________________________________________________________________________________________________
select /*+parallel(512)*/
distinct
ps.row_id PositionId,
o.row_id
from siebel.S_OPTY o,
siebel.S_OPTY_POSTN op,
s_postn ps,
s_user u,
siebel.S_ORG_EXT oe,
siebel.S_ACCNT_POSTN ap,
siebel.S_EMP_PER ep
where 1=1
and o.row_id=op.OPTY_ID 
and o.PR_POSTN_ID = ps.row_id 
and u.row_id = ps.pr_emp_id
and oe.par_row_id = o.PR_DEPT_OU_ID
and oe.row_id = ap.OU_EXT_ID and oe.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and ap.cvrg_role_cd='���������� ��������'
and ps.x_pos_type_id is not null
and oe.X_SBRF_CLIENT_FLG='Y' 
and oe.CLIENT_FLG='Y'
and oe.OU_TYPE_CD='��. ����' 
and oe.INT_ORG_FLG='N' 
and oe.CUST_STAT_CD = '�������'
and rownum < 5001

________________________________________________________________________________________________________
select /*+parallel(ap,512)*/ t3.row_id,o.row_id
from  
siebel.s_org_ext o,
siebel.S_USER u,
siebel.S_CONTACT t3,
S_POSTN p,
S_ACCNT_POSTN ap, 
siebel.S_EMP_PER ep
where 
t3.par_row_id = u.row_id 
and u.row_id = p.pr_emp_id
and o.row_id = ap.OU_EXT_ID and o.pr_postn_id = ap.POSITION_ID
and u.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
and o.X_SBRF_CLIENT_FLG='Y' 
and o.CLIENT_FLG='Y'
and o.OU_TYPE_CD='��. ����' 
and o.INT_ORG_FLG='N' 
and o.CUST_STAT_CD = '�������' 

________________________________________________________________________________________________________
select /*+parallel(512)*/
distinct
u.login,
o.row_id
from siebel.S_OPTY o,
siebel.S_OPTY_POSTN op,
siebel.S_PARTY p,
siebel.S_SALES_METHOD sm,
s_postn ps,
s_user u,
siebel.S_ORG_EXT oe,
siebel.S_STG st
where 1=1
and o.row_id=op.OPTY_ID
and op.POSITION_ID=p.row_id 
and sm.ROW_ID=o.SALES_METHOD_ID
and o.PR_POSTN_ID = ps.row_id 
and u.row_id = ps.pr_emp_id
and oe.par_row_id = o.PR_DEPT_OU_ID
and sm.row_id = st.sales_method_id
and sm.row_id in ('1-IEOW1BN')   
/*and o.row_id = '1-I7N5094'*/
________________________________________________________________________________________________________
select rowid,o.row_id,o.X_QUOTATION_ID
from  
siebel.s_org_ext o
where o.X_QUOTATION_ID is not null
/*and o.row_id = '1-3HMEBHX'*/
rownum < 1001


update siebel.s_org_ext o
set o.X_QUOTATION_ID = '1-3HMEBHX'
where rownum < 1001
________________________________________________________________________________________________________
select s.X_INTEGRATION_ID IntergationID, 
s.CST_OU_ID ReferenceCRMId,
x.sr_id ServiceRequestId
from siebel.s_srv_req s, s_srv_req_x x
where
s.x_integration_id is not null
and s.CST_OU_ID is not null
and s.SR_SUBTYPE_CD in ('��� (����� / �������� ������)')
and s.sr_cat_type_cd in ('���������')
and s.row_id=x.row_id
and s.X_INTEGRATION_ID not in ('crm-to-sbbol-4')
order by s.created desc
________________________________________________________________________________________________________
select distinct c.login,t.lead_id
from siebel.cx_lead_postn t, s_postn a, s_user c, siebel.S_EMP_PER ep
where a.row_id = t.postn_id
and a.pr_emp_id = c.row_id
and c.login not in ('SADMIN')
and c.row_id = ep.row_id and ep.EMP_STAT_CD <> 'Terminated'
________________________________________________________________________________________________________
select c.sbrf_sbbol_id
from siebel.S_OPTY o,
siebel.S_OPTY_POSTN op,
CX_OPTY_SBBOL_X c,
s_postn ps,
s_user u
where 1=1
and c.row_id = o.row_id
and o.row_id=op.OPTY_ID 
and o.PR_POSTN_ID = ps.row_id 
and u.row_id = ps.pr_emp_id
and o.opty_cd = '���'
and u.login = 'SBBOL'
and c.created > sysdate -1
order by c.created desc
________________________________________________________________________________________________________

________________________________________________________________________________________________________

________________________________________________________________________________________________________

________________________________________________________________________________________________________

________________________________________________________________________________________________________

________________________________________________________________________________________________________

________________________________________________________________________________________________________
