package com.sbt.InfluxDB;

import com.sbt.tstub.TStub;
import com.sbt.tstub.webInterface.ResponseHelper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonWriter;
import java.io.*;

public class InfluxDBHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(InfluxDBHandler.class);
    private final String path;
    private final InfluxDBService influxDBService;

    public InfluxDBHandler(final String path, final InfluxDBService influxDBService) {
        this.path = path;
        this.influxDBService = influxDBService;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        int responseCode = 200;
        JsonObject response;
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        try {
            String requestURI = t.getRequestURI().getPath().substring(path.length() + 1);

            switch (requestURI) {
                case "put":
                    StringWriter strWriter = new StringWriter();
                    InputStream is = t.getRequestBody();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    final char[] buffer = new char[1024];
                    int count;
                    while ((count = br.read(buffer)) != -1) {
                        strWriter.write(buffer, 0, count);
                    }
                    br.close();
                    strWriter.close();
                    influxDBService.getInfluxDB().addStats(strWriter + "\n");
                    response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, requestURI);
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, null,
                            "Method \"" + path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (Exception ex) {
            logger.error("Неизвестная ошибка. ", ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, null,
                    "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        String data = strWriter.getBuffer().toString();
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }
}
