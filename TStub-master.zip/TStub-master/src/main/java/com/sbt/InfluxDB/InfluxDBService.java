package com.sbt.InfluxDB;

import com.sbt.tstub.environment.property.PropertyService;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class InfluxDBService {
    private static Logger LOGGER = LogManager.getLogger(InfluxDBService.class);
    @Getter
    private InfluxDB influxDB;

    public InfluxDBService(final PropertyService propertyService) {
        influxDB = create(propertyService);
    }

    private InfluxDB create(final PropertyService propertyService) {
        String host = propertyService.getPropertyValueByName("InfluxDB_host:port");
        String dbName = propertyService.getPropertyValueByName("InfluxDB_database");
        String dbLogin = propertyService.getPropertyValueByName("InfluxDB_login");
        String dbPassword = propertyService.getPropertyValueByName("InfluxDB_password");
        if (host == null || dbName == null) {
            LOGGER.error(
                    "Не найдены параметры для подключения к InfluxDB! Статистика не будет отправляться в InfluxDB.");
            return new InfluxDB(propertyService, host, dbLogin, dbPassword, dbName, 60000);
        }
        if (dbLogin == null || dbPassword == null) {
            dbLogin = "admin";
            dbPassword = "admin";
            LOGGER.debug(
                    "Не заданы параметры для аутентификации в InfluxDB. Будет выполнено подключение без аутентификации.");
        }
        return new InfluxDB(propertyService, host, dbLogin, dbPassword, dbName, 60000);
    }

    public void shutdown() {
        influxDB.shutdown();
    }

    public void restart(final PropertyService propertyService) {
        shutdown();
        influxDB = create(propertyService);
    }
}
