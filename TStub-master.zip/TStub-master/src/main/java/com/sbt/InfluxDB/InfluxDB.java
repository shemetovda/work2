package com.sbt.InfluxDB;

import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.property.PropertyService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

public class InfluxDB extends Thread {

    private static final Logger LOGGER = LogManager.getLogger(InfluxDB.class);

    private final PropertyService propertyService;

    private String URL, login, password, dbName;
    private String name;
    private long delay;
    private long resolution;
    private int counterMax;
    private boolean work;
    private URL url;
    private HttpURLConnection httpConn;
    private ConcurrentMap<String, Integer> statsMap = new ConcurrentHashMap();
    private ConcurrentMap<String, Integer> statsMapClear = new ConcurrentHashMap();
    private ConcurrentMap<String, Integer> statsMapReplace = new ConcurrentHashMap();
    private ConcurrentLinkedQueue<String> statsList = new ConcurrentLinkedQueue();

    InfluxDB(final PropertyService propertyService, String host, String login, String password, String dbName, long delay) {
        this.propertyService = propertyService;
        try {
            URL = "http://" + host;
            this.login = login;
            this.password = password;
            this.dbName = dbName;
            this.delay = delay;
            if (login != null) {
                url = new URL(URL + "/write?db=" + dbName + "&u=" + login + "&p=" + password);
            } else {
                url = new URL(URL + "/write?db=" + this.dbName);
            }
            LOGGER.debug("Ссылка для отправки: " + URL);
        } catch (MalformedURLException ex) {
            LOGGER.fatal("Невалидная ссылка: " + URL);
            URL = null;
        }
        name = propertyService.getPropertyValueByName("TStub_name");
        if (name == null) {
            name = BaseService.T_STUB;
        }
        try {
            resolution = Long.parseLong(propertyService.getPropertyValueByName("InfluxDB_resolution"));
            if (resolution == 0) {
                resolution = 10000;
            } else {
                resolution *= 1000;
            }
        } catch (Exception ex) {
            resolution = 10000;
        }
        work = true;
        counterMax = (int) (this.delay / resolution);
        if (counterMax < 1) {
            counterMax = 1;
        }
    }

    public void putStats(String metric, int value) {
        if (URL != null) {
            statsMap.put(metric, statsMap.getOrDefault(metric, 0) + value);
        }
    }

    public void putStats(String metric) {
        if (URL != null) {
            statsMap.put(metric, statsMap.getOrDefault(metric, 0) + 1);
        }
    }

    public void putStatsClear(String metric, int value) {
        if (URL != null) {
            statsMapClear.put(metric, statsMapClear.getOrDefault(metric, 0) + value);
        }
    }

    public void putStatsClear(String metric) {
        if (URL != null) {
            statsMapClear.put(metric, statsMapClear.getOrDefault(metric, 0) + 1);
        }
    }

    public void putStatsReplace(String metric, int value) {
        if (URL != null) {
            statsMapReplace.put(metric, value);
        }
    }

    public void addMeasurementStats(String measurement, String tags, String values) {
        if (URL != null) {
            String result = measurement + ",instance=" + name;
            if (tags != null) {
                result += "," + tags + " " + values + " " + System.currentTimeMillis() + "000000";
            } else {
                result += " " + values + " " + System.currentTimeMillis() + "000000";
            }
            statsList.add(result);
        }
    }

    public void addStats(String metric) {
        if (URL != null) {
            statsList.add(metric);
        }
    }

    @Override
    public String toString() {
        return "URL = " + URL + ", login = " + login + ", password = " + password + ", dbName = " + dbName;
    }

    private int send(final String message) {
        try {
            OutputStream os;
            BufferedWriter osw;
            httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setRequestMethod("POST");
            httpConn.setDoInput(true);
            httpConn.setDoOutput(true);
            os = httpConn.getOutputStream();
            osw = new BufferedWriter(new OutputStreamWriter(os));
            osw.write(message);
            osw.flush();
            osw.close();
            os.close();
            int state = httpConn.getResponseCode();
            LOGGER.trace("Данные\n{}", message);
            if (state != 204) {
                LOGGER.error("Ошибка отправки сообщения код={}", state);
                LOGGER.trace("Ошибка отправки сообщения код={}\n{}", state, message);
                return state;
            }
            return state;
        } catch (IOException ex) {
            LOGGER.error("Сервер не отвечает.{}", URL, ex);
            return 404;
        }
    }

    @Override
    public void run() {
        Thread.currentThread().setName("InfluxDBsender");
        LOGGER.debug("Поток запущен.");
        int counter = 0;
        StringBuilder builder = new StringBuilder();
        while (work || builder.length() != 0) {
            try {
                for (Map.Entry<String, Integer> entry : statsMap.entrySet()) {
                    builder.append("TStub_stats,instance=").append(name).append(",stat=").append(
                            entry.getKey()).append(" value=").append(entry.getValue()).append(" ").append(
                            System.currentTimeMillis()).append("000000\n");
                }

                for (Map.Entry<String, Integer> entry : statsMapClear.entrySet()) {
                    builder.append("TStub_statsClear,instance=").append(this.name).append(",stat=").append(
                            entry.getKey()).append(" value=").append(entry.getValue()).append(" ").append(
                            System.currentTimeMillis()).append("000000\n");
                }
                statsMapClear.clear();

                for (Map.Entry<String, Integer> entry : statsMapReplace.entrySet()) {
                    builder.append("TStub_statsReplace,instance=").append(name).append(",stat=").append(
                            entry.getKey()).append(" value=").append(entry.getValue()).append(" ").append(
                            System.currentTimeMillis()).append("000000\n");
                }

                for (String entry : statsList) {
                    builder.append(entry).append("\n");
                }
                statsList.clear();

                counter++;
                if (builder.length() != 0 && counter >= counterMax) {
                    builder.append("TStub_InfluxDB,instance=").append(name).append(",stat=length" + " value=").
                            append(builder.length()).append(" ").append(System.currentTimeMillis()).append("000000\n");
                    int state = send(builder.toString());
                    if (state == 400 || state < 300) {
                        counter = 0;
                        builder = new StringBuilder();
                    }
                    if (!work || !Boolean.getBoolean(propertyService.getPropertyValueByName("InfluxDB_senderPersist"))) {
                        builder = new StringBuilder();
                    }
                }
                Thread.sleep(resolution);
            } catch (InterruptedException ex) {
                LOGGER.debug(BaseService.THREAD_WILL_STOP);
                return;
            }
        }
        statsMap.clear();
        statsMapClear.clear();
        statsMapReplace.clear();
        statsList.clear();
        LOGGER.debug(BaseService.THREAD_IS_STOPPED);
    }

    public void shutdown() {
        work = false;
    }
}
