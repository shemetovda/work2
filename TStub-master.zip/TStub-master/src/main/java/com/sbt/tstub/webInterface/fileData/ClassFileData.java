package com.sbt.tstub.webInterface.fileData;

public class ClassFileData extends FileData{
    
    protected String classPath;

    public ClassFileData(int id, String fileName, String classPath, boolean update, int type) {
        super(id, fileName, update, type);
        this.classPath = classPath;
    }

    public String getComment() {
        return this.classPath;
    }
}
