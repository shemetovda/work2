package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.w3c.dom.Element;

public class FormatDateTime extends TemplateNode {

    private int shift;

    public FormatDateTime(Element elem) throws IllegalArgumentException, NumberFormatException {
        this.value = elem.getTextContent();

        if (elem.hasAttribute("shift")) {
            this.shift = Integer.parseInt(elem.getAttribute("shift"));
        } else {
            this.shift = 0;
        }
    }

    public FormatDateTime(String value, int shift) throws IllegalArgumentException, NumberFormatException {
        this.value = value;
        this.shift = shift;
    }

    @Override
    public String process(String value, TStubMessage sourse) throws IllegalArgumentException {
        if (value == null) {
            throw new IllegalArgumentException("Нельзя передавать значение null.");
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat(this.value);
        Date currDate = new Date(System.currentTimeMillis() + this.shift * 1000);
        return dateFormat.format(currDate).replace("\"", "");
    }

    @Override
    public String toString() {
        return "{value=" + this.value + "; shift=" + this.shift + "}";
    }
}
