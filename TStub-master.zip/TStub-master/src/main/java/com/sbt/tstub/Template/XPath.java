package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import org.apache.commons.lang3.StringEscapeUtils;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

public class XPath extends TemplateNode {

    private final javax.xml.xpath.XPath xPath = XPathFactory.newInstance().newXPath();

    public XPath(Element elem) throws IllegalArgumentException {
        value = elem.getTextContent();
    }

    public XPath(String value) throws IllegalArgumentException {
        this.value = value;
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        XPathExpression expr = xPath.compile(value);
        Object obj = expr.evaluate(sourse.getBody(), XPathConstants.NODESET);
        NodeList nodes = (NodeList) obj;
        if (nodes.getLength() != 0) {
            return copyNode(nodes);
        }
        throw new IllegalArgumentException("Не найдена информация по выражению " + value);
    }

    private String copyNode(NodeList nodes) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i).getNodeType() > 1) {
                result.append(StringEscapeUtils.escapeXml10(nodes.item(i).getTextContent()));
            } else {
                result.append("<").append(nodes.item(i).getNodeName());
                for (int j = 0; j < nodes.item(i).getAttributes().getLength(); j++) {
                    result.append(" ").append(nodes.item(i).getAttributes().item(j).getNodeName()).append("=\"").append(nodes.item(i).getAttributes().item(j).getNodeValue()).append("\"");
                }
                result.append(">");
                result.append(copyNode(nodes.item(i).getChildNodes()));
                result.append("</").append(nodes.item(i).getNodeName()).append(">");
            }
        }
        return result.toString();
    }

    @Override
    public String toString() {
        return "{value=" + value + "}";
    }
}
