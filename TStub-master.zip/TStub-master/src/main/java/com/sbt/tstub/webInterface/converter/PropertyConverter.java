package com.sbt.tstub.webInterface.converter;

import com.sbt.tstub.environment.property.Property;

import javax.json.Json;
import javax.json.JsonObjectBuilder;

public class PropertyConverter {

    public JsonObjectBuilder convertToJson(final Property property) {
        JsonObjectBuilder obj = Json.createObjectBuilder();
        obj.add("name", property.getName());
        obj.add("value", property.getValue());
        obj.add("description", property.getDescription());
        return obj;
    }
}
