package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStub;
import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.template.DynamicClassOverloader;
import com.sbt.tstub.template.Template;
import com.sbt.tstub.webInterface.fileData.CertificateFileData;
import com.sbt.tstub.webInterface.fileData.FileData;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Element;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonWriter;
import java.io.*;
import java.lang.reflect.Constructor;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class UploadHandler implements HttpHandler {

    private static final Logger LOGGER = LogManager.getLogger(UploadHandler.class);

    private final String path;

    public UploadHandler(String path) {
        this.path = path;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        JsonObject response;
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        int responseCode = 200;
        try {
            String fileUUID = t.getRequestURI().getPath().substring(path.length() + 1);
            if (!fileUUID.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89ab][0-9a-fA-F]{3}-[0-9a-fA-F]{12}")) {
                LOGGER.error("Неправильный формат UUID: {}", fileUUID);
                responseCode = 400;
                response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, null, "Wrong format of UUID.");
            } else {
                FileData data = UploadEnvironment.getEnvironments().removeFile(fileUUID);
                if (data != null) {
                    //определяем тип загрузки
                    switch (data.getType()) {
                        case FileData.CERTIFICATE:
                            response = uploadCertificate(fileUUID, (CertificateFileData) data, t.getRequestBody());
                            break;
                        case FileData.CLASS:
                            response = uploadClass(fileUUID, data, t.getRequestBody());
                            break;
                        default:
                            responseCode = 501;
                            response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, fileUUID, "File not allowed.");
                            break;
                    }
                } else {
                    LOGGER.error("Не найден файл с fileUUID: {}", fileUUID);
                    responseCode = 400;
                    response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, fileUUID, "File with fileUUID not found.");
                }
            }
        } catch (Exception ex) {
            LOGGER.error("Неизвестная ошибка.", ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, null, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        String data = strWriter.getBuffer().toString();
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject uploadCertificate(String fileUUID, CertificateFileData data, InputStream requestBody) {
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            JsonObject response;
            //Если мы добавляем новый файл
            if (!data.isUpdate()) {
                String folderPath = "certificates";
                File file = new File(folderPath);
                file.mkdir();
                String filePath = "certificates\\" + data.getName();
                file = new File(filePath);
                if (!file.exists()) {
                    OutputStream out = new FileOutputStream(file);

                    int read = 0;
                    byte[] bytes = new byte[1024];

                    while ((read = requestBody.read(bytes)) != -1) {
                        out.write(bytes, 0, read);
                    }
                    out.close();
                    requestBody.close();

                    //Файл записали, добавляем информацию в БД
                    String query = "INSERT INTO SSLCertificates (path, key, JavaChiperSuite, FIPSRequired, SSLType, comment, fileName) ";
                    query += "VALUES(?,?,?,?,?,?,?)";
                    try (PreparedStatement prs = c.prepareStatement(query)) {
                        prs.setString(1, filePath);
                        prs.setString(2, data.getKey());
                        prs.setString(3, data.getJavaChiperSuite());
                        prs.setBoolean(4, data.getFIPSRequired());
                        prs.setString(5, data.getSSLType());
                        prs.setString(6, data.getComment());
                        prs.setString(7, data.getName());

                        int res = prs.executeUpdate();
                        if (res > 0) {
                            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, fileUUID);
                        } else {
                            response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, fileUUID, "SSLCertificates not INSERTED.");
                        }
                        c.commit();
                    } catch (SQLException e) {
                        LOGGER.fatal(fileUUID + ":Ошибка при выполнения запроса к таблице SSLCertificates.", e);
                        response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, fileUUID, "Error with INSERT to SSLCertificates. " + e.getLocalizedMessage());
                    }
                } else {
                    response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, fileUUID, "File with name \"" + data.getName() + "\" already exist.");
                }
            } else { //Если мы меняем предыдущий шаблон
                Statement stmt = c.createStatement();
                String query = "SELECT * FROM SSLCertificates WHERE id=" + data.getId();
                ResultSet rs = stmt.executeQuery(query);
                if (rs.next()) {
                    String oldFilePath = rs.getString("path");
                    rs.close();
                    File file = new File(oldFilePath);
                    file.delete();
                    String newFilePath = "certificates\\" + data.getName();
                    file = new File(newFilePath);
                    if (!file.exists()) {
                        OutputStream out = new FileOutputStream(file);

                        int read = 0;
                        byte[] bytes = new byte[1024];

                        while ((read = requestBody.read(bytes)) != -1) {
                            out.write(bytes, 0, read);
                        }
                        out.close();
                        requestBody.close();

                        query = "UPDATE SSLCertificates SET path=?,key=?,fileName=?,JavaChiperSuite=?,SSLType=?,FIPSRequired=?,comment=? WHERE id=?";
                        try (PreparedStatement prs = c.prepareStatement(query)) {
                            prs.setString(1, newFilePath);
                            prs.setString(2, data.getKey());
                            prs.setString(3, data.getName());
                            prs.setString(4, data.getJavaChiperSuite());
                            prs.setString(5, data.getSSLType());
                            prs.setBoolean(6, data.getFIPSRequired());
                            prs.setString(7, data.getComment());
                            prs.setInt(8, data.getId());

                            int res = prs.executeUpdate();
                            if (res > 0) {
                                response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, fileUUID);
                            } else {
                                response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, fileUUID, "SSLCertificate not INSERTED.");
                            }
                            prs.close();
                            c.commit();
                        } catch (SQLException e) {
                            LOGGER.fatal(fileUUID + ":Ошибка при выполнения запроса к таблице SSLCertificates.", e);
                            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, fileUUID, "Error with INSERT to SSLCertificates. " + e.getLocalizedMessage());
                        }
                    } else {
                        response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, fileUUID, "File with name \"" + data.getName() + "\" already exist.");
                    }
                } else {
                    response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, fileUUID, "File with fileUUID not found.");
                }
            }
            return response;
        } catch (Exception ex) {
            LOGGER.error("{}:Неизвестная ошибка.", fileUUID, ex);
            return ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, fileUUID, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }
    }

    private JsonObject uploadClass(String fileUUID, FileData data, InputStream requestBody) {
        try {
            File file = new File("temp");
            file.mkdirs();
            String fileName = fileUUID + "_" + data.getName();
            String filePath = "temp\\" + fileName;
            //Создание папки, если её нет

            file = new File(filePath);
            JsonObject response;
            if (!file.exists()) {
                //Получаем архив
                OutputStream out = new FileOutputStream(file);

                int read = 0;
                byte[] bytes = new byte[1024];

                while ((read = requestBody.read(bytes)) != -1) {
                    out.write(bytes, 0, read);
                }
                out.close();
                requestBody.close();
                //распаковываем архив
                if (data.getName().toLowerCase().endsWith("zip")) {
                    BaseService.unZIP(filePath, "temp\\" + fileUUID);
                } else {
                    BaseService.unJar(filePath, "temp\\" + fileUUID);
                }

                //распаковали, теперь найти все новые классы
                String tempFilePath = "temp\\" + fileUUID;
                ArrayList<Object> list;
                list = (ArrayList) Files.walk(Paths.get(tempFilePath)).filter(p -> p.toString().endsWith(".class")).filter(Files::isRegularFile).collect(Collectors.toList());

                //Известны все новые классы, TODO заменяем те что есть, если есть
                String classPath = "classes";
                for (Object item : list) {
                    String soursePath = item.toString();
                    String destPath = classPath + soursePath.substring(tempFilePath.length());
                    File srcFile = new File(soursePath);
                    File destFile = new File(destPath.substring(0, destPath.lastIndexOf("\\")));
                    //Сначала загружаем в память, потом копируем файл

                    //Пробрасываем нужные папки
                    destFile.mkdirs();
                    destFile = new File(destPath);
                    try (FileInputStream sfis = new FileInputStream(srcFile); FileOutputStream dfos = new FileOutputStream(destFile, false)) {

                        //Копируем для шаблона
                        byte[] buffer = new byte[sfis.available()];
                        sfis.read(buffer, 0, buffer.length);
                        dfos.write(buffer, 0, buffer.length);

                        //TODO: Загружаем класс в память
                        ClassLoader loader = new DynamicClassOverloader(new String[]{"classes/"});
                        Class clazz = Class.forName(destPath.substring(8, destPath.length() - 6).replace("\\", "."), true, loader);
                        Constructor constructor = clazz.getConstructor(Element.class, Template.class);
                    } catch (IOException ex) {
                        LOGGER.error("Не удалось скопировать файл.", ex);
                    } catch (NoSuchMethodException | SecurityException ex) {
                        throw new IllegalArgumentException("Class constructor not found:" + ex.getLocalizedMessage());
                    } catch (ClassNotFoundException | NoClassDefFoundError ex) {
                        throw new IllegalArgumentException("Class not found:" + ex.getLocalizedMessage());
                    }
                }
                file.delete();
                file = new File(tempFilePath);
                file.delete();
                response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, fileUUID);
            } else {
                response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, fileUUID, "File with name \"" + data.getName() + "\" already exist.");
            }
            return response;
        } catch (Exception ex) {
            LOGGER.error("{}:Неизвестная ошибка.", fileUUID, ex);
            return ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, fileUUID, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }
    }
}
