package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import org.w3c.dom.Element;

public class HTTP extends TemplateNode {

    public static final int ACCEPT_TEXT = 0;
    public static final int ACCEPT_XML = 1;
    public static final int ACCEPT_JSON = 2;
    
    private String urlString;
    private String type;
    private String accept;
    private Template template;

    HTTP(Element elem, Template template) throws IllegalArgumentException {
        this.urlString = elem.getAttribute("URL");
        if (this.urlString.length() < 1) {
            throw new IllegalArgumentException("Attribute \"URL\" is empty.");
        }
        this.type = elem.getAttribute("type");
        if (this.type.length() < 1) {
            throw new IllegalArgumentException("Attribute \"type\" is empty.");
        }
        this.accept = elem.getAttribute("accept");
        if (this.accept.length() < 1) {
            throw new IllegalArgumentException("Attribute \"accept\" is empty.");
        }
    }

    HTTP(String type, int length, int from, int to) throws IllegalArgumentException {
    }    
    
    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        String res = "";
        return res;
    }
}
