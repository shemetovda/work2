package com.sbt.tstub.environment.writer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import org.apache.commons.pool2.ObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPool;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.exception.StubQueueValidationException;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.mq.MQWriter;
import com.sbt.tstub.mq.PooledMQWriter;
import com.sbt.tstub.mq.SenderQueue;
import com.sbt.tstub.mq.StubQueue;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class WriterService {

    private static final String SELECT_ALL_WRITERS_QUERY = "SELECT * FROM MQWriters;";
    private static final String SELECT_WRITERS_QUERY = "SELECT * FROM MQWriters WHERE [default]=0 AND active=1;";
    private static final String SELECT_BY_UNIQUE_QUERY = "SELECT id FROM MQWriters WHERE " +
            "host=? AND port=? AND manager=? AND channel=? AND queue=?";
    private static final String SELECT_DEF_WRITER_QUERY = "SELECT * FROM MQWriters WHERE [default]=1 AND active=1;";
    private static final String INSERT_QUERY = "INSERT INTO MQWriters " +
            "(host, port, manager, channel, queue, active, [default], SSLCertificateID, login, password)" +
            "VALUES(?,?,?,?,?,?,?,?,?,?)";
    private static final String UPDATE_QUERY = "UPDATE MQWriters " +
            "SET host=?, port=?, manager=?, channel=?, queue=?, active=?, [default]=?, SSLCertificateID=?, login=?, password=?" +
            "WHERE id=?";
    private static final String DELETE_QUERY = "DELETE FROM MQWriters WHERE id=?";

    private final PropertyService propertyService;
    private final InfluxDBService influxDBService;

    @Getter
    private final Map<String, ObjectPool<MQWriter>> writers = new ConcurrentHashMap();
    @Getter
    private final List<WriterIdKey> availableWriterKeys = new CopyOnWriteArrayList<>();
    @Getter
    private ObjectPool<MQWriter> defWriter = null;

    public WriterService(PropertyService propertyService,
                         InfluxDBService influxDBService) {
        this.propertyService = propertyService;
        this.influxDBService = influxDBService;
    }

    private void initWriters() throws SQLException, StubQueueValidationException {
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             Statement stmt = c.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_WRITERS_QUERY)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String host = rs.getString("host");
                int port = rs.getInt("port");
                String manager = rs.getString("manager");
                String channel = rs.getString("channel");
                String queue = rs.getString("queue");
                String login = rs.getString("login");
                String password = rs.getString("password");
                boolean active = rs.getBoolean("active");
                int certID = rs.getInt("SSLCertificateID");
                String key = host + ":" + port + ":" + manager + ":" + channel + ":" + queue;
                MQWriter writer = new MQWriter(propertyService, influxDBService, id, host, port, manager, channel,
                                               queue, login, password, active, certID, false);
                SenderQueue.validate(writer.getSq());
                ObjectPool<MQWriter> pool = setObjectPoolParams(new GenericObjectPool<>(new PooledMQWriter(writer)));
                writers.put(key, pool);
                availableWriterKeys.add(new WriterIdKey(key, id));
            }
        }
    }

    public void shutdown() {
        writers.forEach((key, writer) -> writer.close());
        writers.clear();
        availableWriterKeys.clear();
        if (defWriter != null) {
            defWriter.close();
            defWriter = null;
        }
    }

    public void refresh() throws SQLException, StubQueueValidationException {
        shutdown();
        initWriters();
        initDefWriter();
    }

    private void initDefWriter() throws SQLException, StubQueueValidationException {
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             Statement stmt = c.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_DEF_WRITER_QUERY)) {
            if (rs.next()) {
                int id = rs.getInt("id");
                String host = rs.getString("host");
                int port = rs.getInt("port");
                String manager = rs.getString("manager");
                String channel = rs.getString("channel");
                String queue = rs.getString("queue");
                String login = rs.getString("login");
                String password = rs.getString("password");
                boolean active = rs.getBoolean("active");
                int certID = rs.getInt("SSLCertificateID");
                MQWriter writer = new MQWriter(propertyService, influxDBService, id, host, port, manager, channel,
                                               queue, login, password, active, certID, true);
                SenderQueue.validate(writer.getSq());
                ObjectPool<MQWriter> pool = setObjectPoolParams(new GenericObjectPool<>(new PooledMQWriter(writer)));
                defWriter = pool;
            }
        }
    }

    public List<MQWriter> getWritersFromDB() throws SQLException {
        List<MQWriter> result = new LinkedList<>();
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             Statement stmt = c.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_ALL_WRITERS_QUERY)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String host = rs.getString("host");
                int port = rs.getInt("port");
                String manager = rs.getString("manager");
                String channel = rs.getString("channel");
                String queue = rs.getString("queue");
                String login = rs.getString("login");
                String password = rs.getString("password");
                boolean active = rs.getBoolean("active");
                int certID = rs.getInt("SSLCertificateID");
                boolean isDefaultQueue = rs.getBoolean("default");
                result.add(
                        new MQWriter(propertyService, influxDBService, id, host, port, manager, channel, queue, login,
                                     password, active, certID, isDefaultQueue));
            }
        }
        return result;
    }

    public boolean add(final MQWriter writer) throws StubQueueValidationException, SQLException {
        StubQueue.validate(writer.getSq());
        return addToDB(writer);
    }

    public boolean addToWriters(final MQWriter writer) throws StubQueueValidationException {
        SenderQueue.validate(writer.getSq());
        ObjectPool<MQWriter> pool = setObjectPoolParams(new GenericObjectPool<>(new PooledMQWriter(writer)));
        return writers.putIfAbsent(writer.getKey(), pool) == null;
    }

    private boolean addToDB(final MQWriter writer) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            PreparedStatement prs = c.prepareStatement(INSERT_QUERY);
            prs.setString(1, writer.getSq().getHost());
            prs.setInt(2, writer.getSq().getPort());
            prs.setString(3, writer.getSq().getManager());
            prs.setString(4, writer.getSq().getChannel());
            prs.setString(5, writer.getSq().getQueueName());
            prs.setBoolean(6, writer.getSq().isActive());
            prs.setBoolean(7, writer.isDefaultQueue());
            if (writer.getSq().getCertID() == 0) {
                prs.setNull(8, 0);
            } else {
                prs.setInt(8, writer.getSq().getCertID());
            }
            prs.setString(9, writer.getSq().getLogin());
            prs.setString(10, writer.getSq().getPassword());

            prs.executeUpdate();
            prs.close();
            c.commit();

            prs = c.prepareStatement(SELECT_BY_UNIQUE_QUERY);
            prs.setString(1, writer.getSq().getHost());
            prs.setInt(2, writer.getSq().getPort());
            prs.setString(3, writer.getSq().getManager());
            prs.setString(4, writer.getSq().getChannel());
            prs.setString(5, writer.getSq().getQueueName());
            ResultSet rs = prs.executeQuery();
            if (rs.next()) {
                writer.getSq().setId(rs.getInt("id"));
                result = true;
            } else {
                result = false;
            }
            rs.close();
            prs.close();
        }
        return result;
    }

    public boolean update(final MQWriter writer) throws SQLException, StubQueueValidationException {
        StubQueue.validate(writer.getSq());
        return updateIntoDB(writer);
    }

    private boolean updateIntoDB(final MQWriter writer) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             PreparedStatement prs = c.prepareStatement(UPDATE_QUERY)) {
            c.setAutoCommit(false);
            prs.setString(1, writer.getSq().getHost());
            prs.setInt(2, writer.getSq().getPort());
            prs.setString(3, writer.getSq().getManager());
            prs.setString(4, writer.getSq().getChannel());
            prs.setString(5, writer.getSq().getQueueName());
            prs.setBoolean(6, writer.getSq().isActive());
            prs.setBoolean(7, writer.isDefaultQueue());
            if (writer.getSq().getCertID() == 0) {
                prs.setNull(8, 0);
            } else {
                prs.setInt(8, writer.getSq().getCertID());
            }
            prs.setString(9, writer.getSq().getLogin());
            prs.setString(10, writer.getSq().getPassword());
            prs.setInt(11, writer.getSq().getId());
            int res = prs.executeUpdate();
            result = res > 0;
            c.commit();
        }
        return result;
    }

    public boolean remove(final int writerId) throws SQLException {
        return removeFromDB(writerId);
    }

    private boolean removeFromDB(final int writerId) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             PreparedStatement prs = c.prepareStatement(DELETE_QUERY)) {
            c.setAutoCommit(false);
            prs.setInt(1, writerId);
            int res = prs.executeUpdate();
            result = res > 0;
            c.commit();
        }
        return result;
    }

    private GenericObjectPool setObjectPoolParams(final GenericObjectPool pool) {
        pool.setMinIdle(Integer.parseInt(propertyService.getPropertyValueByName("writer_minIdle")));
        pool.setMaxIdle(Integer.parseInt(propertyService.getPropertyValueByName("writer_maxIdle")));
        pool.setMaxTotal(Integer.parseInt(propertyService.getPropertyValueByName("writer_maxTotal")));
        pool.setMaxWaitMillis(Long.parseLong(propertyService.getPropertyValueByName("writer_maxWaitMillis")));
        pool.setMinEvictableIdleTimeMillis(
                Long.parseLong(propertyService.getPropertyValueByName("writer_minEvictableIdleTimeMillis")));
        pool.setTimeBetweenEvictionRunsMillis(
                Long.parseLong(propertyService.getPropertyValueByName("writer_timeBetweenEvictionRunsMillis")));
        return pool;
    }

    public ObjectPool<MQWriter> getPoolByKey(final String poolKey) {
        return writers.get(poolKey);
    }

    public String getWriterKeyByWriterId(final int mqWriterId) {
        WriterIdKey writerKey = availableWriterKeys.stream().filter(
                writer -> writer.getId() == mqWriterId).findAny().orElse(null);
        return writerKey == null ? null : writerKey.getKey();
    }

    @AllArgsConstructor
    @Data
    private static class WriterIdKey {
        private final String key;
        private final int id;
    }

}
