package com.sbt.tstub.environment.exception;

public class StubQueueValidationException extends Exception {

    public StubQueueValidationException(final String errorMessage) {
        super(errorMessage);
    }

    public StubQueueValidationException(final String errorMessage, Exception ex) {
        super(errorMessage, ex);
    }

}
