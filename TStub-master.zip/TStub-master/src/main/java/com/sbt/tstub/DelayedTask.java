package com.sbt.tstub;

import com.sbt.tstub.worker.WorkerTask;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 * Класс для организации очереди заданий, также реализует задержку
 * @author Жуйко Алексей Вячеславович <SBT-Zhuyko-AV@mail.ca.sbrf.ru>
 * @param <T>
 */
public class DelayedTask<T> implements Delayed{
    private final T task;
    private long startTime;

    /**
     * @param task {@link WorkerTask}
     * @param delay Задержка задачи в миллисекундах
     */
    public DelayedTask(T task, long delay) {
        this.task = task;
        this.startTime = System.currentTimeMillis() + delay;
    }

    @Override
    public long getDelay(TimeUnit unit) {
        long diff = startTime - System.currentTimeMillis();
        return unit.convert(diff, TimeUnit.MILLISECONDS);
    }

    @Override
    public int compareTo(Delayed o) {
        if (this.startTime < ((DelayedTask) o).startTime) {
            return -1;
        }
        if (this.startTime > ((DelayedTask) o).startTime) {
            return 1;
        }
        return 0;
    }
    
    public T getTask(){
        return this.task;
    }
    
    public void setDelay(long delay){
        this.startTime = System.currentTimeMillis() + delay;
    }
}
