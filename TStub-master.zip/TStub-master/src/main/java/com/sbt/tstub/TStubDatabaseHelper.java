package com.sbt.tstub;

import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.utils.ScriptRunner;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public final class TStubDatabaseHelper {

    private static final Logger LOGGER = LogManager.getLogger(TStubDatabaseHelper.class);

    private static TStubDatabaseHelper instance;
    private final BasicDataSource ds;

    public TStubDatabaseHelper() {
        checkDataBaseVersionANDUpdate();
        ds = new BasicDataSource();
        ds.setDriverClassName("org.sqlite.JDBC");
        ds.setInitialSize(1);
        ds.setMaxIdle(30);
        ds.setMinIdle(1);
        ds.setMaxTotal(30);
        ds.setMinEvictableIdleTimeMillis(10 * 60 * 1000);
        ds.setEnableAutoCommitOnReturn(true);
        ds.setConnectionProperties("foreign_keys=true");
        ds.setUrl("jdbc:sqlite:TStub.db");
        LOGGER.info("Соединение с базой данных успешно установлено.");

    }

    public static TStubDatabaseHelper getHelper() {
        TStubDatabaseHelper localInstance = instance;
        if (localInstance == null) {
            synchronized (TStubDatabaseHelper.class) {
                localInstance = instance;
                if (localInstance == null) {
                    instance = localInstance = new TStubDatabaseHelper();
                }
            }
        }
        return localInstance;
    }

    public Connection getConnection() {
        try {
            Connection c = ds.getConnection();
            return c;
        } catch (Exception e) {
            LOGGER.fatal("Невозможно установить соединение с базой данных.", e);
            return null;
        }
    }

    public void closeConnection() {
        synchronized (TStubDatabaseHelper.class) {
            try {
                ds.close();
            } catch (Exception e) {
                LOGGER.fatal("Невозможно разорвать соединение с базой данных.", e);
            }
            instance = null;
            LOGGER.info("Соединение с базой данных разорвано.");
        }
    }

    public int getNumIdle() {
        return ds.getNumIdle();
    }

    public int getNumActive() {
        return ds.getNumActive();
    }

    public int getNumTotal() {
        return ds.getNumActive() + ds.getNumIdle();
    }

    public boolean checkDataBaseVersionANDUpdate() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:TStub.db")) {
            conn.setAutoCommit(false);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT version FROM TStubVersions ORDER BY version desc;");

            if (rs.next()) {
                int dbVersion = rs.getInt("version");
                rs.close();
                stmt.close();
                if (dbVersion < BaseService.APPLICATION_VERSION) {
                    for (int i = dbVersion; i < BaseService.APPLICATION_VERSION; i++) {
                        Path path = Paths.get("sql", String.format("%d.sql", i));
                        ScriptRunner sr = new ScriptRunner(conn, false, true);
                        try {
                            sr.runScript(new BufferedReader(new FileReader(path.toFile())));
                        } catch (IOException ex) {
                            LOGGER.fatal("Невозможно проапдейтить базу новыми версиями, обратитесь к разработчику!", ex);
                            System.exit(0);
                        }
                        if (i == 18) {
                            templateRefactor18();
                            conn.close();
                            break;
                        }
                    }
                }
            }
            return true;
        } catch (SQLException | IOException ex) {
            LOGGER.fatal("Не могу выполнить запрос на версионность, база не проверена, работа программы может привести к проблемам с базой!", ex);
        }
        System.exit(0);
        return false;
    }

    private void templateRefactor18() throws SQLException, IOException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:TStub.db")) {
            conn.setAutoCommit(false);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Templates;");
            //заапдейченная база
            //id, template(path), comment
            List<Template> templateList = new LinkedList<>();
            while (rs.next()) {
                Template template = new Template(
                        rs.getInt("id"),
                        rs.getString("template"),
                        rs.getString("comment"));
                templateList.add(template);
            }
            rs.close();
            stmt.close();
            //открываем файл, читаем его в строку целиком
            //запихиваем эту строку во временное хранилище
            for (Template template : templateList) {
                File file = new File(template.getTemplate());
                byte[] encoded = Files.readAllBytes(Paths.get(template.getTemplate()));
                template.setTemplate(new String(encoded));
                file.delete();
            }
            //зачищаем таблицу
            stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM Templates;");
            stmt.close();
            //заливаем новые данные
            for (Template template : templateList) {
                PreparedStatement prs = conn.prepareStatement("INSERT INTO Templates (id, template, comment) VALUES (?,?,?)");
                prs.setInt(1, template.getId());
                prs.setString(2, template.getTemplate());
                prs.setString(3, template.getComment());
                prs.executeUpdate();
                prs.close();
            }
            conn.commit();
        }
        checkDataBaseVersionANDUpdate();
    }

    @Data
    @AllArgsConstructor
    private static class Template {
        private int id;
        private String template;
        private String comment;
    }
}
