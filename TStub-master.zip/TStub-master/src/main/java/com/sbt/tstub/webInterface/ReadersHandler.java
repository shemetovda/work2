package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.mq.MQProducers;
import com.sbt.tstub.mq.MQReader;
import com.sbt.tstub.TStub;
import com.sbt.tstub.environment.BaseService;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;
import java.util.UUID;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ReadersHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(ReadersHandler.class);

    private final String path;
    private final BaseService baseService;

    public ReadersHandler(String path, BaseService baseService) {
        this.path = path;
        this.baseService = baseService;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        int responseCode = 200;
        JsonObject response;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            jsonReader.close();
            switch (requestURI) {
                case "get":
                    response = getReaders(uuid);
                    break;
                case "getmin":
                    response = getReadersMin(uuid);
                    break;
                case "add":
                    response = addReader(uuid, json.getString("host", null), json.getInt("port", 0), json.getString("manager", null), json.getString("channel", null), json.getString("queue", null), json.getInt("numOfProviders", 0), json.getString("login", null), json.getString("password", null), json.getInt("certId", 0), json.getBoolean("active", false), json.getString("selector", ""));
                    break;
                case "update":
                    response = updReader(uuid, json.getInt("id", 0), json.getString("host", null), json.getInt("port", 0), json.getString("manager", null), json.getString("channel", null), json.getString("queue", null), json.getInt("numOfProviders", 0), json.getString("login", null), json.getString("password", null), json.getInt("certId", 0), json.getBoolean("active", false), json.getString("selector", ""));
                    break;
                case "remove":
                    response = removeReader(uuid, json.getInt("id", 0));
                    break;
                case "setpause":
                    if (json.getString("connectionId", null) != null) {
                        response = setPauseReader(uuid, json.getString("connectionId"));
                    } else {
                        logger.error("{}:Не введён connectionId.", uuid);
                        responseCode = 400;
                        response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "connectionId not found.");
                    }
                    break;
                case "setunpause":
                    if (json.getString("connectionId", null) != null) {
                        response = setUnPauseReader(uuid, json.getString("connectionId"));
                    } else {
                        logger.error("{}:Не введён connectionId.", uuid);
                        responseCode = 400;
                        response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "connectionId not found.");
                    }
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + this.path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.", uuid, ex);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (Exception ex) {
            logger.error("{}:Неизвестная ошибка. ", uuid, ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        String data = strWriter.getBuffer().toString();
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject setPauseReader(String uuid, String connectionId) {
        if (MQProducers.pauseReader(connectionId)) {
            return ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } else {
            return ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "MQReader with connectionId=" + connectionId + " not found.");
        }
    }

    private JsonObject setUnPauseReader(String uuid, String connectionId) {
        if (MQProducers.unPauseReader(connectionId)) {
            return ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } else {
            return ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "MQReader with connectionId=" + connectionId + " not found.");
        }
    }

    private JsonObject getReadersMin(String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();

        Set<String> set = MQProducers.getReadersKeys();
        JsonArrayBuilder readers = Json.createArrayBuilder();
        for (String item : set) {
            MQReader reader = MQProducers.getReader(item);
            JsonObjectBuilder obj = Json.createObjectBuilder();
            obj.add("id", reader.getId());
            obj.add("host", reader.getHost());
            obj.add("port", reader.getPort());
            obj.add("manager", reader.getManager());
            obj.add("channel", reader.getChannel());
            obj.add("queue", reader.getQueueName());
            obj.add("state", reader.state);
            obj.add("currentState", reader.currentState);
            obj.add("quantity", MQProducers.getReadersQuantity(item));
            readers.add(obj);
        }
        jsonBuilder.add("readers", readers);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }

    private JsonObject getReaders(String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            Statement stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MQReaders;");
            JsonArrayBuilder readers = Json.createArrayBuilder();
            while (rs.next()) {
                JsonObjectBuilder obj = Json.createObjectBuilder();
                obj.add("id", rs.getInt("id"));
                obj.add("host", rs.getString("host"));
                obj.add("port", rs.getInt("port"));
                obj.add("manager", rs.getString("manager"));
                obj.add("channel", rs.getString("channel"));
                obj.add("queue", rs.getString("queue"));
                if (rs.getString("login") == null) {
                    obj.addNull("login");
                } else {
                    obj.add("login", rs.getString("login"));
                }
                if (rs.getString("password") == null) {
                    obj.addNull("password");
                } else {
                    obj.add("password", rs.getString("password"));
                }
                obj.add("active", rs.getBoolean("active"));
                obj.add("certID", rs.getInt("SSLCertificateID"));
                obj.add("numOfProviders", rs.getInt("numOfProviders"));
                if (rs.getString("selector") == null) {
                    obj.addNull("selector");
                } else {
                    obj.add("selector", rs.getString("selector"));
                }
                readers.add(obj);
            }
            jsonBuilder.add("readers", readers);
            jsonBuilder.add("code", TStub.METHOD_OK);
            jsonBuilder.add("uuid", uuid);

            rs.close();
            stmt.close();
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице MQReaders. ", uuid, e);
            return ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Error with SELECT from MQReaders. " + e.getLocalizedMessage());
        }
        return jsonBuilder.build();
    }

    private JsonObject addReader(String uuid, String host, int port, String manager, String channel, String queue, int numOfProviders, String login, String password, int certId, boolean active, String selector) {
        JsonObject response = baseService.checkParameters(uuid, host, port, manager, channel, queue, numOfProviders);
        if (response != null) {
            return response;
        }

        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            String query = "INSERT INTO MQReaders (host, port, manager, channel, queue, active, numOfProviders, SSLCertificateID, login, password, selector) ";
            query += "VALUES(?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement prs = c.prepareStatement(query);
            prs.setString(1, host);
            prs.setInt(2, port);
            prs.setString(3, manager);
            prs.setString(4, channel);
            prs.setString(5, queue);
            prs.setBoolean(6, active);
            prs.setInt(7, numOfProviders);
            if (certId == 0) {
                prs.setNull(8, 0);
            } else {
                prs.setInt(8, certId);
            }
            prs.setString(9, login);
            prs.setString(10, password);
            if (selector.length() < 1) {
                prs.setNull(11, 0);
            } else {
                prs.setString(11, selector);
            }
            int res = prs.executeUpdate();
            if (res > 0) {
                response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
            } else {
                response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "MQReader not INSERTED.");
            }
            prs.close();
            c.commit();
            return response;
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице MQReaders.", uuid, e);
            return ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Error with INSERT to MQReaders. " + e.getLocalizedMessage());
        }
    }

    private JsonObject updReader(String uuid, int id, String host, int port, String manager, String channel, String queue, int numOfProviders, String login, String password, int certId, boolean active, String selector) {
        JsonObject response = baseService.checkParameters(uuid, host, port, manager, channel, queue, numOfProviders);
        if (response != null) {
            return response;
        }

        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            String query = "UPDATE MQReaders SET "
                    + "host=?,port=?,manager=?,channel=?,queue=?,active=?,numOfProviders=?,SSLCertificateID=?,login=?,password=?,selector=? "
                    + "WHERE id=?";
            PreparedStatement prs = c.prepareStatement(query);
            prs.setString(1, host);
            prs.setInt(2, port);
            prs.setString(3, manager);
            prs.setString(4, channel);
            prs.setString(5, queue);
            prs.setBoolean(6, active);
            prs.setInt(7, numOfProviders);
            if (certId == 0) {
                prs.setNull(8, 0);
            } else {
                prs.setInt(8, certId);
            }
            prs.setString(9, login);
            prs.setString(10, password);
            if (selector.length() < 1) {
                prs.setNull(11, 0);
            } else {
                prs.setString(11, selector);
            }
            prs.setInt(12, id);

            int res = prs.executeUpdate();
            if (res > 0) {
                response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
            } else {
                response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "MQReader with id=" + id + "not found.");
            }
            prs.close();
            c.commit();
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице MQReaders.", uuid, e);
            return ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Error with UPDATE MQReaders. " + e.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject removeReader(String uuid, int id) {
        JsonObject response;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            String query = "DELETE FROM MQReaders WHERE id=?";
            PreparedStatement prs = c.prepareStatement(query);
            prs.setInt(1, id);
            int res = prs.executeUpdate();
            if (res > 0) {
                response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
            } else {
                response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "MQReader with id=" + id + " not found.");
            }
            prs.close();
            c.commit();
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице MQReaders.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Error with DELETE from MQReaders. Probably this reader using in WorkerSteps yet." + e.getLocalizedMessage());
        }
        return response;
    }
}
