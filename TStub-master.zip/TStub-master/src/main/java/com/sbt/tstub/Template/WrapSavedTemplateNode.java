package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;

public class WrapSavedTemplateNode extends TemplateNode {

    private TemplateNode templateNode;
    private String savedResult;

    public WrapSavedTemplateNode(TemplateNode templateNode) {
        this.templateNode = templateNode;
        this.savedResult = null;
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        if (savedResult == null) {
            savedResult = this.templateNode.process(value, sourse);
        }
        return savedResult;
    }
    
    public TemplateNode getTemplateNode(){
        return this.templateNode;
    }
    
    @Override
    public String toString(){
        return templateNode.toString();
    }
    
    @Override
    public Object clone() throws CloneNotSupportedException{
        WrapSavedTemplateNode newNode = (WrapSavedTemplateNode) super.clone();
        newNode.savedResult = null;
        newNode.templateNode = (TemplateNode) newNode.templateNode.clone();
        return newNode;
    }
}
