package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;

public abstract class TemplateNode implements Cloneable {

    protected String value = null;

    public abstract String process(String value, TStubMessage sourse) throws Exception;

    public String getValue() {
        return this.value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public void setTemplate(Template template) {

    }
}
