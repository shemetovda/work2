package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import org.w3c.dom.Element;

public class FROMHeader extends TemplateNode {

    private String name;

    public FROMHeader(Element elem) throws IllegalArgumentException {
        if (!elem.hasAttribute("name")) {
            throw new IllegalArgumentException("Attribute \"name\" is empty.");
        }
        this.name = elem.getAttribute("name");
    }

    public FROMHeader(String name) throws IllegalArgumentException {
        if (name == null || name.length() < 1) {
            throw new IllegalArgumentException("Attribute \"name\" is empty.");
        }
        this.name = name;
    }

    @Override
    public String getValue() {
        return this.name;
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        Object res = sourse.getHeaders().get(value);
        if (res != null) {
            return res.toString();
        }
        return null;
    }

    @Override
    public String toString() {
        return "{name=" + this.name + "; value=" + this.value + "}";
    }
}
