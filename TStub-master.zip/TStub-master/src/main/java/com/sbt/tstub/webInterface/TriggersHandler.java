package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStub;
import com.sbt.tstub.environment.exception.TriggerValidationException;
import com.sbt.tstub.environment.trigger.Trigger;
import com.sbt.tstub.environment.trigger.TriggerService;
import com.sbt.tstub.webInterface.converter.TriggerConverter;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.json.*;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.Collection;
import java.util.UUID;

public class TriggersHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(TriggersHandler.class);

    private final String path;
    private final TriggerService triggerService;
    private final TriggerConverter triggerConverter;

    public TriggersHandler(final String path, TriggerService triggerService, TriggerConverter triggerConverter) {
        this.path = path;
        this.triggerService = triggerService;
        this.triggerConverter = triggerConverter;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        int responseCode = 200;
        JsonObject response;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            jsonReader.close();
            switch (requestURI) {
                case "get":
                    response = getTriggers(uuid);
                    break;
                case "add":
                    response = addTrigger(uuid, json);
                    break;
                case "update":
                    response = updateTrigger(uuid, json);
                    break;
                case "remove":
                    response = removeTrigger(uuid, json.getInt("id", -1));
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.", uuid, ex);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (RuntimeException ex) {
            logger.error("{}:Неизвестная ошибка.", uuid, ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        String data = ResponseHelper.buildResponseData(response);
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject getTriggers(final String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        JsonArrayBuilder triggersJson = Json.createArrayBuilder();
        Collection<Trigger> triggers = triggerService.getTriggers().values();
        triggers.forEach(trigger -> triggersJson.add(triggerConverter.convertToJson(trigger)));
        jsonBuilder.add("triggers", triggersJson);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }

    private JsonObject addTrigger(final String uuid, final JsonObject request) {
        Trigger trigger = triggerConverter.stepToObject(request);
        JsonObject response;
        try {
            triggerService.add(trigger);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице Triggers.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при записи в БД. " + e.getLocalizedMessage());
        } catch (TriggerValidationException ex) {
            logger.fatal("{}:Ошибка при валидации триггера.", uuid, ex);
            response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, ex.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject updateTrigger(String uuid, final JsonObject request) {
        Trigger trigger = triggerConverter.stepToObject(request);
        JsonObject response;
        try {
            triggerService.update(trigger);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице Triggers.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при записи в БД. " + e.getLocalizedMessage());
        } catch (TriggerValidationException ex) {
            logger.fatal("{}:Ошибка при валидации триггера.", uuid, ex);
            response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, ex.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject removeTrigger(final String uuid, final int triggerId) {
        JsonObject response;
        try {
            triggerService.remove(triggerId);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице Triggers.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка удаления из БД. " + e.getLocalizedMessage());
        }
        return response;
    }
}
