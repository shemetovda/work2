package com.sbt.tstub.webInterface;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StaticHandler implements HttpHandler {

    private static String path;

    public StaticHandler(String path) {
        this.path = path;
    }

    private static final Logger logger = LogManager.getLogger(StaticHandler.class);

    public void handle(HttpExchange t) throws IOException {
        try {
            String initPath = "web";
            String uri = t.getRequestURI().getPath().substring(path.length());
            String filePath = initPath + uri;
            if (uri.length() < 2) {
                filePath = initPath + "/index.html";
            }
            File file = new File(filePath).getCanonicalFile();
            if (!file.isFile()) {
                // Object does not exist or is not a file: reject with 404 error.
                String response = "404 (Not Found)\n";
                t.sendResponseHeaders(404, response.length());
                OutputStream os = t.getResponseBody();
                os.write(response.getBytes());
                os.close();
            } else {
                // Object exists and is a file: accept with response code 200.
                switch (filePath.substring(filePath.lastIndexOf(".") + 1).toLowerCase()) {
                    case "js":
                        t.getResponseHeaders().add("Content-Type", "application/javascript;charset=utf-8");
                        break;
                    case "css":
                        t.getResponseHeaders().add("Content-Type", "text/css;charset=utf-8");
                        break;
                    case "html":
                        t.getResponseHeaders().add("Content-Type", "text/html;charset=utf-8");
                        break;
                    default:
                        t.getResponseHeaders().add("Content-Type", "text/plain;charset=utf-8");
                        break;
                }
                OutputStream os = t.getResponseBody();
                if (t.getRequestURI().getPath().equals(path)) {
                    t.getResponseHeaders().add("Location", path + "/");
                    t.sendResponseHeaders(302, 0);
                } else {
                    t.sendResponseHeaders(200, 0);
                    FileInputStream fs = new FileInputStream(file);
                    final byte[] buffer = new byte[0x10000];
                    int count = 0;
                    while ((count = fs.read(buffer)) >= 0) {
                        os.write(buffer, 0, count);
                    }
                    fs.close();
                }
                os.close();
            }
        } catch (Exception ex) {
            logger.error("Неизвестная ошибка.", ex);
        }

    }
}
