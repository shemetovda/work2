package com.sbt.tstub.mq;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.sbt.InfluxDB.InfluxDB;
import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.DelayedTask;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.template.TemplateService;
import com.sbt.tstub.environment.trigger.Trigger;
import com.sbt.tstub.environment.trigger.TriggerService;
import com.sbt.tstub.environment.writer.WriterService;
import com.sbt.tstub.utils.StringUtils;
import com.sbt.tstub.worker.Worker;
import com.sbt.tstub.worker.WorkerTask;

import javax.jms.JMSException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.util.Iterator;
import java.util.List;

/**
 * Класс для определения необходимых действий для входящих сообщений
 *
 * @author Алексей
 */
public class MessageProvider extends Thread {

    private static final Logger LOGGER = LogManager.getLogger(MessageProvider.class);

    private final TriggerService triggerService;
    private final ScenarioService scenarioService;
    private final BaseService baseService;
    private final PropertyService propertyService;
    private final InfluxDBService influxDBService;
    private final TemplateService templateService;
    private final WriterService writerService;

    private final Worker<DelayedTask> worker = new Worker();
    private boolean work;
    private boolean ready;
    private boolean state;
    private final String queueID;

    public MessageProvider(TriggerService triggerService,
                           ScenarioService scenarioService,
                           BaseService baseService,
                           PropertyService propertyService,
                           InfluxDBService influxDBService,
                           TemplateService templateService,
                           WriterService writerService,
                           String queueID) {
        this.triggerService = triggerService;
        this.scenarioService = scenarioService;
        this.baseService = baseService;
        this.propertyService = propertyService;
        this.influxDBService = influxDBService;
        this.templateService = templateService;
        this.writerService = writerService;
        this.queueID = queueID;
        work = true;
    }

    @Override
    public void run() {
        worker.setName(Thread.currentThread().getName() + ":Worker");
        worker.start();
        synchronized (this) {
            boolean res = worker.isAlive();
            if (!res) {
                LOGGER.error("Поток Worker не может быть запущен");
                ready = true;
                state = res;
                return;
            }
            ready = true;
            state = true;
            notifyAll();
        }

        LOGGER.debug("Поток запущен.");
        while (work) {
            MQReader reader = MQProducers.getReader(queueID);
            if (reader != null) {
                process(reader);
            } else {
                LOGGER.error("Очередь для чтения с ID " + queueID + " не определёна.");
            }
        }
        worker.shutdown();
        while (worker.isAlive()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                LOGGER.fatal("Возникла непредвиденная ситуация при заверщении потока. Аварийное завершение...");
                return;
            }
        }
        LOGGER.debug(BaseService.THREAD_IS_STOPPED);
    }

    private void process(MQReader reader) {
        TStubMessage message = null;
        XPath xPath = XPathFactory.newInstance().newXPath();
        try {
            long startTime = System.currentTimeMillis();
            message = reader.read();
            if (message != null) {
                long duration = System.currentTimeMillis() - startTime;
                influxDBService.getInfluxDB().addMeasurementStats("times", "type=Read,queue=" + reader.getKey(),
                                                                  "duration=" + duration);
            }
        } catch (InterruptedException ex) {
            LOGGER.debug("Получена команда на остановку. Останавливаю дочерние потоки.");
            work = false;
        } catch (JMSException ex) {
            try {
                reader.close();
                LOGGER.warn("Соединение было потеряно.", ex);
                reader.currentState = StubQueue.ERROR;
                Thread.sleep(10000L);
                while (work) {
                    LOGGER.warn("Попытка подключиться заново.");
                    int res = reader.connect();
                    if (res == 0) {
                        LOGGER.warn("Соединенеие было восстановлено.");
                        reader.currentState = StubQueue.WORK;
                        break;
                    } else {
                        LOGGER.warn("Соединение не было восстановлено.");
                    }
                }
            } catch (InterruptedException ex1) {
                LOGGER.debug("Получена команда на остановку. Останавливаю дочерние потоки.");
                work = false;
                message = null;
            }
        } catch (ParserConfigurationException ex) {
            LOGGER.debug("Получена команда на остановку. Останавливаю дочерние потоки.");
        }
        if (message != null) {
            InfluxDB influxDB = influxDBService.getInfluxDB();
            long startTime = System.currentTimeMillis();
            Document document = message.getBody();

            List<Trigger> triggerList = triggerService.getAvailableTriggers();
            Iterator<Trigger> triggerIterator = triggerList.iterator();
            boolean check = false;
            int triggerID = 0;
            String triggerName = "null";
            while (triggerIterator.hasNext()) {
                Trigger trigger = triggerIterator.next();
                triggerID = trigger.getId();
                if (baseService.checkHeaders(message, trigger.getHeaders())) {
                    final String expression = trigger.getXPathExpression();
                    try {
                        NodeList nodes = (NodeList) xPath.evaluate(expression, document, XPathConstants.NODESET);
                        if (nodes.getLength() != 0) {
                            check = true;
                            triggerName = StringUtils.normalize(trigger.getComment());
                            influxDB.putStatsClear("expressionResult,result=" + triggerName);
                            LOGGER.debug("Получено сообщение типа {}id={}\n{}", expression, message.getMessageID(),
                                         message);
                            break;
                        }
                    } catch (XPathExpressionException e) {
                        LOGGER.error("triggerID={}: в выражении {} содержится ошибка.", triggerID, expression);
                    }
                }
            }
            if (check) { //найден триггер
                DelayedTask delayedTask = new DelayedTask(
                        new WorkerTask(scenarioService, propertyService, baseService, influxDBService, templateService,
                                       writerService, message, triggerID), 10);
                worker.putTask(delayedTask);
            } else { //триггер не найден
                LOGGER.debug("Получено сообщение неизвестного типа\n{}", message);
                influxDBService.getInfluxDB().putStatsClear("expressionResult,result=UnknownMessage");
                try {
                    MQWriter writer = writerService.getDefWriter().borrowObject();
                    if (writer != null) {
                        writer.put(message);
                        try {
                            writerService.getDefWriter().returnObject(writer);
                        } catch (Exception ex) {
                            LOGGER.error("Не могу вернуть очередь для записи по умолчанию.", ex);
                        }
                    } else {
                        LOGGER.error("Не найдена очередь для записи по умолчанию.");
                    }
                } catch (Exception ex) {
                    LOGGER.warn("Не могу получить очередь для записи по умолчанию.");
                }
            }
            long duration = System.currentTimeMillis() - startTime;
            influxDB.addMeasurementStats("times", "type=WorkerTaskMaker,triggerName=" + triggerName,
                                         "duration=" + duration);
        }
    }

    public boolean getStartState() {
        synchronized (this) {
            try {
                while (!ready) {
                    wait();
                }
            } catch (InterruptedException ex) {
                LOGGER.fatal("Возникла непредвиденная ситуация.", ex);
                return false;
            }
            return state;
        }
    }

    /**
     * Метод для безопасной остановки потока и остановки потока без потерь
     * данных
     */
    public void shutdown() {
        work = false;
        interrupt();
    }

    public int getQuantityWorkerTasks() {
        return worker.getWorkerTasksSize();
    }
}
