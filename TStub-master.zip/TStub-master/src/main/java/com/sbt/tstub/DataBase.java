package com.sbt.tstub;

import com.sbt.tstub.environment.BaseService;
import lombok.Getter;
import org.apache.commons.dbcp2.BasicDataSource;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Класс для создания пула подключений к базе данных
 *
 * @author Жуйко Алексей Вячеславович <SBT-Zhuyko-AV@mail.ca.sbrf.ru>
 */
public class DataBase {

    private static final String ORACLE_THIN = "jdbc:oracle:thin:@";
    private static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String MYSQL = "jdbc:mysql://";
    private static final String MYSQL_DRIVER = "com.mysql.jdbc.Driver";

    private BasicDataSource ds;
    @Getter
    private String key;

    /**
     * Конструктор создания пула подключений к базе данных
     *
     * @param type     Тип базы данных: oracle или mysql, регистронезависимо
     * @param host     Хост для подключения к базе данных
     * @param port     Порт для подключения к базе данных
     * @param schema   Схема/База
     * @param login    Логин для подключения
     * @param password Пароль для подключения
     * @throws IllegalArgumentException если тип базы данных не поддерживается
     * @throws ClassNotFoundException   если не найден класс с драйвером для подкючения к базе данных
     */
    public DataBase(final BaseService baseService,
                    final DataBaseType type,
                    final String host,
                    final String port,
                    final String schema,
                    final String login,
                    final String password) throws ClassNotFoundException {
        key = type.getName() + ":" + host + ":" + port + ":" + schema + ":" + login;
        ds = new BasicDataSource();
        switch (type) {
            case ORACLE:
                Class.forName(ORACLE_DRIVER);
                ds.setDriverClassName(ORACLE_DRIVER);
                ds.setUrl(ORACLE_THIN + host + ":" + port + "/" + schema);
                break;
            case MYSQL:
                Class.forName(MYSQL_DRIVER);
                ds.setDriverClassName(MYSQL_DRIVER);
                ds.setUrl(MYSQL + host + ":" + port + "/" + schema + "?useSSL=false");
                break;
            case LOCAL:
            case MSSQL:
            default:
                throw new IllegalArgumentException("DataBase type \"" + type + "\" not support.");
        }
        baseService.setDataSourceParams(ds);
        ds.setUsername(login);
        ds.setPassword(password);
        ds.setEnableAutoCommitOnReturn(true);
        ds.setRemoveAbandonedOnBorrow(true);
        ds.setRemoveAbandonedOnMaintenance(true);
    }

    /**
     * Получение {@link Connection} для работы с ним в дальнейшем
     *
     * @return {@link Connection}
     * @throws SQLException Вызывается в случае, если не удалось выполнить
     *                      подключение к БД
     */
    public Connection getConnection() throws SQLException {
        return ds.getConnection();
    }

    /**
     * Метод, вызываемый для возвращения коннекта в пул
     *
     * @throws SQLException Вызывается в случае проблем с подключением к базе
     *                      см. также {@link BasicDataSource#close()}
     */
    public void close() throws SQLException {
        ds.close();
    }

    /**
     * Метод возвращающий количество неиспольуемых подключений к БД
     *
     * @return {@link int} Количество неиспольуемых подключений к БД
     */
    public int getNumIdle() {
        return ds.getNumIdle();
    }

    /**
     * Метод возвращающий количество используемых подключений к БД
     *
     * @return {@link int} Количество используемых подключений к БД
     */
    public int getNumActive() {
        return ds.getNumActive();
    }

    /**
     * Метод возвращающий общее количество подключений к БД
     *
     * @return {@link int} Общее количество подключений к БД
     */
    public int getNumTotal() {
        return ds.getNumActive() + ds.getNumIdle();
    }

    @Override
    public String toString() {
        return "{" + key + "}";
    }
}
