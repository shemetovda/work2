package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import org.w3c.dom.Element;

public class Base64 extends TemplateNode {

    boolean encode;

    public Base64(Element elem, Template template) throws IllegalArgumentException, NumberFormatException {
        value = elem.getTextContent();
        elem.hasAttribute("type");
        if (elem.hasAttribute("type")) {
            encode = Boolean.parseBoolean(elem.getAttribute("type"));
        } else {
            throw new IllegalArgumentException("Attribute \"type\" is empty.");
        }
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        if (encode) {
            return new String(java.util.Base64.getEncoder().encode(value.getBytes()));
        }
        return new String(java.util.Base64.getDecoder().decode(value));
    }
}
