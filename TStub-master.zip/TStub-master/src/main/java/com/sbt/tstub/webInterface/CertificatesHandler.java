package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.TStub;
import com.sbt.tstub.webInterface.fileData.CertificateFileData;
import com.sbt.tstub.webInterface.fileData.FileData;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CertificatesHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(CertificatesHandler.class);
    private static String path;

    public CertificatesHandler(String path) {
        this.path = path;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        JsonObject response;
        int responseCode = 200;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            jsonReader.close();

            switch (requestURI) {
                case "get":
                    response = getCertificates(uuid);
                    break;
                case "add":
                    response = addCertificate(uuid, json.getString("fileName", null), json.getString("comment", null), json.getString("key", null), json.getString("JavaChiperSuite", null), json.getString("SSLType", null), json.getBoolean("FIPSRequired", false));
                    break;
                case "remove":
                    response = removeCertificate(uuid, json.getInt("id", 0));
                    break;
                case "update":
                    response = updateCertificate(uuid, json.getInt("id", 0), json.getString("fileName", null), json.getString("comment", null), json.getString("key", null), json.getString("JavaChiperSuite", null), json.getString("SSLType", null), json.getBoolean("FIPSRequired", false));
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + this.path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.", uuid, ex);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (Exception ex) {
            logger.error("{}:Неизвестная ошибка.", uuid, ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        String data = strWriter.getBuffer().toString();
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject getCertificates(String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            Statement stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM SSLCertificates;");
            JsonArrayBuilder certificates = Json.createArrayBuilder();
            while (rs.next()) {
                JsonObjectBuilder obj = Json.createObjectBuilder();

                obj.add("id", rs.getInt("id"));
                obj.add("key", rs.getString("key"));
                obj.add("comment", rs.getString("comment"));
                obj.add("JavaChiperSuite", rs.getString("JavaChiperSuite"));
                obj.add("FIPSRequired", rs.getBoolean("FIPSRequired"));
                obj.add("SSLType", rs.getString("SSLType"));
                certificates.add(obj);
            }
            jsonBuilder.add("certificates", certificates);
            jsonBuilder.add("code", TStub.METHOD_OK);
            jsonBuilder.add("uuid", uuid);

            rs.close();
            stmt.close();
        } catch (SQLException e) {
            logger.fatal(uuid + ":Ошибка при выполнения запроса к таблице SSLCertificates.", e);
            return ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Error with SELECT from SSLCertificates." + e.getLocalizedMessage());
        }
        return jsonBuilder.build();
    }

    private JsonObject addCertificate(String uuid, String fileName, String comment, String key, String JavaChiperSuite, String SSLType, boolean FIPSRequired) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        if (fileName == null) {
            logger.error("{}:Файл не указан.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "File not found.");
        }
        if (comment == null) {
            logger.error("{}:Название не задано.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "Comment not found.");
        }
        if (key == null) {
            logger.error("{}:Пароль не задан.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "Key not found.");
        }
        if (JavaChiperSuite == null) {
            logger.error("{}:JavaChiperSuite не задан.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "JavaChiperSuite not found.");
        }
        if (SSLType == null) {
            logger.error("{}:SSLType не задан.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "SSLType not found.");
        }
        CertificateFileData data = new CertificateFileData(0, fileName, comment, key, JavaChiperSuite, SSLType, FIPSRequired, false, FileData.CERTIFICATE);
        String fileUUID = UUID.randomUUID().toString();
        UploadEnvironment.getEnvironments().putFile(fileUUID, data);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        jsonBuilder.add("fileUUID", fileUUID);
        return jsonBuilder.build();
    }

    private JsonObject updateCertificate(String uuid, int id, String fileName, String comment, String key, String JavaChiperSuite, String SSLType, boolean FIPSRequired) {
        JsonObject response;
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        if (comment == null) {
            logger.error("{}:Название не задано.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "Comment not found.");
        }
        if (key == null) {
            logger.error("{}:Пароль не задан.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "Key not found.");
        }
        if (JavaChiperSuite == null) {
            logger.error("{}:JavaChiperSuite не задан.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "JavaChiperSuite not found.");
        }
        if (SSLType == null) {
            logger.error("{}:SSLType не задан.", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "SSLType not found.");
        }

        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            String query = "SELECT * FROM SSLCertificates WHERE id=?";
            PreparedStatement prs = c.prepareStatement(query);
            prs.setInt(1, id);
            ResultSet rs = prs.executeQuery();
            if (rs.next()) {
                rs.close();
                prs.close();
                if (fileName != null) {
                    CertificateFileData data = new CertificateFileData(id, fileName, comment, key, JavaChiperSuite, SSLType, FIPSRequired, true, FileData.CERTIFICATE);
                    String fileUUID = UUID.randomUUID().toString();
                    UploadEnvironment.getEnvironments().putFile(fileUUID, data);
                    jsonBuilder.add("code", TStub.METHOD_OK);
                    jsonBuilder.add("uuid", uuid);
                    jsonBuilder.add("fileUUID", fileUUID);
                    response = jsonBuilder.build();
                } else {
                    query = "UPDATE SSLCertificates SET key=?,JavaChiperSuite=?,SSLType=?,FIPSRequired=?,comment=? WHERE id=?";
                    prs = c.prepareStatement(query);
                    prs.setString(1, key);
                    prs.setString(2, JavaChiperSuite);
                    prs.setString(3, SSLType);
                    prs.setBoolean(4, FIPSRequired);
                    prs.setString(5, comment);
                    prs.setInt(6, id);
                    int res = prs.executeUpdate();
                    if (res > 0) {
                        response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
                    } else {
                        response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "Certificate with id=" + id + " not found.");
                    }
                    prs.close();
                }
            } else {
                logger.error("{}:Сертификат с id={} не найден.", uuid, id);
                response = ResponseHelper.jsonObjectError(TStub.OBJECT_NOT_FOUND, uuid, "Certificate with id=" + id + " not found.");
            }
            c.commit();
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице SSLCertificates. ", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Error with UPDATE SSLCertificates. " + e.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject removeCertificate(String uuid, int id) {
        JsonObject response;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            String query = "SELECT * FROM SSLCertificates WHERE id=?";
            PreparedStatement prs = c.prepareStatement(query);
            prs.setInt(1, id);
            ResultSet rs = prs.executeQuery();
            if (rs.next()) {
                String filePath = rs.getString("path");
                rs.close();
                prs.close();

                query = "DELETE FROM SSLCertificates WHERE id=?";
                prs = c.prepareStatement(query);
                prs.setInt(1, id);
                int res = prs.executeUpdate();
                if (res > 0) {
                    response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
                    //Удаляем файл физически
                    File file = new File(filePath);
                    file.delete();
                } else {
                    logger.error("{}:Сертификат с id={} не найден.", uuid, id);
                    response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "Certificate with id=" + id + " not found.");
                }
            } else {
                logger.error("{}:Сертификат с id={} не найден.", uuid, id);
                response = ResponseHelper.jsonObjectError(TStub.OBJECT_NOT_FOUND, uuid, "Certificate with id=" + id + " not found.");
            }
            prs.close();
            c.commit();
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице SSLCertificates.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Error with DELETE from SSLCertificates. Probably this certificate using in MQReader or MQWriter yet." + e.getLocalizedMessage());
        }
        return response;
    }

}
