package com.sbt.tstub.utils;

public class StringUtils {

    public static String normalize(final String s) {
        return s.replace(",", "\\,").replace(" ", "\\ ").replace("=", "\\=").replace("\"", "\\\"");
    }

}
