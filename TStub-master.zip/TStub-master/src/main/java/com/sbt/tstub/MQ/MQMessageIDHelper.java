package com.sbt.tstub.mq;

import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.struct.LimitedLinkedHashMap;

import java.util.Collections;
import java.util.Map;

public class MQMessageIDHelper {

    private static MQMessageIDHelper instance;
    private final Map<String, String> idsMap;

    public MQMessageIDHelper(final int maxCapacity) {
        idsMap = Collections.synchronizedMap(new LimitedLinkedHashMap(maxCapacity));
    }

    public static MQMessageIDHelper getHelper(final PropertyService propertyService) {
        MQMessageIDHelper localInstance = instance;
        if (localInstance == null) {
            synchronized (MQMessageIDHelper.class) {
                localInstance = instance;
                if (localInstance == null) {
                    instance = localInstance = new MQMessageIDHelper(
                            Integer.parseInt(propertyService.getPropertyValueByName("MessageIDCorrelationIDMap_MaxSize")));
                }
            }
        }
        return localInstance;
    }

    public String take(final String correlationID) {
        return idsMap.remove(correlationID);
    }

    public String get(final String correlationID) {
        return idsMap.get(correlationID);
    }

    public void put(final String messageID, final String correlationID) {
        idsMap.put(messageID, correlationID);
    }
}
