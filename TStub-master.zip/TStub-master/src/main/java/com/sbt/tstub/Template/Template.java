package com.sbt.tstub.template;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.DataBase;
import com.sbt.tstub.DataBaseType;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.exception.TemplateValidationException;
import com.sbt.tstub.environment.property.PropertyService;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

@Getter
public class Template {

    private static final Logger LOGGER = LogManager.getLogger(Template.class);

    private final BaseService baseService;
    private final InfluxDBService influxDBService;
    private final PropertyService propertyService;

    @Setter
    @NotNull(message = "id должен быть задан")
    private int id;
    @NotNull(message = "Шаблон не должен быть пустым")
    private String template;
    @NotNull(message = "Описание не должно быть пустым")
    @Size(min = 1, message = "Описание не должно быть пустым")
    private String comment;

    private HashMap<String, MQHeader> mqHeaders = new HashMap();
    private ArrayList<SQLUpdate> sqlUpdate = new ArrayList();
    private HashMap<String, TemplateNode> vars = new HashMap();
    private HashMap<String, DataBase> dbVars = new HashMap();
    private ArrayList<ToInfluxDB> influxDBVars = new ArrayList();
    private Document body;

    private boolean saveMessCorrID;
    private boolean base64Encode;
    private boolean isByteMessage;

    public Template(int id, String template, String comment, BaseService baseService, InfluxDBService influxDBService, PropertyService propertyService) throws IllegalArgumentException {
        this.id = id;
        this.template = template;
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.propertyService = propertyService;
        this.comment = comment;
        try {
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = builderFactory.newDocumentBuilder();
            Document body = builder.parse(new ByteArrayInputStream(template.getBytes()));
            checkIsSaveMessCorrID(body);
            checkIsEncoding(body);
            readMessageType(body);
            readHead(body);
            readBody(body);
            LOGGER.debug(toString());
        } catch (SAXException | ParserConfigurationException ex) {
            throw new IllegalArgumentException("Ошибка в формате шаблона.", ex);
        } catch (IOException e) {
            LOGGER.debug(e);
        }
    }

    public Template(Template templateObj, BaseService baseService, InfluxDBService influxDBService, PropertyService propertyService) throws CloneNotSupportedException {
        id = templateObj.getId();
        template = templateObj.getTemplate();
        comment = templateObj.getComment();
        mqHeaders = new HashMap(templateObj.mqHeaders);
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.propertyService = propertyService;
        vars = new HashMap<>();
        for (Entry<String, TemplateNode> entry : templateObj.vars.entrySet()) {
            TemplateNode newNode = (TemplateNode) entry.getValue().clone();
            vars.put(entry.getKey(), newNode);
        }
        dbVars = new HashMap(templateObj.dbVars);
        influxDBVars = new ArrayList(templateObj.influxDBVars);
        comment = templateObj.comment;
        sqlUpdate = new ArrayList(templateObj.sqlUpdate);
        saveMessCorrID = templateObj.saveMessCorrID;
        //Копирование документа, чтобы потом его юзать
        try {
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = builderFactory.newDocumentBuilder();

            Node originalRoot = templateObj.getBody().getDocumentElement();

            Document copiedDocument = builder.newDocument();
            Node copiedRoot = copiedDocument.importNode(originalRoot, true);
            copiedDocument.appendChild(copiedRoot);
            body = copiedDocument;
        } catch (ParserConfigurationException ex) {
            throw new IllegalArgumentException("Ошибка в формате шаблона.", ex);
        }
    }

    /**
     * Метод для валидации объекта
     *
     * @param template валидируемый объект
     * @throws TemplateValidationException исключение в случае ошибок валидации
     */
    public static void validate(final Template template) throws TemplateValidationException {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> errors = validator.validate(template);
        if (!errors.isEmpty()) {
            StringBuilder errorMessage = new StringBuilder();
            for (ConstraintViolation<Object> error : errors) {
                errorMessage.append(" - ").append(error.getMessage()).append("\n");
            }
            errorMessage.append("Содержимое объекта: ").append(template);
            throw new TemplateValidationException(errorMessage.toString());
        }
    }

    public void setTemplateForVars(Template template) {
        vars.forEach((key, value) -> value.setTemplate(template));
    }

    public TemplateNode getVar(String id) {
        return vars.get(id);
    }

    private void readHead(Document template) throws IllegalArgumentException {
        XPath xPath = XPathFactory.newInstance().newXPath();
        try {
            NodeList head = (NodeList) xPath.evaluate("/Template/Head/*", template, XPathConstants.NODESET);
            if (head.getLength() == 0) {
                return;
            }

            for (int i = 0; i < head.getLength(); i++) {
                Element node = (Element) head.item(i);
                if (node.getAttribute("id").length() == 0) {
                    throw new IllegalArgumentException("Parameter " + (i + 1) + ":Attribute \"id\" is empty.");
                }
                try {
                    TemplateNode var = null;
                    boolean addVar = false;
                    switch (node.getNodeName().toLowerCase()) {
                        case "uuid":
                            var = new UUID(node);
                            addVar = true;
                            break;
                        case "formatdatetime":
                            var = new FormatDateTime(node);
                            addVar = true;
                            break;
                        case "var":
                            var = new Var(node, this);
                            addVar = true;
                            break;
                        case "xpath":
                            var = new com.sbt.tstub.template.XPath(node);
                            addVar = true;
                            break;
                        case "replace":
                            var = new Replace(node);
                            addVar = true;
                            break;
                        case "substring":
                            var = new Substring(node);
                            addVar = true;
                            break;
                        case "database":
                            String key = node.getAttribute("type") + ":" + node.getAttribute("host") + ":" + node.getAttribute("port") + ":" + node.getAttribute("schema") + ":" + node.getAttribute("login");
                            DataBase db = DataBaseHelper.getHelper().getDataBase(key);
                            if (db == null) {
                                db = new DataBase(baseService, DataBaseType.getDateBaseTypeByName(node.getAttribute("type")), node.getAttribute("host"), node.getAttribute("port"), node.getAttribute("schema"), node.getAttribute("login"), node.getAttribute("password"));
                                DataBaseHelper.getHelper().putDataBase(db.getKey(), db);
                            }
                            dbVars.put(node.getAttribute("id"), db);
                            break;
                        case "sqlselect":
                            var = new SQLSelect(node, dbVars.get(node.getAttribute("dataBaseId")));
                            addVar = true;
                            break;
                        case "sqlupdate":
                            SQLUpdate upd = new SQLUpdate(node, dbVars.get(node.getAttribute("dataBaseId")));
                            sqlUpdate.add(upd);
                            break;
                        case "toinfluxdb":
                            ToInfluxDB inf = new ToInfluxDB(influxDBService, node, this);
                            influxDBVars.add(inf);
                            break;
                        case "processarray":
                            var = new ProcessArray(node, this);
                            addVar = true;
                            break;
                        case "random":
                            var = new com.sbt.tstub.template.Random(node);
                            addVar = true;
                            break;
                        case "fromheader":
                            var = new FROMHeader(node);
                            addVar = true;
                            break;
                        case "mqheader":
                            mqHeaders.put(node.getAttribute("id"), new MQHeader(propertyService, node));
                            break;
                        case "customclass":
                            ClassLoader loader = new DynamicClassOverloader(new String[]{"classes/"});
                            Class clazz = Class.forName(node.getAttribute("name"), true, loader);
                            Constructor constructor = clazz.getConstructor(Element.class, Template.class);
                            TemplateNode tn = (TemplateNode) constructor.newInstance(node, this);
                            var = tn;
                            addVar = true;
                            break;
                        case "selector":
                            var = new Selector(node, this);
                            addVar = true;
                            break;
                        case "base64":
                            var = new Base64(node, this);
                            addVar = true;
                            break;
                        default:
                            break;
                    }
                    if (addVar) {
                        if (Boolean.parseBoolean(node.getAttribute("once"))) {
                            var = new WrapSavedTemplateNode(var);
                        }
                        vars.put(node.getAttribute("id"), var);
                        LOGGER.debug("{}:параметр id=\"{}\" добавлен: {}", comment, node.getAttribute("id"), var);
                    }
                } catch (IllegalArgumentException ex) {
                    throw new IllegalArgumentException("Parameter " + (i + 1) + ":", ex);
                } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | InvocationTargetException ex) {
                    throw new IllegalArgumentException("Parameter " + (i + 1) + ":Class constructor not found:", ex);
                } catch (ClassNotFoundException | NoClassDefFoundError ex) {
                    throw new IllegalArgumentException("Parameter " + (i + 1) + ":Class not found:", ex);
                }
            }
        } catch (XPathExpressionException ex) {
            //TODO:
        }
    }

    private void readBody(Document template) throws IllegalArgumentException, ParserConfigurationException {
        XPath xPath = XPathFactory.newInstance().newXPath();
        try {
            Node body = (Node) xPath.evaluate("/Template/Body/*", template, XPathConstants.NODE);

            if (body == null) {
                throw new IllegalArgumentException("Ошибка в формате шаблона.");
            }

            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setNamespaceAware(true);
            DocumentBuilder builder = builderFactory.newDocumentBuilder();
            Document bodyDoc = builder.newDocument();
            bodyDoc.setXmlVersion(template.getXmlVersion());
            if (template.getXmlEncoding() != null) {
                //bodyDoc.set(template.getXmlEncoding());
            }

            Node importedNode = bodyDoc.importNode(body, true);
            bodyDoc.appendChild(importedNode);
            this.body = bodyDoc;
        } catch (XPathExpressionException ex) {
            //не выпадет
        }
    }

    private void checkIsSaveMessCorrID(Document template) {
        XPath xPath = XPathFactory.newInstance().newXPath();
        try {
            boolean saveMessCorrIDWhenSend = (Boolean) xPath.evaluate("/Template[@saveMessCorrIDWhenSend = 'true']", template, XPathConstants.BOOLEAN);
            saveMessCorrID = saveMessCorrIDWhenSend;
        } catch (XPathExpressionException ex) {
        }
    }

    private void checkIsEncoding(Document template) {
        XPath xPath = XPathFactory.newInstance().newXPath();
        try {
            boolean base64Encode = (Boolean) xPath.evaluate("/Template[@base64Encode = 'true']", template, XPathConstants.BOOLEAN);
            this.base64Encode = base64Encode;
        } catch (XPathExpressionException ex) {
        }
    }

    private void readMessageType(Document template) {
        XPath xPath = XPathFactory.newInstance().newXPath();
        try {
            boolean isByteMessage = (Boolean) xPath.evaluate("/Template[@bytesMessage = 'true']", template, XPathConstants.BOOLEAN);
            this.isByteMessage = isByteMessage;
        } catch (XPathExpressionException ex) {
        }
    }

    @Override
    public String toString() {
        return "{"
                + "id = " + id
                + ", comment = \"" + comment + '\"'
                + ", template = \"" + template + '\"'
                + ", mqHeaders = " + mqHeaders
                + ", sqlUpdate = " + sqlUpdate
                + ", vars = " + vars
                + ", dbVars = " + dbVars
                + ", influxDBVars = " + influxDBVars
                + ", saveMessCorrID = " + saveMessCorrID
                + ", base64Encode = " + base64Encode
                + ", isByteMessage = " + isByteMessage
                + "}";
    }
}
