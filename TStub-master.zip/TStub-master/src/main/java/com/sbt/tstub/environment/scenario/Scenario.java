package com.sbt.tstub.environment.scenario;

import com.sbt.tstub.environment.exception.ScenarioValidationException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import javax.validation.Validation;
import javax.validation.ValidationException;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.LinkedList;
import java.util.List;

@Getter
@RequiredArgsConstructor
public class Scenario {
    @NotNull(message = "id триггера должен быть задан")
    @Min(value = 1, message = "id триггера не может быть меньше 0")
    private final int triggerId;
    @NotNull(message = "Коллекция не может быть null")
    private final List<Step> steps;

    /**
     * Метод для валидации объекта
     *
     * @param scenario валидируемый объект
     * @throws ValidationException исключение в случае ошибок валидации
     */
    public static void validate(final Scenario scenario) throws ScenarioValidationException {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        List<String> errors = new LinkedList<>();
        validator.validate(scenario).forEach(error -> errors.add(error.getMessage()));
        StringBuilder errorMessage = new StringBuilder();
        if (!errors.isEmpty()) {
            for (String error : errors) {
                errorMessage.append(" - ").append(error).append("\n");
            }
        }
        for(Step step : scenario.getSteps()){
            try {
                validator.validate(step);
            }catch (ValidationException ex){
                errorMessage.append("== Шаг ").append(step.getStepNum()).append(":\n").append(ex.getMessage());
            }
        }

        if (errorMessage.length() > 0) {
            errorMessage.append("\n==Содержимое объекта: ").append(scenario);
            throw new ScenarioValidationException(errorMessage.toString());
        }
    }

    @Override
    public String toString() {
        return "{"
                + "triggerId = " + triggerId
                + ", steps = " + steps
                + "}";
    }
}
