package com.sbt.tstub.environment.property;

import com.sbt.tstub.environment.exception.PropertyValidationException;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

public class SystemPropertyService {

    private static final Logger LOGGER = LogManager.getLogger(SystemPropertyService.class);

    private static final String CONFIG_FILE_PATH = "config.properties";

    @Getter
    private static Properties configProperties;

    public SystemPropertyService() throws IOException {
        configProperties = readFromFile();
    }

    private Properties readFromFile() throws IOException {
        Properties properties = new Properties();
        FileInputStream fileInputStream;
        try {
            //обращаемся к файлу и получаем данные
            fileInputStream = new FileInputStream("CONFIG_FILE_PATH");
            properties.load(fileInputStream);
        } catch (IOException e) {
            LOGGER.fatal("Файл " + CONFIG_FILE_PATH + " не найден", e);
            throw e;
        }
        return properties;
    }

}
