package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import java.util.concurrent.ThreadLocalRandom;
import org.w3c.dom.Element;

public class Selector extends TemplateNode {

    private int chance = -1;
    private String value1;
    private String value2;
    private String exist;
    private Template template;

    Selector(Element elem, Template template) throws IllegalArgumentException {
        this.template = template;
        if (elem.hasAttribute("chance1")) {
            try {
                chance = Integer.parseInt(elem.getAttribute("chance1"));
                if (chance > 10000) {
                    throw new IllegalArgumentException("Attribute \"chance\" must be lower or equal \"10000\"");
                }
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Attribute \"chance\" has wrong number format.");
            }
        } else {
            exist = elem.getAttribute("exist");
            value = exist;
        }
        value1 = elem.getAttribute("value1");
        value2 = elem.getAttribute("value2");
    }

    Selector(int chance1, String exist, String value1, String value2, Template template) throws IllegalArgumentException {
        this.template = template;
        chance = chance1;
        if (chance > 10000) {
            throw new IllegalArgumentException("Attribute \"chance\" must be lower or equal \"10000\"");
        }
        this.value1 = value1;
        this.value2 = value2;
        this.exist = exist;
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        if (chance > -1) {
            int randomValue = ThreadLocalRandom.current().nextInt(10000);
            if (randomValue >= chance) {
                return ReplaceHelper.getReplacedString(value1, sourse, template);
            } else {
                return ReplaceHelper.getReplacedString(value2, sourse, template);
            }
        } else if (value.length() > 0 && !value.equals(exist)) {
            return ReplaceHelper.getReplacedString(value1, sourse, template);
        } else {
            return ReplaceHelper.getReplacedString(value2, sourse, template);
        }
    }

    @Override
    public String toString() {
        return "{exist(value)=" + value + "; chance=" + chance
                + "; value1=" + value1 + "; value2=" + value2 + "}";
    }
    
    @Override
    public void setTemplate(Template template){
        this.template = template;
    }
}
