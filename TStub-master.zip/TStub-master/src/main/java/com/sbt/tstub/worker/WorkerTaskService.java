package com.sbt.tstub.worker;

public class WorkerTaskService {
}
