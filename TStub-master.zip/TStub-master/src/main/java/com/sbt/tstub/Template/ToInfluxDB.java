package com.sbt.tstub.template;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.mq.TStubMessage;
import org.w3c.dom.Element;

public class ToInfluxDB {

    private final InfluxDBService influxDBService;

    private Template template;
    private String id;
    private String measurement;
    private String tags;
    private String values;

    ToInfluxDB(InfluxDBService influxDBService, Element elem, Template template) throws IllegalArgumentException {
        this.influxDBService = influxDBService;
        this.template = template;
        id = elem.getAttribute("id");
        measurement = elem.getAttribute("measurement");
        if (measurement.length() < 1) {
            throw new IllegalArgumentException("Attribute \"measurement\" is empty.");
        }
        tags = elem.getAttribute("tags");
        if (tags.length() < 1) {
            tags = null;
        }
        values = elem.getAttribute("values");
        if (values.length() < 1) {
            throw new IllegalArgumentException("Attribute \"values\" is empty.");
        }
    }

    ToInfluxDB(InfluxDBService influxDBService, String id, String measurement, String tags, String values, Template template) throws IllegalArgumentException {
        this.influxDBService = influxDBService;
        this.template = template;
        if (id == null) {
            throw new IllegalArgumentException("Parameter \"id\" is null.");
        } else {
            this.id = id;
        }
        if (measurement == null) {
            throw new IllegalArgumentException("Parameter \"measurement\" is null.");
        } else {
            this.measurement = measurement;
        }
        this.tags = tags;
        if (values == null) {
            throw new IllegalArgumentException("Parameter \"values\" is null.");
        } else {
            this.values = values;
        }
        if (template == null) {
            throw new IllegalArgumentException("Parameter \"template\" is null.");
        } else {
            this.template = template;
        }
    }

    public void process(TStubMessage sourse) {
        if (tags != null) {
            tags = ReplaceHelper.getReplacedString(tags, sourse, template);
        }
        values = ReplaceHelper.getReplacedString(values, sourse, template);
        influxDBService.getInfluxDB().addMeasurementStats(measurement, tags, values);
    }

    @Override
    public String toString() {
        return "{"
                + "id=" + id
                + ", measurement=" + measurement
                + ", tags=" + tags
                + ", values=" + values
                + "}";
    }
}
