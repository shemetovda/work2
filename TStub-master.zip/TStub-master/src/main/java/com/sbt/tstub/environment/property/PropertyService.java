package com.sbt.tstub.environment.property;

import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.exception.PropertyValidationException;
import lombok.Getter;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PropertyService {

    private static String SELECT_INIT_QUERY = "SELECT * FROM Params ORDER BY id;";
    private static String UPDATE_QUERY = "UPDATE Params SET value=? WHERE name=?";

    @Getter
    private Map<String, Property> properties;
    private static final Map<String, Level> logLevels = new HashMap<>();

    static {
        logLevels.put("ALL", Level.ALL);
        logLevels.put("TRACE", Level.TRACE);
        logLevels.put("DEBUG", Level.DEBUG);
        logLevels.put("INFO", Level.INFO);
        logLevels.put("WARN", Level.WARN);
        logLevels.put("ERROR", Level.ERROR);
        logLevels.put("FATAL", Level.FATAL);
        logLevels.put("OFF", Level.OFF);
    }

    public PropertyService() throws SQLException, PropertyValidationException {
        properties = readFromDB();
    }

    private Map<String, Property> readFromDB() throws SQLException, PropertyValidationException {
        Map<String, Property> propertyMap = new ConcurrentHashMap<>();
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             Statement stmt = c.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_INIT_QUERY)) {
            while (rs.next()) {
                Property property = new Property(
                        rs.getString("name"),
                        rs.getString("value"),
                        rs.getString("description"));
                Property.validate(property);
                propertyMap.put(property.getName(), property);
            }
        }
        return propertyMap;
    }

    public void refresh() throws SQLException, PropertyValidationException {
        properties = readFromDB();
    }

    public Property getPropertyByName(final String name) {
        return properties.get(name);
    }

    public String getPropertyValueByName(final String name) {
        Property property = properties.get(name);
        if (property == null) {
            throw new IllegalArgumentException("Параметра с названием \"" + name + "\" не существует.");
        }
        return property.getValue();
    }

    public void updateProperty(final String name, final String value) throws SQLException, PropertyValidationException {
        Property property = properties.get(name);
        if (property == null) {
            throw new IllegalArgumentException("Параметра с названием \"" + name + "\" не существует.");
        }
        Property newProperty = new Property(name, value, property.getDescription());
        Property.validate(newProperty);
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             PreparedStatement prs = c.prepareStatement(UPDATE_QUERY)) {
            c.setAutoCommit(false);
            prs.setString(1, value);
            prs.setString(2, name);
            prs.executeUpdate();
            c.commit();
        }
        properties.put(name, newProperty);
        if ("logLevel".equals(name)) {
            postUpdate();
        }
    }

    private void postUpdate() {
        //Устанавливаем новый уровень логгирования
        LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
        Configuration config = ctx.getConfiguration();
        LoggerConfig loggerConfig = config.getLoggerConfig(LogManager.ROOT_LOGGER_NAME);
        loggerConfig.setLevel(getLogLevel());
        ctx.updateLoggers();
    }

    public Level getLogLevel() {
        return logLevels.getOrDefault(properties.get("logLevel").getValue(), Level.ERROR);
    }

}
