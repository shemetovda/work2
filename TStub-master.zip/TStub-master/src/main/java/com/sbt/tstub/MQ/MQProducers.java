package com.sbt.tstub.mq;

import com.sbt.tstub.struct.RoundRobin;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Алексей
 */
public class MQProducers {

    private static final Map<String, RoundRobin<MQReader>> mapReaders = new ConcurrentHashMap();

    public static void putReader(final String key, final MQReader MQReader) {
        RoundRobin<MQReader> rrReader = mapReaders.get(key);
        if (rrReader == null) {
            rrReader = new RoundRobin();
        }
        rrReader.add(MQReader);
        mapReaders.put(key, rrReader);
    }

    public static MQReader getReader(final String key) {
        RoundRobin<MQReader> rrReader = mapReaders.get(key);
        if (rrReader != null) {
            return rrReader.next();
        }
        return null;
    }

    public static MQReader removeReader(final String key, final MQReader reader) {
        RoundRobin<MQReader> rrReader = mapReaders.get(key);
        if (rrReader != null) {
            rrReader.remove(reader);
            if (rrReader.isEmpty()) {
                mapReaders.remove(key);
            }
            return reader;
        }
        return null;
    }

    public static boolean pauseReader(final String key) {
        RoundRobin<MQReader> rrReader = mapReaders.get(key);
        if (rrReader != null) {
            for (MQReader item : rrReader.getList()) {
                item.pause();
            }
            return true;
        }
        return false;
    }

    public static boolean unPauseReader(final String key) {
        RoundRobin<MQReader> rrReader = mapReaders.get(key);
        if (rrReader != null) {
            for (MQReader item : rrReader.getList()) {
                item.unPause();
            }
            return true;
        }
        return false;
    }

    public static Set<String> getReadersKeys() {
        return mapReaders.keySet();
    }

    public static Collection<RoundRobin<MQReader>> getReaders() {
        return mapReaders.values();
    }

    public static int getReadersQuantity(final String key) {
        RoundRobin<MQReader> rrReader = mapReaders.get(key);
        if (rrReader != null) {
            return rrReader.size();
        }
        return -1;
    }

    public static void clearAll() {
        mapReaders.clear();
    }
}
