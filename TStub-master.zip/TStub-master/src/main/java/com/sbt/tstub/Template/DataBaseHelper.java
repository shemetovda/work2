package com.sbt.tstub.template;

import com.sbt.tstub.DataBase;
import java.sql.SQLException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class DataBaseHelper {

    private static DataBaseHelper instance;
    private static Map<String, DataBase> dataBaseMap;

    public DataBaseHelper() {
        dataBaseMap = new ConcurrentHashMap();
    }

    public static DataBaseHelper getHelper() {
        DataBaseHelper localInstance = instance;
        if (localInstance == null) {
            synchronized (DataBaseHelper.class) {
                localInstance = instance;
                if (localInstance == null) {
                    instance = localInstance = new DataBaseHelper();
                }
            }
        }
        return localInstance;
    }
    
    public void close() throws SQLException{
        Set<String> set = dataBaseMap.keySet();
        for(String item : set){
            DataBase db = dataBaseMap.remove(item);
            db.close();
        }
    }

    public void putDataBase(String key, DataBase db) {
        dataBaseMap.putIfAbsent(key, db);
    }
    
    public DataBase getDataBase(String key){
        return dataBaseMap.get(key);
    }
    
    public DataBase removeDataBase(String key){
        return dataBaseMap.remove(key);
    }
    
    public Set<String> getDataBaseSet(){
        return dataBaseMap.keySet();
    }
}
