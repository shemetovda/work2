package com.sbt.tstub.worker;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.sbt.tstub.DelayedTask;
import com.sbt.tstub.environment.BaseService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Класс для управления выполнениями задач по обработке сообщений
 *
 * @author Алексей
 * @param <T>
 */
public class Worker<T> extends Thread {

    private static final Logger logger = LogManager.getLogger(Worker.class);

    private final ExecutorService pool;
    private final ExecutorCompletionService<T> completionService;
    private final DelayQueue<DelayedTask> workerTasks;
    private final WorkerTaskCompletionService workerTaskCompleter;

    private Boolean work;

    public Worker() {
        int numOfThreads;
        if ((numOfThreads = (int) (Runtime.getRuntime().availableProcessors() / 2)) < 1) {
            numOfThreads = 1;
        }
        logger.debug("Создан пул на " + numOfThreads + " потоков.");
        pool = Executors.newFixedThreadPool(numOfThreads);
        completionService = new ExecutorCompletionService<>(pool);
        work = true;
        workerTasks = new DelayQueue();
        workerTaskCompleter = new WorkerTaskCompletionService(completionService, workerTasks);
    }

    /**
     * Этот процесс играет роль арбитра сообщений, полученных на обработку
     *
     */
    @Override
    public void run() {
        //Создаём поток, который будет забирать выполненные таски и отправлять в очередь на ожидание
        workerTaskCompleter.setName(Thread.currentThread().getName() + ":TaskCompleter");
        workerTaskCompleter.start();
        logger.debug("Поток запущен.");
        //Цикл, в котором задания из очереди распределяются
        while (work || !workerTasks.isEmpty()) {
            DelayedTask<WorkerTask> delTask;
            try {
                delTask = workerTasks.take();
            } catch (InterruptedException ex) {
                logger.debug("Получена команда на остановку. Останавливаю дочерние потоки.");
                continue;
            }
            WorkerTask task = delTask.getTask();
            task.nextStep();
            switch (task.getStepType()) {
                case STEP_NOT_DEFINE:
                    //DONE: такое событие не может произойти, только если не вызван WorkerTask.nextStep() в первый раз
                    break;
                case STEP_DROP:
                    //DONE: Ничего не делаем, выкидываем таску
                    task.responseHTTP(true);
                    task.dispose();
                    break;
                case STEP_WAIT:
                    //DONE: Отправляем таску на ожидание обратно в очередь
                    delTask.setDelay(task.getDelay());
                    workerTasks.put(delTask);
                    break;
                case STEP_HTTP:
                    //DONE: Отправляем сообщение по HTTP если есть куда.
                    completionService.submit(task);
                    break;
                case STEP_WRITE:
                    //DONE: отправляем сообщение в очередь
                    completionService.submit(task);
                    break;
                case STEP_WORK:
                    //DONE: Отправляем задание на обработку
                    completionService.submit(task);
                    break;
            }
        }
        workerTaskCompleter.shutdown();
        while (workerTaskCompleter.isAlive()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                logger.fatal("Возникла непредвиденная ситуация при заверщении потока. Аварийное завершение...",ex);
                pool.shutdownNow();
                return;
            }
        }
        pool.shutdown();
        logger.debug(BaseService.THREAD_IS_STOPPED);
    }

    public void putTask(DelayedTask delayedTask) {
        workerTasks.add(delayedTask);
    }

    //Метод для безопасной остановки потока и остановки потока без потерь данных
    public void shutdown() {
        work = false;
        interrupt();
    }

    public int getWorkerTasksSize() {
        return workerTasks.size();
    }
}
