package com.sbt.tstub.mq;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.environment.property.PropertyService;

import lombok.Getter;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;

public class PooledMQWriter extends BasePooledObjectFactory<MQWriter> {

    @Getter
    public final MQWriter writer;
    private int counter = 0;

    public PooledMQWriter(PropertyService propertyService,
                          InfluxDBService influxDBService,
                          int id,
                          String host,
                          int port,
                          String manager,
                          String channel,
                          String queueName,
                          String login,
                          String password,
                          boolean active,
                          int certID,
                          boolean isDefaultQueue) {
        writer = new MQWriter(propertyService, influxDBService, id, host, port, manager, channel, queueName, login,
                              password, active, certID, isDefaultQueue);
    }

    public PooledMQWriter(final MQWriter writer) {
        this.writer = writer;
    }

    @Override
    public MQWriter create() {
        MQWriter writer1 = new MQWriter(writer);
        writer1.setName(writer1.getKey() + "-" + counter);
        writer1.start();
        counter++;
        return writer1;
    }

    @Override
    public boolean validateObject(PooledObject<MQWriter> p) {
        return p.getObject().getStartState();
    }

    @Override
    public void destroyObject(PooledObject<MQWriter> p) {
        p.getObject().shutdown();
    }

    @Override
    public PooledObject<MQWriter> wrap(MQWriter obj) {
        return new DefaultPooledObject<>(obj);
    }
}
