package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStub;
import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.exception.PropertyValidationException;
import com.sbt.tstub.environment.property.Property;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.webInterface.converter.PropertyConverter;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.json.*;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.UUID;

public class ParamsHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(ParamsHandler.class);

    private final String path;
    private final PropertyService propertyService;
    private final PropertyConverter propertyConverter;

    public ParamsHandler(String path, PropertyService propertyService, PropertyConverter propertyConverter) {
        this.path = path;
        this.propertyService = propertyService;
        this.propertyConverter = propertyConverter;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        int responseCode = 200;
        JsonObject response;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            jsonReader.close();
            switch (requestURI) {
                case "get":
                    if (json.getJsonArray("params") != null) {
                        response = getParamByIds(uuid, json.getJsonArray("params"));
                    } else {
                        response = getParams(uuid);
                    }
                    break;
                case "set":
                    response = setParam(uuid, json.getString("name", null), json.getString("value", null));
                    break;
                case "version":
                    response = getVersion(uuid);
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.", uuid, ex);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (Exception ex) {
            logger.error("{}:Неизвестная ошибка.", uuid, ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        String data = ResponseHelper.buildResponseData(response);
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject getParams(String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        JsonArrayBuilder PropertiesJson = Json.createArrayBuilder();
        Collection<Property> properties = propertyService.getProperties().values();
        properties.forEach(property -> PropertiesJson.add(propertyConverter.convertToJson(property)));
        jsonBuilder.add("params", PropertiesJson);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }

    private JsonObject getParamByIds(String uuid, JsonArray inParams) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        JsonArrayBuilder outParams = Json.createArrayBuilder();
        int size = inParams.size();
        for (int i = 0; i < size; i++) {
            Property property = propertyService.getPropertyByName(inParams.getString(i));
            if (property != null) {
                outParams.add(propertyConverter.convertToJson(property));
            }
        }
        jsonBuilder.add("params", outParams);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }

    private JsonObject setParam(String uuid, String name, String value) {
        JsonObject response;
        try {
            propertyService.updateProperty(name, value);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException ex) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице Params.", uuid, ex);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при записи в БД. " + ex.getLocalizedMessage());
        } catch (PropertyValidationException ex) {
            logger.fatal("{}:Ошибка при валидации параметра.", uuid, ex);
            response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, ex.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject getVersion(String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            String query = "SELECT userversion FROM TStubVersions WHERE version = ?;";
            PreparedStatement prs = c.prepareStatement(query);
            prs.setInt(1, BaseService.APPLICATION_VERSION);
            ResultSet rs = prs.executeQuery();
            JsonArrayBuilder params = Json.createArrayBuilder();
            if (rs.next()) {
                JsonObjectBuilder obj = Json.createObjectBuilder();
                obj.add("name", "version");
                obj.add("value", rs.getString("userversion"));
                obj.add("description", "Версия приложения");
                params.add(obj);
            }
            jsonBuilder.add("params", params);
            jsonBuilder.add("code", TStub.METHOD_OK);
            jsonBuilder.add("uuid", uuid);

            rs.close();
            prs.close();
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице TStubVersions.", uuid, e);
            return ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Error with SELECT from TStubVersions. " + e.getLocalizedMessage());
        }
        return jsonBuilder.build();
    }
}
