package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStub;
import com.sbt.tstub.environment.exception.StubQueueValidationException;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.scenario.Step;
import com.sbt.tstub.environment.writer.WriterService;
import com.sbt.tstub.mq.MQWriter;
import com.sbt.tstub.webInterface.converter.WriterConverter;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.commons.pool2.ObjectPool;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.sqlite.SQLiteException;

import javax.json.*;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class WritersHandler implements HttpHandler {

    private static final Logger LOGGER = LogManager.getLogger(WritersHandler.class);

    private final String path;
    private final ScenarioService scenarioService;
    private final WriterService writerService;
    private final WriterConverter writerConverter;

    public WritersHandler(String path, ScenarioService scenarioService, WriterService writerService, WriterConverter writerConverter) {
        this.path = path;
        this.scenarioService = scenarioService;
        this.writerService = writerService;
        this.writerConverter = writerConverter;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        int responseCode = 200;
        JsonObject response;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            jsonReader.close();
            switch (requestURI) {
                case "getmin":
                    response = getWritersMin(uuid);
                    break;
                case "get":
                    response = getWriters(uuid);
                    break;
                case "add":
                    response = addWriter(uuid, json);
                    break;
                case "update":
                    response = updWriter(uuid, json);
                    break;
                case "remove":
                    response = removeWriter(uuid, json.getInt("id", 0));
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + this.path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            LOGGER.error("{}:Неправильный формат запроса.", uuid, ex);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (Exception ex) {
            LOGGER.error("{}:Неизвестная ошибка.", uuid, ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        String data = ResponseHelper.buildResponseData(response);
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject getWritersMin(final String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        Map<String, ObjectPool<MQWriter>> pools = new HashMap<>(writerService.getWriters());
        JsonArrayBuilder writers = Json.createArrayBuilder();
        for (Map.Entry<String, ObjectPool<MQWriter>> item : pools.entrySet()) {
            try {
                ObjectPool<MQWriter> pool = item.getValue();
                MQWriter writer = pool.borrowObject();
                if (writer != null) {
                    JsonObjectBuilder obj = writerConverter.convertToMinJson(writer);
                    obj.add("quantity", pool.getNumActive() + pool.getNumIdle());
                    writers.add(obj);
                    try {
                        pool.returnObject(writer);
                    } catch (Exception ex) {
                        LOGGER.error("{}:Не могу вернуть очередь для записи queue={}", uuid, item.getKey(), ex);
                    }
                }
            } catch (Exception ex) {
                LOGGER.error("{}:Не могу получить очередь для записи queue={}", uuid, item.getKey(), ex);
            }
        }
        //default
        try {
            ObjectPool<MQWriter> pool = writerService.getDefWriter();
            if (pool != null) {
                MQWriter writer = pool.borrowObject();
                JsonObjectBuilder obj = writerConverter.convertToMinJson(writer);
                obj.add("quantity", pool.getNumActive() + pool.getNumIdle());
                writers.add(obj);
                try {
                    pool.returnObject(writer);
                } catch (Exception ex) {
                    LOGGER.error("{}:Не могу вернуть очередь для записи по умолчанию.", uuid, ex);
                }
            }
        } catch (Exception ex) {
            LOGGER.error("{}:Не могу получить очередь для записи по умолчанию.", uuid, ex);
        }
        jsonBuilder.add("writers", writers);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }

    private JsonObject getWriters(final String uuid) {
        JsonObject response;
        try {
            JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
            List<MQWriter> writers = writerService.getWritersFromDB();
            JsonArrayBuilder writersJson = Json.createArrayBuilder();
            writers.forEach(writer -> writersJson.add(writerConverter.convertToJson(writer)));
            jsonBuilder.add("writers", writersJson);
            jsonBuilder.add("code", TStub.METHOD_OK);
            jsonBuilder.add("uuid", uuid);
            response = jsonBuilder.build();
        } catch (SQLException e) {
            LOGGER.fatal("{}:Ошибка при выполнения запроса к таблице MQWriters.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при чтении из БД. " + e.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject addWriter(final String uuid, final JsonObject request) {
        MQWriter writer = writerConverter.toObject(request);
        JsonObject response;
        try {
            writerService.add(writer);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException e) {
            LOGGER.fatal("{}:Ошибка при выполнения запроса к таблице MQWriters.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при записи в БД. " + e.getLocalizedMessage());
        } catch (StubQueueValidationException ex) {
            LOGGER.fatal("{}:Ошибка при валидации подключения на запись.", uuid, ex);
            response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, ex.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject updWriter(String uuid, final JsonObject request) {
        MQWriter writer = writerConverter.toObject(request);
        JsonObject response;
        try {
            writerService.update(writer);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException e) {
            LOGGER.fatal("{}:Ошибка при выполнения запроса к таблице MQWriters.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при записи в БД. " + e.getLocalizedMessage());
        } catch (StubQueueValidationException ex) {
            LOGGER.fatal("{}:Ошибка при валидации подключения на запись.", uuid, ex);
            response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, ex.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject removeWriter(String uuid, int writerId) {
        JsonObject response;
        try {
            writerService.remove(writerId);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException e) {
            if (e instanceof SQLiteException
                    && ((SQLiteException) e).getErrorCode() == 19) {
                response = getUsingTemplates(uuid, writerId);
            } else {
                LOGGER.fatal(uuid + ":Ошибка при выполнения запроса к таблице MQWriters.", e);
                response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка удаления из БД. \n" + e.getLocalizedMessage());
            }
        }
        return response;
    }

    private JsonObject getUsingTemplates(String uuid, int id) {
        List<Step> stepList = scenarioService.getStepsByMqWriterId(id);
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("Список шагов, в которых используется подключение:");
        stepList.forEach(step -> {
            strBuilder.append(" triggerID=")
                    .append(step.getTriggerId())
                    .append(" Номер шага = ")
                    .append(step.getStepNum())
                    .append(";");
        });
        JsonObject response = ResponseHelper.jsonObjectError(
                TStub.METHOD_NOT_ALLOWED,
                uuid,
                strBuilder.toString());
        return response;
    }
}
