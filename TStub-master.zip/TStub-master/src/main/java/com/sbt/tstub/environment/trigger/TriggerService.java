package com.sbt.tstub.environment.trigger;

import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.exception.TriggerValidationException;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Класс для получения доступа к триггерам на обработку
 */
public class TriggerService {

    private static String SELECT_QUERY = "SELECT * FROM Triggers";
    private static String SELECT_BY_UNIQUE_QUERY = "SELECT * FROM Triggers WHERE expression=? AND headers=?";
    private static String INSERT_QUERY = "INSERT INTO Triggers (expression, headers, comment, active) VALUES (?,?,?,?)";
    private static String UPDATE_QUERY = "UPDATE Triggers SET expression=?, headers=?, comment=?, active=? WHERE id=?";
    private static String DELETE_QUERY = "DELETE FROM Triggers WHERE id=?";

    @Getter
    private Map<Integer, Trigger> triggers;

    private static final Logger LOGGER = LogManager.getLogger(TriggerService.class);

    public TriggerService() throws SQLException, TriggerValidationException {
        try {
            triggers = readFromDB();
        } catch (SQLException | TriggerValidationException ex) {
            triggers = new ConcurrentHashMap<>();
            throw ex;
        }
    }

    private Map<Integer, Trigger> readFromDB() throws SQLException, TriggerValidationException {
        Map<Integer, Trigger> triggerMap = new ConcurrentHashMap<>();
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             Statement stmt = c.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_QUERY)) {
            while (rs.next()) {
                int triggerId = rs.getInt("id");
                Trigger trigger = new Trigger(triggerId,
                        rs.getString("expression"),
                        rs.getString("comment"),
                        buildHeadersMap(triggerId, rs.getString("headers")),
                        rs.getBoolean("active"));
                Trigger.validate(trigger);
                triggerMap.put(triggerId, trigger);
            }
        }
        return triggerMap;
    }

    public Map<String, String> buildHeadersMap(final int triggerId, final String headers) {
        Map<String, String> result = new HashMap<>();
        if (StringUtils.isNotBlank(headers)) {
            String[] arr = headers.split(",");
            for (String header : arr) {
                String[] param = header.split("=", 2);
                if (param.length < 2) {
                    LOGGER.error("{} - Заголовок {} имеет неправильный формат.", triggerId, header);
                    continue;
                }
                result.put(param[0], param[1]);
            }
        }
        return result;
    }

    public void refresh() throws SQLException, TriggerValidationException {
        triggers = readFromDB();
    }

    /**
     * Метод для добавления триггера в БД и в кеш
     *
     * @param trigger триггера
     * @return успешность добавления: true - триггер был добавлен. false - триггер не был добавлен в БД или в кеш,
     * требуется обновить кеш.
     * @throws SQLException ошибка добавления триггера в БД
     */
    public boolean add(final Trigger trigger) throws SQLException, TriggerValidationException {
        Trigger.validate(trigger);
        if (addToDB(trigger)) {
            return triggers.putIfAbsent(trigger.getId(), trigger) == null;
        }
        return false;
    }

    private boolean addToDB(final Trigger trigger) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            PreparedStatement prs = c.prepareStatement(INSERT_QUERY);
            c.setAutoCommit(false);
            prs.setString(1, trigger.getXPathExpression());
            prs.setString(2, buildHeadersForDB(trigger.getHeaders()));
            prs.setString(3, trigger.getComment());
            prs.setBoolean(4, trigger.isActive());
            prs.executeUpdate();
            prs.close();
            c.commit();

            prs = c.prepareStatement(SELECT_BY_UNIQUE_QUERY);
            prs.setString(1, trigger.getXPathExpression());
            prs.setString(2, buildHeadersForDB(trigger.getHeaders()));
            ResultSet rs = prs.executeQuery();
            if (rs.next()) {
                trigger.setId(rs.getInt("id"));
                result = true;
            } else {
                result = false;
            }
            rs.close();
            prs.close();
        }
        return result;
    }

    /**
     * Метод для удаления триггера из БД и из кеша
     *
     * @param triggerId идентификатор триггера
     * @return успешность удаления: true - подключение было удалено. false - триггер не был найден в БД или в кеше,
     * требуется обновить кеш.
     * @throws SQLException ошибка удаления триггера из БД
     */
    public boolean remove(final int triggerId) throws SQLException {
        if (removeFromDB(triggerId)) {
            return triggers.remove(triggerId) != null;
        }
        return false;
    }

    private boolean removeFromDB(final int triggerId) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             PreparedStatement prs = c.prepareStatement(DELETE_QUERY)) {
            c.setAutoCommit(false);
            prs.setInt(1, triggerId);
            int res = prs.executeUpdate();
            result = res > 0;
            c.commit();
        }
        return result;
    }

    public boolean update(final Trigger trigger) throws SQLException, TriggerValidationException {
        Trigger.validate(trigger);
        if (updateIntoDB(trigger)) {
            triggers.put(trigger.getId(), trigger);
            return true;
        }
        return false;
    }

    private boolean updateIntoDB(final Trigger trigger) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             PreparedStatement prs = c.prepareStatement(UPDATE_QUERY)) {
            c.setAutoCommit(false);
            prs.setString(1, trigger.getXPathExpression());
            prs.setString(2, buildHeadersForDB(trigger.getHeaders()));
            prs.setString(3, trigger.getComment());
            prs.setBoolean(4, trigger.isActive());
            prs.setInt(5, trigger.getId());
            int res = prs.executeUpdate();
            result = res > 0;
            c.commit();
        }
        return result;
    }

    public String buildHeadersForDB(Map<String, String> headerMap) {
        StringBuilder headers = new StringBuilder();
        headerMap.forEach((key, value) -> headers.append(StringUtils.join(key + '=' + value, ',')));
        return headers.toString();
    }

    public List<Trigger> getAvailableTriggers() {
        return triggers.values().stream().filter(trigger -> trigger.isActive()).collect(Collectors.toList());
    }
}
