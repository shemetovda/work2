package com.sbt.tstub.WebProvider;

import com.sbt.tstub.DelayedTask;
import com.sbt.tstub.environment.BaseService;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Класс для управления выполнениями задач по обработке сообщений
 *
 * @author Алексей
 */
public class HTTPWorker extends Thread {
    private static final Logger logger = LogManager.getLogger(HTTPWorker.class);
    
    private final ExecutorService pool;
    private final DelayQueue<DelayedTask> httpTasks;

    private Boolean work;

    public HTTPWorker() {
        int numOfThreads = Runtime.getRuntime().availableProcessors()*4;
        logger.debug("Создан пул на " + numOfThreads + " потоков.");
        this.pool = Executors.newFixedThreadPool(numOfThreads);
        this.work = true;
        this.httpTasks = new DelayQueue();
    }

    /**
     * Этот процесс играет роль арбитра сообщений, полученных на обработку
    *
     */
    @Override
    public void run() {
        logger.debug("Поток запущен.");
        //Цикл, в котором задания из очереди распределяются
        while (work || !httpTasks.isEmpty()) {
            DelayedTask<HTTPTask> delTask;
            try {
                delTask = httpTasks.take();
            } catch (InterruptedException ex) {
                logger.debug("Получена команда на остановку. Останавливаю дочерние потоки.");
                continue;
            }
            HTTPTask task = delTask.getTask();
            pool.submit(task);
        }
        pool.shutdown();
        logger.debug(BaseService.THREAD_IS_STOPPED);
    }

    public void put(DelayedTask delayedTask) {
        httpTasks.add(delayedTask);
    }

    //Метод для безопасной остановки потока и остановки потока без потерь данных
    public void shutdown() {
        work = false;
        interrupt();
    }
    
    public int getWorkerTasks(){
        return httpTasks.size();
    }
}
