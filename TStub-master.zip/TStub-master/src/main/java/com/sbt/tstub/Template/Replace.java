package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import org.w3c.dom.Element;

public class Replace extends TemplateNode {

    private final String from;
    private final String to;

    public Replace(Element elem) throws IllegalArgumentException {
        this.from = elem.getAttribute("from");
        this.to = elem.getAttribute("to");
        this.value = elem.getTextContent();
    }

    public Replace(String value, String from, String to) throws IllegalArgumentException {
        this.from = from;
        this.to = to;
        this.value = value;
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        return value.replaceAll(this.from, this.to);
    }

    @Override
    public String toString() {
        return "{value=" + this.value + "; from=" + this.from + "; to=" + this.to + "}";
    }
}
