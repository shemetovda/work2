package com.sbt.tstub;

import org.apache.commons.pool2.ObjectPool;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.exception.StubQueueValidationException;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.template.TemplateService;
import com.sbt.tstub.environment.trigger.TriggerService;
import com.sbt.tstub.environment.writer.WriterService;
import com.sbt.tstub.mq.MQProducers;
import com.sbt.tstub.mq.MQReader;
import com.sbt.tstub.mq.MQWriter;
import com.sbt.tstub.mq.MessageProvider;
import com.sbt.tstub.template.DataBaseHelper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

/**
 * Этот класс предназначен для управления потоками на чтение сообщений...
 * Создаётся подключение к базе данных Создаются потоки, которые читают
 * сообщения, потоки для обработки сообщений, потоки для записи сообщений
 *
 * @author Алексей
 */
public class TStubThread extends Thread {

    private static final Logger LOGGER = LogManager.getLogger(TStubThread.class);

    private final TriggerService triggerService;
    private final ScenarioService scenarioService;
    private final PropertyService propertyService;
    private final BaseService baseService;
    private final InfluxDBService influxDBService;
    private final TemplateService templateService;
    private final WriterService writerService;

    private final List<MessageProvider> messageProviderThreadPool = new ArrayList();
    private final List<MQReader> MQReadersPool = new ArrayList();
    boolean work = true;

    private int state = 0;
    private boolean ready;

    public TStubThread(TriggerService triggerService,
                       ScenarioService scenarioService,
                       PropertyService propertyService,
                       BaseService baseService,
                       InfluxDBService influxDBService,
                       TemplateService templateService,
                       WriterService writerService) {
        this.triggerService = triggerService;
        this.scenarioService = scenarioService;
        this.propertyService = propertyService;
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.templateService = templateService;
        this.writerService = writerService;
    }

    @Override
    public void run() {
        try {
            writerService.refresh();
        } catch (SQLException e) {
            LOGGER.fatal("Ошибка при выполнения запроса к таблице MQWriters.", e);
            throw new RuntimeException(e);
        } catch (StubQueueValidationException e) {
            LOGGER.fatal("Ошибка при валидации подключений на запись.", e);
            throw new RuntimeException(e);
        }
        synchronized (this) {
            //Готовим подключения для работы программы
            influxDBService.restart(propertyService);
            influxDBService.getInfluxDB().start();

            //Создаём MQReaders из базы
            try (Connection c = TStubDatabaseHelper.getHelper().getConnection(); Statement stmt = c.createStatement()) {
                ResultSet rs = stmt.executeQuery("SELECT * FROM MQReaders;");
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String host = rs.getString("host");
                    int port = rs.getInt("port");
                    String manager = rs.getString("manager");
                    String channel = rs.getString("channel");
                    String queue = rs.getString("queue");
                    String login = rs.getString("login");
                    String password = rs.getString("password");
                    boolean active = rs.getBoolean("active");
                    int certID = rs.getInt("SSLCertificateID");
                    int numOfProviders = rs.getInt("numOfProviders");
                    String selector = rs.getString("selector");
                    if (active) {
                        if (numOfProviders < 1) {
                            numOfProviders = 1;
                        }
                        String key = host + ":" + port + ":" + manager + ":" + channel + ":" + queue;
                        if (certID != 0) {
                            for (int i = 0; i < numOfProviders; i++) {
                                MQReader reader;
                                if (selector != null) {
                                    reader = new MQReader(propertyService, influxDBService, id, host, port, manager,
                                                          channel, queue, login, password, active, certID, selector);
                                } else {
                                    reader = new MQReader(propertyService, influxDBService, id, host, port, manager,
                                                          channel, queue, login, password, active, certID);
                                }
                                if (reader.connect() == -1) {
                                    LOGGER.warn(
                                            "Не могу подключиться к очереди " + key + ". Подключение будет поставлено на паузу.");
                                    reader.pause();
                                }
                                MQProducers.putReader(key, reader);
                                MQReadersPool.add(reader);
                            }
                        } else {
                            for (int i = 0; i < numOfProviders; i++) {
                                MQReader reader;
                                if (selector != null) {
                                    reader = new MQReader(propertyService, influxDBService, id, host, port, manager,
                                                          channel, queue, login, password, active, -1, selector);
                                } else {
                                    reader = new MQReader(propertyService, influxDBService, id, host, port, manager,
                                                          channel, queue, login, password, active, -1);
                                }
                                if (reader.connect() == -1) {
                                    LOGGER.warn(
                                            "Не могу подключиться к очереди " + key + ". Подключение будет поставлено на паузу.");
                                    reader.pause();
                                }
                                MQProducers.putReader(key, reader);
                                MQReadersPool.add(reader);
                            }
                        }
                        for (int i = 0; i < numOfProviders; i++) {
                            MessageProvider provider = new MessageProvider(triggerService, scenarioService, baseService,
                                                                           propertyService, influxDBService,
                                                                           templateService, writerService, key);
                            provider.setName("MessageProvider:" + key + "-" + i);
                            messageProviderThreadPool.add(provider);
                        }
                    }
                }
                rs.close();
            } catch (SQLException e) {
                LOGGER.fatal("Ошибка при выполнения запроса к таблице MQReaders.", e);
            }

            //проверяем потоки на запись
            for (ObjectPool<MQWriter> pool : writerService.getWriters().values()) {
                if (!checkWriter(pool)) {
                    dispose();
                    return;
                }
            }
            ObjectPool<MQWriter> pool = writerService.getDefWriter();
            if (pool != null) {
                if (!checkWriter(pool)) {
                    dispose();
                    return;
                }
            }

            //Запускаем чтение сообщений
            LOGGER.debug("Запуск потоков на обработку...");
            for (int i = 0; i < messageProviderThreadPool.size(); i++) {
                messageProviderThreadPool.get(i).start();
            }

            //проверяем потоки на чтение
            LOGGER.debug("Проверка потоков на обработку...");
            for (int i = 0; i < messageProviderThreadPool.size(); i++) {
                if (!messageProviderThreadPool.get(i).getStartState()) {
                    dispose();
                    return;
                }
            }
            state = 0;
            ready = true;
            notifyAll();
        }

        work = true;
        LOGGER.debug("Потоки запущены, приступаю к работе...");
        while (work) {
            try {
                Thread.sleep(200);
                ready = false;
                Thread.sleep(1800);
                //DONE: Количество подключений у пула
                for (Entry<String, ObjectPool<MQWriter>> entry : writerService.getWriters().entrySet()) {
                    int idle = entry.getValue().getNumIdle();
                    int active = entry.getValue().getNumActive();
                    influxDBService.getInfluxDB().addMeasurementStats("pool", "queue=" + entry.getKey(),
                                                                      "idle=" + idle + ",active=" + active + ",total=" + (idle + active));
                }
                ObjectPool<MQWriter> pool = writerService.getDefWriter();
                if (pool != null) {
                    int idle = pool.getNumIdle();
                    int active = pool.getNumActive();
                    influxDBService.getInfluxDB().addMeasurementStats("pool", "queue=default",
                                                                      "idle=" + idle + ",active=" + active + ",total=" + (idle + active));
                }
                int count = 0;
                for (int i = 0; i < messageProviderThreadPool.size(); i++) {
                    count += messageProviderThreadPool.get(i).getQuantityWorkerTasks();
                }
                influxDBService.getInfluxDB().putStatsReplace("workerTasksInDelayQueue", count);

                for (String key : DataBaseHelper.getHelper().getDataBaseSet()) {
                    DataBase db = DataBaseHelper.getHelper().getDataBase(key);
                    if (db != null) {
                        influxDBService.getInfluxDB().addMeasurementStats("DBPC", "DB=" + key,
                                                                          "idle=" + db.getNumIdle() + ",active=" + db.getNumActive() + ",total=" + db.getNumTotal());
                    }
                }

                influxDBService.getInfluxDB().addMeasurementStats("DBPC", "DB=TStub",
                                                                  "idle=" + TStubDatabaseHelper.getHelper().getNumIdle() + ",active=" + TStubDatabaseHelper.getHelper().getNumActive() + ",total=" + TStubDatabaseHelper.getHelper().getNumTotal());

            } catch (InterruptedException ex) {
                LOGGER.fatal("Непредвиденная ошибка ", ex);
            }
        }

        synchronized (this) {
            dispose();
            state = 1;
            ready = true;
            notifyAll();
        }
        LOGGER.debug("Поток остановлен, работа заглушки завершена.");
    }

    private boolean checkWriter(final ObjectPool<MQWriter> writerObjectPool) {
        try {
            MQWriter writer = writerObjectPool.borrowObject();
            if (writer != null) {
                if (!writer.getStartState()) {
                    try {
                        writerObjectPool.returnObject(writer);
                    } catch (Exception ex) {
                        LOGGER.error("Не могу вернуть очередь для записи.\n", ex);
                    }
                    return false;
                }
            } else {
                LOGGER.error("Отправитель сообщений не определён.");
            }
        } catch (Exception ex) {
            LOGGER.error("Не могу получить очередь для записи.\n", ex);
        }
        return true;
    }

    //Метод для безопасной остановки потока и остановки потока без потерь данных
    public void shutdown() {
        work = false;
        interrupt();
    }

    private void dispose() {
        influxDBService.shutdown();
        work = false;
        state = -1;
        LOGGER.debug("Получена команда на остановку. Останавливаю дочерние потоки...");
        for (int i = 0; i < messageProviderThreadPool.size(); i++) {
            messageProviderThreadPool.get(i).shutdown();
        }

        boolean check = true;
        while (check) {
            check = false;
            for (MessageProvider provider : messageProviderThreadPool) {
                if (provider.isAlive()) {
                    check = true;
                    break;
                }
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                LOGGER.fatal("Возникла непредвиденная ситуация при завершении работы. Аварийное завершение...");
                return;
            }
        }
        for (int i = 0; i < messageProviderThreadPool.size(); i++) {
            if (messageProviderThreadPool.get(i).isAlive()) {
                check = true;
                break;
            }
        }

        for (MQReader reader : MQReadersPool) {
            reader.close();
        }
        MQReadersPool.clear();
        writerService.shutdown();

        while (check) {
            check = false;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                LOGGER.fatal("Возникла непредвиденная ситуация при завершении работы. Аварийное завершение...");
            }
        }

        MQProducers.clearAll();
        writerService.shutdown();
        state = -1;
        ready = true;
        notifyAll();
    }

    public int getConnectionState() {
        synchronized (this) {
            try {
                while (!ready) {
                    wait();
                }
            } catch (InterruptedException ex) {
                LOGGER.fatal("Непредвиденная ошибка.", ex);
                return -1;
            }
            return state;
        }
    }
}
