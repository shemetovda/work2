package com.sbt.tstub.webInterface.fileData;


public class FileData {
    public static final int TEMPLATE = 1;
    public static final int LOGS = 2;
    public static final int REQUEST = 3;
    public static final int CERTIFICATE = 4;
    public static final int CLASS = 5;

    protected int id;
    protected String fileName;
    protected boolean update;
    protected int type;
    
    public FileData(int id, String fileName, boolean update, int type) {
        this.fileName = fileName;
        this.update = update;
        this.id = id;
        this.type = type;
    }

    public String getName() {
        return this.fileName;
    }
    
    public boolean isUpdate() {
        return this.update;
    }
    
    public int getId() {
        return this.id;
    }
    
    public int getType() {
        return this.type;
    }
}
