package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Класс предназначен для того, чтобы обрабатывать различные значения на предмет
 * подстановки их в формироуемое сообщений. В классе определены только
 * статические методы
 *
 * @author Алексей
 */
public class ReplaceHelper {

    private static final Logger logger = LogManager.getLogger(ReplaceHelper.class);

    /**
     * В этом методе мы определяем наличие экранирующих символов
     * [%<наше_значение>%]
     *
     * @param id
     * @param sourse
     * @param template
     * @return
     */
    public static String getReplacedId(String id, TStubMessage sourse, Template template) {
        TemplateNode var = template.getVar(id);
        if (var != null) {
            String value = var.getValue();
            try {
                if (value != null) {
                    Pattern pattern = Pattern.compile("\\[%.*?%\\]", Pattern.CASE_INSENSITIVE);
                    Matcher matcher = pattern.matcher(value);
                    int index = 0;
                    String back = "";
                    while (matcher.find()) {
                        String group = matcher.group();
                        back += value.substring(index, matcher.start());
                        index = matcher.end();
                        if (group.length() > 4) {
                            back += getReplacedId(group.substring(2, group.length() - 2), sourse, template);
                        } else {
                            back += group;
                        }
                    }
                    back += value.substring(index, value.length());
                    if (index == 0) {
                        return var.process(value, sourse);
                    } else {
                        return var.process(back, sourse);
                    }
                } else {
                    return var.process(value, sourse);
                }
            } catch (Exception ex) {
                logger.warn(template.getComment() + ":" + id, ex);
            }
        }
        return "[%" + id + "%]";
    }

    public static String getReplacedString(String value, TStubMessage sourse, Template template) {
        Pattern pattern = Pattern.compile("\\[%.*?%\\]", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(value);
        int index = 0;
        StringBuilder back = new StringBuilder();
        while (matcher.find()) {
            //Добавляем обычный текст
            back.append(value.substring(index, matcher.start()));
            index = matcher.end();
            //Проверяем найденную часть
            String group = matcher.group();
            if (group.length() > 4) {
                String id = group.substring(2, group.length() - 2);
                back.append(ReplaceHelper.getReplacedId(id, sourse, template));
            } else {
                back.append(group);
            }
        }
        back.append(value.substring(index, value.length()));
        if (index == 0) {
            return value;
        }
        return back.toString();
    }

    public static Object castForHeader(String type, String value) {
        Object result;
        try {
            switch (type.toLowerCase()) {
                case "destination":
                case "string":
                    result = value;
                    break;
                case "integer":
                    result = Integer.parseInt(value);
                    break;
                case "boolean":
                    result = Boolean.parseBoolean(value);
                    break;
                case "long":
                    result = Long.parseLong(value);
                    break;
                default:
                    result = null;
                    break;
            }
        } catch (ClassCastException ex) {
            result = null;
            logger.warn("Ошибка при парсинге значения, выражение: " + type + "(" + value + ")");
        }
        return result;
    }
}
