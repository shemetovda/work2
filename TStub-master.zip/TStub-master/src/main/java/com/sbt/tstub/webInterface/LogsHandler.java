package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStub;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogsHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(LogsHandler.class);

    private static String path;

    public LogsHandler(String path) {
        this.path = path;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        int responseCode = 200;
        JsonObject response;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            jsonReader.close();
            switch (requestURI) {
                case "get":
                    response = getLogsList(uuid);
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.", uuid, ex);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (Exception ex) {
            logger.error("{}:Неизвестная ошибка.", uuid, ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        String data = strWriter.getBuffer().toString();
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject getLogsList(String uuid) {
        String logsPath = "logs";
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        JsonArrayBuilder logs = Json.createArrayBuilder();
        ArrayList<Object> list;
        try {
            list = (ArrayList) Files.walk(Paths.get(logsPath)).filter(Files::isRegularFile).collect(Collectors.toList());
        } catch (Exception e) {
            logger.fatal("{}:Ошибка при поиске файлов с логами.", uuid, e);
            return ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "Error with findind logs files. " + e.getLocalizedMessage());
        }

        for (Object item : list) {
            String name = item.toString();
            name = name.substring(name.lastIndexOf("\\") + 1);
            JsonObjectBuilder obj = Json.createObjectBuilder();
            obj.add("fileName", name);
            logs.add(obj);
        }
        jsonBuilder.add("logs", logs);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }
}
