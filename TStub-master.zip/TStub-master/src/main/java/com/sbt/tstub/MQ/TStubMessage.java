package com.sbt.tstub.mq;

import com.ibm.jms.JMSMessage;
import lombok.Getter;
import lombok.Setter;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.jms.QueueSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TStubMessage {

    @Getter
    private final Document body;
    @Getter
    private final Map<String, Object> headers;
    @Getter
    private final MQReader reader;
    @Getter
    private final String templateName;
    @Setter
    @Getter
    private String inJMSMessageID;
    @Getter
    private final String messageID;
    @Getter
    private final boolean encode;
    @Getter
    private final boolean isByteMessage;


    public TStubMessage(final Document body,
                        final Map<String, Object> props,
                        final MQReader reader,
                        final String templateName,
                        final boolean encode,
                        final boolean isByteMessage) {
        this.body = body;
        if (props == null) {
            headers = new HashMap<>();
        } else {
            headers = props;
        }
        this.reader = reader;
        this.templateName = templateName;
        messageID = UUID.randomUUID().toString();
        this.encode = encode;
        this.isByteMessage = isByteMessage;
    }

//    public TStubMessage(final String message,
//                        final Map<String, Object> props,
//                        final MQReader reader,
//                        final String templateName,
//                        final boolean encode) throws ParserConfigurationException, SAXException, IOException {
//        this(message, props, reader, templateName, encode, false);
//    }

    public TStubMessage(final String message,
                        final Map<String, Object> props,
                        final MQReader reader,
                        final String templateName,
                        final boolean encode,
                        final boolean isByteMessage) throws ParserConfigurationException, SAXException, IOException {
        this(parseBody(message), props, reader, templateName, encode, isByteMessage);
    }

    public String getBodyString() {
        TransformerFactory tf = TransformerFactory.newInstance();
        String result = null;
        try {
            Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(body), new StreamResult(writer));
            result = writer.getBuffer().toString();
        } catch (TransformerException ex) {
            ex.printStackTrace();
        }
        if (result != null && encode) {
            result = new String(Base64.getEncoder().encode(result.getBytes()));
        }
        return result;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("headers=").append(headers).append("\n");
        result.append(getBodyString());
        return result.toString();
    }

    private static Document parseBody(final String message) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
        builderFactory.setValidating(false);
        DocumentBuilder builder = builderFactory.newDocumentBuilder();
        String decodedMessage = message;
        if (decodedMessage.endsWith("==")) {
            decodedMessage = new String(Base64.getDecoder().decode(message));
        }
        InputSource source = new InputSource(new StringReader(decodedMessage));
        return builder.parse(source);
    }
}
