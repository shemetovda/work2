package com.sbt.tstub.environment;

import com.sbt.tstub.TStub;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.mq.TStubMessage;
import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import java.io.*;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

//ALL > TRACE > DEBUG > INFO > WARN > ERROR > FATAL > OFF
public class BaseService {

    public static final int APPLICATION_VERSION = 23;
    public static final String T_STUB = "TStub";
    public static final String THREAD_IS_STOPPED = "Поток остановлен.";
    public static final String THREAD_WILL_STOP = "Получена команда на остановку...";

    private final PropertyService propertyService;

    public BaseService(PropertyService propertyService) {
        this.propertyService = propertyService;
    }

    /**
     * Метод для определения все ли обязательные параметры в наличии
     *
     * @param uuid             - uuid запроса
     * @param host             - Хост подключения
     * @param port             - Порт подключения
     * @param manager          - Менеджер подключения
     * @param channel          - Канал подключения
     * @param queue            - Очередь для подключения
     * @param numOfConnections - Количество подключений
     * @return строка с сообщением об ошибки или null, если ошибки не обнаружены
     */
    public JsonObject checkParameters(String uuid,
                                      String host,
                                      int port,
                                      String manager,
                                      String channel,
                                      String queue,
                                      int numOfConnections) {
        Logger logger = LogManager.getLogger(TStub.class);
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        //Проверки на наличие обязательных параметров
        if (host == null) {
            logger.error("{}:Хост не задан.", uuid);
            jsonBuilder.add("code", TStub.ARGUMENT_NOT_FOUND_ERROR);
            jsonBuilder.add("uuid", uuid);
            jsonBuilder.add("message", "Host not found.");
            return jsonBuilder.build();
        }
        if (port == 0) {
            logger.error("{}:Порт не задан.", uuid);
            jsonBuilder.add("code", TStub.ARGUMENT_NOT_FOUND_ERROR);
            jsonBuilder.add("uuid", uuid);
            jsonBuilder.add("message", "Port not found.");
            return jsonBuilder.build();
        }
        if (manager == null) {
            logger.error("{}:Менеджер не задан.", uuid);
            jsonBuilder.add("code", TStub.ARGUMENT_NOT_FOUND_ERROR);
            jsonBuilder.add("uuid", uuid);
            jsonBuilder.add("message", "Manager not found.");
            return jsonBuilder.build();
        }
        if (channel == null) {
            logger.error("{}:Канал не задан.", uuid);
            jsonBuilder.add("code", TStub.ARGUMENT_NOT_FOUND_ERROR);
            jsonBuilder.add("uuid", uuid);
            jsonBuilder.add("message", "Channel not found.");
            return jsonBuilder.build();
        }
        if (queue == null) {
            logger.error("{}:Очередь не задана.", uuid);
            jsonBuilder.add("code", TStub.ARGUMENT_NOT_FOUND_ERROR);
            jsonBuilder.add("uuid", uuid);
            jsonBuilder.add("message", "Queue name not found.");
            return jsonBuilder.build();
        }
        if (numOfConnections == 0) {
            logger.error("{}:Количество подключений не задано.", uuid);
            jsonBuilder.add("code", TStub.ARGUMENT_NOT_FOUND_ERROR);
            jsonBuilder.add("uuid", uuid);
            jsonBuilder.add("message", "numOfConnections (numOfConsumers or numOfProviders) not found.");
            return jsonBuilder.build();
        }
        return null;
    }

    /**
     * Метод предназначенный для обработки случаев, когда key или value являются
     * null
     *
     * @param properties - объект Properties, в который мы хотим поместить
     *                   значение
     * @param key        - ключ
     * @param value      - значение
     * @return Объект Properties, в который добавлен параметр, если ключ или
     * значение не null
     */
    public static HashMap<String, Object> putNotNull(HashMap properties, Object key, Object value) {
        if (key != null && value != null) {
            properties.put(key, value);
        }
        return properties;
    }

    public static void unZIP(String zipFilePath, String destDir) throws IOException {
        File dir = new File(destDir);
        // create output directory if it doesn't exist
        if (!dir.exists()) {
            dir.mkdirs();
        }
        FileInputStream fis;
        //buffer for read and write data to file
        byte[] buffer = new byte[1024];
        fis = new FileInputStream(zipFilePath);
        ZipInputStream zis = new ZipInputStream(fis);
        ZipEntry ze = zis.getNextEntry();
        while (ze != null) {
            String fileName = ze.getName();
            File newFile = new File(destDir + File.separator + fileName);
            //create directories for sub directories in zip
            new File(newFile.getParent()).mkdirs();
            FileOutputStream fos = new FileOutputStream(newFile);
            int len;
            while ((len = zis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            //close this ZipEntry
            zis.closeEntry();
            ze = zis.getNextEntry();
        }
        //close last ZipEntry
        zis.closeEntry();
        zis.close();
        fis.close();
    }

    public static void unJar(String jarFilePath, String destDir) throws IOException {
        File file = new File(jarFilePath);
        JarFile jar = new JarFile(file);

        // fist get all directories,
        // then make those directory on the destination Path
        for (Enumeration<JarEntry> enums = jar.entries(); enums.hasMoreElements(); ) {
            JarEntry entry = enums.nextElement();

            String fileName = destDir + File.separator + entry.getName();
            File f = new File(fileName);

            if (fileName.endsWith("/")) {
                f.mkdirs();
            }

        }
        //now create all files
        for (Enumeration<JarEntry> enums = jar.entries(); enums.hasMoreElements(); ) {
            JarEntry entry = enums.nextElement();

            String fileName = destDir + File.separator + entry.getName();
            File f = new File(fileName);

            if (!fileName.endsWith("/")) {
                InputStream is = jar.getInputStream(entry);
                FileOutputStream fos = new FileOutputStream(f);

                // write contents of 'is' to 'fos'
                while (is.available() > 0) {
                    fos.write(is.read());
                }

                fos.close();
                is.close();
            }
        }
        jar.close();
    }

    public BasicDataSource setDataSourceParams(final BasicDataSource dataSource) {
        dataSource.setMinIdle(Integer.parseInt(propertyService.getPropertyValueByName("DataBase_minIdle")));
        dataSource.setMaxIdle(Integer.parseInt(propertyService.getPropertyValueByName("DataBase_maxIdle")));
        dataSource.setMaxTotal(Integer.parseInt(propertyService.getPropertyValueByName("DataBase_maxTotal")));
        dataSource.setMaxWaitMillis(Integer.parseInt(propertyService.getPropertyValueByName("DataBase_maxWaitMillis")));
        dataSource.setMinEvictableIdleTimeMillis(
                Long.parseLong(propertyService.getPropertyValueByName("DataBase_minEvictableIdleTimeMillis")));
        dataSource.setTimeBetweenEvictionRunsMillis(
                Long.parseLong(propertyService.getPropertyValueByName("DataBase_timeBetweenEvictionRunsMillis")));
        return dataSource;
    }

    public boolean checkHeaders(final TStubMessage message, final Map<String, String> headers) {
        if (!headers.isEmpty()) {
            for (Map.Entry<String, String> header : headers.entrySet()) {
                switch (header.getKey()) {
                    case "ReaderQueue":
                        if (message.getReader() != null) {
                            if (!message.getReader().getKey().equalsIgnoreCase(header.getValue())) {
                                return false;
                            }
                            break;
                        }
                    default:
                        String value = (String) message.getHeaders().get(header.getKey());
                        if (value != null) {
                            if (!value.equalsIgnoreCase(header.getValue())) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                        break;
                }
            }
        }
        return true;
    }
}
