package com.sbt.tstub.template;

import com.sbt.tstub.DataBase;
import com.sbt.tstub.mq.TStubMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Element;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SQLSelect extends TemplateNode {

    private static final Logger logger = LogManager.getLogger(SQLSelect.class);

    private final DataBase db;
    private String query;
    private List<Map<String, String>> results;

    public SQLSelect(Element elem, DataBase db) throws IllegalArgumentException {
        value = elem.getTextContent();
        this.db = db;
        if (this.db == null) {
            throw new IllegalArgumentException("DataBase not defined.");
        }
        query = "";
        results = new ArrayList<Map<String, String>>();
    }

    public SQLSelect(SQLSelect selector) throws IllegalArgumentException {
        value = selector.value;
        db = selector.db;
        if (db == null) {
            throw new IllegalArgumentException("DataBase not defined.");
        }
        query = "";
        results = new ArrayList<Map<String, String>>();
    }

    public String getResult(String label) {
        if (!results.isEmpty()) {
            String value = results.get(0).get(label);
            if (value != null) {
                return value;
            }
        }
        return label;
    }

    @Override
    public String process(String value, TStubMessage sourse) throws IllegalArgumentException {
        //Выполняем запрос, если он ещё не выполнен
        if (!query.equals(value)) {
            results.clear();
            try (Connection c = db.getConnection();
                 Statement stmt = c.createStatement();
                 ResultSet rs = stmt.executeQuery(value)) {
                while (rs.next()) {
                    Map<String, String> result = new HashMap<>();
                    int numcolumn = rs.getMetaData().getColumnCount();
                    for (int i = 1; i <= numcolumn; i++) {
                        result.put(rs.getMetaData().getColumnLabel(i).toLowerCase(), rs.getString(i));
                    }
                    results.add(result);
                }
                query = value;
                if (rs.getFetchSize() == 0) {
                    throw new IllegalArgumentException("Данные по запросу \"" + value + "\" не найдены");
                }
                logger.trace("Успешно выполнен запрос \"{}\"", value);
            } catch (SQLException ex) {
                throw new IllegalArgumentException(
                        "Ошибка при выполнении запроса \"" + value + "\". " + ex.getLocalizedMessage(), ex);
            }
        }
        return value;
    }

    public List<Map<String, String>> getResults(){
        return results;
    }

    @Override
    public String toString() {
        return "{"
                + "value=" + value + '\"'
                + ", DataBase=" + db + '\"'
                + "}";
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        SQLSelect newSelect = (SQLSelect) super.clone();
        newSelect.query = "";
        newSelect.results = new ArrayList<Map<String, String>>();
        return newSelect;
    }
}
