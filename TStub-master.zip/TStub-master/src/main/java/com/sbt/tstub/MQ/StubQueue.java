package com.sbt.tstub.mq;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import com.sbt.tstub.environment.exception.StubQueueValidationException;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Set;

@Getter
public class StubQueue {

    public static final int STOP = -1;
    public static final int WORK = 1;
    public static final int PAUSE = 2;
    public static final int ERROR = 3;

    @Setter
    @NotNull(message = "id не может быть пустым")
    protected int id;
    @NotNull(message = "Не указан хост")
    @Size(min = 1, message = "Не указан хост")
    protected String host;
    @NotNull(message = "Не указан порт")
    @Min(value = 1, message = "Не указан порт")
    protected int port;
    @NotNull(message = "Не указан менеджер")
    @Size(min = 1, message = "Не указан менеджер")
    protected String manager;
    @NotNull(message = "Не указан канал")
    @Size(min = 1, message = "Не указан канал")
    protected String channel;
    @NotNull(message = "Не указана очередь")
    @Size(min = 1, message = "Не указана очередь")
    protected String queueName;
    protected boolean active;
    protected int certID;
    protected String login;
    protected String password;

    /**
     * Метод для валидации объекта
     *
     * @param writer валидируемый объект
     * @throws StubQueueValidationException исключение в случае ошибок валидации
     */
    public static void validate(final StubQueue queue) throws StubQueueValidationException {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> errors = validator.validate(queue);
        if (!errors.isEmpty()) {
            StringBuilder errorMessage = new StringBuilder();
            for (ConstraintViolation<Object> error : errors) {
                errorMessage.append(" - ").append(error.getMessage()).append("\n");
            }
            errorMessage.append("Содержимое объекта: ").append(queue);
            throw new StubQueueValidationException(errorMessage.toString());
        }
    }

    StubQueue(int id,
              String host,
              int port,
              String manager,
              String channel,
              String queueName,
              String login,
              String password,
              boolean active,
              int certID) {
        this.id = id;
        this.manager = StringUtils.trim(manager);
        this.host = StringUtils.trim(host);
        this.port = port;
        this.channel = StringUtils.trim(channel);
        this.queueName = StringUtils.trim(queueName);
        this.certID = certID;
        this.login = login;
        this.password = password;
        this.active = active;
    }

    public String getKey() {
        return host + ":" + port + ":" + manager + ":" + channel + ":" + queueName;
    }

    @Override
    public String toString() {
        return "{"
                + "id = " + id
                + ", host = " + host
                + ", port = " + port
                + ", manager = " + manager
                + ", channel = " + channel
                + ", queueName = " + queueName
                + ", login = " + login
                + ", password = " + password
                + ", active = " + active
                + ", certID = " + certID
                + "}";
    }
}
