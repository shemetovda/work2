package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import java.util.concurrent.ThreadLocalRandom;
import org.w3c.dom.Element;

public class Random extends TemplateNode {

    private int length = -1;
    private int from = -1;
    private int to = -1;

    Random(Element elem) throws IllegalArgumentException {
        if (elem.getAttribute("length").length() > 0) {
            try {
                this.length = Integer.parseInt(elem.getAttribute("length"));
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Attribute \"length\" has wrong number format.");
            }
        } else {
            try {
                this.from = Integer.parseInt(elem.getAttribute("from"));
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Attribute \"from\" has wrong number format.");
            }
            try {
                this.to = Integer.parseInt(elem.getAttribute("to"));
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Attribute \"to\" has wrong number format.");
            }
        }
    }

    Random(String type, int length, int from, int to) throws IllegalArgumentException {
        if (length > 0) {
            this.length = length;
        } else if (from != 0 && to != 0 && (to > from)) {
            this.from = from;
            this.to = to;
        } else {
            throw new IllegalArgumentException("Attribute \"from\" or \"to\" has wrong number format.");
        }
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        String res = "";
        if (this.length != -1) {
            for (int i = 0; i < this.length; i++) {
                res += ThreadLocalRandom.current().nextInt(9);
            }
        } else {
            res += ThreadLocalRandom.current().nextLong(this.from, this.to);
        }
        return res;
    }

    @Override
    public String toString() {
        return "{value=" + this.value + "; length=" + this.length
                + "; from=" + this.from + "; to=" + this.to + "}";
    }
}
