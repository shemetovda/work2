package com.sbt.tstub.webInterface.fileData;

public class TemplateFileData extends FileData{
    
    protected String comment;

    public TemplateFileData(int id, String fileName, String comment, boolean update, int type) {
        super(id, fileName, update, type);
        this.comment = comment;
    }

    public String getComment() {
        return this.comment;
    }
}
