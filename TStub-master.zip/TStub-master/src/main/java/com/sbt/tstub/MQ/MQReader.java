package com.sbt.tstub.mq;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.xml.sax.SAXException;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.property.PropertyService;

import javax.jms.*;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.HashMap;

/**
 * @author Алексей
 */
public class MQReader extends StubQueue {

    private static final Logger LOGGER = LogManager.getLogger(MQReader.class);

    public int state;
    public int currentState;

    private MQQueueConnectionFactory cf = null;
    private QueueConnection connection = null;
    private QueueSession session = null;
    private Queue queue = null;
    private QueueReceiver receiver = null;

    private String selector = null;

    private final PropertyService propertyService;
    private final InfluxDBService influxDBService;

    public MQReader(final PropertyService propertyService,
                    final InfluxDBService influxDBService,
                    final int id,
                    final String host,
                    final int port,
                    final String manager,
                    final String channel,
                    final String queueName,
                    final String login,
                    final String password,
                    final boolean active,
                    final int certID) {
        super(id, host, port, manager, channel, queueName, login, password, active, certID);
        this.propertyService = propertyService;
        this.influxDBService = influxDBService;
    }

    public MQReader(final PropertyService propertyService,
                    final InfluxDBService influxDBService,
                    final int id,
                    final String host,
                    final int port,
                    final String manager,
                    final String channel,
                    final String queueName,
                    final String login,
                    final String password,
                    final boolean active,
                    final int certID,
                    final String selector) {
        this(propertyService, influxDBService, id, host, port, manager, channel, queueName, login, password, active,
             certID);
        this.selector = selector;
    }

    public TStubMessage read() throws InterruptedException, JMSException, ParserConfigurationException {
        BytesMessage jmsbMessage;
        TextMessage jmstMessage;
        try {
            if (state == 2) { // если поток приостановлен
                Thread.sleep(1000);
                return null;
            }
            long startTime = System.nanoTime();
            Message jmsMessage = receiver.receiveNoWait();
            if (jmsMessage != null) {
                long duration = System.nanoTime() - startTime;
                influxDBService.getInfluxDB().addMeasurementStats("times", "type=receive_mq_message,queue=" + getKey(),
                                                                  "duration=" + duration);
                startTime = System.nanoTime();
                if (BytesMessage.class.isAssignableFrom(jmsMessage.getClass())) {
                    jmsbMessage = (BytesMessage) jmsMessage;
                    int messageLength = new Long(jmsbMessage.getBodyLength()).intValue();
                    byte[] bin = new byte[messageLength];
                    jmsbMessage.readBytes(bin, messageLength);

                    HashMap<String, Object> props = saveProperties(jmsbMessage);

                    try {
                        String message = new String(bin);
                        influxDBService.getInfluxDB().addMeasurementStats("length",
                                                                          "type=input,queue=" + getKey(),
                                                                          "length=" + message.length());
                        return new TStubMessage(message, props, this, "MQInput", false, false);
                    } catch (SAXException | IOException e) {
                        LOGGER.error("Сообщение не валидно.\n{}", new String(bin));
                        return null;
                    }
                }
                if (TextMessage.class.isAssignableFrom(jmsMessage.getClass())) {
                    jmstMessage = (TextMessage) jmsMessage;
                    HashMap<String, Object> props = saveProperties(jmstMessage);
                    try {
                        String message = jmstMessage.getText();
                        influxDBService.getInfluxDB().addMeasurementStats("length",
                                                                          "type=input,queue=" + getKey(),
                                                                          "length=" + message.length());
                        return new TStubMessage(message, props, this, "MQInput", false, false);
                    } catch (SAXException | IOException e) {
                        LOGGER.error("Сообщение не валидно.\n{}", jmstMessage.getText());
                        return null;
                    }
                }
                duration = System.nanoTime() - startTime;
                influxDBService.getInfluxDB().addMeasurementStats("times", "type=create_TStub,queue=" + getKey(),
                                                                  "duration=" + duration);
            }
            Thread.sleep(100);
            return null;
        } catch (NullPointerException ex) {
            LOGGER.error("Невозможно прочитать сообщение из очереди.", ex);
            Thread.sleep(50);
            return null;
        }
    }

    private HashMap<String, Object> saveProperties(Message jmsMessage) throws JMSException {
        HashMap<String, Object> props = new HashMap();
        Enumeration enumProp = jmsMessage.getPropertyNames();
        while (enumProp.hasMoreElements()) {
            String propName = (String) enumProp.nextElement();
            props.put(propName, jmsMessage.getObjectProperty(propName));
        }
        props = BaseService.putNotNull(props, "JMSCorrelationID", jmsMessage.getJMSCorrelationID());
        props = BaseService.putNotNull(props, "JMSDeliveryMode", jmsMessage.getJMSDeliveryMode());
        props = BaseService.putNotNull(props, "JMSExpiration", jmsMessage.getJMSExpiration());
        props = BaseService.putNotNull(props, "JMSMessageID", jmsMessage.getJMSMessageID());
        props = BaseService.putNotNull(props, "JMSPriority", jmsMessage.getJMSPriority());
        props = BaseService.putNotNull(props, "JMSRedelivered", jmsMessage.getJMSRedelivered());
        props = BaseService.putNotNull(props, "JMSReplyTo", jmsMessage.getJMSReplyTo());
        props = BaseService.putNotNull(props, "JMSTimestamp", jmsMessage.getJMSTimestamp());
        props = BaseService.putNotNull(props, "JMSType", jmsMessage.getJMSType());
        return props;
    }

    public int connect() {
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            cf = new MQQueueConnectionFactory();
            // Config
            cf.setHostName(host);
            cf.setPort(port);
            cf.setTransportType(1);
            cf.setQueueManager(manager);
            cf.setChannel(channel);
            String name = propertyService.getPropertyValueByName("readerName");
            if (name == null) {
                name = "TStubReader";
            }
            cf.setAppName(name);

            if (certID != -1) {
                Statement stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM SSLCertificates WHERE id= " + certID);
                String path = "";
                if (rs.next()) {
                    LOGGER.debug(getKey() + " - Найден сертификат для подключения к очереди.");
                    path = rs.getString("path");
                    String key = rs.getString("key");
                    String SSLType = rs.getString("SSLType");
                    String JavaChiperSuite = rs.getString("JavaChiperSuite");
                    boolean FIPSRequired = rs.getBoolean("FIPSRequired");

                    KeyStore ks = KeyStore.getInstance("JKS");
                    ks.load(new FileInputStream(path), key.toCharArray());

                    KeyStore trustStore = KeyStore.getInstance("JKS");
                    trustStore.load(new FileInputStream(path), key.toCharArray());

                    TrustManagerFactory trustManagerFactory
                            = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                    KeyManagerFactory keyManagerFactory
                            = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());

                    trustManagerFactory.init(trustStore);
                    keyManagerFactory.init(ks, key.toCharArray());

                    SSLContext sslContext = SSLContext.getInstance(SSLType);
                    sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
                    SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

                    cf.setSSLFipsRequired(FIPSRequired);
                    cf.setSSLCipherSuite(JavaChiperSuite);
                    cf.setSSLSocketFactory(sslSocketFactory);

                }
                rs.close();
                stmt.close();
            }

            if (login != null) {
                LOGGER.debug(getKey() + " - Найдены параметры для аутентификации пользователя.");
                connection = cf.createQueueConnection(login, password);
            } else {
                connection = cf.createQueueConnection();
            }

            session = connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            if (queueName.contains("/")) {
                queue = session.createQueue("queue://" + queueName);
            } else {
                queue = session.createQueue("queue:///" + queueName);
            }

            if (selector != null) {
                receiver = (QueueReceiver) session.createConsumer(queue, selector);
            } else {
                receiver = (QueueReceiver) session.createConsumer(queue);
            }

            connection.start();
            LOGGER.debug("Соединение установлено.");
            currentState = StubQueue.WORK;
        } catch (JMSException ex) {
            LOGGER.error("Очередь недоступна для подключения.", ex);
            currentState = StubQueue.ERROR;
            return -1;
        } catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException | UnrecoverableKeyException | CertificateException ex) {
            LOGGER.error("Невозможно создать шифрованное подключение.", ex);
            currentState = StubQueue.ERROR;
            return -1;
        } catch (IOException | SQLException ex) {
            LOGGER.error("Невозможно получить данные из базы данных.", ex);
            currentState = StubQueue.ERROR;
            return -1;
        }
        state = StubQueue.WORK;
        return 0;
    }

    public boolean close() {
        try {
            if (receiver != null) {
                receiver.close();
            }
            if (session != null) {
                session.close();
            }
            if (connection != null) {
                connection.close();
            }
            return true;
        } catch (JMSException ex) {
            LOGGER.error("{} - Невозможно разорвать соединение с очередью. ", getKey(), ex);
            return false;
        }
    }

    public Destination getDestination() {
        return queue;
    }

    public void pause() {
        state = StubQueue.PAUSE;
    }

    public void unPause() {
        state = StubQueue.WORK;
    }

}
