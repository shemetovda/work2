package com.sbt.tstub.struct;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Класс, который выдаёт одинаковые очереди в качестве балансировщика На деле
 * это круговое распределение очередей на запись Имеется пул, который копит
 * сообщения Здесь обеспечивается поддержка сообщений с задержкой
 *
 * @author Алексей
 */
public class RoundRobin<T> {

    private CopyOnWriteArrayList<T> serv;
    Integer curr;

    public RoundRobin() {
        curr = 0;
        serv = new CopyOnWriteArrayList<T>();
    }

    @Deprecated
    public CopyOnWriteArrayList<T> getList(){
        return serv;
    }
    
    public int size(){
        return serv.size();
    }
    
    public void add(T m) {
        serv.add(m);
    }

    public boolean isEmpty() {
        return serv.isEmpty();
    }

    public T remove() {
        synchronized (curr) {
            T m = null;
            if (serv.size() > 0) {
                m = serv.remove(curr.intValue());
                if (curr == serv.size() - 1) {
                    curr = 0;
                }
            }
            return m;
        }
    }

    public T get(int i){
        return serv.get(i);
    }
    
    public void clear(){
        serv.clear();
    }
    
    public T remove(T t) {
        synchronized (curr) {
            T m = null;
            for (int i = 0; i < serv.size(); i++) {
                if (t.equals(serv.get(i))) {
                    m = serv.remove(i);
                    if (curr == serv.size() - 1) {
                        curr = 0;
                    }
                }
            }
            return m;
        }
    }

    public T next() {
        if (serv.size() > 0) {
            curr++;
            if (curr >= serv.size()) {
                curr = 0;
            }
            T m = serv.get(curr);
            return m;
        }
        return null;
    }
}
