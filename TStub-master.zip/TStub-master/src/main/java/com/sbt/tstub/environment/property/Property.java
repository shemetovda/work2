package com.sbt.tstub.environment.property;

import com.sbt.tstub.environment.exception.PropertyValidationException;
import lombok.Data;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Set;

@Data
public class Property {
    @NotNull(message = "Наименование не может быть пустым")
    @Size(min = 1, message = "Наименование не может быть пустым")
    private final String name;
    @NotNull(message = "Значение не может быть пустым")
    @Size(min = 1, message = "Значение не может быть пустым")
    private final String value;
    @NotNull(message = "Описание не может быть пустым")
    @Size(min = 1, message = "Описание не может быть пустым")
    private final String description;

    /**
     * Метод для валидации объекта
     *
     * @param property валидируемый объект
     * @throws PropertyValidationException исключение в случае ошибок валидации
     */
    public static void validate(final Property property) throws PropertyValidationException {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> errors = validator.validate(property);
        if (!errors.isEmpty()) {
            StringBuilder errorMessage = new StringBuilder();
            for (ConstraintViolation<Object> error : errors) {
                errorMessage.append(" - ").append(error.getMessage()).append("\n");
            }
            errorMessage.append("\nСодержимое объекта: ").append(property);
            throw new PropertyValidationException(errorMessage.toString());
        }
    }

    @Override
    public String toString() {
        return "{"
                + "name = " + name
                + ", value = " + value
                + ", description = " + description
                + "}";
    }
}
