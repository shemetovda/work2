package com.sbt.tstub.WebProvider;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.DelayedTask;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.template.TemplateService;
import com.sbt.tstub.environment.trigger.TriggerService;
import com.sbt.tstub.environment.writer.WriterService;
import com.sbt.tstub.worker.Worker;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;

public class HTTPHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(HTTPHandler.class);
    private static HTTPWorker httpWorker;
    private static Worker worker;
    private final String path;

    private final PropertyService propertyService;
    private final BaseService baseService;
    private final InfluxDBService influxDBService;
    private final TriggerService triggerService;
    private final ScenarioService scenarioService;
    private final TemplateService templateService;
    private final WriterService writerService;

    public HTTPHandler(String path, PropertyService propertyService, BaseService baseService, InfluxDBService influxDBService, TriggerService triggerService, ScenarioService scenarioService, TemplateService templateService, WriterService writerService) {
        this.path = path;
        this.propertyService = propertyService;
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.triggerService = triggerService;
        this.scenarioService = scenarioService;
        this.templateService = templateService;
        this.writerService = writerService;
        HTTPHandler.httpWorker = new HTTPWorker();
        HTTPHandler.httpWorker.setName("HTTPWorker");
        HTTPHandler.httpWorker.start();

        HTTPHandler.worker = new Worker();
        HTTPHandler.worker.setName("HTTPProcessingWorker");
        HTTPHandler.worker.start();
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        long startTime = System.currentTimeMillis();

        String requestURI = t.getRequestURI().getPath().substring(path.length());

        HTTPTask task;
        DelayedTask delTask;
        switch (requestURI.toLowerCase()) {
            case "/process":
                task = new HTTPTask(triggerService, scenarioService, propertyService, baseService, influxDBService, templateService, writerService, t, worker);
                delTask = new DelayedTask(task, 0);
                httpWorker.put(delTask);
                break;
            default:
                if (requestURI.length() > 1) {
                    try {
                        requestURI = requestURI.substring(1);
                        String[] arr = requestURI.split("/", 2);
                        long delay;
                        if (arr.length > 1) {
                            delay = ThreadLocalRandom.current().nextLong(Long.parseLong(arr[0]), Long.parseLong(arr[1]));
                        } else {
                            delay = Long.parseLong(arr[0]);
                        }
                        task = new HTTPTask(triggerService, scenarioService, propertyService, baseService, influxDBService, templateService, writerService, t, null);
                        delTask = new DelayedTask(task, delay);
                        httpWorker.put(delTask);
                    } catch (NumberFormatException ex) {
                        logger.warn("В ссылке плохое значение=" + requestURI);
                    }
                } else {
                    task = new HTTPTask(triggerService, scenarioService, propertyService, baseService, influxDBService, templateService, writerService, t, null);
                    delTask = new DelayedTask(task, 0);
                    httpWorker.put(delTask);
                }
                break;
        }
        long duration = System.currentTimeMillis() - startTime;
        influxDBService.getInfluxDB().addMeasurementStats("times", "type=HTTP_TaskCreating", "duration=" + duration);
    }
}
