package com.sbt.tstub.environment.exception;

public class TriggerValidationException extends Exception {

    public TriggerValidationException(final String errorMessage) {
        super(errorMessage);
    }

    public TriggerValidationException(final String errorMessage, Exception ex) {
        super(errorMessage, ex);
    }

}
