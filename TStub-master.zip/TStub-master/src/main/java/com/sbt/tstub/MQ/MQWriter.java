package com.sbt.tstub.mq;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.exception.StubQueueValidationException;
import com.sbt.tstub.environment.property.PropertyService;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.jms.JMSException;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Класс, который служит для отправки сообщений по очередям
 *
 * @author Алексей
 */
public class MQWriter extends Thread {

    private static final Logger LOGGER = LogManager.getLogger(MQWriter.class);

    private final LinkedBlockingQueue<TStubMessage> messageQueue;
    private Boolean work;
    private boolean ready;
    public int state;
    public int currentState;
    @Getter
    public final SenderQueue sq;
    @Getter
    private boolean defaultQueue;

    @Getter
    private final String key;

    public MQWriter(PropertyService propertyService, InfluxDBService influxDBService, int id, String host, int port, String manager, String channel, String queueName, String login, String password, boolean active, int certID, boolean isDefaultQueue) {
        messageQueue = new LinkedBlockingQueue(Integer.parseInt(propertyService.getPropertyValueByName("writer_maxQueueLength")));
        work = true;
        defaultQueue = isDefaultQueue;
        currentState = StubQueue.WORK;
        key = host + ":" + port + ":" + manager + ":" + channel + ":" + queueName;
        ready = false;
        sq = new SenderQueue(propertyService, influxDBService,
                id,
                manager,
                host,
                port,
                channel,
                queueName,
                login,
                password,
                active,
                certID);
    }

    public MQWriter(MQWriter writer) {
        this(writer.sq.propertyService, writer.sq.influxDBService,
                writer.sq.id,
                writer.sq.host,
                writer.sq.port,
                writer.sq.manager,
                writer.sq.channel,
                writer.sq.queueName,
                writer.sq.login,
                writer.sq.password,
                writer.sq.active,
                writer.sq.certID,
                writer.defaultQueue);
    }

    /**
     * Метод для валидации объекта
     *
     * @param writer валидируемый объект
     * @throws StubQueueValidationException исключение в случае ошибок валидации
     */
    public static void validate(final MQWriter writer) throws StubQueueValidationException {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> errors = validator.validate(writer);
        if (!errors.isEmpty()) {
            StringBuilder errorMessage = new StringBuilder();
            for (ConstraintViolation<Object> error : errors) {
                errorMessage.append(" - ").append(error.getMessage()).append("\n");
            }
            errorMessage.append("Содержимое объекта: ").append(writer);
            throw new StubQueueValidationException(errorMessage.toString());
        }
    }


    public void put(TStubMessage message) throws InterruptedException {
        if (message != null) {
            messageQueue.put(message);
        }
    }

    @Override
    public void run() {
        synchronized (this) {
            int res = sq.connect();
            if (res != 0) {
                LOGGER.error("Невозможно подключиться к очереди. " + getKey());
                state = res;
                currentState = StubQueue.ERROR;
                LOGGER.warn("Поток запущен с ошибками.");
            } else {
                state = StubQueue.WORK;
                currentState = StubQueue.WORK;
                LOGGER.debug("Поток запущен.");
            }
            ready = true;
            notifyAll();
        }
        TStubMessage message = null;
        int attempts = 0;
        int maxAttempts = 1;
        if (Integer.parseInt(sq.propertyService.getPropertyValueByName("resendOnERROR_attempts")) > 1) {
            maxAttempts = Integer.parseInt(sq.propertyService.getPropertyValueByName("resendOnERROR_attempts"));
        }
        while (work || !messageQueue.isEmpty()) {
            try {
                boolean check = Boolean.parseBoolean(sq.propertyService.getPropertyValueByName("resendOnERROR"));
                if (message == null || !check || maxAttempts <= attempts) {
                    message = messageQueue.take();
                    attempts = 0;
                }
                sq.send(message);
                message = null;
            } catch (InterruptedException ex) {
                LOGGER.debug(BaseService.THREAD_WILL_STOP);
            } catch (JMSException ex) {
                attempts++;
                try {
                    while (work) {
                        currentState = StubQueue.ERROR;
                        sq.close();
                        LOGGER.warn("Cоединение было потеряно.");
                        Thread.sleep(10000L);
                        LOGGER.debug("Попытка подключиться заново.");
                        int res = sq.connect();
                        if (res == 0) {
                            LOGGER.debug("Соединение было восстановлено.");
                            currentState = StubQueue.WORK;
                            break;
                        } else {
                            LOGGER.warn("Соединение не было восстановлено.");
                        }
                    }
                } catch (InterruptedException ex1) {
                    LOGGER.debug(BaseService.THREAD_WILL_STOP);
                }
            }
        }
        sq.close();
        LOGGER.debug(BaseService.THREAD_IS_STOPPED);
    }

    //Метод для безопасной остановки потока и остановки потока без потерь данных
    public void shutdown() {
        work = false;
        interrupt();
    }

    public int getConnectionState() {
        synchronized (this) {
            try {
                while (!ready) {
                    wait();
                }
            } catch (InterruptedException ex) {
                LOGGER.fatal("Непредвиденная ошибка.", ex);
                return SenderQueue.STOP;
            }
            return state;
        }
    }

    public int getQueueDepth() {
        return messageQueue.size();
    }

    public boolean getStartState() {
        synchronized (this) {
            try {
                while (!ready) {
                    wait();
                }
            } catch (InterruptedException ex) {
                LOGGER.fatal("Возникла непредвиденная ситуация. ", ex);
                return false;
            }
            return state == StubQueue.WORK;
        }
    }
}
