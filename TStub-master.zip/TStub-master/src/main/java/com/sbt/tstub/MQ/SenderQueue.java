package com.sbt.tstub.mq;

import com.ibm.mq.jms.JMSC;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.utils.StringUtils;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Map.Entry;

public class SenderQueue extends StubQueue {

    private static final Logger LOGGER = LogManager.getLogger(SenderQueue.class);

    protected final PropertyService propertyService;
    protected final InfluxDBService influxDBService;

    private MQQueueConnectionFactory cf;
    private QueueConnection connection;
    private QueueSession session;
    private Queue queue;
    private QueueSender sender;

    public SenderQueue(PropertyService propertyService,
                       InfluxDBService influxDBService,
                       int id,
                       String manager,
                       String host,
                       int port,
                       String channel,
                       String queueName,
                       String login,
                       String password,
                       boolean active,
                       int certID) {
        super(id, host, port, manager, channel, queueName, login, password, active, certID);
        this.propertyService = propertyService;
        this.influxDBService = influxDBService;
    }

    public boolean send(TStubMessage message) throws JMSException {
        String body = message.getBodyString();
        Message jmsMessage = createMessage(
            message.getTemplateName(),
            body,
            message.getHeaders(),
            message.isByteMessage()
        );
        long startTime = System.currentTimeMillis();
        sender.send(jmsMessage);
        long duration = System.currentTimeMillis() - startTime;
        if (message.getInJMSMessageID() != null) {
            MQMessageIDHelper.getHelper(propertyService).put(jmsMessage.getJMSMessageID(), message.getInJMSMessageID());
            LOGGER.debug(
                    "Сохранена пара: OutputMessageID=" + jmsMessage.getJMSMessageID() + " CorrelationID=" + message.getInJMSMessageID());
        }
        LOGGER.debug("Сообщение отправлено id=" + message.getMessageID() + jmsMessage + "\n" + message.getBodyString());
        String templateName = StringUtils.normalize(message.getTemplateName());
        influxDBService.getInfluxDB().addMeasurementStats("times", "type=sending,queue=" + getKey()
                + ",templateName=" + templateName, "duration=" + duration);
        influxDBService.getInfluxDB().addMeasurementStats("length", "type=output,queue=" + getKey()
                + ",templateName=" + templateName, "length=" + body.length());
        return true;
    }

    public int connect() {
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection(); Statement stmt = c.createStatement()) {
            cf = new MQQueueConnectionFactory();
            // Config
            cf.setHostName(host);
            cf.setPort(port);
            cf.setTransportType(JMSC.MQJMS_TP_CLIENT_MQ_TCPIP);
            cf.setQueueManager(manager);
            cf.setChannel(channel);
            String name = propertyService.getPropertyValueByName("writerName");
            if (name == null) {
                name = "TStubSender";
            }
            cf.setAppName(name);

            if (certID > 0) {
                ResultSet rs = stmt.executeQuery("SELECT * FROM SSLCertificates WHERE id= " + certID);
                if (rs.next()) {
                    LOGGER.debug("Найден сертификат для подключения к очереди.");
                    String path = rs.getString("path");
                    String key = rs.getString("key");
                    String sslType = rs.getString("SSLType");
                    String javaChiperSuite = rs.getString("JavaChiperSuite");
                    boolean FIPSRequired = rs.getBoolean("FIPSRequired");

                    KeyStore ks = KeyStore.getInstance("JKS");
                    ks.load(new FileInputStream(path), key.toCharArray());

                    KeyStore trustStore = KeyStore.getInstance("JKS");
                    trustStore.load(new FileInputStream(path), key.toCharArray());

                    TrustManagerFactory trustManagerFactory
                            = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                    KeyManagerFactory keyManagerFactory
                            = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());

                    trustManagerFactory.init(trustStore);
                    keyManagerFactory.init(ks, key.toCharArray());

                    SSLContext sslContext = SSLContext.getInstance(sslType);
                    sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
                    SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

                    cf.setSSLFipsRequired(FIPSRequired);
                    cf.setSSLCipherSuite(javaChiperSuite);
                    cf.setSSLSocketFactory(sslSocketFactory);
                    rs.close();
                }
            }

            if (login != null) {
                LOGGER.debug("Найдены параметры для аутентификации пользователя.");
                connection = cf.createQueueConnection(login, password);
            } else {
                connection = cf.createQueueConnection();
            }

            session = connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            if (queueName.contains("/")) {
                queue = session.createQueue("queue://" + queueName);
            } else {
                queue = session.createQueue("queue:///" + queueName);
            }
            sender = session.createSender(queue);

            connection.start();
        } catch (JMSException ex) {
            LOGGER.error("Очередь недоступна для подключения.", ex);
            return SenderQueue.STOP;
        } catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException | UnrecoverableKeyException | CertificateException ex) {
            LOGGER.error("Невозможно создать шифрованное подключение.", ex);
            return SenderQueue.STOP;
        } catch (IOException | SQLException ex) {
            LOGGER.error("Невозможно получить данные из базы данных.", ex);
            return SenderQueue.STOP;
        }
        return 0;
    }

    public int close() {
        try {
            if (sender != null) {
                sender.close();
            }
            if (session != null) {
                session.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (JMSException ex) {
            LOGGER.error("Невозможно разорвать соединение с очередью.", ex);
            return SenderQueue.STOP;
        }
        return 0;
    }

    private Message createMessage(final String name, final String body, final Map<String, Object> headers, boolean isByteMessage) throws JMSException {
        Message jmsMessage;
        if (isByteMessage) {
            BytesMessage bytesMessage = session.createBytesMessage();
            bytesMessage.writeBytes(body.getBytes());
            jmsMessage = bytesMessage;
        } else {
            jmsMessage = session.createTextMessage(body);
        }
        if (headers != null) {
            for (Entry<String, Object> entry : headers.entrySet()) {
                try {
                    switch (entry.getKey()) {
                        case "JMSDestination":
                        case "JMSMessageID":
                        case "JMSTimestamp":
                            //НИЗЯ
                            LOGGER.warn("Нельзя задавать значение заголовка \"{}\".", entry.getKey());
                            break;
                        case "JMSDeliveryMode":
                            jmsMessage.setJMSDeliveryMode((Integer) entry.getValue());
                            break;
                        case "JMSCorrelationID":
                            jmsMessage.setJMSCorrelationID((String) entry.getValue());
                            break;
                        case "JMSReplyTo":
                            //TODO: Если надо вписать ReplyTo
                            jmsMessage.setJMSReplyTo(MQProducers.getReader((String) entry.getValue()).getDestination());
                            break;
                        case "JMSRedelivered":
                            jmsMessage.setJMSRedelivered((Boolean) entry.getValue());
                            break;
                        case "JMSType":
                            jmsMessage.setJMSType((String) entry.getValue());
                            break;
                        case "JMSExpiration":
                            jmsMessage.setJMSExpiration((Long) entry.getValue());
                            break;
                        case "JMSPriority": //0-9
                            jmsMessage.setJMSPriority((Integer) entry.getValue());
                            break;
                        default:
                            jmsMessage.setObjectProperty(entry.getKey(), entry.getValue());
                            break;
                    }
                } catch (Exception ex) {
                    LOGGER.warn("Шаблон \"{}\". В параметре MQHeader name=\"{}\" value=\"{}\" содержится ошибка.",
                                name, entry.getKey(), entry.getValue(), ex);
                }
            }
        }
        return jmsMessage;
    }
}
