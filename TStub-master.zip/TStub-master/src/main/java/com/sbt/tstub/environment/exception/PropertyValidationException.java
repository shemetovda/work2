package com.sbt.tstub.environment.exception;

public class PropertyValidationException extends Exception {

    public PropertyValidationException(final String errorMessage) {
        super(errorMessage);
    }

    public PropertyValidationException(final String errorMessage, Exception ex) {
        super(errorMessage, ex);
    }

}
