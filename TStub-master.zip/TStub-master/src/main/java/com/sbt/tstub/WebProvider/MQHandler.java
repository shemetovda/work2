package com.sbt.tstub.WebProvider;

import com.sbt.tstub.environment.writer.WriterService;
import com.sbt.tstub.mq.MQProducers;
import com.sbt.tstub.mq.MQWriter;
import com.sbt.tstub.mq.TStubMessage;
import com.sbt.tstub.TStub;
import com.sbt.tstub.webInterface.ResponseHelper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonWriter;
import org.apache.commons.pool2.ObjectPool;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MQHandler implements HttpHandler {

    private static final Logger LOGGER = LogManager.getLogger(MQHandler.class);

    private final String path;

    private final WriterService writerService;

    public MQHandler(String path, WriterService writerService) {
        this.path = path;
        this.writerService = writerService;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        JsonObject response = null;
        int responseCode = 200;
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        try {
            String requestURI = t.getRequestURI().getPath().substring(path.length());
            //TODO: Работа с заголовками

            if (requestURI.length() > 1) {
                requestURI = requestURI.substring(1);
                ObjectPool<MQWriter> pool = writerService.getPoolByKey(requestURI);
                try {
                    MQWriter writer = pool.borrowObject();
                    if (writer != null) {
                        StringWriter strWriter = new StringWriter();
                        InputStream is = t.getRequestBody();
                        BufferedReader br = new BufferedReader(new InputStreamReader(is));
                        final char[] buffer = new char[1024];
                        int count = 0;
                        while ((count = br.read(buffer)) != -1) {
                            strWriter.write(buffer, 0, count);
                        }
                        br.close();
                        strWriter.close();
                        writer.put(new TStubMessage(strWriter.toString(), null, null, "HTTPtoMQInput", false, false));
                        response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, requestURI);
                        try {
                            pool.returnObject(writer);
                        } catch (Exception ex) {
                            LOGGER.error("Не могу вернуть очередь для записи queue=" + requestURI + ".\n", ex);
                        }
                    } else {
                        responseCode = 404;
                        response = ResponseHelper.jsonObjectError(TStub.OBJECT_NOT_FOUND, requestURI, "Writer not found");
                    }
                } catch (Exception ex) {
                    LOGGER.error("Не могу получить очередь для записи queue=" + requestURI + ".\n", ex);
                }
            } else {
                responseCode = 501;
                response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, null, "WriterID not found");
            }
        } catch (Exception ex) {
            LOGGER.error("Неизвестная ошибка. ", ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, null, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        String data = strWriter.getBuffer().toString();
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }
}
