package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.webInterface.fileData.FileData;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.json.JsonException;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.UUID;

public class DownloadHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(DownloadHandler.class);

    private static String path;

    public DownloadHandler(String path) {
        this.path = path;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        InputStreamReader isr = new InputStreamReader(t.getRequestBody(), "utf-8");
        BufferedReader br = new BufferedReader(isr);
        String query = br.readLine();
        String[] arr = query.split("&");
        HashMap<String, Object> params = new HashMap();
        for (int i = 0; i < arr.length; i++) {
            String[] arr2 = arr[i].split("=", 2);
            if (arr2.length > 1) {
                params.put(arr2[0], arr2[1]);
            }
        }

        String uuid = UUID.randomUUID().toString();
        try {
            //определяем тип загрузки
            switch (Integer.parseInt((String) params.get("type"))) {
                case FileData.LOGS:
                    downloadLog(uuid, (String) params.get("fileName"), t);
                    break;
                case FileData.TEMPLATE:
                case FileData.CERTIFICATE:
                case FileData.REQUEST:
                default:
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.", uuid, ex);
        } catch (Exception ex) {
            logger.error("{}:Неизвестная ошибка.", uuid, ex);
        }
    }

    private void downloadLog(String uuid, String fileName, HttpExchange t) {
        try {
            String filePath = "logs/" + fileName;
            File file = new File(filePath).getCanonicalFile();
            if (file.isFile()) {
                t.getResponseHeaders().add("content-type", "application/octet-stream");
                t.getResponseHeaders().add("content-disposition", "attachment; filename=\"" + fileName + "\"");
                t.sendResponseHeaders(200, 0);
                OutputStream os = t.getResponseBody();
                FileInputStream fs = new FileInputStream(file);
                final byte[] buffer = new byte[0x10000];
                int count = 0;
                while ((count = fs.read(buffer)) >= 0) {
                    os.write(buffer, 0, count);
                }
                fs.close();
                os.close();
            } else {
                String response = "404 (Not Found)\n";
                t.sendResponseHeaders(404, response.length());
                OutputStream os = t.getResponseBody();
                os.write(response.getBytes());
                os.close();
            }
        } catch (Exception ex) {
            logger.error("{}:Неизвестная ошибка. ", uuid, ex);
        }
    }
}
