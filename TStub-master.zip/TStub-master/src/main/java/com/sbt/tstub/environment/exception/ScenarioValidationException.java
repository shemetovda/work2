package com.sbt.tstub.environment.exception;

public class ScenarioValidationException extends Exception {

    public ScenarioValidationException(final String errorMessage) {
        super(errorMessage);
    }

    public ScenarioValidationException(final String errorMessage, Exception ex) {
        super(errorMessage, ex);
    }

}
