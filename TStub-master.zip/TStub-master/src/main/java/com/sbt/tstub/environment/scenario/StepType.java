package com.sbt.tstub.environment.scenario;

import lombok.Getter;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

@Getter
public enum StepType {

    STEP_NOT_DEFINE(-1),
    STEP_DROP(0),
    STEP_WAIT(1),
    STEP_WRITE(2),
    STEP_WORK(3),
    STEP_HTTP(4);

    private int typeId;
    private static final Map<Integer, StepType> stepTypeMap;

    static {
        stepTypeMap = Arrays.stream(StepType.values())
                .collect(Collectors.toMap(StepType::getTypeId, stepType -> stepType));
    }

    StepType(final int typeId) {
        this.typeId = typeId;
    }

    public static StepType getStepTypeById(final int id) {
        StepType stepType = stepTypeMap.get(id);
        if (stepType == null) {
            throw new IllegalArgumentException("StepType c id = " + id + " не существует");
        }
        return stepType;
    }
}
