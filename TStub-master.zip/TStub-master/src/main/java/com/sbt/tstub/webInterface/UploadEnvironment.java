package com.sbt.tstub.webInterface;

import com.sbt.tstub.webInterface.fileData.FileData;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class UploadEnvironment {
    
    private static UploadEnvironment instance;

    private static ConcurrentMap<String, FileData> files;

    public UploadEnvironment() {
        files = new ConcurrentHashMap();
    }

    public static UploadEnvironment getEnvironments() {
        UploadEnvironment localInstance = instance;
        if (localInstance == null) {
            synchronized (UploadEnvironment.class) {
                localInstance = instance;
                if (localInstance == null) {
                    instance = localInstance = new UploadEnvironment();
                }
            }
        }
        return localInstance;
    }
    /**
     * 
     * @param key - UUID файла
     * @param value - имя файла
     */
    public void putFile(String key, FileData value){
        files.put(key, value);
    }
    /**
     * 
     * @param key - UUID файла
     */
    public FileData getFile(String key){
        return files.get(key);
    }
    
    /**
     * 
     * @param key - UUID файла
     */
    public FileData removeFile(String key){
        return files.remove(key);
    }
}
