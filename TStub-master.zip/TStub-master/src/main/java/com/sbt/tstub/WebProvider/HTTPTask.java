package com.sbt.tstub.WebProvider;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.DelayedTask;
import com.sbt.tstub.TStub;
import com.sbt.tstub.environment.template.TemplateService;
import com.sbt.tstub.environment.writer.WriterService;
import com.sbt.tstub.template.Template;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.scenario.Step;
import com.sbt.tstub.environment.scenario.StepType;
import com.sbt.tstub.environment.trigger.Trigger;
import com.sbt.tstub.environment.trigger.TriggerService;
import com.sbt.tstub.mq.TStubMessage;
import com.sbt.tstub.utils.StringUtils;
import com.sbt.tstub.worker.Worker;
import com.sbt.tstub.worker.WorkerTask;
import com.sun.net.httpserver.HttpExchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class HTTPTask implements Runnable {

    private final HttpExchange t;
    private final Worker worker;
    private static final Logger logger = LogManager.getLogger(HTTPTask.class);

    private final ScenarioService scenarioService;
    private final TriggerService triggerService;
    private final PropertyService propertyService;
    private final BaseService baseService;
    private final InfluxDBService influxDBService;
    private final TemplateService templateService;
    private final WriterService writerService;

    public HTTPTask(TriggerService triggerService, ScenarioService scenarioService, PropertyService propertyService, BaseService baseService, InfluxDBService influxDBService, TemplateService templateService, WriterService writerService, HttpExchange t, Worker worker) {
        this.triggerService = triggerService;
        this.scenarioService = scenarioService;
        this.propertyService = propertyService;
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.templateService = templateService;
        this.writerService = writerService;
        this.t = t;
        this.worker = worker;
    }

    @Override
    public void run() {
        long startTime = System.currentTimeMillis();
        int responseCode = 200;
        String response = "<?xml version=\"1.0\" encoding=\"UTF8\" standalone=\"yes\"?>\n";
        t.getResponseHeaders().add("content-type", "application/xml; charset=utf-8");
        boolean check = false;
        try {
            StringWriter strWriter = new StringWriter();
            InputStream is = t.getRequestBody();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            final char[] buffer = new char[1024];
            int count;
            while ((count = br.read(buffer)) != -1) {
                strWriter.write(buffer, 0, count);
            }
            br.close();
            strWriter.close();

            String request = strWriter.toString();
            String params = t.getRequestURI().getQuery();
            HashMap<String, Object> prop = parseProperties(params);

            //Определить шаблон
            TStubMessage message = null;
            try {
                message = new TStubMessage(request, prop, null, "HTTPInput", false, false);
            } catch (SAXException | IOException e) {
                logger.error("Сообщение не валидно.\n" + request);
                responseCode = 400;
                response += "<Error>\n    <code>" + TStub.PARSING_ERROR + "</code>\n    <message>Can't validate message</message>\n</Error>";
            }

            if (message != null) {
                Document document = message.getBody();

                XPath xPath = XPathFactory.newInstance().newXPath();
                WorkerTask task = null;
                List<Trigger> triggerList = triggerService.getAvailableTriggers();
                Iterator<Trigger> triggerIterator = triggerList.iterator();
                int triggerID = 0;
                String triggerName = "";
                while (triggerIterator.hasNext()) {
                    Trigger trigger = triggerIterator.next();
                    triggerID = trigger.getId();
                    if (baseService.checkHeaders(message, trigger.getHeaders())) {
                        final String expression = trigger.getXPathExpression();
                        try {
                            NodeList nodes = (NodeList) xPath.evaluate(expression, document, XPathConstants.NODESET);
                            if (nodes.getLength() != 0) {
                                check = true;
                                triggerName = StringUtils.normalize(trigger.getComment());
                                influxDBService.getInfluxDB().putStatsClear("expressionResult,result=" + triggerName);
                                logger.debug("Получено сообщение типа {} id={}\n{}", expression, message.getMessageID(), message);
                                long duration = System.currentTimeMillis() - startTime;
                                influxDBService.getInfluxDB().addMeasurementStats("times", "type=HTTP_WorkerTaskMaker,triggerName=" + StringUtils.normalize(expression), "duration=" + duration);
                                break;
                            }
                        } catch (XPathExpressionException e) {
                            logger.error("triggerID={}: в выражении {} содержится ошибка. ", triggerID, expression, e);
                        }
                    }
                }
                startTime = System.currentTimeMillis();
                Template template = null;
                if (check) { //найден триггер
                    if (worker != null) {
                        //Если нам надо обработать по сценарию
                        task = new WorkerTask(scenarioService, baseService, propertyService, influxDBService, templateService, message, writerService, triggerID, t);
                        worker.putTask(new DelayedTask(task, 0));
                    } else {
                        //Если нам не надо по сценарию, а просто ответить
                        Step step = scenarioService.getStepByStepType(triggerID, StepType.STEP_WORK);
                        if (step != null) {
                            int templateID = step.getStepTemplateId();
                            template = templateService.getTemplateById(templateID);
                            if (template != null) {
                                task = new WorkerTask(scenarioService, baseService, propertyService, influxDBService, templateService, message, writerService, template, triggerID);
                            } else {
                                logger.error("Шаблон с id={} не найден.", templateID);
                                response += "<Error>\n    <code>" + TStub.OBJECT_NOT_FOUND + "</code>\n    <message>template with id=" + templateID + " not found</message>\n</Error>\n";
                                responseCode = 404;
                            }
                        } else {
                            logger.error("Cценарий для триггера \"{}\" не найден.", triggerName);
                            response += "<Error>\n    <code>" + TStub.OBJECT_NOT_FOUND + "</code>\n    <message>Scenario for trigger \"" + triggerName + "\" not found</message>\n</Error>\n";
                            responseCode = 404;
                        }
                    }
                } else {
                    logger.debug("Получено сообщение неизвестного типа id={}\n{}", message.getMessageID(), message);
                    response += "<Error>\n    <code>" + TStub.OBJECT_NOT_FOUND + "</code>\n    <message>Trigger for message not found</message>\n</Error>\n";
                    responseCode = 404;
                }
                long duration = System.currentTimeMillis() - startTime;
                influxDBService.getInfluxDB().addMeasurementStats("times", "type=HTTP_WorkerTaskMaker2,templateName=" + (template == null ? "worker" : StringUtils.normalize(template.getComment())), "duration=" + duration);
                influxDBService.getInfluxDB().addMeasurementStats("length", "type=HTTP_input,templateName=" + (template == null ? "worker" : StringUtils.normalize(template.getComment())), "length=" + request.length());
                //запускаем обработку
                if (worker == null) {
                    if (task != null) {
                        task = (WorkerTask) task.call();
                        //отвечаем на запрос
                        TStubMessage result = task.getMessage(1);
                        if (result != null) {
                            response = result.getBodyString();
                            logger.debug("Отправлено ответное сообщение - {}\n{}", result.getMessageID(), response);
                        } else {
                            responseCode = 500;
                            response += "<Error>\n    <code>" + TStub.UNKNOWN_ERROR + "</code>\n    <message>Processing error</message>\n</Error>\n";
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.error("Неизвестная ошибка. ", ex);
            responseCode = 500;
            response += "<Error>\n    <code>" + TStub.UNKNOWN_ERROR + "</code>\n    <message>UnknownError: " + ex.getLocalizedMessage() + "</message>\n</Error>\n";
        }

        if (worker == null || !check) {
            startTime = System.currentTimeMillis();
            try (OutputStream os = t.getResponseBody()) {
                t.sendResponseHeaders(responseCode, response.getBytes().length);
                os.write(response.getBytes());
            } catch (IOException ex) {
                logger.error("Неизвестная ошибка при отправке ответа.", ex);
            }
            long duration = System.currentTimeMillis() - startTime;
            influxDBService.getInfluxDB().addMeasurementStats("times", "type=HTTP_Sending", "duration=" + duration);
            influxDBService.getInfluxDB().addMeasurementStats("length", "type=HTTP_output", "length=" + response.length());
        }
    }

    private HashMap<String, Object> parseProperties(String params) {
        if (params != null) {
            String[] spParam1 = params.split("&");
            HashMap<String, Object> res = new HashMap<>();
            for (String pair : spParam1) {
                String[] param = pair.split("=", 2);
                if (param.length == 2) {
                    res.put(param[0], param[1]);
                }
            }
            return res;
        } else {
            return null;
        }
    }
}
