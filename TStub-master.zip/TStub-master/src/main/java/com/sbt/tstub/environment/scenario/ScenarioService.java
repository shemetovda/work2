package com.sbt.tstub.environment.scenario;

import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.exception.ScenarioValidationException;
import com.sbt.tstub.environment.trigger.TriggerService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Класс для получения доступа к триггерам на обработку
 */
public class ScenarioService {

    private static String SELECT_QUERY = "SELECT * FROM WorkerSteps WHERE triggerID=? ORDER BY stepNum";
    private static String DELETE_QUERY = "DELETE FROM WorkerSteps WHERE triggerID=?";
    private static String INSERT_QUERY = "INSERT INTO WorkerSteps " +
            "(triggerID, stepNum, stepType, srcStepMessage, stepTemplateid, delay, MQWriterid, chance)" +
            "VALUES (?,?,?,?,?,?,?,?)";

    private static final Logger LOGGER = LogManager.getLogger(ScenarioService.class);

    private final TriggerService triggerService;
    private Map<Integer, Scenario> scenarios;

    public ScenarioService(final TriggerService triggerService) throws SQLException, ScenarioValidationException {
        this.triggerService = triggerService;
        try {
            scenarios = readFromDB();
        } catch (SQLException | ScenarioValidationException ex) {
            scenarios = new ConcurrentHashMap<>();
            throw ex;
        }
    }

    private Map<Integer, Scenario> readFromDB() throws SQLException, ScenarioValidationException {
        Set<Integer> triggerIdSet = triggerService.getTriggers().keySet();
        Map<Integer, Scenario> scenarioMap = new ConcurrentHashMap<>();
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             PreparedStatement prs = c.prepareStatement(SELECT_QUERY)) {
            for (int triggerId : triggerIdSet) {
                prs.setInt(1, triggerId);
                ResultSet rs = prs.executeQuery();
                List<Step> steps = new ArrayList<>();
                while (rs.next()) {
                    StepType stepType = StepType.getStepTypeById(rs.getInt("stepType"));
                    Step step;
                    switch (stepType) {
                        case STEP_WAIT:
                            step = Step.StepWait(triggerId,
                                    rs.getInt("stepNum"),
                                    rs.getInt("delay"));
                            break;
                        case STEP_WRITE:
                            step = Step.StepWrite(triggerId,
                                    rs.getInt("stepNum"),
                                    rs.getInt("srcStepMessage"),
                                    rs.getInt("MQWriterid"),
                                    rs.getInt("chance"));
                            break;
                        case STEP_WORK:
                            step = Step.StepWork(triggerId,
                                    rs.getInt("stepNum"),
                                    rs.getInt("stepTemplateId"),
                                    rs.getInt("srcStepMessage"));
                            break;
                        case STEP_HTTP:
                            step = Step.StepHttp(triggerId,
                                    rs.getInt("stepNum"),
                                    rs.getInt("srcStepMessage"));
                            break;
                        case STEP_NOT_DEFINE:
                            continue;
                        case STEP_DROP:
                        default:
                            step = Step.StepDrop(triggerId,
                                    rs.getInt("stepNum"));
                    }
                    steps.add(step);
                }
                Scenario scenario = new Scenario(triggerId, steps);
                Scenario.validate(scenario);
                scenarioMap.put(triggerId, scenario);
            }
        }
        return scenarioMap;
    }

    public void refresh() throws SQLException, ScenarioValidationException {
        scenarios = readFromDB();
    }

    /**
     * Метод для обновления сценария в БД и в кеш.
     * Также этот метод создаст новый сценарий, если его не было
     *
     * @param scenario сценарий
     * @throws SQLException                ошибка добавления scenario в БД
     * @throws ScenarioValidationException при ошибка валидации
     */
    public void update(final Scenario scenario) throws SQLException, ScenarioValidationException {
        if (triggerService.getTriggers().containsKey(scenario.getTriggerId())) {
            Scenario.validate(scenario);
            updateIntoDB(scenario);
            scenarios.put(scenario.getTriggerId(), scenario);
        } else {
            throw new ScenarioValidationException("Триггер с id = " + scenario.getTriggerId() + " не найден");
        }
    }

    private void updateIntoDB(final Scenario scenario) throws SQLException {
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            //Удаление старого сценария
            PreparedStatement prs = c.prepareStatement(DELETE_QUERY);
            prs.setInt(1, scenario.getTriggerId());
            prs.executeUpdate();
            prs.close();
            //Запись нового сценария
            for (Step step : scenario.getSteps()) {
                prs = c.prepareStatement(INSERT_QUERY);
                prs.setInt(1, scenario.getTriggerId());
                prs.setInt(2, step.getStepNum());
                prs.setInt(3, step.getStepType().getTypeId());
                prs.setInt(4, step.getSrcStepMessage());
                setIntOrNull(prs, 5, step.getStepTemplateId());
                prs.setInt(6, step.getDelay());
                setIntOrNull(prs, 7, step.getMqWriterId());
                prs.setInt(8, step.getChance());
                prs.executeUpdate();
                prs.close();
            }
            c.commit();
        }
    }

    private void setIntOrNull(final PreparedStatement prs, final int parameterIndex, final int value) throws SQLException {
        if (value < 0) {
            prs.setNull(parameterIndex, Types.INTEGER);
        } else {
            prs.setInt(parameterIndex, value);
        }
    }

    /**
     * Метод для получения сценария по id триггера
     *
     * @param triggerId идентификатор триггера
     * @return сценарий или null если сценарий не был найден
     */
    public Scenario getScenarioByTriggerId(final int triggerId) {
        return scenarios.get(triggerId);
    }

    public List<Step> getStepsByStepNumber(final int triggerId, final int stepNum) {
        Scenario scenario = scenarios.get(triggerId);
        if (scenario == null) {
            return null;
        }
        return scenario.getSteps().stream().filter(step -> step.getStepNum() == stepNum).collect(Collectors.toList());
    }

    public Step getStepByStepType(final int triggerId, final StepType stepType) {
        Scenario scenario = scenarios.get(triggerId);
        if (scenario == null) {
            return null;
        }
        return scenario.getSteps().stream().filter(step -> step.getStepType() == stepType).findFirst().orElse(null);
    }

    public List<Step> getStepsByMqWriterId(final int mqWriterId) {
        List<Step> steps = new LinkedList<>();
        scenarios.values().forEach(
                scenario -> steps.addAll(scenario.getSteps().stream().filter(
                        step -> step.getMqWriterId() == mqWriterId).collect(Collectors.toList())));
        return steps;
    }

}
