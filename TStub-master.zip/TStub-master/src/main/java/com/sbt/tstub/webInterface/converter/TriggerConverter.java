package com.sbt.tstub.webInterface.converter;

import com.sbt.tstub.environment.trigger.Trigger;
import com.sbt.tstub.environment.trigger.TriggerService;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

public class TriggerConverter {

    private static int NOT_DEFINE = -1;

    private final TriggerService triggerService;

    public TriggerConverter(final TriggerService triggerService) {
        this.triggerService = triggerService;
    }

    public JsonObjectBuilder convertToJson(final Trigger trigger) {
        JsonObjectBuilder obj = Json.createObjectBuilder();
        obj.add("id", trigger.getId());
        obj.add("expression", trigger.getXPathExpression());
        if (trigger.getHeaders().isEmpty()) {
            obj.addNull("headers");
        } else {
            obj.add("headers", triggerService.buildHeadersForDB(trigger.getHeaders()));
        }
        obj.add("comment", trigger.getComment());
        obj.add("active", trigger.isActive());
        return obj;
    }

    public Trigger stepToObject(final JsonObject obj) {
        int triggerId = obj.getInt("id", NOT_DEFINE);
        return new Trigger(
                triggerId,
                obj.getString("expression"),
                obj.getString("comment"),
                triggerService.buildHeadersMap(triggerId, obj.getString("headers", "")),
                obj.getBoolean("active")
        );
    }

}
