package com.sbt.tstub.environment.exception;

public class TemplateValidationException extends Exception {

    public TemplateValidationException(final String errorMessage) {
        super(errorMessage);
    }

    public TemplateValidationException(final String errorMessage, Exception ex) {
        super(errorMessage, ex);
    }

}
