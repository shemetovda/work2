package com.sbt.tstub.template;

import org.apache.commons.lang3.StringEscapeUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.sbt.tstub.mq.TStubMessage;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProcessArray extends TemplateNode {

    private final String xPathForArray;
    private final String sqlSelectId;
    private int numbers = 0;
    private Template template;
    private SQLSelect selector;

    private final javax.xml.xpath.XPath xPath = XPathFactory.newInstance().newXPath();

    public ProcessArray(Element elem, Template template) throws IllegalArgumentException {
        value = elem.getTextContent();
        xPathForArray = elem.getAttribute("XPath");
        sqlSelectId = elem.getAttribute("sqlSelectId");
        this.template = template;
        TemplateNode node = template.getVar(sqlSelectId);
        if(node != null) {
            if (node instanceof SQLSelect) {
                selector = (SQLSelect) node;
            } else {
                throw new IllegalArgumentException("В аттрибуте sqlSelectId указан id не от инструкции SQLSelect");
            }
        }
        String strNumbers = elem.getAttribute("number");
        if (!strNumbers.isEmpty()) {
            String[] arr = strNumbers.split(";", 2);
            if (arr.length == 1) {
                numbers = Integer.parseInt(arr[0]);
            } else {
                int from = Integer.parseInt(arr[0]);
                int to = Integer.parseInt(arr[1]);
                numbers = ThreadLocalRandom.current().nextInt(from, to);
            }
        }
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        StringBuilder result = new StringBuilder();
        String xmlBlock = "<?xml version=\"1.0\" encoding=\"windows-1251\"?>\n" + this.value;
        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = builderFactory.newDocumentBuilder();
        InputSource src = new InputSource(new StringReader(xmlBlock));
        Document docBlock = builder.parse(src);
        HashMap<String, NodeList> xMap = new HashMap();
        if (numbers == 0) {
            if (selector != null) {
                List<Map<String, String>> results = selector.getResults();
                for (Map<String, String> entry : results) {
                    //TODO: доделать пробегание
                }
            } else {
                Object obj = xPath.compile(xPathForArray).evaluate(sourse.getBody(), XPathConstants.NODESET);
                NodeList nodes = (NodeList) obj;
                for (int i = 0; i < nodes.getLength(); i++) {
                    result.append(processEachXPathNodes(docBlock.getChildNodes(), sourse, i, xMap));
                }
            }
        } else {
            for (int i = 0; i < numbers; i++) {
                result.append(processEachXPathNodes(docBlock.getChildNodes(), sourse, i, xMap));
            }
        }
        return result.toString();
    }

    private String processEachXPathNodes(NodeList nodes,
                                         TStubMessage sourse,
                                         int num,
                                         HashMap<String, NodeList> xMap) throws Exception {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i).getNodeType() > 1) {
                //дошли до внутренности элемента (nodes.item(i).getTextContent())
                result.append(
                        getReplaced(StringEscapeUtils.escapeXml10(nodes.item(i).getTextContent()), sourse, num, xMap));
            } else {
                result.append("<").append(nodes.item(i).getNodeName());
                for (int j = 0; j < nodes.item(i).getAttributes().getLength(); j++) {
                    //дошли до внутренности аттрибута (nodes.item(i).getAttributes().item(j).getNodeValue())
                    result.append(" ").append(nodes.item(i).getAttributes().item(j).getNodeName()).append("=\"")
                          .append(getReplaced(nodes.item(i).getAttributes().item(j).getNodeValue(), sourse, num, xMap))
                          .append("\"");
                }
                result.append(">");
                result.append(processEachXPathNodes(nodes.item(i).getChildNodes(), sourse, num, xMap));
                result.append("</").append(nodes.item(i).getNodeName()).append(">\n");
            }
        }
        return result.toString();
    }

    private String getReplaced(String param,
                               TStubMessage sourse,
                               int num,
                               HashMap<String, NodeList> xMap) throws Exception {
        Pattern pattern = Pattern.compile("\\[%.*?%\\]", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(param);
        int index = 0;
        StringBuilder back = new StringBuilder();
        while (matcher.find()) {
            String group = matcher.group();
            back.append(param, index, matcher.start());
            index = matcher.end();
            if (group.length() > 4) {
                int start = group.indexOf("(");
                int end = group.lastIndexOf(")");
                if (start != -1 && end != -1) {
                    String newValue = group.substring(start + 1, end);
                    String id = group.substring(2, start);
                    switch (id.toLowerCase()) {
                        case "xpath":
                            NodeList list = xMap.get(newValue);
                            if (list == null) {
                                XPathExpression expr = xPath.compile(newValue);
                                list = (NodeList) expr.evaluate(sourse.getBody(), XPathConstants.NODESET);
                                xMap.put(newValue, list);
                            }
                            back.append(processEachXPathNodes(list.item(num).getChildNodes(), sourse, num, xMap));
                            break;
                        default:
                            TemplateNode var = template.getVar(id);
                            if (var != null) {
                                var.setValue(newValue);
                                back.append(ReplaceHelper.getReplacedId(id, sourse, template));
                            } else {
                                back.append(group);
                            }
                    }
                } else {
                    back.append(ReplaceHelper.getReplacedId(group.substring(2, group.length() - 2), sourse, template));
                }
            } else {
                back.append(group);
            }
        }
        back.append(param.substring(index));
        return back.toString();
    }

    @Override
    public String toString() {
        return "{"
                + "value=" + value + '\"'
                + ", xPathForArray=\"" + xPathForArray + '\"'
                + ", numbers=\"" + numbers + '\"'
                + ", sqlSelectId=\"" + sqlSelectId + '\"'
                + "}";
    }

    @Override
    public void setTemplate(Template template) {
        this.template = template;
        selector = (SQLSelect) template.getVar(sqlSelectId);
    }
}
