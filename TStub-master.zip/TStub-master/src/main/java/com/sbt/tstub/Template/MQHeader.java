package com.sbt.tstub.template;

import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.mq.MQMessageIDHelper;
import org.w3c.dom.Element;

public class MQHeader {

    private final PropertyService propertyService;

    private String name;
    private String value;
    private String type;

    MQHeader(PropertyService propertyService, Element node) {
        this.propertyService = propertyService;
        if (!node.hasAttribute("type")) {
            throw new IllegalArgumentException("Attribute \"type\" is empty.");
        }
        type = node.getAttribute("type");
        if (!node.hasAttribute("name")) {
            throw new IllegalArgumentException("Attribute \"name\" is empty.");
        }
        name = node.getAttribute("name");
        value = node.getTextContent();
    }

    MQHeader(String type, String name, PropertyService propertyService, String value) {
        this.propertyService = propertyService;
        if (type == null || type.length() < 1) {
            throw new IllegalArgumentException("Attribute \"type\" is empty.");
        }
        if (name == null || name.length() < 1) {
            throw new IllegalArgumentException("Attribute \"name\" is empty.");
        }
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public String getName() {
        return name;
    }

    public Object getObject(String value) {
        Object result;
        switch (type.toLowerCase()) {
            case "correlationidmap":
                result = MQMessageIDHelper.getHelper(propertyService).take(value);
                break;
            case "correlationidmapnoremove":
                result = MQMessageIDHelper.getHelper(propertyService).get(value);
                break;
            default:
                result = ReplaceHelper.castForHeader(type, value);
                break;
        }
        return result;
    }

    @Override
    public String toString() {
        return "{"
                + "name = " + name
                + ", type = " + type
                + ", value = " + value
                + "}";
    }
}
