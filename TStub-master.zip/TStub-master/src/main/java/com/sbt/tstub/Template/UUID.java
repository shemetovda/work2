package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import org.w3c.dom.Element;

public class UUID extends TemplateNode {

    private static final String FROM_STRING = "string";

    private final String type;
    private final boolean dash;

    public UUID(Element elem) throws IllegalArgumentException {
        if (elem.getAttribute("type").length() == 0) {
            throw new IllegalArgumentException("Attribute \"type\" is empty.");
        } else {
            type = elem.getAttribute("type");
        }

        this.value = elem.getTextContent();
        if (value.length() == 0) {
            value = null;
        }

        dash = !elem.getAttribute("dash").equals("false");
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        String result;
        if (type.equals(FROM_STRING)) {
            result = java.util.UUID.fromString(value).toString();
        } else {
            result = java.util.UUID.randomUUID().toString();
        }
        if (dash) {
            return result;
        } else {
            return result.replace("-", "");
        }
    }

    @Override
    public String toString() {
        return "{value=" + value + ";type=" + type + "; dash=" + dash + "}";
    }
}
