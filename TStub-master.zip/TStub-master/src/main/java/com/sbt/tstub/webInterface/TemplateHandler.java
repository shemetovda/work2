package com.sbt.tstub.webInterface;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.TStub;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.exception.TemplateValidationException;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.environment.template.TemplateService;
import com.sbt.tstub.template.Template;
import com.sbt.tstub.webInterface.converter.TemplateConverter;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.json.*;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.Collection;
import java.util.UUID;

public class TemplateHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(TemplateHandler.class);

    private final String path;
    private final TemplateService templateService;
    private final TemplateConverter templateConverter;
    private final BaseService baseService;
    private final InfluxDBService influxDBService;
    private final PropertyService propertyService;

    public TemplateHandler(String path, TemplateService templateService, TemplateConverter templateConverter, BaseService baseService, InfluxDBService influxDBService, PropertyService propertyService) {
        this.path = path;
        this.templateService = templateService;
        this.templateConverter = templateConverter;
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.propertyService = propertyService;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        JsonObject response = null;
        int responseCode = 200;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            jsonReader.close();
            switch (requestURI) {
                case "get":
                    response = getTemplates(uuid);
                    break;
                case "add":
                    response = addTemplate(uuid, json.getString("template", null), json.getString("comment", null));
                    break;
                case "remove":
                    response = removeTemplate(uuid, json.getInt("id", 0));
                    break;
                case "update":
                    response = updateTemplate(uuid, json.getInt("id", 0), json.getString("template", null), json.getString("comment", null));
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.", uuid, ex);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (IllegalArgumentException ex) {
            logger.fatal("{}:Ошибка при парсинге шаблона.", uuid, ex);
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, ex.getLocalizedMessage());
        } catch (Exception ex) {
            logger.error("{}:Неизвестная ошибка.", uuid, ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        String data = strWriter.getBuffer().toString();
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject getTemplates(String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        JsonArrayBuilder templatesJson = Json.createArrayBuilder();
        Collection<Template> templates = templateService.getTemplates().values();
        templates.forEach(template -> templatesJson.add(templateConverter.convertToJson(template)));
        jsonBuilder.add("templates", templatesJson);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }

    private JsonObject addTemplate(String uuid, String template, String comment) {
        JsonObject response;
        try {
            Template templateObj = new Template(-1, template, comment, baseService, influxDBService, propertyService);
            templateService.add(templateObj);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнения запроса к таблице Templates.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при записи в БД. " + e.getLocalizedMessage());
        } catch (TemplateValidationException ex) {
            logger.fatal("{}:Ошибка при валидации шаблона.", uuid, ex);
            response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, ex.getLocalizedMessage());
        }
        return response;
    }

    private JsonObject updateTemplate(String uuid, int templateId, String template, String comment) {
        Template templateObj = templateService.getTemplateById(templateId);
        JsonObject response;
        if (templateObj != null) {
            try {
                templateObj = new Template(templateId, template, comment,
                        baseService, influxDBService, propertyService);
                templateService.update(templateObj);
                response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
            } catch (SQLException e) {
                logger.fatal("{}:Ошибка при выполнения запроса к таблице Templates.", uuid, e);
                response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при записи в БД. " + e.getLocalizedMessage());
            } catch (TemplateValidationException ex) {
                logger.fatal("{}:Ошибка при валидации шаблона.", uuid, ex);
                response = ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, ex.getLocalizedMessage());
            }
        } else {
            logger.error("{}:Шаблон с id={} не найден.", uuid, templateId);
            response = ResponseHelper.jsonObjectError(TStub.OBJECT_NOT_FOUND, uuid, "template with id=" + templateId + " not found.");
        }
        return response;
    }

    private JsonObject removeTemplate(String uuid, int templateId) {
        JsonObject response;
        try {
            templateService.remove(templateId);
            response = ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
        } catch (SQLException e) {
            logger.fatal("{}:Ошибка при выполнении запроса к таблице Templates.", uuid, e);
            response = ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка удаления из БД. Шаблон ещё используется.");
        }
        return response;
    }
}
