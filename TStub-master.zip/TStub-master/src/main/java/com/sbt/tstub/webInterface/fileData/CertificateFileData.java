package com.sbt.tstub.webInterface.fileData;

public class CertificateFileData extends FileData {
    
    private String comment;
    private String key;
    private String JavaChiperSuite;
    private String SSLType;
    private boolean FIPSRequired;

    public CertificateFileData(int id, String fileName, String comment, String key, String JavaChiperSuite, String SSLType, boolean FIPSRequired, boolean update, int type) {
        super(id, fileName, update, type);
        this.comment = comment;
        this.key = key;
        this.JavaChiperSuite = JavaChiperSuite;
        this.SSLType = SSLType;
        this.FIPSRequired = FIPSRequired;
    }
    
    public String getComment(){
        return this.comment;
    }
    
    public String getKey(){
        return this.key;
    }
    
    public String getJavaChiperSuite(){
        return this.JavaChiperSuite;
    }
    
    public String getSSLType(){
        return this.SSLType;
    }
    
    public boolean getFIPSRequired(){
        return this.FIPSRequired;
    }
}
