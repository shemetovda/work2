package com.sbt.tstub.webInterface.converter;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.mq.MQWriter;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

public class WriterConverter {

    private static int NOT_DEFINE = -1;

    private final PropertyService propertyService;
    private final InfluxDBService influxDBService;

    public WriterConverter(PropertyService propertyService, InfluxDBService influxDBService) {
        this.propertyService = propertyService;
        this.influxDBService = influxDBService;
    }

    public JsonObjectBuilder convertToMinJson(final MQWriter writer) {
        JsonObjectBuilder obj = Json.createObjectBuilder();
        obj.add("id", writer.sq.getId());
        obj.add("host", writer.sq.getHost());
        obj.add("port", writer.sq.getPort());
        obj.add("manager", writer.sq.getManager());
        obj.add("channel", writer.sq.getChannel());
        obj.add("queue", writer.sq.getQueueName());
        obj.add("state", writer.state);
        obj.add("currentState", writer.currentState);
        return obj;
    }

    public JsonObjectBuilder convertToJson(final MQWriter writer) {
        JsonObjectBuilder obj = Json.createObjectBuilder();
        obj.add("id", writer.getSq().getId());
        obj.add("host", writer.getSq().getHost());
        obj.add("port", writer.getSq().getPort());
        obj.add("manager", writer.getSq().getManager());
        obj.add("channel", writer.getSq().getChannel());
        obj.add("queue", writer.getSq().getQueueName());
        if (writer.getSq().getLogin() == null) {
            obj.addNull("login");
        } else {
            obj.add("login", writer.getSq().getLogin());
        }
        if (writer.getSq().getPassword() == null) {
            obj.addNull("password");
        } else {
            obj.add("password", writer.getSq().getPassword());
        }
        obj.add("active", writer.getSq().isActive());
        obj.add("isDefault", writer.isDefaultQueue());
        obj.add("certID", writer.getSq().getCertID());
        return obj;
    }

    public MQWriter toObject(final JsonObject json) {
        int writerId = json.getInt("id", NOT_DEFINE);
        return new MQWriter(
                propertyService, influxDBService,
                writerId,
                json.getString("host", null),
                json.getInt("port", 0),
                json.getString("manager", null),
                json.getString("channel", null),
                json.getString("queue", null),
                json.getString("login", null),
                json.getString("password", null),
                json.getBoolean("active", false),
                json.getInt("certId", 0),
                json.getBoolean("defaultWriter", false)
        );
    }

}
