package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import org.w3c.dom.Element;

public class Substring extends TemplateNode {

    private final int from;
    private final int to;

    public Substring(Element elem) throws IllegalArgumentException, NumberFormatException {
        this.value = elem.getTextContent();

        if (elem.getAttribute("from").length() == 0) {
            this.from = 0;
        } else {
            this.from = Integer.parseInt(elem.getAttribute("from"));
        }

        if (elem.getAttribute("to").length() == 0) {
            this.to = -1;
        } else {
            this.to = Integer.parseInt(elem.getAttribute("to"));
        }

    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        int length = value.length();
        if (length > 0) {
            if (length >= this.from) {
                if (this.to != -1 && length >= this.to) {
                    return value.substring(this.from, this.to);
                } else {
                    return value.substring(this.from);
                }
            }
        }
        throw new IllegalArgumentException("Нельзя передавать пустое значение.");
    }

    @Override
    public String toString() {
        return "{value=" + this.value + "; from=" + this.from + "; to=" + this.to + "}";
    }
}
