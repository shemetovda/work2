package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStub;
import com.sbt.tstub.webInterface.fileData.FileData;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ClassesHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(ClassesHandler.class);

    private static String path;

    public ClassesHandler(String path) {
        this.path = path;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        int responseCode = 200;
        JsonObject response;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            jsonReader.close();

            switch (requestURI) {
                case "get":
                    response = getClassesList(uuid);
                    break;
                case "add":
                    response = addClass(uuid, json.getString("fileName", null));
                    break;
                case "remove":
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.\n", uuid);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (Exception ex) {
            logger.error("{}:Неизвестная ошибка.", uuid, ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        String data = strWriter.getBuffer().toString();
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject getClassesList(String uuid) {
        String classPath = "classes";
        File file = new File(classPath);
        file.mkdir();
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        JsonArrayBuilder classes = Json.createArrayBuilder();
        ArrayList<Object> list;
        try {
            list = (ArrayList) Files.walk(Paths.get(classPath)).filter(p -> p.toString().endsWith(".class")).filter(Files::isRegularFile).collect(Collectors.toList());
        } catch (Exception e) {
            logger.fatal("{}:Ошибка при поиске файлов с классами.", uuid, e);
            return ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "Error with findind class files. " + e.getLocalizedMessage());
        }

        for (Object item : list) {
            String name = item.toString();
            name = name.substring(8, name.length() - 6).replace("\\", ".");
            JsonObjectBuilder obj = Json.createObjectBuilder();
            obj.add("className", name);
            classes.add(obj);
        }
        jsonBuilder.add("classes", classes);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }

    private JsonObject addClass(String uuid, String fileName) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        if (fileName == null) {
            logger.error(uuid + ":Имя файла не задано.");
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "FileName not found.");
        }
        if (!fileName.toLowerCase().endsWith("zip") && !fileName.toLowerCase().endsWith("jar")) {
            logger.error(uuid + ":Неверный формат файла.");
            return ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, "Wrong type of file. (zip or jar)");
        }
        FileData data = new FileData(0, fileName, false, FileData.CLASS);
        String fileUUID = UUID.randomUUID().toString();
        UploadEnvironment.getEnvironments().putFile(fileUUID, data);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        jsonBuilder.add("fileUUID", fileUUID);
        return jsonBuilder.build();
    }
}
