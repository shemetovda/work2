package com.sbt.tstub.webInterface.converter;

import com.sbt.tstub.environment.scenario.Step;
import com.sbt.tstub.environment.scenario.StepType;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

public class StepConverter {

    private static int NOT_DEFINE = -1;

    public JsonObjectBuilder convertToJson(final Step step) {
        JsonObjectBuilder obj = Json.createObjectBuilder();
        obj.add("triggerID", step.getTriggerId());
        obj.add("stepNum", step.getStepNum());
        obj.add("stepType", step.getStepType().getTypeId());
        obj.add("srcStepMessage", step.getSrcStepMessage());
        obj.add("stepTemplateid", step.getStepTemplateId());
        obj.add("delay", step.getDelay());
        obj.add("MQWriterid", step.getMqWriterId());
        obj.add("chance", step.getChance());
        return obj;
    }

    public Step stepToObject(final int triggerId, final JsonObject obj) {
        return new Step(
                triggerId,
                obj.getInt("stepNum"),
                StepType.getStepTypeById(obj.getInt("stepType")),
                obj.getInt("stepTemplateid", NOT_DEFINE),
                obj.getInt("srcStepMessage", NOT_DEFINE),
                obj.getInt("MQWriterid", NOT_DEFINE),
                obj.getInt("delay", NOT_DEFINE),
                obj.getInt("chance", NOT_DEFINE)
        );
    }

}
