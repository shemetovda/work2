package com.sbt.tstub;

import lombok.Getter;

import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

@Getter
public enum DataBaseType {
    LOCAL("local"),
    MYSQL("mysql"),
    ORACLE("oracle"),
    MSSQL("mssql");

    private String name;
    private static final Map<String, DataBaseType> dataBaseTypeMap;

    static {
        dataBaseTypeMap = Arrays.stream(DataBaseType.values())
                .collect(Collectors.toMap(DataBaseType::getName, name -> name));
    }

    DataBaseType(final String name) {
        this.name = name;
    }

    /**
     * Поиск по названию типа
     *
     * @param name название типа БД
     * @return тип БД
     * @throws IllegalArgumentException если тип базы данных не поддерживается
     */
    public static DataBaseType getDateBaseTypeByName(final String name) {
        DataBaseType dataBaseType = dataBaseTypeMap.get(name.toLowerCase(Locale.ENGLISH));
        if (dataBaseType == null) {
            throw new IllegalArgumentException("DataBaseType c name = " + name + " не существует");
        }
        return dataBaseType;
    }
}
