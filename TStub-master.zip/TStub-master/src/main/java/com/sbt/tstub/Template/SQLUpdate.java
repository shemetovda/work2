package com.sbt.tstub.template;

import com.sbt.tstub.DataBase;
import com.sbt.tstub.mq.TStubMessage;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import org.w3c.dom.Element;

public class SQLUpdate extends TemplateNode {

    private final String id;
    private final DataBase db;

    public SQLUpdate(Element elem, DataBase db) throws IllegalArgumentException, NumberFormatException {
        this.id = elem.getAttribute("id");
        this.value = elem.getTextContent();
        this.db = db;
        if (this.db == null) {
            throw new IllegalArgumentException("DataBase not defined.");
        }
    }

    public SQLUpdate(String id, DataBase db, String value) throws IllegalArgumentException, NumberFormatException {
        this.id = id;
        this.value = value;
        this.db = db;
        if (this.db == null) {
            throw new IllegalArgumentException("DataBase not defined.");
        }
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        String error = "";
        if (value.length() > 0) {
            try (Connection c = db.getConnection()) {
                try (Statement stmt = c.createStatement()) {
                    try {
                        int res = stmt.executeUpdate(value);
                        return value;
                    } catch (Exception ex) {
                        error += " " + ex.getLocalizedMessage();
                    }
                } catch (SQLException ex) {
                    error += " " + ex.getLocalizedMessage();
                }
            } catch (SQLException ex) {
                error += " " + ex.getLocalizedMessage();
            }
        }
        throw new IllegalArgumentException("Ошибка при выполнении запроса \"" + value + "\"." + error);
    }

    public String getId() {
        return this.id;
    }

    @Override
    public String toString() {
        return "{value=" + this.value + "; id=" + this.id + "; DataBase=" + this.db + "}";
    }
}
