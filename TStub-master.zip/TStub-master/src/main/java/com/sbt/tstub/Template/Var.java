package com.sbt.tstub.template;

import com.sbt.tstub.mq.TStubMessage;
import org.w3c.dom.Element;

public class Var extends TemplateNode {

    private Template template;
    private final String SQLSelectId;
    private final String inputValue;
    private final String defaultValue;

    public Var(Element elem, Template template) throws IllegalArgumentException, NumberFormatException {
        value = elem.getTextContent();
        inputValue = value;
        this.template = template;
        SQLSelectId = elem.getAttribute("SQLId");
        TemplateNode temp = template.getVar(SQLSelectId);
        if (temp != null) {
            if (!temp.getClass().isAssignableFrom(SQLSelect.class)) {
                throw new IllegalArgumentException("SQLSelect c id=" + SQLSelectId + " не найден");
            }
        }
        if (elem.hasAttribute("defaultValue")) {
            defaultValue = elem.getAttribute("defaultValue");
        } else {
            defaultValue = null;
        }
    }

    public Var(Var var) throws IllegalArgumentException {
        value = var.value;
        inputValue = var.value;
        template = var.template;
        SQLSelectId = var.SQLSelectId;
        defaultValue = var.defaultValue;
    }

    @Override
    public String process(String value, TStubMessage sourse) throws Exception {
        String selectorId = ReplaceHelper.getReplacedString(SQLSelectId, sourse, template);
        SQLSelect selector = (SQLSelect) template.getVar(selectorId);
        if (selector != null) {
            //вызываем чтобы данные заселектились из БД
            ReplaceHelper.getReplacedId(SQLSelectId, sourse, template);
            value = selector.getResult(value);
        }
        if (value.equals(inputValue) && defaultValue != null) {
            return ReplaceHelper.getReplacedString(defaultValue, sourse, template);
        }
        return value;
    }

    @Override
    public String toString() {
        return "{"
                + "value=" + value
                + ", SQLSelectId=" + SQLSelectId
                + ", defaultValue=" + defaultValue
                + "}";
    }

    @Override
    public void setTemplate(Template template) {
        this.template = template;
    }
}
