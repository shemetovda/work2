package com.sbt.tstub.environment.scenario;

import lombok.AllArgsConstructor;
import lombok.Getter;

import javax.validation.Validation;
import javax.validation.ValidationException;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.LinkedList;
import java.util.List;

@Getter
@AllArgsConstructor
public class Step {
    private static int NOT_DEFINE = -1;

    @NotNull(message = "Идентификатор триггера должен быть задан")
    @Min(value = 1, message = "Идентификатор триггера не может быть меньше 1")
    private final int triggerId;
    @NotNull(message = "Номер шага должен быть задан")
    @Min(value = 1, message = "Номер шага не может быть меньше 1")
    private final int stepNum;
    @NotNull(message = "Тип шага обязательно должен быть указан")
    private final StepType stepType;
    private final int stepTemplateId;
    private final int srcStepMessage;
    private final int mqWriterId;
    private final int delay;
    private final int chance;

    public static Step StepDrop(final int triggerId, final int stepNum) {
        return new Step(triggerId, stepNum, StepType.STEP_DROP,
                NOT_DEFINE, NOT_DEFINE, NOT_DEFINE, NOT_DEFINE, NOT_DEFINE);
    }

    public static Step StepWait(final int triggerId, final int stepNum, final int delay) {
        return new Step(triggerId, stepNum, StepType.STEP_WAIT,
                NOT_DEFINE, NOT_DEFINE, NOT_DEFINE, delay, NOT_DEFINE);
    }

    public static Step StepWrite(final int triggerId, final int stepNum, final int srcStepMessage, final int mqWriterId, final int chance) {
        return new Step(triggerId, stepNum, StepType.STEP_WRITE,
                NOT_DEFINE, srcStepMessage, mqWriterId, NOT_DEFINE, chance);
    }

    public static Step StepWork(final int triggerId, final int stepNum, final int stepTemplateId, final int srcStepMessage) {
        return new Step(triggerId, stepNum, StepType.STEP_WORK,
                stepTemplateId, srcStepMessage, NOT_DEFINE, NOT_DEFINE, NOT_DEFINE);
    }

    public static Step StepHttp(final int triggerId, final int stepNum, final int srcStepMessage) {
        return new Step(triggerId, stepNum, StepType.STEP_HTTP,
                NOT_DEFINE, srcStepMessage, NOT_DEFINE, NOT_DEFINE, NOT_DEFINE);
    }

    /**
     * Метод для валидации объекта
     *
     * @param step валидируемый объект
     * @throws ValidationException исключение в случае ошибок валидации
     */
    public static void validate(final Step step) throws ValidationException {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        List<String> errors = new LinkedList<>();
        validator.validate(step).forEach(error -> errors.add(error.getMessage()));
        switch (step.getStepType()) {
            case STEP_NOT_DEFINE:
            case STEP_DROP:
                break;
            case STEP_WAIT:
                validateDelay(step, errors);
                break;
            case STEP_WRITE:
                validateSrcStepMessage(step, errors);
                validateMqWriterId(step, errors);
                validateChance(step, errors);
                break;
            case STEP_WORK:
                validateSrcStepMessage(step, errors);
                validateStepTemplateId(step, errors);
                break;
            case STEP_HTTP:
                validateSrcStepMessage(step, errors);
                break;
        }
        if (!errors.isEmpty()) {
            StringBuilder errorMessage = new StringBuilder();
            for (String error : errors) {
                errorMessage.append(" - ").append(error).append("\n");
            }
            errorMessage.append("Содержимое объекта: ").append(step);
            throw new ValidationException(errorMessage.toString());
        }
    }

    private static void validateSrcStepMessage(final Step step, final List<String> errors) {
        if (step.getSrcStepMessage() < 0) {
            errors.add("Номер сообщения-источника не может быть меньше 0");
        }
    }

    private static void validateStepTemplateId(final Step step, final List<String> errors) {
        if (step.getStepTemplateId() < 1) {
            errors.add("id шаблона не может быть меньше 1");
        }
    }

    private static void validateDelay(final Step step, final List<String> errors) {
        if (step.getDelay() < 1) {
            errors.add("Время ожидания не может быть меньше 1");
        }
    }

    private static void validateMqWriterId(final Step step, final List<String> errors) {
        if (step.getMqWriterId() < 1) {
            errors.add("id подключения на запись не может быть меньше 1");
        }
    }

    private static void validateChance(final Step step, final List<String> errors) {
        if (step.getChance() < 1) {
            errors.add("Вероятность не может быть меньше 1");
        }
        if (step.getChance() > 10000) {
            errors.add("Вероятность не может быть больше 10000");
        }
    }

    @Override
    public String toString() {
        return "{"
                + "stepNum = " + stepNum
                + ", stepType = " + stepType
                + ", stepTemplateId = " + stepTemplateId
                + ", srcStepMessage = " + srcStepMessage
                + ", mqWriterId = " + mqWriterId
                + ", delay = " + delay
                + ", chance = " + chance
                + "}";
    }
}
