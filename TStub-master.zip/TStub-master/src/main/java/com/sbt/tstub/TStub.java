package com.sbt.tstub;

import com.sbt.InfluxDB.InfluxDBHandler;
import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.WebProvider.HTTPHandler;
import com.sbt.tstub.WebProvider.MQHandler;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.exception.*;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.template.TemplateService;
import com.sbt.tstub.environment.trigger.TriggerService;
import com.sbt.tstub.environment.writer.WriterService;
import com.sbt.tstub.webInterface.*;
import com.sbt.tstub.webInterface.converter.*;
import com.sun.net.httpserver.HttpServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.sql.SQLException;

/**
 * Класс, который является входной точкой проекта. В нём определяются адреса, на
 * которые перенаправляются хендлеры, а также типы ошибок, которые могут
 * возникнуть в процессе работы программы
 *
 * @author Жуйко Алексей Вячеславович <SBT-Zhuyko-AV@mail.ca.sbrf.ru>
 */
public class TStub {

    private static final Logger LOGGER = LogManager.getLogger(TStub.class);

    public static final int METHOD_OK = 0;
    public static final int METHOD_NOT_ALLOWED = 1;
    public static final int PARSING_ERROR = 10;
    public static final int ARGUMENT_NOT_FOUND_ERROR = 20;
    public static final int BAD_ARGUMENT_ERROR = 30;
    public static final int METHOD_NOT_IMPLEMENTED = 40;
    public static final int OBJECT_NOT_FOUND = 50;
    public static final int DB_FAIL = 60;
    public static final int UNKNOWN_ERROR = 999;

    private static final String MAIN_PATH = "/TStub";
    private static final String CONTROL_PATH = MAIN_PATH + "/control";
    private static final String WRITERS = CONTROL_PATH + "/writers";
    private static final String READERS = CONTROL_PATH + "/readers";
    private static final String TRIGGERS = CONTROL_PATH + "/triggers";
    private static final String STEPS = CONTROL_PATH + "/steps";
    private static final String PARAMS = CONTROL_PATH + "/params";
    private static final String TEMPLATES = CONTROL_PATH + "/templates";
    private static final String CERTIFICATES = CONTROL_PATH + "/certificates";
    private static final String LOGS = CONTROL_PATH + "/logs";
    private static final String CLASSES = CONTROL_PATH + "/classes";
    private static final String UPLOAD = MAIN_PATH + "/upload";
    private static final String DOWNLOAD = MAIN_PATH + "/download";
    private static final String MESSAGE_TO_IBMMQ = MAIN_PATH + "/message";
    private static final String INFLUXDB_AGREGATOR = MAIN_PATH + "/influxdb";
    private static final String HTTP = MAIN_PATH + "/http";

    private static TriggerService triggerService;
    private static ScenarioService scenarioService;
    private static BaseService baseService;
    private static InfluxDBService influxDBService;
    private static PropertyService propertyService;
    private static TemplateService templateService;
    private static StepConverter stepConverter;
    private static TriggerConverter triggerConverter;
    private static PropertyConverter propertyConverter;
    private static TemplateConverter templateConverter;
    private static WriterConverter writerConverter;
    private static WriterService writerService;

    private static void init() throws SQLException, PropertyValidationException, ScenarioValidationException, TriggerValidationException, TemplateValidationException, StubQueueValidationException {
        try {
            triggerService = new TriggerService();
            propertyService = new PropertyService();
            scenarioService = new ScenarioService(triggerService);
            baseService = new BaseService(propertyService);
            influxDBService = new InfluxDBService(propertyService);
            templateService = new TemplateService(baseService, influxDBService, propertyService);
            writerService = new WriterService(propertyService, influxDBService);
        } catch (TriggerValidationException | PropertyValidationException | ScenarioValidationException | TemplateValidationException e) {
            LOGGER.fatal("Ошибка при загрузке данных из БД. Проверьте консистентность данных.", e);
            throw e;
        } catch (SQLException e) {
            LOGGER.fatal("Ошибка при обращении к БД.", e);
            throw e;
        }
        writerConverter = new WriterConverter(propertyService, influxDBService);
        triggerConverter = new TriggerConverter(triggerService);
        stepConverter = new StepConverter();
        propertyConverter = new PropertyConverter();
        templateConverter = new TemplateConverter();
    }

    /**
     * Главный поток, в котором создаётся сервер и некоторые его параметры
     */
    public static void main(String[] args) throws SQLException, ScenarioValidationException, TriggerValidationException, PropertyValidationException, TemplateValidationException, StubQueueValidationException {
        int port = 0;
        int portSHTTP = 0;
        int portMQ = 0;
        int portInfluxDB = 0;
        if (args.length < 1) {
            LOGGER.fatal("Не заданы параметры запуска приложения.");
            return;
        }
        for (int i = 0; i < args.length; i++) {
            String[] param = args[i].split("=", 2);
            if (param.length < 2) {
                LOGGER.fatal("Проверьте правильность задания параметров");
                return;
            }
            switch (param[0]) {
                case "-port":
                    try {
                        port = Integer.parseInt(param[1]);
                    } catch (NumberFormatException ex) {
                        LOGGER.fatal("Неправильно задан параметр -port.");
                        return;
                    }
                    break;
                case "-portMQ":
                    try {
                        portMQ = Integer.parseInt(param[1]);
                    } catch (NumberFormatException ex) {
                        LOGGER.error("Неправильно задан параметр -portMQ.");
                    }
                    break;
                case "-portSHTTP":
                    try {
                        portSHTTP = Integer.parseInt(param[1]);
                    } catch (NumberFormatException ex) {
                        LOGGER.error("Неправильно задан параметр -portSHTTP.");
                    }
                    break;
                case "-portInfluxDB":
                    try {
                        portInfluxDB = Integer.parseInt(param[1]);
                    } catch (NumberFormatException ex) {
                        LOGGER.error("Неправильно задан параметр -portInfluxDB.");
                    }
                    break;
                default:
                    LOGGER.error("Проверьте правильность задания параметра {}", param[0]);
                    break;
            }
        }

        init();

        try {
            if (port != 0) {
                HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
                server.createContext(MAIN_PATH, new StaticHandler(MAIN_PATH));
                server.createContext(CONTROL_PATH, new MainHandler(CONTROL_PATH, triggerService, scenarioService, propertyService, baseService, influxDBService, templateService, writerService));
                server.createContext(WRITERS, new WritersHandler(WRITERS, scenarioService, writerService, writerConverter));
                server.createContext(READERS, new ReadersHandler(READERS, baseService));
                server.createContext(TRIGGERS, new TriggersHandler(TRIGGERS, triggerService, triggerConverter));
                server.createContext(PARAMS, new ParamsHandler(PARAMS, propertyService, propertyConverter));
                server.createContext(TEMPLATES, new TemplateHandler(TEMPLATES, templateService, templateConverter, baseService, influxDBService, propertyService));
                server.createContext(UPLOAD, new UploadHandler(UPLOAD));
                server.createContext(CLASSES, new ClassesHandler(CLASSES));
                server.createContext(DOWNLOAD, new DownloadHandler(DOWNLOAD));
                server.createContext(STEPS, new StepsHandler(STEPS, scenarioService, stepConverter));
                server.createContext(LOGS, new LogsHandler(LOGS));
                server.createContext(CERTIFICATES, new CertificatesHandler(CERTIFICATES));
                server.createContext(HTTP, new HTTPHandler(HTTP, propertyService, baseService, influxDBService, triggerService, scenarioService, templateService, writerService));
                server.setExecutor(null);
                server.start();
                LOGGER.debug("HTTP Server started at port {}", port);
                if (portSHTTP != 0) {
                    HttpServer serverToMQ = HttpServer.create(new InetSocketAddress(portSHTTP), 0);
                    serverToMQ.createContext("/", new HTTPHandler("/", propertyService, baseService, influxDBService, triggerService, scenarioService, templateService, writerService));
                    serverToMQ.setExecutor(null);
                    serverToMQ.start();
                    LOGGER.debug("Super HTTP started at port {}", portSHTTP);
                }
                if (portMQ != 0) {
                    HttpServer serverToMQ = HttpServer.create(new InetSocketAddress(portMQ), 0);
                    serverToMQ.createContext(MESSAGE_TO_IBMMQ, new MQHandler(MESSAGE_TO_IBMMQ, writerService));
                    serverToMQ.setExecutor(null);
                    serverToMQ.start();
                    LOGGER.debug("HTTP ServerToMQ started at port {}", portMQ);
                }
                if (portInfluxDB != 0) {
                    HttpServer ServerInfluxDBAggregator = HttpServer.create(new InetSocketAddress(portInfluxDB), 0);
                    ServerInfluxDBAggregator.createContext(INFLUXDB_AGREGATOR, new InfluxDBHandler(INFLUXDB_AGREGATOR, influxDBService));
                    ServerInfluxDBAggregator.setExecutor(null);
                    ServerInfluxDBAggregator.start();
                    LOGGER.debug("HTTP ServerInfluxDBAggregator started at port {}", portInfluxDB);
                }
            }
        } catch (IOException ex) {
            LOGGER.fatal("Не могу запустить сервер. Проверьте свободен ли порт {}", port, ex);
        }
    }
}
