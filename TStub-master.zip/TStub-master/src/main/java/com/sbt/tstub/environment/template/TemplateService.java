package com.sbt.tstub.environment.template;

import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.exception.TemplateValidationException;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.template.Template;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TemplateService {

    private static final Logger LOGGER = LogManager.getLogger(TemplateService.class);

    private static final String SELECT_INIT_QUERY = "SELECT * FROM Templates";
    private static final String SELECT_BY_UNIQUE_QUERY = "SELECT * FROM Templates WHERE comment=?";
    private static final String INSERT_QUERY = "INSERT INTO Templates (template, comment) VALUES(?,?)";
    private static final String UPDATE_QUERY = "UPDATE Templates SET template=?, comment=? WHERE id=?";
    private static final String DELETE_QUERY = "DELETE FROM Templates WHERE id=?";

    private final BaseService baseService;
    private final InfluxDBService influxDBService;
    private final PropertyService propertyService;

    @Getter
    private Map<Integer, Template> templates;

    public TemplateService(BaseService baseService,
                           InfluxDBService influxDBService,
                           PropertyService propertyService) throws SQLException, TemplateValidationException {
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.propertyService = propertyService;
        try {
            templates = readFromDB();
        } catch (SQLException | TemplateValidationException ex) {
            templates = new ConcurrentHashMap<>();
            throw ex;
        }
    }

    private Map<Integer, Template> readFromDB() throws SQLException, TemplateValidationException {
        Map<Integer, Template> templateMap = new ConcurrentHashMap<>();
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection(); Statement stmt = c.createStatement()) {
            ResultSet rs = stmt.executeQuery(SELECT_INIT_QUERY);
            while (rs.next()) {
                try {
                    Template template = new Template(
                            rs.getInt("id"),
                            rs.getString("template"),
                            rs.getString("comment"),
                            baseService, influxDBService, propertyService);
                    Template.validate(template);
                    templateMap.put(template.getId(), template);
                } catch (IllegalArgumentException ex) { //Проблема с самим шаблоном
                    LOGGER.error("template comment={}.", rs.getString("comment"), ex);
                }
            }
            rs.close();
        }
        return templateMap;
    }

    public void refresh() throws SQLException, TemplateValidationException {
        templates = readFromDB();
    }

    public Template getTemplateById(final int templateId) {
        Template template = templates.get(templateId);
        if (template != null) {
            try {
                template = new Template(template, baseService, influxDBService, propertyService);
            } catch (CloneNotSupportedException ex) {
            }
            template.setTemplateForVars(template);
        }
        return template;
    }

    public boolean add(final Template template) throws TemplateValidationException, SQLException {
        Template.validate(template);
        if (addToDB(template)) {
            return templates.putIfAbsent(template.getId(), template) == null;
        }
        return false;
    }

    private boolean addToDB(final Template template) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            c.setAutoCommit(false);
            PreparedStatement prs = c.prepareStatement(INSERT_QUERY);
            prs.setString(1, template.getTemplate());
            prs.setString(2, template.getComment());
            prs.executeUpdate();
            prs.close();
            c.commit();

            prs = c.prepareStatement(SELECT_BY_UNIQUE_QUERY);
            prs.setString(1, template.getComment());
            ResultSet rs = prs.executeQuery();
            if (rs.next()) {
                template.setId(rs.getInt("id"));
                result = true;
            } else {
                result = false;
            }
            rs.close();
            prs.close();
        }
        return result;
    }

    public boolean update(final Template template) throws TemplateValidationException, SQLException {
        Template.validate(template);
        if (updateIntoDB(template)) {
            templates.put(template.getId(), template);
            return true;
        }
        return false;
    }

    private boolean updateIntoDB(final Template template) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             PreparedStatement prs = c.prepareStatement(UPDATE_QUERY)) {
            c.setAutoCommit(false);
            prs.setString(1, template.getTemplate());
            prs.setString(2, template.getComment());
            prs.setInt(3, template.getId());
            int res = prs.executeUpdate();
            result = res > 0;
            c.commit();
        }
        return result;
    }

    public boolean remove(final int templateId) throws SQLException {
        if (removeFromDB(templateId)) {
            return templates.remove(templateId) != null;
        }
        return false;
    }

    private boolean removeFromDB(final int templateId) throws SQLException {
        boolean result;
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection();
             PreparedStatement prs = c.prepareStatement(DELETE_QUERY)) {
            c.setAutoCommit(false);
            prs.setInt(1, templateId);
            int res = prs.executeUpdate();
            result = res > 0;
            c.commit();
        }
        return result;
    }
}
