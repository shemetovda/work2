package com.sbt.tstub.worker;

import com.sun.net.httpserver.HttpExchange;
import lombok.Getter;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.pool2.ObjectPool;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.TStub;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.scenario.Step;
import com.sbt.tstub.environment.scenario.StepType;
import com.sbt.tstub.environment.template.TemplateService;
import com.sbt.tstub.environment.writer.WriterService;
import com.sbt.tstub.mq.MQReader;
import com.sbt.tstub.mq.MQWriter;
import com.sbt.tstub.mq.TStubMessage;
import com.sbt.tstub.template.MQHeader;
import com.sbt.tstub.template.ReplaceHelper;
import com.sbt.tstub.template.SQLUpdate;
import com.sbt.tstub.template.Template;
import com.sbt.tstub.template.ToInfluxDB;
import com.sbt.tstub.utils.StringUtils;

import javax.jms.Destination;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;

/**
 * @author Алексей
 */
public class WorkerTask implements Callable {

    private static final Logger LOGGER = LogManager.getLogger(ReplaceHelper.class);

    private final ScenarioService scenarioService;
    private final PropertyService propertyService;
    private final BaseService baseService;
    private final InfluxDBService influxDBService;
    private final TemplateService templateService;
    private final WriterService writerService;

    private Map<Integer, TStubMessage> stepMessages;
    private int step;
    @Getter
    private StepType stepType;
    @Getter
    private long delay;
    private int stepMessage;
    @Getter
    private String queueID;
    private int triggerID;
    @Getter
    private final String workerID;
    private Template template;
    private HttpExchange httpExchange;
    private boolean httpSended = false;


    public WorkerTask(ScenarioService scenarioService,
                      PropertyService propertyService,
                      BaseService baseService,
                      InfluxDBService influxDBService,
                      TemplateService templateService,
                      WriterService writerService,
                      TStubMessage initMessage,
                      int triggerID) {
        this.scenarioService = scenarioService;
        this.propertyService = propertyService;
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.templateService = templateService;
        this.writerService = writerService;
        httpExchange = null;
        stepMessages = new HashMap();
        stepMessages.put(0, initMessage);
        this.triggerID = triggerID;
        stepType = StepType.STEP_NOT_DEFINE;
        step = 0;
        delay = 0;
        stepMessage = 0;
        queueID = null;
        template = null;
        workerID = initMessage.getMessageID();
    }

    public WorkerTask(ScenarioService scenarioService,
                      BaseService baseService,
                      PropertyService propertyService,
                      InfluxDBService influxDBService,
                      TemplateService templateService,
                      TStubMessage initMessage,
                      WriterService writerService,
                      int triggerID,
                      HttpExchange httpExchange) {
        this(scenarioService, propertyService, baseService, influxDBService, templateService, writerService,
             initMessage, triggerID);
        this.httpExchange = httpExchange;
    }

    public WorkerTask(ScenarioService scenarioService,
                      BaseService baseService,
                      PropertyService propertyService,
                      InfluxDBService influxDBService,
                      TemplateService templateService,
                      TStubMessage initMessage,
                      WriterService writerService,
                      Template template,
                      int triggerID) {
        this(scenarioService, propertyService, baseService, influxDBService, templateService, writerService,
             initMessage, triggerID);
        this.triggerID = 0;
        stepType = StepType.STEP_WORK;
        step = 1;
        this.template = template;
    }

    //В этом методе будет обрабатываться сообщение по шаблону
    @Override
    public Object call() {
        Thread.currentThread().setName("WorkerPool - " + workerID);
        //берём исходное сообщение
        switch (stepType) {
            case STEP_WORK:
                process();
                break;
            case STEP_WRITE:
                sendToMQ();
                break;
            case STEP_HTTP:
                responseHTTP(false);
                break;
        }
        Thread.currentThread().setName("WorkerPool - wait");
        return this;
    }

    private void process() {
        long startTime = System.currentTimeMillis();
        final TStubMessage srcXML = stepMessages.get(stepMessage);
        if (srcXML == null) {
            LOGGER.error("TriggerID={} StepNum={}: Не найден исходный документ от шага. {}", triggerID, step,
                         stepMessage);
            return;
        }
        StringBuilder result = new StringBuilder();
        result.append("<?xml version=\"").append(srcXML.getBody().getXmlVersion()).append("\"").append(
                srcXML.getBody().getXmlEncoding() != null ? (" encoding=\"" + srcXML.getBody().getXmlEncoding()) + "\"" : "").append(
                "?>\n");

        result.append(processBody(template.getBody().getChildNodes(), srcXML));

        try {
            //Заголовки, если есть
            HashMap<String, Object> prop = new HashMap();
            for (MQHeader entry : template.getMqHeaders().values()) {
                String value = getReplaced(entry.getValue(), srcXML);
                Object obj = entry.getObject(value);
                BaseService.putNotNull(prop, entry.getName(), obj);
            }
            BaseService.putNotNull(prop, "TStub_JMSReplyTo", srcXML.getHeaders().get("JMSReplyTo"));
            TStubMessage tMessage = new TStubMessage(result.toString(), prop, srcXML.getReader(), template.getComment(),
                                                     template.isBase64Encode(), template.isByteMessage());
            if (template.isSaveMessCorrID()) {
                tMessage.setInJMSMessageID((String) srcXML.getHeaders().get("JMSMessageID"));
            }
            stepMessages.put(step, tMessage);
        } catch (ParserConfigurationException | SAXException | IOException ex) {
            LOGGER.fatal("Ошибка при обработке сообщения, пожалуйста, обратитесь к разработчику! ", ex);
        }
        for (SQLUpdate upd : template.getSqlUpdate()) {
            String value = getReplaced(upd.getValue(), srcXML);
            try {
                upd.process(value, srcXML);
            } catch (Exception ex) {
                LOGGER.warn("Ошибка при обработке SQLUpdate с id={} ", upd.getId(), ex, "\n" + value);
            }
        }
        for (ToInfluxDB influx : template.getInfluxDBVars()) {
            influx.process(srcXML);
        }
        long duration = System.currentTimeMillis() - startTime;
        influxDBService.getInfluxDB().addMeasurementStats("times", "type=processing,template=" + StringUtils.normalize(
                template.getComment()), "duration=" + duration);
    }

    private String processBody(NodeList templateNodes, TStubMessage sourse) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < templateNodes.getLength(); i++) {
            if (templateNodes.item(i).getNodeType() > 1) {
                result.append(
                        getReplaced(StringEscapeUtils.escapeXml10(templateNodes.item(i).getTextContent()), sourse));
            } else {
                result.append("<").append(templateNodes.item(i).getNodeName());
                for (int j = 0; j < templateNodes.item(i).getAttributes().getLength(); j++) {
                    result.append(" ").append(templateNodes.item(i).getAttributes().item(j).getNodeName()).append(
                            "=\"").append(
                            getReplaced(templateNodes.item(i).getAttributes().item(j).getNodeValue(), sourse).replace(
                                    "<", "%lt;").replace(">", "%gt;")).append("\"");
                }
                result.append(">");
                result.append(processBody(templateNodes.item(i).getChildNodes(), sourse));
                result.append("</").append(templateNodes.item(i).getNodeName()).append(">");
            }
        }
        return result.toString();
    }

    private String getReplaced(String param, TStubMessage sourse) {
        return ReplaceHelper.getReplacedString(param, sourse, template);
    }

    /**
     * При вызове данного метода определяется тип операции, которая будет
     * выполняться в данном шаге
     */
    public void nextStep() {
        step++;
        List<Step> stepList = scenarioService.getStepsByStepNumber(triggerID, step);
        Iterator<Step> stepIterator = stepList.iterator();
        if (stepIterator.hasNext()) {
            Step step = stepIterator.next();
            stepType = step.getStepType();
            switch (stepType) {
                case STEP_DROP:
                    break;
                case STEP_WAIT:
                    delay = step.getDelay();
                    break;
                case STEP_WORK:
                    Integer templateID = step.getStepTemplateId();
                    template = templateService.getTemplateById(templateID);
                    if (template != null) {
                        stepMessage = step.getSrcStepMessage();
                    } else {
                        LOGGER.error("Шаблон с id={} не найден.", templateID);
                        stepType = StepType.STEP_DROP;
                    }
                    break;
                case STEP_WRITE:
                    int mqWriterID = step.getMqWriterId();
                    stepMessage = step.getSrcStepMessage();
                    int cum = step.getChance();
                    int random = ThreadLocalRandom.current().nextInt(10000);
                    while (stepIterator.hasNext()) {
                        step = stepIterator.next();
                        if (cum >= random) {
                            break;
                        } else {
                            cum += step.getChance();
                            mqWriterID = step.getMqWriterId();
                            stepMessage = step.getSrcStepMessage();
                        }
                    }
                    queueID = writerService.getWriterKeyByWriterId(mqWriterID);
                    if (queueID == null) {
                        LOGGER.error("Не обнаружен отправитель сообщений с id={}", mqWriterID);
                        stepType = StepType.STEP_DROP;
                    }
                    break;
                case STEP_HTTP:
                    //Здесь, если запрос был получен по HTTP вызывается отправка обратно на того, кто вызвал
                    //Если был обычный mq, то пропустить шаг
                    stepMessage = step.getSrcStepMessage();
                    if (httpExchange == null) {
                        nextStep();
                    }
                    break;
                default:
                    stepType = StepType.STEP_DROP;
                    break;
            }
        } else {
            stepType = StepType.STEP_DROP;
        }
    }

    /**
     * Этот метод возвращает сообщение, которое было сформировано на
     * определённом шаге
     *
     * @return String message сообщение, которое необходимо для отправки в
     * текущем шаге
     */
    public TStubMessage getMessage() {
        return stepMessages.get(stepMessage);
    }

    public TStubMessage getMessage(int num) {
        return stepMessages.get(num);
    }

    public void dispose() {
        stepMessages.clear();
        stepMessages = null;
    }

    public void responseHTTP(boolean last) {
        if (httpExchange != null) {
            if (!httpSended) {
                String textMessage;
                if (last) {
                    textMessage = "<?xml version=\"1.0\" encoding=\"UTF8\" standalone=\"yes\"?>\n"
                            + "<Response>\n    <code>" + TStub.METHOD_OK + "</code>\n    <message>Processing has been complete.</message>\n</Response>";
                } else {
                    textMessage = getMessage().getBodyString();
                }
                try (OutputStream os = httpExchange.getResponseBody()) {
                    httpSended = true;
                    httpExchange.sendResponseHeaders(200, textMessage.getBytes().length);
                    os.write(textMessage.getBytes());
                    os.close();
                    influxDBService.getInfluxDB().addMeasurementStats("length", "type=HTTP_output",
                                                                      "length=" + textMessage.length());
                    LOGGER.debug("Отправлено ответное сообщение\n" + textMessage);
                } catch (IOException ex) {
                    LOGGER.error("Не могу ответить на HTTP запрос.\n", ex);
                }
            }
        }
    }

    public void sendToMQ() {
        TStubMessage message = getMessage();
        Destination destination = (Destination) message.getHeaders().remove("TStub_JMSReplyTo");
        if ((Boolean.parseBoolean(propertyService.getPropertyValueByName("ReplyTo_enabled"))) && destination != null) {
            LOGGER.debug("Найден параметр ReplyTo=" + destination.toString());
            String strDest = destination.toString();
            //queue://M99.PS.PMIL.CLS9/PS.CARDTOCARD.V004.WAY4.RESPONSE?targetClient=1
            String[] arr = strDest.split("/", 4);
            arr[3] = arr[3].split("\\?")[0];
            //arr[0], arr[1] - не нужны
            //arr[2] - менеджер, может быть нулевой длины
            //arr[3] - очередь, всегда есть, если есть ReplyTo
            //DONE: сформировать ключ
            String newQueue;
            if (arr[2].length() > 0 && Boolean.parseBoolean(
                    propertyService.getPropertyValueByName("ReplyToMgr_enabled"))) {
                newQueue = arr[2] + "/" + arr[3];
            } else {
                newQueue = arr[3];
            }
            MQReader reader = message.getReader();
            String key = reader.getHost() + ":" + reader.getPort() + ":";
            key += reader.getManager() + ":" + reader.getChannel() + ":" + newQueue;

            ObjectPool<MQWriter> pool = writerService.getPoolByKey(key);
            MQWriter writer;
            if (pool != null) {
                try {
                    writer = pool.borrowObject();
                    try {
                        writer.put(message);
                    } catch (Exception ex) {
                        LOGGER.error("Не могу поместить сообщение в queue=" + key + ".\n", ex);
                    }
                    try {
                        pool.returnObject(writer);
                    } catch (Exception ex) {
                        LOGGER.error("Не могу вернуть очередь для записи queue=" + key + ".\n", ex);
                    }
                } catch (Exception ex) {
                    LOGGER.error("Не могу получить очередь для записи queue=" + key + ".\n", ex);
                }
            } else {
                //DONE: Нет подключения, делаем новое
                MQWriter newMQWriter = new MQWriter(propertyService, influxDBService, 0, reader.getHost(),
                                                    reader.getPort(), reader.getManager(), reader.getChannel(),
                                                    newQueue, reader.getLogin(), reader.getPassword(), true,
                                                    reader.getCertID(), false);
                //DONE: Переслать сообщение в новую очередь
                try {
                    writerService.addToWriters(newMQWriter);
                    pool = writerService.getPoolByKey(key);
                    writer = pool.borrowObject();
                    try {
                        writer.put(message);
                    } catch (Exception ex) {
                        LOGGER.error("Не могу поместить сообщение в queue=" + key + ".\n", ex);
                    }
                    try {
                        pool.returnObject(writer);
                    } catch (Exception ex) {
                        LOGGER.error("Не могу вернуть очередь для записи queue=" + key + ".\n", ex);
                    }
                } catch (Exception ex) {
                    LOGGER.error("Не могу получить очередь для записи queue=" + key + ".\n", ex);
                }
            }
        } else { //Если нет replyTo
            ObjectPool<MQWriter> pool = writerService.getPoolByKey(getQueueID());
            if (pool == null) {
                LOGGER.error("Отправитель сообщений с ID=" + getQueueID() + " не определён.");
            } else {
                try {
                    MQWriter writer = pool.borrowObject();
                    try {
                        writer.put(getMessage());
                    } catch (Exception ex) {
                        LOGGER.error("Не могу поместить сообщение в queue=" + getQueueID() + ".\n", ex);
                    }
                    try {
                        pool.returnObject(writer);
                    } catch (Exception ex) {
                        LOGGER.error("Не могу вернуть очередь для записи queue=" + getQueueID() + ".\n", ex);
                    }
                } catch (Exception ex) {
                    LOGGER.error("Не могу получить очередь для записи queue=" + getQueueID() + ".\n", ex);
                }
            }
        }
    }
}
