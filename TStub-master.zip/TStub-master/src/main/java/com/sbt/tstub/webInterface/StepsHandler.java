package com.sbt.tstub.webInterface;

import com.sbt.tstub.TStub;
import com.sbt.tstub.environment.exception.ScenarioValidationException;
import com.sbt.tstub.environment.scenario.Scenario;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.scenario.Step;
import com.sbt.tstub.webInterface.converter.StepConverter;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.json.*;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StepsHandler implements HttpHandler {

    private static final Logger logger = LogManager.getLogger(StepsHandler.class);

    private final String path;
    private final ScenarioService scenarioService;
    private final StepConverter stepConverter;

    public StepsHandler(final String path, ScenarioService scenarioService, StepConverter stepConverter) {
        this.path = path;
        this.scenarioService = scenarioService;
        this.stepConverter = stepConverter;
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("content-type", "application/json; charset=utf-8");
        int responseCode = 200;
        JsonObject response;

        String uuid = UUID.randomUUID().toString();
        try (JsonReader jsonReader = Json.createReader(t.getRequestBody())) {
            JsonObject json = jsonReader.readObject();
            switch (requestURI) {
                case "get":
                    response = getScenarioByTriggerId(uuid, json.getInt("triggerID", 0));
                    break;
                case "save":
                    response = updateScenario(uuid, json);
                    break;
                default:
                    responseCode = 501;
                    response = ResponseHelper.jsonObjectError(TStub.METHOD_NOT_IMPLEMENTED, uuid, "Method \"" + path + "\\" + requestURI + "\" not found.");
                    break;
            }
        } catch (JsonException ex) {
            logger.error("{}:Неправильный формат запроса.", uuid, ex);
            responseCode = 400;
            response = ResponseHelper.jsonObjectError(TStub.PARSING_ERROR, uuid, "Wrong format of request Body.");
        } catch (RuntimeException ex) {
            logger.error("{}:Неизвестная ошибка. ", ex);
            responseCode = 500;
            response = ResponseHelper.jsonObjectError(TStub.UNKNOWN_ERROR, uuid, "UNKNOWN_ERROR:" + ex.getLocalizedMessage());
        }

        String data = ResponseHelper.buildResponseData(response);
        t.sendResponseHeaders(responseCode, data.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(data.getBytes());
        os.close();
    }

    private JsonObject getScenarioByTriggerId(String uuid, int triggerID) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        Scenario scenario = scenarioService.getScenarioByTriggerId(triggerID);
        JsonArrayBuilder steps = Json.createArrayBuilder();
        if (scenario != null) {
            scenario.getSteps().forEach(step -> steps.add(stepConverter.convertToJson(step)));
        }
        jsonBuilder.add("steps", steps);
        jsonBuilder.add("code", TStub.METHOD_OK);
        jsonBuilder.add("uuid", uuid);
        return jsonBuilder.build();
    }

    private JsonObject updateScenario(final String uuid, final JsonObject request) {
        int triggerId = request.getInt("triggerID", -1);
        if (request.getJsonArray("steps") == null) {
            logger.error("{}:Не заданы шаги", uuid);
            return ResponseHelper.jsonObjectError(TStub.ARGUMENT_NOT_FOUND_ERROR, uuid, "Steps not found.");
        }

        JsonArray jsonSteps = request.getJsonArray("steps");
        List<Step> steps = new ArrayList<>();
        jsonSteps.forEach(step -> steps.add(stepConverter.stepToObject(triggerId, step.asJsonObject())));

        Scenario scenario = new Scenario(triggerId, steps);
        try {
            scenarioService.update(scenario);
        } catch (SQLException ex) {
            logger.fatal("{}:Ошибка при обновлении сценария.", uuid, ex);
            return ResponseHelper.jsonObjectError(TStub.DB_FAIL, uuid, "Ошибка при записи в БД. " + ex.getLocalizedMessage());
        } catch (ScenarioValidationException ex) {
            logger.fatal("{}:Ошибка при валидации сценария.", uuid, ex);
            return ResponseHelper.jsonObjectError(TStub.BAD_ARGUMENT_ERROR, uuid, ex.getLocalizedMessage());
        }
        return ResponseHelper.jsonObjectOK(TStub.METHOD_OK, uuid);
    }
}
