package com.sbt.tstub.webInterface;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;
import java.io.StringWriter;

public class ResponseHelper {

    /**
     * Функция для формирования ответного сообщения
     *
     * @param code - код сообщения
     * @param uuid - uuid сообщения
     * @return JsonObject в котором содержатся поля code и uuid
     */
    public static JsonObject jsonObjectOK(int code, String uuid) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        jsonBuilder.add("code", code);
        addStringOrNull(jsonBuilder, "uuid", uuid);
        return jsonBuilder.build();
    }

    /**
     * Функция для формирования ответного сообщения
     *
     * @param code - код сообщения
     * @param uuid - uuid сообщения
     * @param message - дополнительное сообщение
     * @return JsonObject в котором содержатся поля code, uuid и message
     */
    public static JsonObject jsonObjectError(int code, String uuid, String message) {
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        jsonBuilder.add("code", code);
        addStringOrNull(jsonBuilder, "uuid", uuid);
        jsonBuilder.add("message", message);
        return jsonBuilder.build();
    }

    public static String buildResponseData(final JsonObject response){
        StringWriter strWriter = new StringWriter();
        JsonWriter writer = Json.createWriter(strWriter);
        writer.writeObject(response);
        writer.close();
        return strWriter.getBuffer().toString();
    }

    public static void addStringOrNull(JsonObjectBuilder obj, String name, String value) {
        if (value == null) {
            obj.addNull(name);
        } else {
            obj.add(name, value);
        }
    }
}
