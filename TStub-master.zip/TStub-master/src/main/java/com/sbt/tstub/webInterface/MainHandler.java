package com.sbt.tstub.webInterface;

import com.sbt.InfluxDB.InfluxDBService;
import com.sbt.tstub.TStub;
import com.sbt.tstub.TStubDatabaseHelper;
import com.sbt.tstub.TStubThread;
import com.sbt.tstub.environment.BaseService;
import com.sbt.tstub.environment.property.PropertyService;
import com.sbt.tstub.environment.scenario.ScenarioService;
import com.sbt.tstub.environment.template.TemplateService;
import com.sbt.tstub.environment.trigger.TriggerService;
import com.sbt.tstub.environment.writer.WriterService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

/**
 * Класс, который обрабатывает разные запросы, которые лень было писать в отдельный хендлер
 *
 * @author Жуйко Алексей Вячеславович <SBT-Zhuyko-AV@mail.ca.sbrf.ru>
 */
public class MainHandler implements HttpHandler {

    private static final Logger LOGGER = LogManager.getLogger(MainHandler.class);

    private static Boolean work = false;

    //Переменная, содержащая поток заглушки
    private static TStubThread MQThread;
    private final String path;
    private final TriggerService triggerService;
    private final ScenarioService scenarioService;
    private final PropertyService propertyService;
    private final BaseService baseService;
    private final InfluxDBService influxDBService;
    private final TemplateService templateService;
    private final WriterService writerService;

    public MainHandler(final String path,
                       final TriggerService triggerService,
                       final ScenarioService scenarioService,
                       PropertyService propertyService, final BaseService baseService,
                       final InfluxDBService influxDBService, TemplateService templateService, WriterService writerService) {
        this.path = path;
        this.triggerService = triggerService;
        this.scenarioService = scenarioService;
        this.propertyService = propertyService;
        this.baseService = baseService;
        this.influxDBService = influxDBService;
        this.templateService = templateService;
        this.writerService = writerService;
        boolean autoStart = Boolean.parseBoolean(propertyService.getPropertyValueByName("AutoStart"));
        if (autoStart) {
            startMQTStub(UUID.randomUUID().toString());
        }
    }

    @Override
    public void handle(HttpExchange t) throws IOException {
        String requestURI = t.getRequestURI().getPath().substring(path.length() + 1).toLowerCase();
        t.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        String response;
        int responseCode = 200;

        try {
            String uuid = UUID.randomUUID().toString();
            switch (requestURI) {
                case "startmqtstub":
                    response = startMQTStub(uuid);
                    break;
                case "stopmqtstub":
                    response = stopMQTStub(uuid);
                    break;
                case "getstate":
                    response = getState(uuid);
                    break;
                case "getsteptypes":
                    response = getStepTypes(uuid);
                    break;
                default:
                    responseCode = 501;
                    response = "{\"code\":" + TStub.METHOD_NOT_IMPLEMENTED + ",\"uuid\":\"" + uuid + "\",\"message\":\"Method \\\"" + this.path + "/" + requestURI + "\\\" not found.\"}";
                    break;
            }
        } catch (RuntimeException ex) {
            LOGGER.error("Неизвестная ошибка.", ex);
            responseCode = 500;
            response = "{\"code\":" + TStub.UNKNOWN_ERROR + ",\"message\":\"UNKNOWN_ERROR: " + ex.getLocalizedMessage().replace("\"", "\\\"") + "\"}";
        }

        t.sendResponseHeaders(responseCode, response.getBytes().length);
        OutputStream os = t.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }

    private String getState(final String uuid) {
        String response = "{\"code\":" + TStub.METHOD_OK + ",\"uuid\":\"" + uuid + "\", \"workMQ\":" + work + "";
        response += "}";
        return response;
    }

    private String getStepTypes(final String uuid) {
        String response = "{\"code\":" + TStub.METHOD_OK + ",\"uuid\":\"" + uuid + "\",\"stepTypes\":[";
        try (Connection c = TStubDatabaseHelper.getHelper().getConnection()) {
            Statement stmt = c.createStatement();
            boolean check = false;
            ResultSet rs = stmt.executeQuery("SELECT * FROM StepType;");
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String comment = rs.getString("comment");
                if (comment == null) {
                    comment = null;
                } else {
                    comment = "\"" + comment.replace("\"", "\\\"") + "\"";
                }

                response += "{\"id\":" + id + ",";
                response += "\"name\":\"" + name + "\",";
                response += "\"comment\":" + comment;
                response += "},";
                check = true;
            }

            rs.close();
            stmt.close();
            if (check) {
                response = response.substring(0, response.length() - 1);
            }
            response += "]}";
        } catch (SQLException e) {
            LOGGER.fatal("{}:Ошибка при выполнения запроса к таблице StepType.", uuid, e);
            response = "{\"code\":" + TStub.DB_FAIL + ",\"uuid\":\"" + uuid + "\",\"message\":\"Error with SELECT from StepType." + e.getLocalizedMessage().replace("\"", "\\\"") + "\"}";
        }
        return response;
    }

    private String startMQTStub(final String uuid) {
        synchronized (work) {
            if (!work) {
                int res;
                try {
                    MQThread = new TStubThread(triggerService, scenarioService, propertyService, baseService, influxDBService, templateService, writerService);
                    MQThread.setName("MQTStub");
                    MQThread.start();
                    res = MQThread.getConnectionState();
                } catch (RuntimeException ex) {
                    res = -1;
                    LOGGER.error("Ошибка при запуске заглушки", ex);
                }
                if (res != 0) {
                    return "{\"code\":" + TStub.UNKNOWN_ERROR + ",\"message\":\"UNKNOWN_ERROR\"}";
                } else {
                    work = true;
                }
            } else {
                return "{\"code\":" + TStub.METHOD_NOT_ALLOWED + ",\"uuid\":\"" + uuid + "\",\"message\":\"TStub already started.\"}";
            }
        }
        return "{\"code\":" + TStub.METHOD_OK + ",\"uuid\":\"" + uuid + "\",\"message\":\"TStub started.\"}";
    }

    private String stopMQTStub(final String uuid) {
        synchronized (work) {
            if (work) {
                influxDBService.shutdown();
                MQThread.shutdown();
                int res = MQThread.getConnectionState();
                if (res != 1) {
                    return "{\"code\":" + TStub.UNKNOWN_ERROR + ",\"message\":\"UNKNOWN_ERROR\"}";
                } else {
                    MQThread = null;
                    work = false;
                }
            } else {
                return "{\"code\":" + TStub.METHOD_NOT_ALLOWED + ",\"uuid\":\"" + uuid + "\",\"message\":\"TStub already stopped.\"}";
            }
        }
        return "{\"code\":" + TStub.METHOD_OK + ",\"uuid\":\"" + uuid + "\",\"message\":\"TStub stopped.\"}";
    }
}