package com.sbt.tstub.webInterface.converter;

import com.sbt.tstub.environment.property.Property;
import com.sbt.tstub.environment.trigger.Trigger;
import com.sbt.tstub.template.Template;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

public class TemplateConverter {

    public JsonObjectBuilder convertToJson(final Template template) {
        JsonObjectBuilder obj = Json.createObjectBuilder();
        obj.add("id", template.getId());
        obj.add("template", template.getTemplate());
        obj.add("comment", template.getComment());
        return obj;
    }
}
