package com.sbt.tstub.worker;

import java.util.concurrent.CompletionService;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import com.sbt.tstub.DelayedTask;
import com.sbt.tstub.environment.BaseService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Алексей
 */
public class WorkerTaskCompletionService<T> extends Thread {
    private static final Logger logger = LogManager.getLogger(WorkerTaskCompletionService.class);

    private final CompletionService<T> completionService;
    private final DelayQueue<DelayedTask> workerTasks;

    private boolean work = true;

    public WorkerTaskCompletionService(CompletionService<T> completionService, DelayQueue<DelayedTask> workerTasks) {
        this.completionService = completionService;
        this.workerTasks = workerTasks;
    }

    @Override
    public void run() {
        logger.debug("Поток запущен.");
        while (work || !workerTasks.isEmpty()) {
            try {
                Future<T> future = completionService.poll(10000, TimeUnit.MILLISECONDS);
                if(future != null) {
                    workerTasks.add(new DelayedTask(future.get(), 5));
                }
            } catch (InterruptedException ex) {
                logger.debug(BaseService.THREAD_WILL_STOP);
            } catch (ExecutionException ex) {
                logger.error("Не могу получить WorkerTask",ex);
            }
        }
        logger.debug(BaseService.THREAD_IS_STOPPED);
    }

    //Метод для безопасной остановки потока и остановки потока без потерь данных
    public void shutdown() {
        work = false;
    }
}
