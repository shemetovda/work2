package com.sbt.tstub.environment.trigger;

import com.sbt.tstub.environment.exception.TriggerValidationException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Data
@AllArgsConstructor
public class Trigger {
    @NotNull(message = "id должен быть задан")
    private int id;
    @NotNull(message = "xPath выражение не может быть пустым")
    @Size(min = 1, message = "xPath выражение не может быть пустым")
    private final String xPathExpression;
    @NotNull(message = "Описание не может пустым")
    @Size(min = 1, message = "Описание не может пустым")
    private final String comment;
    @NotNull
    private final Map<String, String> headers;
    private final boolean active;

    public Trigger(final int id, final String xPathExpression, final String comment, final boolean active) {
        this(id, xPathExpression, comment, new HashMap<>(), active);
    }

    /**
     * Метод для валидации объекта
     *
     * @param trigger валидируемый объект
     * @throws TriggerValidationException исключение в случае ошибок валидации
     */
    public static void validate(final Trigger trigger) throws TriggerValidationException {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> errors = validator.validate(trigger);
        if (!errors.isEmpty()) {
            StringBuilder errorMessage = new StringBuilder();
            for (ConstraintViolation<Object> error : errors) {
                errorMessage.append(" - ").append(error.getMessage()).append("\n");
            }
            errorMessage.append("Содержимое объекта: ").append(trigger);
            throw new TriggerValidationException(errorMessage.toString());
        }
    }

    @Override
    public String toString() {
        return "{"
                + "id = " + id
                + ", xPathExpression = " + xPathExpression
                + ", comment = " + comment
                + ", headers = " + headers
                + ", active = " + active
                + "}";
    }
}
