$(document).ready(function() {
	getVersion();
});

function serviceFail(data){
	$('#modalLoader').modal('hide');
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function getVersion(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/params/version',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getVersionSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getVersionSuccess(json){
	if(json.code == 0){
		var content = $('#content')[0];
		content.innerHTML = content.innerHTML + "\n <H4>Версия приложения: " + json.params[0].value + "</H4>";
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};