$(document).ready(function() {
	getParams();
});

function serviceFail(data){
	$('#modalLoader').modal('hide');
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function serviceSuccess(json){
	if(json.code == 0){
		getParams();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. <br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
}

function getParams(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/params/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getParamsSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getParamsSuccess(json){
	if(json.code == 0){
		var table = $('#tableParams')[0];
		var tbody = $('#tableParamsBody')[0];
		tbody.innerHTML = "";
		
		for(var k in json.params) {
			var row = document.createElement("tr");
			var cellName = document.createElement("td");
			var cellValue = document.createElement("td");
			var cellDescription = document.createElement("td");
			var cellUpdate = document.createElement("td");

			row.id = 'param_' + k;
			cellName.innerHTML = json.params[k].name;
			if(json.params[k].value == 'null')
				cellValue.innerHTML = '';
			else
				cellValue.innerHTML = json.params[k].value;

			if(json.params[k].description == 'null')
				cellDescription.innerHTML = '';
			else
				cellDescription.innerHTML = json.params[k].description;
			
			cellUpdate.innerHTML = '<button onclick="setParam('+ k +');" class="btn btn-default btn-warning">Редактировать</button>';

			row.appendChild(cellName);
			row.appendChild(cellValue);
			row.appendChild(cellDescription);
			row.appendChild(cellUpdate);
			tbody.appendChild(row);
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function setParam(number){
	var cells = $('#param_'+number)[0].cells;
	$('#updParamName')[0].innerHTML = cells[0].innerHTML;
	$('#updParamValue')[0].value = cells[1].innerHTML;
	$('#updParamDescription')[0].innerHTML = cells[2].innerHTML;

	$("#btnModalUpdParamConfirm").click(function(){
		updateParam();
		$('#btnModalUpdParamConfirm').off('click');
	});
	$('#modalUpdParam').modal('show');
};

function updateParam(){
	var name = $('#updParamName')[0].innerHTML;
	var value = $('#updParamValue')[0].value;

	var request = '{\"uuid\":\"' + generateUUID() + '\",';
	request += '\"name\":\"' + name + '\",\"value\":\"' + value + '\"}';

	$('#modalUpdParam').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/params/set',
		dataType: "json",
		contentType: "application/json",
		data: request,
		success: function(data) {serviceSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};