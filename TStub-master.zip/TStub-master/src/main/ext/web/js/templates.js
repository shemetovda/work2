$(document).ready(function () {
	getTemplates();

	$("#btnAddTemplate").click(function () {
		$('#modalAddTemplate').modal('show');
	});
	$("#btnModalAddTemplateConfirm").click(function () {
		preAddTemplate();
	});
});

function serviceFail(data) {
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function serviceSuccess(json, type) {
	if (json.code == 0) {
		getTemplates();
	} else {
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. <br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message + '</p>';
		$('#modalDanger').modal('show');
		if (type == "update") {
			$('#btnDangerOk').off('click');
			$("#btnDangerOk").click(function () {
				$('#modalEditTemplate').modal('show');
			});
		}
		if (type == "add") {
			$('#btnDangerOk').off('click');
			$("#btnDangerOk").click(function () {
				$('#modalAddTemplate').modal('show');
			});
		}
	}
}

function getTemplates() {
	jQuery.ajax({
		type: "POST",
		async: true,
		url: 'control/templates/get',
		dataType: "json",
		contentType: "application/json",
		data: '{}',
		success: function (data) { getTemplatesSuccess(data) },
		error: function (data) { serviceFail(data) }
	});
};

function getTemplatesSuccess(json) {
	if (json.code == 0) {
		templates = [];
		json.templates.forEach(element => {
			templates[element.id] = element;
		});
		drawTemplates();
	} else {
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message + '</p>';
		$('#modalDanger').modal('show');
	}
};

function drawTemplates() {
	var tbody = $('#tableTemplatesBody')[0];
	tbody.innerHTML = "";
	for (var k in templates) {
		var row = document.createElement("tr");
		var cellComment = document.createElement("td");

		row.id = 'template_' + templates[k].id;

		cellComment.innerHTML = templates[k].comment;

		var btnEdit = document.createElement("td");
		var btnRemove = document.createElement("td");

		btnEdit.innerHTML = '<button type="button" onclick="preEditTemplate(' + templates[k].id + ');" class="btn btn-default btn-warning" title="Редактировать"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>';
		btnRemove.innerHTML = '<button onclick="removeTemplate(' + templates[k].id + ');" class="btn btn-default btn-danger" title="Удалить"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button>';

		row.appendChild(cellComment);
		row.appendChild(btnEdit);
		row.appendChild(btnRemove);
		tbody.appendChild(row);
	}
};

function preAddTemplate() {
	var template = $('#addTemplate')[0].value;
	var comment = $('#addTemplateComment')[0].value;

	var check = true;
	if (template == "" || comment == "") {
		check = false;
	}
	if (check != true) {
		$('#modalAddTemplate').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function () {
			$('#modalAddTemplate').modal('show');
		});
		return;
	}

	var data = {
		'template': template,
		'comment': comment
	};

	$('#modalAddTemplate').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		dataType: "json",
		contentType: "application/json",
		url: 'control/templates/add',
		data: JSON.stringify(data),
		success: function (data) { serviceSuccess(data, "add") },
		error: function (data) { serviceFail(data) }
	});
};

function preEditTemplate(number) {
	$('#editTemplate')[0].value = templates[number].template;
	$('#editTemplateComment')[0].value = templates[number].comment;

	$('#btnModalEditTemplateConfirm').off('click');
	$("#btnModalEditTemplateConfirm").click(function () {
		editTemplate(number);
	});
	$('#modalEditTemplate').modal('show');
};

function editTemplate(number) {
	var template = $('#editTemplate')[0].value;
	var comment = $('#editTemplateComment')[0].value;

	var check = true;
	if (template == "" || comment == "") {
		check = false;
	}
	if (check != true) {
		$('#modalEditTemplate').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function () {
			$('#modalEditTemplate').modal('show');
		});
		return;
	}

	var data = {
		'id': number * 1,
		'template': template,
		'comment': comment
	}

	$('#modalEditTemplate').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		dataType: "json",
		contentType: "application/json",
		url: 'control/templates/update',
		data: JSON.stringify(data),
		success: function (data) { serviceSuccess(data, "update") },
		error: function (data) { serviceFail(data) }
	});
};

function removeTemplate(number) {
	var comment = templates[number].comment;
	$('#modalConfirmRemove .modal-body')[0].innerHTML = '<p>Вы действительно хотите удалить шаблон <strong>' + comment + '</strong>?</p>';
	$('#modalConfirmRemove').modal('show');

	$('#btnModalConfirmRemove').off('click');
	$('#btnModalConfirmRemove').click(function () {
		jQuery.ajax({
			type: "POST",
			async: false,
			dataType: "json",
			contentType: "application/json",
			url: 'control/templates/remove',
			data: '{\"id\":' + number + '}',
			success: function (data) { serviceSuccess(data) },
			error: function (data) { serviceFail(data) }
		});
		$('#modalConfirmRemove').modal('hide');
		$('#btnModalConfirmRemove').off('click');
	});
};
