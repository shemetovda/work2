$(document).ready(function() {
	//Загрузка с учётом того, что в адресной строке
	$("#content").load($("#state").attr("data-url"));
	var hash = window.location.hash;
	var href = $('#nav a').each(function(){
		var href = $(this).attr('href');
		if(hash==href){
			var url = $(this).attr("data-url");
			$("#content").load(url);
			$(".nav").find(".active").removeClass("active");
			$(this).parent().addClass("active");
			return;
		} 
	});

	$('.nav a').click(function (e) {
		var url = $(this).attr("data-url");

		history.replaceState(null, null, $(this).attr('href'));
		$(".nav").find(".active").removeClass("active");
		$(this).parent().addClass("active");
		window.location.search = "";
		
	    $('#content').hide('fast',loadContent);
	    function loadContent() {
	    	$('#content').load(url,'',showNewContent())
	    }
	    function showNewContent() {
	    	$('#content').show('normal');
	    }

	});
});