$(document).ready(function() {
	getTriggers();

	$("#btnAddTrigger").click(function(){
		$('#modalAddTrigger').modal('show');
	});

	$("#btnModalAddTriggerConfirm").click(function(){
		addTrigger();
	});
});

function serviceFail(data){
	$('#modalLoader').modal('hide');
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function serviceSuccess(json){
	if(json.code == 0){
		getTriggers();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. <br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
}

function getTriggers(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/triggers/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getTriggersSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getTriggersSuccess(json){
	if(json.code == 0){
		var table = $('#tableTriggers')[0];
		var tbody = $('#tableTriggersBody')[0];
		tbody.innerHTML = "";
		for(var k in json.triggers) {
			var row = document.createElement("tr");
			var cellId = document.createElement("td");
			var cellExpression = document.createElement("td");
			var cellHeaders = document.createElement("td");
			var cellComment = document.createElement("td");
			var cellActive = document.createElement("td");
			var cellScenario = document.createElement("td");
			var cellChange = document.createElement("td");
			var cellRemove = document.createElement("td");

			$(cellExpression).addClass('text-left');
			$(cellExpression).css("padding-left","20px");
			$(cellHeaders).addClass('text-left');
			$(cellHeaders).css("padding-left","20px");

			row.id = 'trigger_' + json.triggers[k].id;
			cellId.innerHTML = json.triggers[k].id;
			cellExpression.innerHTML = json.triggers[k].expression;
			cellHeaders.innerHTML = json.triggers[k].headers||'-';
			if(json.triggers[k].comment == 'null')
				cellComment.innerHTML = '';
			else
				cellComment.innerHTML = json.triggers[k].comment;

			cellActive.innerHTML = json.triggers[k].active;

			cellScenario.innerHTML = '<button onclick="showScenario('+ json.triggers[k].id +');" class="btn btn-default btn-success" title="Сценарий">Сценарий</button>';
			cellChange.innerHTML = '<button onclick="editTrigger('+ json.triggers[k].id +');" class="btn btn-default btn-warning" title="Редактировать"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>';
			cellRemove.innerHTML = '<button onclick="removeTrigger('+ json.triggers[k].id +');" class="btn btn-default btn-danger" title="Удалить"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button>';

			row.appendChild(cellId);
			row.appendChild(cellExpression);
			row.appendChild(cellHeaders);
			row.appendChild(cellComment);
			row.appendChild(cellActive);
			row.appendChild(cellScenario);
			row.appendChild(cellChange);
			row.appendChild(cellRemove);
			tbody.appendChild(row);
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function editTrigger(number){
	var cells = $('#trigger_'+number)[0].cells;
	$('#updTriggerExpression')[0].value = cells[1].innerText;

    if(cells[2].innerHTML == '-')
        $('#updTriggerHeaders')[0].value = '';
    else
        $('#updTriggerHeaders')[0].value = cells[2].innerHTML;

	$('#updTriggerComment')[0].value = cells[3].innerHTML;
	
	if(cells[4].innerHTML == 'true')
		$('#updTriggerActive')[0].checked = true;
	else
		$('#updTriggerNonActive')[0].checked = true;

	$('#btnModalUpdTriggerConfirm').off('click');
	$("#btnModalUpdTriggerConfirm").click(function(){
		updateTrigger(number);
	});
	$('#modalUpdTrigger').modal('show');
};

function updateTrigger(number){
	var expression = $('#updTriggerExpression')[0].value;
	var headers = $('#updTriggerHeaders')[0].value||null;
	var comment = $('#updTriggerComment')[0].value||null;
	var active;
	if($('#updTriggerActive')[0].checked == true)
		active = true;
	else
		active = false;

	var check = true;
	if(expression == ""){
		check = false;
	}
	if(check != true){
		$('#modalUpdTrigger').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalUpdTrigger').modal('show');
		});
		return;
	}

	var request = {
		'uuid': generateUUID(),
		'id': number,
		'expression': expression,
		'comment': comment,
		'headers': headers,
		'active': active
	}

	$('#modalUpdTrigger').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/triggers/update',
		dataType: "json",
		contentType: "application/json",
		data: JSON.stringify(request),
		success: function(data) {serviceSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function addTrigger(){
	var expression = $('#addTriggerExpression')[0].value;
	var headers = $('#addTriggerHeaders')[0].value||null;
	var comment = $('#addTriggerComment')[0].value||null;
	var active;
	if($('#addTriggerActive')[0].checked == true)
		active = true;
	else
		active = false;

	var check = true;
	if(expression == ""){
		check = false;
	}
	if(check != true){
		$('#modalAddTrigger').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalAddTrigger').modal('show');
		});
		return;
	}

	var request = {
		'uuid': generateUUID(),
		'expression': expression,
		'comment': comment,
		'headers': headers,
		'active': active
	}

	$('#modalAddTrigger').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/triggers/add',
		dataType: "json",
		contentType: "application/json",
		data: JSON.stringify(request),
		success: function(data) {serviceSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function removeTrigger(number){
	var expression = $('#trigger_'+number)[0].cells[0].innerHTML;
	$('#modalConfirmRemove .modal-body')[0].innerHTML = '<p>Вы действительно хотите удалить триггер <strong>'+ expression + '</strong>?</p>';
	$('#modalConfirmRemove').modal('show');
	$('#btnModalConfirmRemove').off('click');
	$('#btnModalConfirmRemove').click(function(){
		jQuery.ajax({
			type: "POST",
			async: false,
			url: 'control/triggers/remove',
			dataType: "json",
			contentType: "application/json",
			data: '{\"uuid\":\"' + generateUUID() + '\", \"id\":' + number + '}',
			success: function(data) {serviceSuccess(data)},
			error: function(data) {serviceFail(data)}
		});
		$('#modalConfirmRemove').modal('hide');
		$('#btnModalConfirmRemove').off('click');
	});
};

function showScenario(number){
	var url = 'scenario.html?id='+ number;
	history.replaceState(null, null, '?id=' + number + '#scenario');
	$('#content').hide('fast',loadContent);
	function loadContent() {
	    $('#content').load(url,'',showNewContent())
	}
	function showNewContent() {
	    $('#content').show('normal');
	}
	$(".nav").find(".active").removeClass("active");
	$('#btnTabScenario').parent().addClass("active");
};

