$(document).ready(function() {
    var classes = {};
	getClasses();

	$("#btnAddClass").click(function(){
		$('#modalAddClass').modal('show');
	});
	$("#btnModalAddClassConfirm").click(function(){
		preAddClass();
	});
});

function serviceFail(data){
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function serviceSuccess(json){
	if(json.code == 0){
		getTemplates();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. <br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
}

function getClasses(){
	jQuery.ajax({
		type: "POST",
		async: true,
		url: 'control/classes/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getClassesSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getClassesSuccess(json){
	if(json.code == 0){	
		classes = json.classes;
		drawClasses();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function drawClasses(){
	var table = $('#tableClasses')[0];
	var tbody = $('#tableClassesBody')[0];
	tbody.innerHTML = "";
	$.each(classes, function(k, v){

		var row = document.createElement("tr");
		var cellClassName = document.createElement("td");
		var btnDownload = document.createElement("td");

		cellClassName.innerHTML = classes[k].className;
		var btn = $('<button type="button" class="btn btn-default btn-success" title="Скачать"><span class="glyphicon glyphicon-save" aria-hidden="true"></span></button>');
		//btn.on("click",function(){return downloadLog(classes[k].fileName);});
		btnDownload.append(btn[0]);

		row.appendChild(cellClassName);
		row.appendChild(btnDownload);
		tbody.appendChild(row);
	})
};

function preAddClass(){
	var file = $("#addFile")[0].files[0]||null;

	var check = true;
	if(file == null){
		check = false;
	}
	if(check != true){
		$('#modalAddClass').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalAddClass').modal('show');
		});
		return;
	}

	$('#modalAddClass').modal('hide');
	var data = JSON.stringify ({
		'uuid': generateUUID(),
		'fileName': file.name
	});

	jQuery.ajax({
		type: "POST",
		async: false,
		dataType: "json",
		contentType: "application/json",
		url: 'control/classes/add',
		data: data,
		success: function(data) {preUploadSuccess(file, data)},
		error: function(data) {serviceFail(data)}
	});
};

function preUploadSuccess(file, json){
	if(json.code == 0){	
		if(file != null){
			uploadClass(file, json.fileUUID);
		}else{
			getClasses();
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function uploadClass(file, id){
	jQuery.ajax({
		type: "POST",
		async: true,
		processData: false,
		url: 'upload/' + id,
		data: file,
		success: function(data) {uploadSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function uploadSuccess(json){
	if(json.code == 0){	
		getClasses();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};