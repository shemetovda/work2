$(document).ready(function() {
	$("#btnTest").click(function(){
		sendForTest();
	});
});

function testSuccess(data){
	$('#resultMessage')[0].value = data.responseText;
}

function sendForTest(){
	var headers = $('#incomingHeaders')[0].value
	if($('#incomingHeaders')[0].value.length*1 > 0){
		headers = "?" + headers.split(",").join("&")
	}

	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'http' + headers,
		dataType: "json",
		contentType: "application/xml",
		data: $('#incomingMessage')[0].value,
		success: function(data) {testSuccess(data)},
		error: function(data) {testSuccess(data)}
	});
};