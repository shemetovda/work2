$(document).ready(function() {
	getState();
	getReadersMin();
	getWritersMin();

	$("#btnStart").click(function(){
		if(!this.classList.contains('disabled')){
			$('#btnStart').addClass('disabled');
			$('#modalLoader').modal('show');
			jQuery.ajax({
				type: "POST",
				async: false,
				url: 'control/startMQTStub',
				dataType: "json",
				contentType: "application/json",
				data: "{\"uuid\":\"" + generateUUID() + "\"}",
				success: function(data) {startSuccess(data)},
				error: function(data) {serviceFail(data)}
			});
		}
	});
	$("#btnStop").click(function(){
		if(!this.classList.contains('disabled')){
			$('#btnStop').addClass('disabled');
			$('#modalLoader').modal('show');
			jQuery.ajax({
				type: "POST",
				async: false,
				url: 'control/stopMQTStub',
				dataType: "json",
				contentType: "application/json",
				data: "{\"uuid\":\"" + generateUUID() + "\"}",
				success: function(data) {stopSuccess(data)},
				error: function(data) {serviceFail(data)}
			});
		}
	});
	$("#btnRefresh").click(function(){
		refresh();
	});
});

function refresh(){
	getState();
	getReadersMin();
	getWritersMin();
}

function startSuccess(json){
	if(json.code == 0){
		$('#statusText').html("Заглушка работает.");
		$('#status').removeClass();
		$('#status').addClass('alert alert-success');
		$('#btnStop').removeClass('disabled');
		$('#btnStart').addClass('disabled');
	}else{
		$('#statusText').html("Заглушка остановлена.");
		$('#status').removeClass();
		$('#status').addClass('alert alert-danger');
		$('#btnStart').removeClass('disabled');
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. Скорее всего какие-то проблемы с подключением к очереди на запись<br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
	$('#modalLoader').modal('hide');
	refresh();
};

function stopSuccess(json){
	if(json.code == 0){
		$('#statusText').html("Заглушка остановлена.");
		$('#status').removeClass();
		$('#status').addClass('alert alert-danger');
		$('#btnStart').removeClass('disabled');
		$('#btnStop').addClass('disabled');
	}
	$('#modalLoader').modal('hide');
	refresh();
};
function serviceFail(data){
	$('#modalLoader').modal('hide');
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. </br>Код ошибки: ' + data.status + '</br>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function getState(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/getstate',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getStateSuccess(data)},
		error: function(data) {getStateFail(data)}
	});
};
function getStateSuccess(json){
	if(json.code == 0){
		if(json.workMQ == true){
			$('#statusText').html("Заглушка функционирует.");
			$('#status').removeClass();
			$('#status').addClass('alert alert-success');
			$('#btnStop').removeClass('disabled');
			$('#btnStart').addClass('disabled');
			return;
		} else{
			$('#statusText').html("Заглушка остановлена.");
			$('#status').removeClass();
			$('#status').addClass('alert alert-danger');
			$('#btnStart').removeClass('disabled');
			$('#btnStop').addClass('disabled');
			return;
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};
function getStateFail(data){
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. </br>Код ошибки: ' + data.status + '</br>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
	$('#statusText').html("Состояние не известно");
	$('#status').removeClass();
	$('#status').addClass('alert alert-info');
	$('#btnStart').addClass('disabled');
	$('#btnStop').addClass('disabled');
}

function getReadersMin(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/readers/getMin',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getReadersMinSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getReadersMinSuccess(json){
	if(json.code == 0){
		var tbody = $("#readersMinTableBody")[0];
		tbody.innerHTML = "";
		
		for(var k in json.readers) {
			var row = document.createElement("tr");
			var cellHost = document.createElement("td");
			var cellPort = document.createElement("td");
			var cellManager = document.createElement("td");
			var cellChannel = document.createElement("td");
			var cellQueue = document.createElement("td");
			var cellQuantity = document.createElement("td");
			var cellState = document.createElement("td");
			var cellAction = document.createElement("td");

			row.id = 'reader_' + k;
			cellHost.innerHTML = json.readers[k].host;
			cellPort.innerHTML = json.readers[k].port;
			cellManager.innerHTML = json.readers[k].manager;
			cellChannel.innerHTML = json.readers[k].channel;
			cellQueue.innerHTML = json.readers[k].queue;
			cellQuantity.innerHTML = json.readers[k].quantity;
			if(json.readers[k].currentState == 1)
				cellState.innerHTML = '<span class="glyphicon glyphicon-ok" style="color:green;" aria-hidden="true"></span>';
			else
				cellState.innerHTML = '<span class="glyphicon glyphicon-remove" style="color:red;" aria-hidden="true"></span>';
			if(json.readers[k].state == 1)
				cellAction.innerHTML = '<button onclick="setPause('+ k +');" class="btn btn-default btn-warning">Приостановить чтение</button>';
			else
				cellAction.innerHTML = '<button onclick="setUnPause('+ k +');" class="btn btn-default btn-success">Возобновить чтение</button>';

			row.appendChild(cellHost);
			row.appendChild(cellPort);
			row.appendChild(cellManager);
			row.appendChild(cellChannel);
			row.appendChild(cellQueue);
			row.appendChild(cellQuantity);
			row.appendChild(cellState);
			row.appendChild(cellAction);
			tbody.appendChild(row);
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function setPause(number){
	$('#modalLoader').modal('show');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/readers/setPause',
		dataType: "json",
		contentType: "application/json",
		data: PauseData(number),
		success: function(data) {PauseSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function setUnPause(number){
	$('#modalLoader').modal('show');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/readers/setUnPause',
		dataType: "json",
		contentType: "application/json",
		data: PauseData(number),
		success: function(data) {PauseSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function PauseData(number){
	var cells = $('#reader_'+number)[0].cells;
	var host = cells[0].innerHTML;
	var port = cells[1].innerHTML;
	var manager = cells[2].innerHTML;
	var channel = cells[3].innerHTML;
	var queue = cells[4].innerHTML;
	var response = '{\"uuid\":\"' + generateUUID() + '\",'
	response += '\"connectionId\":\"' + host + ":" + port + ":" + manager + ":" + channel + ":" + queue + '\"';
	response += '}';
	return response;
};

function PauseSuccess(json){
	if(json.code == 0){
		refresh();
		$('#modalLoader').modal('hide');
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function getWritersMin(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/writers/getMin',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getWritersMinSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getWritersMinSuccess(json){
	if(json.code == 0){
		var tbody = $("#writersMinTableBody")[0];
		tbody.innerHTML = "";
		
		for(var k in json.writers) {
			var row = document.createElement("tr");
			var cellHost = document.createElement("td");
			var cellPort = document.createElement("td");
			var cellManager = document.createElement("td");
			var cellChannel = document.createElement("td");
			var cellQueue = document.createElement("td");
			var cellQuantity = document.createElement("td");
			var cellState = document.createElement("td");
			var cellAction = document.createElement("td");

			row.id = 'writer_' + k;
			cellHost.innerHTML = json.writers[k].host;
			cellPort.innerHTML = json.writers[k].port;
			cellManager.innerHTML = json.writers[k].manager;
			cellChannel.innerHTML = json.writers[k].channel;
			cellQueue.innerHTML = json.writers[k].queue;
			cellQuantity.innerHTML = json.writers[k].quantity;
			if(json.writers[k].currentState == 1)
				cellState.innerHTML = '<span class="glyphicon glyphicon-ok" style="color:green;" aria-hidden="true"></span>';
			else
				cellState.innerHTML = '<span class="glyphicon glyphicon-remove" style="color:red;" aria-hidden="true"></span>';

			row.appendChild(cellHost);
			row.appendChild(cellPort);
			row.appendChild(cellManager);
			row.appendChild(cellChannel);
			row.appendChild(cellQueue);
			row.appendChild(cellQuantity);
			row.appendChild(cellState);
			tbody.appendChild(row);
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};
