var get = {};
var writers = [];
var stepTypes = {};
var steps = {};
var templates = {};
var typesSelector = null;
var nullStep = {
	'stepNum':0
}
$(document).ready(function() {
	if (location.search) {
		var c = location.search.substring(1).split('&');

		for (var i = 0; i < c.length; i++) { 
			var ar = c[i].split('=');
			if (ar[0] != '') {
				get[ar[0]] = unescape(ar[1]);
			}
		}
	}

	typesSelector = document.createElement("select");
	typesSelector.className = "form-control text-center";
	typesSelector.id = 'addStepType';
	typesSelector.addEventListener("change", typeChange);

	var id = get['id'];
	if(id != undefined){
		refresh();
		$("#btnAddStep").click(function(){
			preAddStep();
		});
		$("#btnSaveScenario").click(function(){
			preSaveScenario(id);
		});
	}else{
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Вы перешли на страницу без параметров. Пожалуйста, добавьте их, или перейдите со страницы "Триггеры"</p>';
		$('#modalInfo').modal('show');
	}
});

function refresh(){
	getWriters();
	getStepTypes();
	getTemplates();
	getSteps();
};

function serviceSuccess(json){
	if(json.code == 0){
		refresh();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. <br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
}

function serviceFail(data){
	$('#modalLoader').modal('hide');
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};


function getSteps(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/steps/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\",\"triggerID\":' + get['id'] + '}',
		success: function(data) {getStepsSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getStepsSuccess(json){
	if(json.code == 0){	
		steps = json.steps;
		for(var k in steps){
			steps[k].srcStepMessage = (steps[k].srcStepMessage > -1) ? (steps[steps[k].srcStepMessage-1]||nullStep) : null;
		}
		drawSteps();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function drawSteps(){
	var tbody = $('#tableStepsBody')[0];
	tbody.innerHTML = "";
	for(var k in steps) {
		var row = document.createElement("tr");
		row.id = (steps[k].stepNum);
		var cellNum = document.createElement("td");
		var cellType = document.createElement("td");
		var cellSrc = document.createElement("td");
		var cellTemplate = document.createElement("td");
		var cellDelay = document.createElement("td");
		var cellWriter = document.createElement("td");

		var btnUpd = document.createElement("td");
		var btnRem = document.createElement("td");

		cellNum.innerHTML = steps[k].stepNum;
		//Матчим типы
		for(var j in stepTypes) {
			if(stepTypes[j].id == steps[k].stepType){
				cellType.innerHTML = stepTypes[j].comment;
				break;
			}
		}
		//сообщения источники
		cellSrc.innerHTML = steps[k].srcStepMessage != null ? steps[k].srcStepMessage.stepNum : '-';
		//матчим шаблоны
		for(var j in templates) {
			if(templates[j].id == steps[k].stepTemplateid){
				cellTemplate.innerHTML = templates[j].comment;
				break;
			}else{
				cellTemplate.innerHTML = '-';
			}
		}
		//Задержка
		cellDelay.innerHTML = steps[k].delay > 0 ? steps[k].delay : '-';

        //матчим отправителя v2
        if(steps[k].MQWriterid > 0 && steps[k].lock != true){
            for(var k1 in steps){
                if(steps[k].stepNum == steps[k1].stepNum){
                    for(var j in writers) {
                        if(writers[j].id == steps[k1].MQWriterid){
                            cellWriter.innerHTML = cellWriter.innerHTML + writers[j].queue + '(' + steps[k1].chance + ')' + ' ';
                            steps[k1].lock = true;
                            break;
                        }
                    }
                }
            }
        }else{
            if(steps[k].lock == true){
                continue;
            }
            cellWriter.innerHTML = '-';
        }
        

		btnUpd.innerHTML = '<button onclick="preEditStep('+ steps[k].stepNum +');" class="btn btn-default btn-warning"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>';
		btnRem.innerHTML = '<button onclick="removeStep('+ steps[k].stepNum +');" class="btn btn-default btn-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button>';

		row.appendChild(cellNum);
		row.appendChild(cellType);
		row.appendChild(cellSrc);
		row.appendChild(cellTemplate);
		row.appendChild(cellDelay);
		row.appendChild(cellWriter);
		row.appendChild(btnUpd);
		row.appendChild(btnRem);
		tbody.appendChild(row);

		r = $(tbody);
		r.sortable({
			beforeStop: DnDstep
		});
	}
    for(var k in steps) {
        steps[k].lock = false;
    }
}

function getWriters(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/writers/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getWritersSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getWritersSuccess(json){
	if(json.code == 0){	
        writers = [];
        for(var k in json.writers){
            if(json.writers[k].isDefault == false){
                writers.push(json.writers[k]);
            }
        }
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function getStepTypes(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/getsteptypes',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getStepTypesSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getStepTypesSuccess(json){
	if(json.code == 0){
		for(var j in stepTypes)
			typesSelector.remove(j);
		stepTypes = json.stepTypes;
		i = 0;
		for(var j in stepTypes){
			typesSelector.options[i] = new Option(stepTypes[j].comment);
			i++;
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function getTemplates(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/templates/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getTemplatesSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getTemplatesSuccess(json){
	if(json.code == 0){	
		templates = json.templates;
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function preAddStep(){
	var tbody = $('#modalWindow tbody')[0];
	tbody.innerHTML = '';
	var row = document.createElement("tr");
	var cellName = document.createElement("td");
	var cellValue = document.createElement("td");

	cellName.innerHTML = 'Тип';
	cellValue.appendChild(typesSelector);
	typesSelector.options.selectedIndex = 0;

	row.appendChild(cellName);
	row.appendChild(cellValue);
	tbody.appendChild(row);

	$('#modalWindow .modal-content')[0].className = 'modal-content panel-success';
	$('#modalWindow .modal-title')[0].innerHTML = 'Добавление шага';
	$('#modalWindow .btn-primary')[0].className = 'btn btn-primary btn-success';
	$('#modalWindow .btn-primary')[0].innerHTML = 'Добавить';

	$('#modalWindow .modal-footer .btn-primary').off('click');
	$('#modalWindow .modal-footer .btn-primary').click(function(){
		addStep();
	});

	$('#modalWindow').modal('show');
};

function typeChange(){
	var tbody = $('#modalWindow tbody')[0];
	tbody.innerHTML = '';
	//Строка с типом операции
	var rowType = document.createElement("tr");
	var cellType = document.createElement("td");
	var cellTypeValue = document.createElement("td");
	rowType.appendChild(cellType);
	rowType.appendChild(cellTypeValue);
	cellType.innerHTML = 'Тип';
	cellTypeValue.appendChild(typesSelector);
	tbody.appendChild(rowType);

	//Строка с задержкой
	var rowDelay = document.createElement("tr");
	var cellDelay = document.createElement("td");
	var cellDelayValue = document.createElement("td");
	rowDelay.appendChild(cellDelay);
	rowDelay.appendChild(cellDelayValue);
	cellDelay.innerHTML = 'Задержка, мс*';
	var inputDelay = document.createElement("input");
		inputDelay.id = 'delay';
		inputDelay.className = 'form-control text-center';
		inputDelay.type = 'number';
		inputDelay.placeholder = 'Задержка, мс';
	cellDelayValue.appendChild(inputDelay);

	//Строка с сообщением источником
	var rowSrcMessage = document.createElement("tr");
	var cellSrcMessage = document.createElement("td");
	var cellSrcMessageValue = document.createElement("td");
	rowSrcMessage.appendChild(cellSrcMessage);
	rowSrcMessage.appendChild(cellSrcMessageValue);
	var srcMessageSelector = document.createElement("select");
	cellSrcMessageValue.appendChild(srcMessageSelector);
	cellSrcMessage.innerHTML = 'Источник';
	srcMessageSelector.className = "form-control text-center";
	srcMessageSelector.id = 'srcMessage';
	srcMessageSelector.options[0] = new Option(0);
	var i = 1;
	for(var k in steps){
		if(steps[k].stepType == 3){
			srcMessageSelector.options[i] = new Option(k*1+1);
			i++;
		}
	}

	//Строка с выбором отправителя
	var rowWriter = document.createElement("tr");
	var cellWriter = document.createElement("td");
	var cellWriterValue = document.createElement("td");
	rowWriter.appendChild(cellWriter);
	rowWriter.appendChild(cellWriterValue);
	
	cellWriter.innerHTML = 'Очередь для записи';
	var writerSelector = document.createElement("select");
	cellWriterValue.appendChild(writerSelector);
	writerSelector.className = "form-control text-center";
	writerSelector.id = 'writer';
	var i = 0;
	for(var k in writers){
    	writerSelector.options[i] = new Option(writers[k].host + ':' + writers[k].port + ':' + writers[k].manager + ':' + writers[k].channel + ':' + writers[k].queue);
    	i++;
	}

    //кнопка для добавления отправителя в рандом
    var rowAddWriter = document.createElement("tr");
    var cellAddWriter = document.createElement("td");
    var cellAddWriterButton = document.createElement("td");
    var cellAddWriterDummy = document.createElement("td");
    var cellAddWriterDummy1 = document.createElement("td");
    cellAddWriter.innerHTML = 'Добавление очереди';
    var addWriterButton = document.createElement("button");
        addWriterButton.id = 'addWriterButton';
        addWriterButton.className = 'btn btn-default btn-success';
        addWriterButton.innerHTML = 'Добавить очередь';
    addWriterButton.addEventListener("click",addWriterRow);
    rowAddWriter.appendChild(cellAddWriter);
    cellAddWriterButton.appendChild(addWriterButton);
    rowAddWriter.appendChild(cellAddWriterButton);
    rowAddWriter.appendChild(cellAddWriterDummy);
    rowAddWriter.appendChild(cellAddWriterDummy1);

	//Строка с выбором шаблона
	var rowTemplate = document.createElement("tr");
	var cellTemplate = document.createElement("td");
	var cellTemplateValue = document.createElement("td");
	rowTemplate.appendChild(cellTemplate);
	rowTemplate.appendChild(cellTemplateValue);
	
	cellTemplate.innerHTML = 'Шаблон';
	var templateSelector = document.createElement("select");
	cellTemplateValue.appendChild(templateSelector);
	templateSelector.className = "form-control text-center";
	templateSelector.id = 'template';
	var i = 0;
	for(var k in templates){
		templateSelector.options[i] = new Option(templates[k].comment);
		i++;
	}

	switch(stepTypes[typesSelector.options.selectedIndex].name){
		case 'DROP': 
			//ничего не выводим
			break; 
		case 'WAIT':
			//добавляем поле для ввода задержки 
			tbody.appendChild(rowDelay);
			break; 
		case 'WRITE': 
			//Добавляем поля Сообщение источник и очередь для записи
			tbody.appendChild(rowSrcMessage);
			tbody.appendChild(newWriterRow(1));
            tbody.appendChild(rowAddWriter);
			break; 
        case 'HTTP':
            //Добавляем поля 
            tbody.appendChild(rowSrcMessage);
            break; 
		case 'WORK':
			//Добавляем поля 
			tbody.appendChild(rowSrcMessage);
			tbody.appendChild(rowTemplate);
			break; 
	}
};

function addWriterRow(){
    var tbody = $('#modalWindow tbody')[0];
    //когда одна запись то 4
    var lastAddedRow = tbody.childElementCount-3;
    tbody.insertBefore(newWriterRow(lastAddedRow+1), tbody.childNodes[tbody.childElementCount-1]);
}

function newWriterRow(writerNum){
    //Строка с выбором источника, шаблона и вероятности
    var rowWriter = document.createElement("tr");
    rowWriter.id = 'writerRow_' + writerNum;
    var cellWriter = document.createElement("td");
    var cellWriterSelector = document.createElement("td");
    var cellWriterChance = document.createElement("td");
    var cellWriterDelButton = document.createElement("td");
    rowWriter.appendChild(cellWriter);
    rowWriter.appendChild(cellWriterSelector);
    rowWriter.appendChild(cellWriterChance);
    rowWriter.appendChild(cellWriterDelButton);

    var inputChance = document.createElement("input");
        inputChance.id = 'writerChance_' + writerNum;
        inputChance.className = 'form-control text-center';
        inputChance.type = 'number';
        inputChance.placeholder = 'Вероятность, 1/10000 от 100%';
    cellWriterChance.appendChild(inputChance);

    var delButton = document.createElement("button");
        delButton.id = 'delWriter_' + writerNum;
        delButton.className = 'btn btn-default btn-danger';
        delButton.innerHTML = '<span class="glyphicon glyphicon-trash" aria-hidden="true"></span>';
        delButton.addEventListener("click",function(){delWriterRow(writerNum)});
    cellWriterDelButton.appendChild(delButton);

    if(writerNum == 1){
        $(inputChance).hide();
        inputChance.value = '10000';
        $(delButton).hide();
    }else{
        $('#writerChance_1').show();
        $('#delWriter_1').show();
    }

    cellWriter.innerHTML = 'Очередь';
    var writerSelector = document.createElement("select");
    cellWriterSelector.appendChild(writerSelector);
    writerSelector.className = "form-control text-center";
    writerSelector.id = 'writerSelector_' + writerNum;
    var i = 0;
    for(var k in writers){
        writerSelector.options[i] = new Option(writers[k].host + ':' + writers[k].port + ':' + writers[k].manager + ':' + writers[k].channel + ':' + writers[k].queue);
        i++;
    }
    return rowWriter;
}

function delWriterRow(writerNum){
    var tbody = $('#modalWindow tbody')[0];
    var numOfRows = tbody.childElementCount-3;
    var delWriter = $('#writerRow_' + writerNum)[0];
    tbody.removeChild(delWriter);
    for(var i=writerNum;i<numOfRows;i++){
        var row = tbody.childNodes[i+1];
        row.id = 'writerRow_' + i;
        //вероятность
        row.childNodes[2].childNodes[0].id = 'writerChance_' + i;
        //удаление
        row.childNodes[3].childNodes[0].id = 'delWriter_' + i;
        $(row.childNodes[3].childNodes[0]).off('click');
        row.childNodes[3].childNodes[0].addEventListener("click",function(){delWriterRow(i)});
    }
    if(numOfRows == 2){
        $('#writerChance_1').hide();
        $('#writerChance_1')[0].value = '10000';
        $('#delWriter_1').hide();
    }
}

function editStep(stepNum){
    var index = -1; var indexCol = 0;
    for(var k in steps){
        if(steps[k].stepNum == stepNum){
            indexCol++;
            if(index == -1){
                index = k*1;
            }
        }
    }

    var elem = {
        'stepNum': stepNum,
        'delay': $('#modalWindow tbody #delay')[0] ? $('#modalWindow tbody #delay')[0].value*1 : 0,
        'stepType': stepTypes[typesSelector.options.selectedIndex].id*1,
        'srcStepMessage': $('#modalWindow tbody #srcMessage')[0] ? $('#modalWindow tbody #srcMessage')[0].options[$('#modalWindow tbody #srcMessage')[0].options.selectedIndex].value*1 : null,
        'stepTemplateid': $('#modalWindow tbody #template')[0] ? templates[$('#modalWindow tbody #template')[0].options.selectedIndex].id*1 : null,
        'MQWriterid': null,
        'chance': null
    }
    //Если задержка 0 и тип задержка
    if(elem.stepType == 1 && elem.delay <= 0){
        $('#modalWindow').modal('hide');
        $('#modalInfo .modal-body')[0].innerHTML = '<p>Введите время задержки > 0.</p>';
        $('#modalInfo').modal('show');
        $('#btnInfoOk').off('click');
        $("#btnInfoOk").click(function(){
            $('#modalWindow').modal('show');
        });
        return;
    }
    //Если тип обработка или отправка
    if(elem.stepType >= 2){
        elem.srcStepMessage = (steps[elem.srcStepMessage-1] || nullStep);
    }

    if(elem.stepType == 2){
        var tbody = $('#modalWindow tbody')[0];
        var numOfRows = tbody.childElementCount-3;
        var cumChance = 0; var check = true;
        for(var i=0; i < numOfRows; i++){
            var row = tbody.childNodes[i+2];
            cumChance = cumChance + row.childNodes[2].childNodes[0].value*1;
            if((row.childNodes[2].childNodes[0].value || null) == null || row.childNodes[2].childNodes[0].value*1 <= 0){
                check = false;
            }
        }
        if(cumChance != 10000 || check == false){
            $('#modalWindow').modal('hide');
            $('#modalInfo .modal-body')[0].innerHTML = '<p>Сумма вероятностей не равна 10000 или какая-то вероятность задана неверно.</p>';
            $('#modalInfo').modal('show');
            $('#btnInfoOk').off('click');
            $("#btnInfoOk").click(function(){
                $('#modalWindow').modal('show');
            });
            return;
        }
        steps.splice(index,indexCol);
        for(var i=0; i < numOfRows; i++){
            var obj = Object.assign({},elem);
            var row = tbody.childNodes[i+2];
            var MQWriterid = writers[row.childNodes[1].childNodes[0].options.selectedIndex].id*1;
            obj.MQWriterid = MQWriterid;
            obj.chance = row.childNodes[2].childNodes[0].value*1;
            steps.splice(index+i,0,obj);
        }
    }else{
        steps.splice(index, indexCol);
        steps.splice(index, 0, elem);
    }

    drawSteps();
    $('#modalWindow').modal('hide');
}

function addStep(){
    var lastStepNum = steps.length-1;
    if(lastStepNum<0)
        lastStepNum=0;
    else
        lastStepNum = steps[lastStepNum].stepNum;

	var elem = {
		'stepNum': lastStepNum+1,
		'delay': $('#modalWindow tbody #delay')[0] ? $('#modalWindow tbody #delay')[0].value*1 : 0,
		'stepType': stepTypes[typesSelector.options.selectedIndex].id,
		'srcStepMessage': $('#modalWindow tbody #srcMessage')[0] ? $('#modalWindow tbody #srcMessage')[0].options[$('#modalWindow tbody #srcMessage')[0].options.selectedIndex].value*1 : null,
		'stepTemplateid': $('#modalWindow tbody #template')[0] ? templates[$('#modalWindow tbody #template')[0].options.selectedIndex].id*1 : null,
		'MQWriterid': null,
        'chance': null
	}
	//Если задержка 0 и тип задержка
	if(elem.stepType == 1 && elem.delay <= 0){
		$('#modalWindow').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Введите время задержки > 0.</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalWindow').modal('show');
		});
		return;
	}
	//Если тип обработка или отправка
	if(elem.stepType >= 2){
		elem.srcStepMessage = (steps[elem.srcStepMessage-1] || nullStep);
	}

    if(elem.stepType == 2){
        var tbody = $('#modalWindow tbody')[0];
        var numOfRows = tbody.childElementCount-3;
        var cumChance = 0; var check = true;
        for(var i=0; i < numOfRows; i++){
            var row = tbody.childNodes[i+2];
            cumChance = cumChance + row.childNodes[2].childNodes[0].value*1;
            if((row.childNodes[2].childNodes[0].value || null) == null || row.childNodes[2].childNodes[0].value*1 < 0){
                check = false;
            }
        }
        if(cumChance != 10000 || check == false){
            $('#modalWindow').modal('hide');
            $('#modalInfo .modal-body')[0].innerHTML = '<p>Сумма вероятностей не равна 10000 или какая-то вероятность задана неверно.</p>';
            $('#modalInfo').modal('show');
            $('#btnInfoOk').off('click');
            $("#btnInfoOk").click(function(){
                $('#modalWindow').modal('show');
            });
            return;
        }
        for(var i=0; i < numOfRows; i++){
            var obj = Object.assign({},elem);
            var row = tbody.childNodes[i+2];
            var MQWriterid = writers[row.childNodes[1].childNodes[0].options.selectedIndex].id*1;
            obj.MQWriterid = MQWriterid;
            obj.chance = row.childNodes[2].childNodes[0].value*1;
            steps.push(obj);
        }
    }else{
        steps.push(elem);
    }

	drawSteps();
	$('#modalWindow').modal('hide');
};

function removeStep(stepNum){
	$('#modalConfirmRemove .modal-body')[0].innerHTML = '<p>Вы действительно хотите удалить шаг номер <strong>'+ stepNum + '</strong>?</p>';
	$('#modalConfirmRemove').modal('show');

	$('#btnModalConfirmRemove').off('click');
	$('#btnModalConfirmRemove').click(function(){
		removeStepAccept(stepNum);
		$('#modalConfirmRemove').modal('hide');
	});
}

function removeStepAccept(stepNum){
	//проверяем можно ли удалить шаг, используются ли его данные где-либо?
    var step;

    var num = 0;
    for(var i in steps){
        if(steps[i].stepNum == stepNum){
            step = steps[i];
            break;
        }
        num++;
    }


	//проверяем по типу 
	var del = true;
	switch(stepTypes[step.stepType].name){
		//удаляем
		case 'DROP': 
		case 'WAIT':
		case 'WRITE': 
        case 'HTTP': 
			break; 
		case 'WORK':
			//Если используется в srcStepMessage, то выдаём ошибку
			for(var k in steps){
				if(steps[k].srcStepMessage != null){
					if(steps[k].srcStepMessage.stepNum == stepNum){
						del = false;
						$('#modalDanger .modal-body')[0].innerHTML = '<p>Нельзя удалить шаг <strong>' + stepNum + '</strong>, он ещё используется.</p>';
						$('#modalDanger').modal('show');
						break;
					}
				}
			}
			break; 
	}

    var count = 0;
    for(var k in steps){
        if(steps[k].stepNum == step.stepNum){
            count++;
        }
    }

	if(step != null && del){
		steps.splice(num,count);
		recalcSteps(stepNum);
		drawSteps();
	}
	$('#modalWindow').modal('hide');
}

function recalcSteps(stepNum){
	for(var k in steps){
        if(steps[k].stepNum > stepNum){
		  steps[k].stepNum = steps[k].stepNum - 1;
        }
	}
};

function preEditStep(stepNum){
	var tbody = $('#modalWindow tbody')[0];
	tbody.innerHTML = '';

    var editedStep = -1;

    for(var i in steps){
        if(steps[i].stepNum == stepNum){
            for(var j in stepTypes) {
                if(stepTypes[j].id == steps[i].stepType){
                    typesSelector.options.selectedIndex = j;
                    editedStep = steps[i];
                    break;
                }
            }
            break;
        }
    }

	typeChange();

	switch(stepTypes[typesSelector.options.selectedIndex].name){
		case 'DROP': 
			//ничего не выводим
			break; 
		case 'WAIT':
			//добавляем поле для ввода задержки 
			$('#delay')[0].value = editedStep.delay;
			break; 
		case 'WRITE': 
			//Ставим сообщение
			for(var k in $('#srcMessage')[0].options){
				if($('#srcMessage')[0].options[k].innerHTML*1 == editedStep.srcStepMessage.stepNum*1){
					$('#srcMessage')[0].selectedIndex = k;
					break;
				}
			}
			//Ставим отправителя
            var i = 1;
            for(var k in steps){
                if(steps[k].stepNum == stepNum){
                    if(i > 1){
                        addWriterRow();
                    }
                    for(var k1 in writers){
                        if(writers[k1].id == steps[k].MQWriterid){
                            $('#writerSelector_' + i)[0].selectedIndex = k1;
                            $('#writerChance_' + i)[0].value = steps[k].chance;
                            i++;
                            break;
                        }
                    }
                }
            }
			break; 
        case 'HTTP': 
            //Ставим сообщение
            for(var k in $('#srcMessage')[0].options){
                if($('#srcMessage')[0].options[k].innerHTML*1 == editedStep.srcStepMessage.stepNum*1){
                    $('#srcMessage')[0].selectedIndex = k;
                    break;
                }
            }
            break; 
		case 'WORK':
			//Ставим сообщение
			for(var k in $('#srcMessage')[0].options){
				if($('#srcMessage')[0].options[k].innerHTML*1 == editedStep.srcStepMessage.stepNum*1){
					$('#srcMessage')[0].selectedIndex = k;
					break;
				}
			}
			//Ставим шаблон
			for(var k in templates){
				if(templates[k].id == editedStep.stepTemplateid){
					$('#template')[0].selectedIndex = k;
					break;
				}
			}
			break; 
	}

	$('#modalWindow .modal-content')[0].className = 'modal-content panel-warning';
	$('#modalWindow .modal-title')[0].innerHTML = 'Редактирование шага ' + stepNum;
	$('#modalWindow .btn-primary')[0].className = 'btn btn-primary btn-warning';
	$('#modalWindow .btn-primary')[0].innerHTML = 'Сохранить';

	$('#modalWindow .modal-footer .btn-primary').off('click');
	$('#modalWindow .modal-footer .btn-primary').click(function(){
		editStep(stepNum);
	});

	$('#modalWindow').modal('show');
};

function DnDstep(event, ui){
	var oldId = ui.item[0].id;
	var newTBody = event.target;
	var children = {};
	var i=0;
	for(var k in newTBody.childNodes){
		if((newTBody.childNodes[k].id||null) != null){
			children[i] = newTBody.childNodes[k];
			i++;
		}
	}
	var newId = 0;
	for(var k in children){
		if(children[k].id*1 == oldId*1){
			newId = k*1+1;
		}
	}

	if(steps[oldId-1].srcStepMessage != null){
		if(steps[oldId-1].srcStepMessage.stepNum >= newId){
			$(newTBody).sortable('cancel');
			$('#modalDanger .modal-body')[0].innerHTML = '<p>Нельзя переместить шаг <strong>' + oldId + '</strong> выше шага <strong>' + steps[oldId-1].srcStepMessage.stepNum + '</strong>!</p>';
			$('#modalDanger').modal('show');
			return;
		}
	}

	for(var k in steps){
		if(steps[k].srcStepMessage != null){
			if(steps[k].srcStepMessage.stepNum == oldId && steps[k].stepNum <= newId){
				$(newTBody).sortable('cancel');
				$('#modalDanger .modal-body')[0].innerHTML = '<p>Нельзя переместить шаг <strong>' + oldId + '</strong> ниже шага <strong>' + newId + '</strong>!</p>';
				$('#modalDanger').modal('show');
				return;
			}
		}
	}
	//Применяем
	var tStep = steps[oldId-1];
	tStep.stepNum = newId*1;
	steps[oldId-1] = steps[newId-1];
	steps[oldId-1].stepNum = oldId*1;
	steps[newId-1] = tStep;
	//Перерисовываем
	drawSteps();
};

function preSaveScenario(id){
	$('#modalConfirmSave .modal-body')[0].innerHTML = '<p>Вы действительно хотите сохранить данный сценарий?</p>';
	$('#modalConfirmSave').modal('show');

	$('#btnModalConfirmSave').off('click');
	$('#btnModalConfirmSave').click(function(){
		var data = JSON.parse(JSON.stringify(steps));
		for(var k in data){
			if(data[k].srcStepMessage != null){
				data[k].srcStepMessage = data[k].srcStepMessage.stepNum;
			}
		}
		data = {
			'uuid': generateUUID(),
			'triggerID':id*1,
			'steps': data
		}
		jQuery.ajax({
			type: "POST",
			async: false,
			dataType: "json",
			contentType: "application/json",
			url: 'control/steps/save',
			data: JSON.stringify(data),
			success: function(data) {serviceSuccess(data)},
			error: function(data) {serviceFail(data)}
		});
		$('#modalConfirmSave').modal('hide');
	});
};