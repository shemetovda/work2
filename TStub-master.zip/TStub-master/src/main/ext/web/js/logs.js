$(document).ready(function() {
    var logs = {};
	getLogs();
});

function serviceFail(data){
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function serviceSuccess(json){
	if(json.code == 0){
		getTemplates();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. <br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
}

function getLogs(){
	jQuery.ajax({
		type: "POST",
		async: true,
		url: 'control/logs/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getLogsSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getLogsSuccess(json){
	if(json.code == 0){	
		logs = json.logs;
		drawLogs();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function drawLogs(){
	var table = $('#tableLogs')[0];
	var tbody = $('#tableLogsBody')[0];
	tbody.innerHTML = "";
	$.each(logs, function(k, v){

		var row = document.createElement("tr");
		var cellFileName = document.createElement("td");
		var btnDownload = document.createElement("td");

		cellFileName.innerHTML = logs[k].fileName;
		var btn = $('<button type="button" class="btn btn-default btn-success" title="Скачать"><span class="glyphicon glyphicon-save" aria-hidden="true"></span></button>');
		btn.on("click",function(){return downloadLog(logs[k].fileName);});
		btnDownload.append(btn[0]);

		row.appendChild(cellFileName);
		row.appendChild(btnDownload);
		tbody.appendChild(row);
	})

};


function downloadLog(fileName){
	console.log(fileName);
	var params = {
		'uuid':generateUUID(),
		'type':2*1,
		'fileName':fileName
	};
	jQuery.ajax({
		type: "POST",
		async: true,
		url: 'download',
		data: params,
		success: function(response, status, request) {
			var disp = request.getResponseHeader('Content-Disposition');
			if(disp && disp.search('attachment') != -1){
				var form = $('<form method="POST" action="download">');
				$.each(params, function(k,v){
					form.append($('<input type="hidden" name="' + k + '" value="' + v + '">'));
				});
				$('body').append(form);
				form.submit();
			}
		}
	});
};