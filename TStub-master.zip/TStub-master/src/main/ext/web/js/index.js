$(document).ready(function() {
	getTitle();
});

function setTitle(json){
	if(json.code == 0){	
		$('#TStub_title')[0].innerHTML = json.params[0].value;
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
}

function getTitle(){
	jQuery.ajax({
		type: "POST",
		async: true,
		url: 'control/params/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\",\"params\":[\"TStub_title\"]}',
		success: function(data) {setTitle(data)},
		error: function(data) {serviceFail(data)}
	});
};

function serviceFail(data){
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};