var certificates = {};
$(document).ready(function() {
	getCertificates();

	$("#btnAddCertificate").click(function(){
		$('#modalAddCertificate').modal('show');
	});
	$("#btnModalAddCertificateConfirm").click(function(){
		preAddCertificate();
	});
});

function serviceFail(data){
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function serviceSuccess(json){
	if(json.code == 0){
		getCertificates();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. <br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
}

function getCertificates(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/certificates/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getCertificatesSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getCertificatesSuccess(json){
	if(json.code == 0){	
		certificates = json.certificates;
		drawCertificates();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function drawCertificates(){
	var table = $('#tableCertificates')[0];
	var tbody = $('#tableCertificatesBody')[0];
	tbody.innerHTML = "";
	for(var k in certificates) {
		var row = document.createElement("tr");
		var cellName = document.createElement("td");
		var cellKey = document.createElement("td");
		var cellJavaChiperSuite = document.createElement("td");
		var cellFIPSRequired = document.createElement("td");
		var cellSSLType = document.createElement("td");

		row.id = 'certificate_' + certificates[k].id;
		cellName.innerHTML = certificates[k].comment;
		cellKey.innerHTML = certificates[k].key;
		cellJavaChiperSuite.innerHTML = certificates[k].JavaChiperSuite;
		cellFIPSRequired.innerHTML = certificates[k].FIPSRequired;
		cellSSLType.innerHTML = certificates[k].SSLType;

		var btnEdit = document.createElement("td");
		var btnRemove = document.createElement("td");

		btnEdit.innerHTML = '<button onclick="preEditCertificate('+ certificates[k].id +');" class="btn btn-default btn-warning"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>';
		btnRemove.innerHTML = '<button onclick="removeCertificate('+ certificates[k].id +');" class="btn btn-default btn-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button>';

		row.appendChild(cellName);
		row.appendChild(cellKey);
		row.appendChild(cellJavaChiperSuite);
		row.appendChild(cellSSLType);
		row.appendChild(cellFIPSRequired);
		row.appendChild(btnEdit);
		row.appendChild(btnRemove);
		tbody.appendChild(row);
	}
};

function preEditCertificate(number){
	var cells = $('#certificate_'+number)[0].cells;
	$('#editCertificateComment')[0].value = cells[0].innerHTML;
	$('#editCertificateKey')[0].value = cells[1].innerHTML;
	$('#editCertificateJavaChiperSuite')[0].value = cells[2].innerHTML;
	$('#editCertificateSSLType')[0].value = cells[3].innerHTML;
	
	if(cells[4].innerHTML == 'true')
		$('#editCertificateFIPSRequired')[0].checked = true;
	else
		$('#editCertificateNonFIPSRequired')[0].checked = true;

	$('#btnModalEditCertificateConfirm').off('click');
	$("#btnModalEditCertificateConfirm").click(function(){
		editCertificate(number);
	});
	$('#modalEditCertificate').modal('show');
};

function editCertificate(id){
	var file = $("#editFileCertificate")[0].files[0]||null;
	var comment = $('#editCertificateComment')[0].value;
	var key = $('#editCertificateKey')[0].value;
	var JavaChiperSuite = $('#editCertificateJavaChiperSuite')[0].value;
	var SSLType = $('#editCertificateSSLType')[0].value;
	var FIPSRequired = $('#editCertificateFIPSRequired')[0].checked||false;

	var check = true;
	if(comment == "" || key == "" || JavaChiperSuite == "" || SSLType == ""){
		check = false;
	}
	if(check != true){
		$('#modalEditCertificate').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalEditCertificate').modal('show');
		});
		return;
	}

	if(file == null){
		var data = {
			'uuid': generateUUID(),
			'id': id*1,
			'comment': comment,
			'key': key,
			'JavaChiperSuite': JavaChiperSuite,
			'SSLType': SSLType,
			'FIPSRequired': FIPSRequired,
			'fileName': null
		}
	}else{
		var data = {
			'uuid': generateUUID(),
			'id': id*1,
			'comment': comment,
			'key': key,
			'JavaChiperSuite': JavaChiperSuite,
			'SSLType': SSLType,
			'FIPSRequired': FIPSRequired,
			'fileName': file.name
		}
	}
	$('#modalEditCertificate').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		dataType: "json",
		contentType: "application/json",
		url: 'control/certificates/update',
		data: JSON.stringify(data),
		success: function(data) {preUploadSuccess(file, data)},
		error: function(data) {serviceFail(data)}
	});
};

function preUploadSuccess(file, json){
	if(json.code == 0){	
		if(file != null)
			uploadCertificate(file, json.fileUUID);
		else
			getCertificates();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function uploadCertificate(file, id){
	jQuery.ajax({
		type: "POST",
		async: true,
		processData: false,
		url: 'upload/' + id,
		data: file,
		success: function(data) {uploadSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function uploadSuccess(json){
	if(json.code == 0){	
		getCertificates();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function preAddCertificate(){
	var file = $("#addFileCertificate")[0].files[0]||null;
	var comment = $('#addCertificateComment')[0].value;
	var key = $('#addCertificateKey')[0].value;
	var JavaChiperSuite = $('#addCertificateJavaChiperSuite')[0].value;
	var SSLType = $('#addCertificateSSLType')[0].value;
	var FIPSRequired = $('#addCertificateFIPSRequired')[0].checked||false;

	var check = true;
	if(file == null || comment == "" || key == "" || JavaChiperSuite == "" || SSLType == ""){
		check = false;
	}
	if(check != true){
		$('#modalAddCertificate').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalAddCertificate').modal('show');
		});
		return;
	}
	$('#modalAddCertificate').modal('hide');

	var data = {
		'uuid': generateUUID(),
		'comment': comment,
		'key': key,
		'JavaChiperSuite': JavaChiperSuite,
		'SSLType': SSLType,
		'FIPSRequired': FIPSRequired,
		'fileName': file.name
	}

	jQuery.ajax({
		type: "POST",
		async: false,
		dataType: "json",
		contentType: "application/json",
		url: 'control/certificates/add',
		data: JSON.stringify(data),
		success: function(data) {preUploadSuccess(file, data)},
		error: function(data) {serviceFail(data)}
	});
};

function removeCertificate(id){
	var comment = $('#certificate_'+id)[0].cells[0].innerHTML;
	$('#modalConfirmRemove .modal-body')[0].innerHTML = '<p>Вы действительно хотите удалить сертификат <strong>'+ comment + '</strong>?</p>';
	$('#modalConfirmRemove').modal('show');

	$('#btnModalConfirmRemove').click(function(){
		jQuery.ajax({
			type: "POST",
			async: false,
			dataType: "json",
			contentType: "application/json",
			url: 'control/certificates/remove',
			data: '{\"uuid\":\"' + generateUUID() + '\", \"id\":' + id + '}',
			success: function(data) {serviceSuccess(data)},
			error: function(data) {serviceFail(data)}
		});
		$('#modalConfirmRemove').modal('hide');
		$('#btnModalConfirmRemove').off('click');
	});
};