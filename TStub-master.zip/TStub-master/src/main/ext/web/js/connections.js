var certificates = {};
$(document).ready(function() {
	refreshData();

	$("#btnAddReader").click(function(){
		$('#modalAddReader').modal('show');
	});

	$("#btnAddWriter").click(function(){
		$('#modalAddWriter').modal('show');
	});

	$("#modalAddReaderConfirm").click(function(){
		readerAdd();
	});

	$("#modalAddWriterConfirm").click(function(){
		writerAdd();
	});

	$("#cngReaderHost").on("keyup",function(){keyUpdate("cng", "Reader");});
	$("#cngReaderPort").on("keyup",function(){keyUpdate("cng", "Reader");});
	$("#cngReaderManager").on("keyup",function(){keyUpdate("cng", "Reader");});
	$("#cngReaderChannel").on("keyup",function(){keyUpdate("cng", "Reader");});
	$("#cngReaderQueue").on("keyup",function(){keyUpdate("cng", "Reader");});

	$("#cngWriterHost").on("keyup",function(){keyUpdate("cng", "Writer");});
	$("#cngWriterPort").on("keyup",function(){keyUpdate("cng", "Writer");});
	$("#cngWriterManager").on("keyup",function(){keyUpdate("cng", "Writer");});
	$("#cngWriterChannel").on("keyup",function(){keyUpdate("cng", "Writer");});
	$("#cngWriterQueue").on("keyup",function(){keyUpdate("cng", "Writer");});

	$("#addReaderHost").on("keyup",function(){keyUpdate("add", "Reader");});
	$("#addReaderPort").on("keyup",function(){keyUpdate("add", "Reader");});
	$("#addReaderManager").on("keyup",function(){keyUpdate("add", "Reader");});
	$("#addReaderChannel").on("keyup",function(){keyUpdate("add", "Reader");});
	$("#addReaderQueue").on("keyup",function(){keyUpdate("add", "Reader");});

	$("#addWriterHost").on("keyup",function(){keyUpdate("add", "Writer");});
	$("#addWriterPort").on("keyup",function(){keyUpdate("add", "Writer");});
	$("#addWriterManager").on("keyup",function(){keyUpdate("add", "Writer");});
	$("#addWriterChannel").on("keyup",function(){keyUpdate("add", "Writer");});
	$("#addWriterQueue").on("keyup",function(){keyUpdate("add", "Writer");});

});

function refreshData(){
	getCertificates();
	getReaders();
	getWriters();
};

function serviceFail(data){
	$('#modalLoader').modal('hide');
	$('#modalDanger .modal-body')[0].innerHTML = '<p>Сервис недоступен, повторите попытку позже. <br/>Код ошибки: ' + data.status + '<br/>Сообщение сервера: ' + $.parseJSON(data.responseText).message + '</p>';
	$('#modalDanger').modal('show');
};

function serviceSuccess(json){
	if(json.code == 0){
		refreshData();
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. <br/>Код ошибки: ' + json.code + '<br/>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
}

function getCertificates(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/certificates/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getCertificatesSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getCertificatesSuccess(json){
	if(json.code == 0){	
		certificates = json.certificates;
		$('#addReaderCertId')[0].options[0] = new Option('');
		i = 1;
		for(var j in certificates){
			$('#addReaderCertId')[0].options[i] = new Option(certificates[j].comment);
			i++;
		}
		$('#addWriterCertId')[0].options[0] = new Option('');
		i = 1;
		for(var j in certificates){
			$('#addWriterCertId')[0].options[i] = new Option(certificates[j].comment);
			i++;
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};


function getReaders(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/readers/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getReadersSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getReadersSuccess(json){
	if(json.code == 0){
		var table = $('#tableReaders')[0];
		var tbody = $('#tableReadersBody')[0];
		tbody.innerHTML = "";
		
		for(var k in json.readers) {
			var row = document.createElement("tr");
			var cellHost = document.createElement("td");
			var cellPort = document.createElement("td");
			var cellManager = document.createElement("td");
			var cellChannel = document.createElement("td");
			var cellQueue = document.createElement("td");
            var cellSelector = document.createElement("td");
			var cellLogin = document.createElement("td");
			var cellPassword = document.createElement("td");
			var cellActive = document.createElement("td");
			var cellCert = document.createElement("td");
			var cellQuantity = document.createElement("td");
			var cellSave = document.createElement("td");
			var cellRemove = document.createElement("td");

			row.id = 'reader_' + json.readers[k].id;
			cellHost.innerHTML = json.readers[k].host;
			cellPort.innerHTML = json.readers[k].port;
			cellManager.innerHTML = json.readers[k].manager;
			cellChannel.innerHTML = json.readers[k].channel;
			cellQueue.innerHTML = json.readers[k].queue;
            cellSelector.innerHTML = json.readers[k].selector ? json.readers[k].selector : '-';
			if(json.readers[k].login != null)
				cellLogin.innerHTML = json.readers[k].login;
			else
				cellLogin.innerHTML = 'Не задан';
			if(json.readers[k].password != null)
				cellPassword.innerHTML = json.readers[k].password;
			else
				cellPassword.innerHTML = 'Не задан';
			
			cellActive.innerHTML = json.readers[k].active;

			if(json.readers[k].certID > 0){
				for(var j in certificates){
					if(certificates[j].id == json.readers[k].certID){
						cellCert.innerHTML = certificates[j].comment;
						break;
					}
				}
			}
			else{
				cellCert.innerHTML = 'Не задан';
			}

			cellQuantity.innerHTML = json.readers[k].numOfProviders;

			cellSave.innerHTML = '<button onclick="readerChange('+ json.readers[k].id +');" class="btn btn-default btn-warning"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>';
			cellRemove.innerHTML = '<button onclick="readerRemove('+ json.readers[k].id +');" class="btn btn-default btn-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button>';

			row.appendChild(cellHost);
			row.appendChild(cellPort);
			row.appendChild(cellManager);
			row.appendChild(cellChannel);
			row.appendChild(cellQueue);
            row.appendChild(cellSelector);
			row.appendChild(cellQuantity);
			row.appendChild(cellLogin);
			row.appendChild(cellPassword);
			row.appendChild(cellCert);
			row.appendChild(cellActive);
			row.appendChild(cellSave);
			row.appendChild(cellRemove);
			tbody.appendChild(row);
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function readerChange(number){
	var cells = $('#reader_'+number)[0].cells;
	$('#cngReaderHost')[0].value = cells[0].innerHTML;
	$('#cngReaderPort')[0].value = cells[1].innerHTML;
	$('#cngReaderManager')[0].value = cells[2].innerHTML;
	$('#cngReaderChannel')[0].value = cells[3].innerHTML;
	$('#cngReaderQueue')[0].value = cells[4].innerHTML;

    if(cells[5].innerHTML == '-')
        $('#cngReaderSelector')[0].value = '';
    else
        $('#cngReaderSelector')[0].value = cells[5].innerHTML;

	$('#cngReaderNumOfProviders')[0].value = cells[6].innerHTML;
	if(cells[7].innerHTML == 'Не задан')
		$('#cngReaderLogin')[0].value = '';
	else
		$('#cngReaderLogin')[0].value = cells[7].innerHTML;
	if(cells[8].innerHTML == 'Не задан')
		$('#cngReaderPassword')[0].value = '';
	else
		$('#cngReaderPassword')[0].value = cells[8].innerHTML;
	
	//Сертификат
	$('#cngReaderCertId')[0].options[0] = new Option('');
	i = 1;
	for(var j in certificates){
		$('#cngReaderCertId')[0].options[i] = new Option(certificates[j].comment);
		i++;
	}
	if(cells[9].innerHTML != 'Не задан'){
		$('#cngReaderCertId')[0].value = cells[9].innerHTML;
	}

	if(cells[10].innerHTML == 'true')
		$('#cngReaderActive')[0].checked = true;
	else
		$('#cngReaderNonActive')[0].checked = true;
	
	keyUpdate("cng","Reader");

	$('#modalChangeReaderConfirm').off('click');
	$("#modalChangeReaderConfirm").click(function(){
		updateReader(number);
	});
	$('#modalChangeReader').modal('show');
};

function updateReader(number){
	var host = $('#cngReaderHost')[0].value;
	var port = $('#cngReaderPort')[0].value;
	var manager = $('#cngReaderManager')[0].value;
	var channel = $('#cngReaderChannel')[0].value;
	var queue = $('#cngReaderQueue')[0].value;
    var selector = $('#cngReaderSelector')[0].value;
	var numOfProviders = $('#cngReaderNumOfProviders')[0].value;
	var login = $('#cngReaderLogin')[0].value||null;
	var password = $('#cngReaderPassword')[0].value||null;
	var active = $('#cngReaderActive')[0].checked||false;

	var certId = 0;
	for(var k in certificates){
		if(certificates[k].comment == $('#cngReaderCertId')[0].value){
			certId = certificates[k].id;
			break;
		}
	}

	var check = true;
	if(host == "" || port == "" || manager == "" || channel == "" || queue == "" || numOfProviders == ""){
		check = false;
	}
	if(check != true){
		$('#modalChangeReader').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalChangeReader').modal('show');
		});
		return;
	}

	var request = {
		'uuid': generateUUID(),
		'id': number,
		'host': host,
		'port': port*1,
		'manager': manager,
		'channel': channel,
		'queue': queue,
		'numOfProviders': numOfProviders*1,
		'login': login,
		'password': password,
		'certId': certId*1,
		'active': active,
        'selector': selector
	}

	$('#modalChangeReader').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/readers/update',
		dataType: "json",
		contentType: "application/json",
		data: JSON.stringify(request),
		success: function(data) {serviceSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function readerAdd(){
	var host = $('#addReaderHost')[0].value;
	var port = $('#addReaderPort')[0].value;
	var manager = $('#addReaderManager')[0].value;
	var channel = $('#addReaderChannel')[0].value;
	var queue = $('#addReaderQueue')[0].value;
	var numOfProviders = $('#addReaderNumOfProviders')[0].value;
    var selector = $('#addReaderSelector')[0].value||null;
	var login = $('#addReaderLogin')[0].value||null;
	var password = $('#addReaderPassword')[0].value||null;
	var active = $('#addReaderActive')[0].checked||false;

	var certId = 0;
	for(var k in certificates){
		if(certificates[k].comment == $('#addReaderCertId')[0].value){
			certId = certificates[k].id;
			break;
		}
	}

	var check = true;
	if(host == "" || port == "" || manager == "" || channel == "" || queue == "" || numOfProviders == ""){
		check = false;
	}
	if(check != true){
		$('#modalAddReader').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalAddReader').modal('show');
		});
		return;
	}

	var request = {
		'uuid': generateUUID(),
		'host': host,
		'port': port*1,
		'manager': manager,
		'channel': channel,
		'queue': queue,
		'numOfProviders': numOfProviders*1,
		'login': login,
		'password': password,
		'certId': certId*1,
		'active': active,
        'selector': selector
	}

	$('#modalAddReader').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/readers/add',
		dataType: "json",
		contentType: "application/json",
		data: JSON.stringify(request),
		success: function(data) {serviceSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function readerRemove(number){
	var host = $('#reader_'+number)[0].cells[0].innerHTML;
	var port = $('#reader_'+number)[0].cells[1].innerHTML;
	var manager = $('#reader_'+number)[0].cells[2].innerHTML;
	var channel = $('#reader_'+number)[0].cells[3].innerHTML;
	var queue = $('#reader_'+number)[0].cells[4].innerHTML;
	$('#modalConfirmRemove .modal-body')[0].innerHTML = '<p>Вы действительно хотите удалить очередь на чтение <strong>'+ host + ":" + port + ":" + manager + ":" + channel + ":" + queue +'</strong>?</p>';
	$('#modalConfirmRemove').modal('show');
	$('#btnModalConfirmRemove').off('click');
	$('#btnModalConfirmRemove').click(function(){
		jQuery.ajax({
			type: "POST",
			async: false,
			url: 'control/readers/remove',
			dataType: "json",
			contentType: "application/json",
			data: '{\"uuid\":\"' + generateUUID() + '\", \"id\":' + number + '}',
			success: function(data) {serviceSuccess(data)},
			error: function(data) {serviceFail(data)}
		});
		$('#modalConfirmRemove').modal('hide');
	});
};

function getWriters(){
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/writers/get',
		dataType: "json",
		contentType: "application/json",
		data: '{\"uuid\":\"' + generateUUID() + '\"}',
		success: function(data) {getWritersSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function getWritersSuccess(json){
	if(json.code == 0){
		var table = $('#tableWriters')[0];
		var tbody = $('#tableWritersBody')[0];
		tbody.innerHTML = "";
		
		for(var k in json.writers) {
			var row = document.createElement("tr");
			var cellHost = document.createElement("td");
			var cellPort = document.createElement("td");
			var cellManager = document.createElement("td");
			var cellChannel = document.createElement("td");
			var cellQueue = document.createElement("td");
			var cellLogin = document.createElement("td");
			var cellPassword = document.createElement("td");
			var cellActive = document.createElement("td");
			var cellDefault = document.createElement("td");
			var cellCert = document.createElement("td");
			var cellSave = document.createElement("td");
			var cellRemove = document.createElement("td");

			row.id = 'writer_' + json.writers[k].id;
			cellHost.innerHTML = json.writers[k].host;
			cellPort.innerHTML = json.writers[k].port;
			cellManager.innerHTML = json.writers[k].manager;
			cellChannel.innerHTML = json.writers[k].channel;
			cellQueue.innerHTML = json.writers[k].queue;
			if(json.writers[k].login != null)
				cellLogin.innerHTML = json.writers[k].login;
			else
				cellLogin.innerHTML = 'Не задан';
			if(json.writers[k].password != null)
				cellPassword.innerHTML = json.writers[k].password;
			else
				cellPassword.innerHTML = 'Не задан';
			
			cellActive.innerHTML = json.writers[k].active;

			if(json.writers[k].certID > 0){
				for(var j in certificates){
					if(certificates[j].id == json.writers[k].certID){
						cellCert.innerHTML = certificates[j].comment;
						break;
					}
				}
			}
			else{
				cellCert.innerHTML = 'Не задан';
			}

			cellDefault.innerHTML = json.writers[k].isDefault;

			cellSave.innerHTML = '<button onclick="writerChange('+ json.writers[k].id +');" class="btn btn-default btn-warning"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>';
			cellRemove.innerHTML = '<button onclick="writerRemove('+ json.writers[k].id +');" class="btn btn-default btn-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button>';

			row.appendChild(cellHost);
			row.appendChild(cellPort);
			row.appendChild(cellManager);
			row.appendChild(cellChannel);
			row.appendChild(cellQueue);
			row.appendChild(cellLogin);
			row.appendChild(cellPassword);
			row.appendChild(cellCert);
			row.appendChild(cellActive);
			row.appendChild(cellDefault);
			row.appendChild(cellSave);
			row.appendChild(cellRemove);
			tbody.appendChild(row);
		}
	}else{
		$('#modalDanger .modal-body')[0].innerHTML = '<p>Ошибка при выполнении запроса. </br>Код ошибки: ' + json.code + '</br>Сообщение сервера: ' + json.message +'</p>';
		$('#modalDanger').modal('show');
	}
};

function writerChange(number){
	var cells = $('#writer_'+number)[0].cells;
	$('#cngWriterHost')[0].value = cells[0].innerHTML;
	$('#cngWriterPort')[0].value = cells[1].innerHTML;
	$('#cngWriterManager')[0].value = cells[2].innerHTML;
	$('#cngWriterChannel')[0].value = cells[3].innerHTML;
	$('#cngWriterQueue')[0].value = cells[4].innerHTML;
	if(cells[5].innerHTML == 'Не задан')
		$('#cngWriterLogin')[0].value = '';
	else
		$('#cngWriterLogin')[0].value = cells[5].innerHTML;
	if(cells[6].innerHTML == 'Не задан')
		$('#cngWriterPassword')[0].value = '';
	else
		$('#cngWriterPassword')[0].value = cells[6].innerHTML;
	
	//Сертификат
	$('#cngWriterCertId')[0].options[0] = new Option('');
	i = 1;
	for(var j in certificates){
		$('#cngWriterCertId')[0].options[i] = new Option(certificates[j].comment);
		i++;
	}
	if(cells[7].innerHTML != 'Не задан'){
		$('#cngWriterCertId')[0].value = cells[7].innerHTML;
	}

	if(cells[8].innerHTML == 'true')
		$('#cngWriterActive')[0].checked = true;
	else
		$('#cngWriterNonActive')[0].checked = true;

	if(cells[9].innerHTML == 'true')
		$('#cngWriterDefault')[0].checked = true;
	else
		$('#cngWriterNonDefault')[0].checked = true;

	$('#modalChangeWriterConfirm').off('click');
	$("#modalChangeWriterConfirm").click(function(){
		updateWriter(number);
	});
	
	keyUpdate("cng","Writer");

	$('#modalChangeWriter').modal('show');
};

function updateWriter(number){
	var host = $('#cngWriterHost')[0].value;
	var port = $('#cngWriterPort')[0].value;
	var manager = $('#cngWriterManager')[0].value;
	var channel = $('#cngWriterChannel')[0].value;
	var queue = $('#cngWriterQueue')[0].value;

	var login = $('#cngWriterLogin')[0].value||null;
	var password = $('#cngWriterPassword')[0].value||null;

	var active = $('#cngWriterActive')[0].checked||false;
	var defaultWriter = $('#cngWriterDefault')[0].checked||false;

	var certId = 0;
	for(var k in certificates){
		if(certificates[k].comment == $('#cngWriterCertId')[0].value){
			certId = certificates[k].id;
			break;
		}
	}

	var check = true;
	if(host == "" || port == "" || manager == "" || channel == "" || queue == "" ){
		check = false;
	}
	if(check != true){
		$('#modalChangeWriter').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalChangeWriter').modal('show');
		});
		return;
	}

	var request = {
		'uuid': generateUUID(),
		'id': number,
		'host': host,
		'port': port*1,
		'manager': manager,
		'channel': channel,
		'queue': queue,
		'login': login,
		'password': password,
		'certId': certId*1,
		'active': active,
		'defaultWriter': defaultWriter
	}

	$('#modalChangeWriter').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/writers/update',
		dataType: "json",
		contentType: "application/json",
		data: JSON.stringify(request),
		success: function(data) {serviceSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};


function writerRemove(number){
	var host = $('#writer_'+number)[0].cells[0].innerHTML;
	var port = $('#writer_'+number)[0].cells[1].innerHTML;
	var manager = $('#writer_'+number)[0].cells[2].innerHTML;
	var channel = $('#writer_'+number)[0].cells[3].innerHTML;
	var queue = $('#writer_'+number)[0].cells[4].innerHTML;
	$('#modalConfirmRemove .modal-body')[0].innerHTML = '<p>Вы действительно хотите удалить очередь на запись <strong>'+ host + ":" + port + ":" + manager + ":" + channel + ":" + queue +'</strong>?</p>';
	$('#modalConfirmRemove').modal('show');
	$('#btnModalConfirmRemove').off('click');
	$('#btnModalConfirmRemove').click(function(){
		jQuery.ajax({
			type: "POST",
			async: false,
			url: 'control/writers/remove',
			dataType: "json",
			contentType: "application/json",
			data: '{\"uuid\":\"' + generateUUID() + '\", \"id\":' + number + '}',
			success: function(data) {serviceSuccess(data)},
			error: function(data) {serviceFail(data)}
		});
		$('#modalConfirmRemove').modal('hide');
	});
};

function writerAdd(){
	var host = $('#addWriterHost')[0].value;
	var port = $('#addWriterPort')[0].value;
	var manager = $('#addWriterManager')[0].value;
	var channel = $('#addWriterChannel')[0].value;
	var queue = $('#addWriterQueue')[0].value;
	var login = $('#addWriterLogin')[0].value||null;
	var password = $('#addWriterPassword')[0].value||null;
	var active = $('#addWriterActive')[0].checked||false;
	var defaultWriter = $('#addWriterDefault')[0].checked||false;

	var certId = 0;
	for(var k in certificates){
		if(certificates[k].comment == $('#addWriterCertId')[0].value){
			certId = certificates[k].id;
			break;
		}
	}

	var check = true;
	if(host == "" || port == "" || manager == "" || channel == "" || queue == ""){
		check = false;
	}
	if(check != true){
		$('#modalAddWriter').modal('hide');
		$('#modalInfo .modal-body')[0].innerHTML = '<p>Проверьте правильность заполнения полей</p>';
		$('#modalInfo').modal('show');
		$('#btnInfoOk').off('click');
		$("#btnInfoOk").click(function(){
			$('#modalAddWriter').modal('show');
		});
		return;
	}

	var request = {
		'uuid': generateUUID(),
		'host': host,
		'port': port*1,
		'manager': manager,
		'channel': channel,
		'queue': queue,
		'login': login,
		'password': password,
		'certId': certId*1,
		'active': active,
		'defaultWriter': defaultWriter
	}

	$('#modalAddWriter').modal('hide');
	jQuery.ajax({
		type: "POST",
		async: false,
		url: 'control/writers/add',
		dataType: "json",
		contentType: "application/json",
		data: JSON.stringify(request),
		success: function(data) {serviceSuccess(data)},
		error: function(data) {serviceFail(data)}
	});
};

function keyUpdate(type,action){
	var keyField = $('#'+type + action + "Key")[0];
	var content = "";
	content += $('#' + type + action + "Host")[0].value;
	content += ":" + $('#' + type + action + "Port")[0].value;
	content += ":" + $('#' + type + action + "Manager")[0].value;
	content += ":" + $('#' + type + action + "Channel")[0].value;
	content += ":" + $('#' + type + action + "Queue")[0].value;
	keyField.innerHTML = content;
}