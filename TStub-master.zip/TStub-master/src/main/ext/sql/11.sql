INSERT INTO TStubVersions(version, userversion) VALUES (11, "1.3.4hf3");
INSERT INTO TStubVersions(version, userversion) VALUES (12, "1.3.4hf3");