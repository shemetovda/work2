ALTER TABLE WorkerSteps ADD chance INTEGER(5) NULL;
UPDATE WorkerSteps SET chance=10000 WHERE stepType=2;
INSERT INTO TStubVersions(version) VALUES (8);