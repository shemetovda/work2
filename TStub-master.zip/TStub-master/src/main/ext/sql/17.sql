DELETE FROM Params WHERE name="threads";
INSERT INTO TStubVersions(version, userversion) VALUES (18, "1.4.0");