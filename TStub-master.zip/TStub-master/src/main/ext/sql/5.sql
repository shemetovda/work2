ALTER TABLE Triggers ADD headers_new CHAR(700) NULL;
UPDATE Triggers SET headers_new=headers WHERE headers<>"";
CREATE TABLE Triggers4e68
(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    expression CHAR(700) NOT NULL,
    comment CHAR(600) NOT NULL,
    active BOOLEAN DEFAULT 0 NOT NULL,
    headers CHAR(700)
);
CREATE UNIQUE INDEX Triggers_expression_header ON Triggers4e68 (expression, headers);
INSERT INTO Triggers4e68(id, expression, comment, active, headers) SELECT id, expression, comment, active, headers_new FROM Triggers;
DROP TABLE Triggers;
ALTER TABLE Triggers4e68 RENAME TO Triggers;
INSERT INTO TStubVersions(version) VALUES (6);