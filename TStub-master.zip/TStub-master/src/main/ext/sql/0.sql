INSERT INTO StepType(id,name,comment) VALUES (4,"HTTP", "Отправка ответа на HTTP запрос");
INSERT INTO TStubVersions(version) VALUES (1);