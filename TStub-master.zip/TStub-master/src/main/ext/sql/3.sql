CREATE TABLE Triggers013f
(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    expression CHAR(700) NOT NULL,
    comment CHAR(600) NOT NULL,
    active BOOLEAN DEFAULT 0 NOT NULL,
    headers CHAR(700) DEFAULT "" NOT NULL
);
CREATE UNIQUE INDEX Triggers_expression_headers_uindex ON Triggers013f (expression, headers);
INSERT INTO Triggers013f(id, expression, comment, active) SELECT id, expression, comment, active FROM Triggers;
DROP TABLE Triggers;
ALTER TABLE Triggers013f RENAME TO Triggers;
INSERT INTO TStubVersions(version) VALUES (4);