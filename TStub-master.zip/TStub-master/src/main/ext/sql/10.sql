DROP INDEX TStubVersions_version_uindex;
ALTER TABLE TStubVersions ADD userversion VARCHAR(20) NULL;