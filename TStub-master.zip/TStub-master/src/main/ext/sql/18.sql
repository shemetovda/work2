CREATE TABLE Templatesf4fd
(
  id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
  template TEXT NOT NULL,
  comment TEXT NOT NULL
);
INSERT INTO Templatesf4fd(id, template, comment) SELECT id, path, comment FROM Templates;
DROP TABLE Templates;
ALTER TABLE Templatesf4fd RENAME TO Templates;
INSERT INTO TStubVersions(version, userversion) VALUES (19, "1.4.1");