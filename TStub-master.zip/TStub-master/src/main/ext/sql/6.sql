INSERT INTO Params(name,value,description) VALUES ("TStub_title", "TStub","Название, которое будет отображаться в заголовке в веб-интерфейсе");
INSERT INTO TStubVersions(version) VALUES (7);