CREATE TABLE WorkerSteps806d
(
    triggerID INTEGER NOT NULL,
    stepNum INTEGER NOT NULL,
    stepType INTEGER NOT NULL,
    srcStepMessage INTEGER,
    stepTemplateid INTEGER,
    delay INTEGER(7),
    MQWriterid INTEGER,
    chance INTEGER(5),
    FOREIGN KEY (triggerID) REFERENCES Triggers (id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (stepType) REFERENCES StepType (id) ON UPDATE CASCADE,
    FOREIGN KEY (stepTemplateid) REFERENCES Templates (id) ON UPDATE CASCADE,
    FOREIGN KEY (MQWriterid) REFERENCES MQWriters (id) ON UPDATE CASCADE
);
INSERT INTO WorkerSteps806d(triggerID, stepNum, stepType, srcStepMessage, stepTemplateid, delay, MQWriterid, chance) SELECT triggerID, stepNum, stepType, srcStepMessage, stepTemplateid, delay, MQWriterid, chance FROM WorkerSteps;
DROP TABLE WorkerSteps;
ALTER TABLE WorkerSteps806d RENAME TO WorkerSteps;
INSERT INTO TStubVersions(version, userversion) VALUES (15, "1.3.6");