INSERT INTO Params(name,value,description) VALUES ("AutoStart", "false","Параметр определяющий запускать ли заглушку после загрузки автоматически.");
INSERT INTO Params(name,value,description) VALUES ("DataBase_minIdle", 0,"Минимальное количество неиспользуемых подключений к БД в пуле.");
INSERT INTO Params(name,value,description) VALUES ("DataBase_maxIdle", 50,"Максимальное количество неиспользуемых подключений к БД в пуле.");
INSERT INTO Params(name,value,description) VALUES ("DataBase_maxTotal", 50,"Максимальное общее количество подключений к БД в пуле.");
INSERT INTO Params(name,value,description) VALUES ("DataBase_maxWaitMillis", 5000,"Максимальное время ожидания до выдачи ошибки о недоступных подключениях к БД. Миллисекунды.");
INSERT INTO Params(name,value,description) VALUES ("DataBase_minEvictableIdleTimeMillis", 216000,"Минимальное время жизни подключения к БД, если оно не использовалось. Миллисекунды.");
INSERT INTO Params(name,value,description) VALUES ("DataBase_timeBetweenEvictionRunsMillis", 216000,"Время между проверками подключений к БД, которые долго не использовались с целью отключения. Миллисекунды.");
INSERT INTO TStubVersions(version, userversion) VALUES (17, "1.3.8");