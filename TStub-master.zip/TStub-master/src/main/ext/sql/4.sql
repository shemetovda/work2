CREATE TABLE MQReadersc110
(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    host CHAR(250) NOT NULL,
    port INTEGER(5) NOT NULL,
    manager CHAR(250) NOT NULL,
    channel CHAR(250) NOT NULL,
    queue CHAR(250) NOT NULL,
    active BOOLEAN DEFAULT 1 NOT NULL,
    numOfProviders INTEGER(2),
    SSLCertificateID INTEGER,
    login CHAR(100),
    password CHAR(128),
    selector CHAR(350),
    FOREIGN KEY (SSLCertificateID) REFERENCES SSLCertificates (id) ON UPDATE CASCADE
);
CREATE UNIQUE INDEX MQReaders_index_1 ON MQReadersc110 (host, port, manager, channel, queue, selector);
INSERT INTO MQReadersc110(id, host, port, manager, channel, queue, active, numOfProviders, SSLCertificateID, login, password) SELECT id, host, port, manager, channel, queue, active, numOfProviders, SSLCertificateID, login, password FROM MQReaders;
DROP TABLE MQReaders;
ALTER TABLE MQReadersc110 RENAME TO MQReaders;
INSERT INTO TStubVersions(version) VALUES (5);