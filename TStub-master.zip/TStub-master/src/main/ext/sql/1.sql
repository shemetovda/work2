CREATE TABLE MQWriters9e6b
(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    host CHAR(250) NOT NULL,
    port INTEGER(5) NOT NULL,
    manager CHAR(250) NOT NULL,
    channel CHAR(250) NOT NULL,
    queue CHAR(250) NOT NULL,
    active BOOLEAN DEFAULT 1 NOT NULL,
    numOfConsumers INTEGER(2),
    "default" BOOLEAN DEFAULT 0 NOT NULL,
    SSLCertificateID INTEGER,
    login CHAR(100),
    password CHAR(128),
    FOREIGN KEY (SSLCertificateID) REFERENCES SSLCertificates (id) ON UPDATE CASCADE
);
CREATE UNIQUE INDEX MQWriters_host_port_manager_channel_queue_uindex ON MQWriters9e6b (host, port, manager, channel, queue);
INSERT INTO MQWriters9e6b(id, host, port, manager, channel, queue, active, numOfConsumers, "default", SSLCertificateID, login, password) SELECT id, host, port, manager, channel, queue, active, numOfConsumers, "default", SSLCertificateID, login, password FROM MQWriters;
DROP TABLE MQWriters;
ALTER TABLE MQWriters9e6b RENAME TO MQWriters;
DROP INDEX MQWriters_host_port_manager_channel_queue_uindex;
CREATE TABLE MQWriters2607
(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    host CHAR(250) NOT NULL,
    port INTEGER(5) NOT NULL,
    manager CHAR(250) NOT NULL,
    channel CHAR(250) NOT NULL,
    queue CHAR(250) NOT NULL,
    active BOOLEAN DEFAULT 1 NOT NULL,
    numOfConsumers INTEGER(2),
    "default" BOOLEAN DEFAULT 0 NOT NULL,
    SSLCertificateID INTEGER,
    login CHAR(100),
    password CHAR(128),
    FOREIGN KEY (SSLCertificateID) REFERENCES SSLCertificates (id) ON UPDATE CASCADE
);
CREATE UNIQUE INDEX MQWriters_host_port_manager_channel_queue_uindex ON MQWriters2607 (host, port, manager, channel, queue);
INSERT INTO MQWriters2607(id, host, port, manager, channel, queue, active, numOfConsumers, "default", SSLCertificateID, login, password) SELECT id, host, port, manager, channel, queue, active, numOfConsumers, "default", SSLCertificateID, login, password FROM MQWriters;
DROP TABLE MQWriters;
ALTER TABLE MQWriters2607 RENAME TO MQWriters;
INSERT INTO Params(name,value,description) VALUES ("resendOnERROR_attempts", 1,"Количество попыток повторной отправки сообщений в MQ. Не меньше 1.");
INSERT INTO Params(name,value,description) VALUES ("writer_maxQueueLength", 500,"Максимальный размер очереди на отправку. При достижении размера принудительно замедляется работа заглушки.");
INSERT INTO Params(name,value,description) VALUES ("writer_minIdle", 0,"Минимальное количество неиспользуемых подключений на запись в пуле.");
INSERT INTO Params(name,value,description) VALUES ("writer_maxIdle", 10,"Максимальное количество неиспользуемых подключений на запись в пуле.");
INSERT INTO Params(name,value,description) VALUES ("writer_maxTotal", 10,"Максимальное общее количество подключений на запись в пуле.");
INSERT INTO Params(name,value,description) VALUES ("writer_maxWaitMillis", 5000,"Максимальное время ожидания до выдачи ошибки о недоступных подключениях на запись. Миллисекунды.");
INSERT INTO Params(name,value,description) VALUES ("writer_minEvictableIdleTimeMillis", 216000,"Минимальное время жизни подключения на запись, если оно не использовалось. Миллисекунды.");
INSERT INTO Params(name,value,description) VALUES ("writer_timeBetweenEvictionRunsMillis", 216000,"Время между проверками подключений, которые долго не использовались с целью отключения. Миллисекунды.");
INSERT INTO TStubVersions(version) VALUES (2);