# Универсальный фреймворк заглушек

Инструкция: https://confluence.ca.sbrf.ru/display/YNTiA/unistub

Схема: http://confluence.ca.sbrf.ru/display/YNTiA/Unistub+scheme