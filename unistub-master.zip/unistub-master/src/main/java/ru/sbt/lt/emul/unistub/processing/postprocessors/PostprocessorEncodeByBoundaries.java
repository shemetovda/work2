package ru.sbt.lt.emul.unistub.processing.postprocessors;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class PostprocessorEncodeByBoundaries implements IPostprocessor{
        String _LB = "";
        String _RB = "";
        
    public PostprocessorEncodeByBoundaries(String LB, String RB){
        _LB = LB;
        _RB = RB;
    }
    @Override
    public UnifiedMessage postprocess(UnifiedMessage message) {
        String body = message.getBody();
        String decoded = StringUtils.substringBetween(body, _LB, _RB);
        
        String encoded = Base64.encodeBase64String(decoded.getBytes());
              
        String newBody = StringUtils.replace(body, decoded, encoded);
        message.setBody(newBody);
        return message;
    }
}
