package ru.sbt.lt.emul.unistub.connections.database;

import ru.sbt.lt.emul.unistub.StubRunner;

import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBService{

    private static final Logger logger = Logger.getLogger(StubRunner.class.getName());

    private Connection connection = null;

    public DBService(String type, String host, int port, String schema, String login, String password) 
			throws ClassNotFoundException, SQLException {
        connection = DBConnectionFactory.createConnectionByDBType(type, host, port, schema, login, password);
        if(connection == null){
            throw new SQLException(type + "databases not supported!");
        }
    }

    public String doSqlQuery(String sqlQuery, List<String> parameters, Integer timeout) {
        String result = null;
        try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            for (int i = 0; i < parameters.size(); i++) {
                statement.setString(i + 1, parameters.get(i));
            }
            statement.setQueryTimeout(timeout);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    result = resultSet.getObject(1).toString();
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "SQL query wasn't execute!\n{0}" , e);
        }
		
        return result;
    }

    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
				logger.log(Level.WARNING, "Error occured when closing DB connection!\n{0}" , e);
            }
        }
    }
}
