package ru.sbt.lt.emul.unistub.processing.extractors;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ExtractString implements IExtractor{
    private final String _extractorName;
    private final String _stringValue;
    
    public ExtractString(String extractorName, String stringValue){
        _extractorName = extractorName;
        _stringValue = stringValue;
    }
    @Override
    public String extractFrom(UnifiedMessage message) {
        return _stringValue;
    }

    @Override
    public String getName() {
        return _extractorName;
    }
    
}
