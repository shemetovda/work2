package ru.sbt.lt.emul.unistub.stats;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;
import ru.sbt.lt.emul.unistub.SMS_AgentAdapter;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.processing.OperationStatistics;


/**
 *
 * @author sbt-verbovskiy-dm
 */
public class StatsSender implements Runnable {
    private static final Logger logger = Logger.getLogger(StatsSender.class.getName());
    int _sendDelayMs;
    int OrderId;
    String _url;
    
    public StatsSender(int sendDelaySec, String url){
      _sendDelayMs = sendDelaySec*1000;  
      _url = url;
      OrderId = 1;
      
      
    }
        
    public void sendStats(){
        
        logger.log(Level.INFO, "Processed: {0}", StubRunner.global_processed_count);
        logger.log(Level.INFO, "Failed: {0}", StubRunner.global_failed_count);
        logger.log(Level.FINE, "AgentName: {0}", SMS_AgentAdapter.AgentName);
        logger.log(Level.FINE, "SessionId: {0}", SMS_AgentAdapter.SessionId);
        logger.log(Level.FINE, "StubName: {0}", SMS_AgentAdapter.StubName);
        logger.log(Level.INFO, "_____________________________________");
        
        OrderId += 1;
        try {
            String body = getStatusBody();
            logger.log(Level.INFO, body);            
            sendPost(_url, body);
            
        } catch (IOException ex) {
            logger.log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void run() {
        
        while (true){
            try {
                Thread.sleep(_sendDelayMs);
            } catch (InterruptedException ex) {
               logger.log(Level.SEVERE, null, ex);
            }


            sendStats();
        }
    }
    
    public void sendPost(String url, String body) throws MalformedURLException, IOException{
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        
        con.setRequestMethod("POST");
        
        con.setDoOutput(true);
        try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
            wr.writeBytes(body);
            wr.flush();
        }
        
        int responseCode = con.getResponseCode();
        
        StringBuffer response;
        try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
            String inputLine;
            response = new StringBuffer();
            while ((inputLine = in.readLine()) != null){
                response.append(inputLine);
            }
        }
    }

    private String getStatusBody() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<StubStatusRq>\n");
        sb.append("    <SessionId>").append(SMS_AgentAdapter.SessionId).append("</SessionId>\n");
        sb.append("    <InitialTaskID>").append(SMS_AgentAdapter.InitialTaskID).append("</InitialTaskID>\n");
        sb.append("    <AgentName>").append(SMS_AgentAdapter.AgentName).append("</AgentName>\n");
        sb.append("    <StubName>").append(SMS_AgentAdapter.StubName).append("</StubName> \n");
        sb.append("    <OrderId>").append(OrderId).append("</OrderId>\n");
        sb.append("    <Timestamp>").append(new Timestamp(System.currentTimeMillis())).append("</Timestamp>\n");
        sb.append("    <Operations>\n");
        sb.append("        <Operation>\n");
        sb.append("            <opName>Total Statistic</opName>\n");
        sb.append("            <Params>\n");
        sb.append("                <Param name=\"Incoming\">").append(StubRunner.global_incoming_count).append("</Param>\n");
        sb.append("                <Param name=\"Processed\">").append(StubRunner.global_processed_count).append("</Param>\n");
        sb.append("                <Param name=\"Failed\">").append(StubRunner.global_failed_count).append("</Param>\n");
        sb.append("            </Params>\n");
        sb.append("        </Operation>\n");
        
        for (OperationStatistics s: StubRunner.processings.getStatistics()){
            sb.append("        <Operation>\n");
            sb.append("         <opName>").append(s.get_op_name()).append("</opName>\n");
            sb.append("            <Params>\n");
            sb.append("                <Param name=\"Processed\">").append(s.get_processed_count()).append("</Param>\n");
            sb.append("                <Param name=\"Failed\">").append(s.get_failed_count()).append("</Param>\n");
            sb.append("            </Params>\n");
            sb.append("        </Operation>\n");
        }       

        sb.append("    </Operations>\n");
        sb.append("</StubStatusRq>");


        return sb.toString();
  
    }
}
