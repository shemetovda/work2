package ru.sbt.lt.emul.unistub.processing;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import static ru.sbt.lt.emul.unistub.StubRunner.config;
import ru.sbt.lt.emul.unistub.configuration.ConfigHandler;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class BasicProcessingManager {
	private static final Logger logger = Logger.getLogger(BasicOperationProcessing.class.getName());

	private final static HashMap<String, BasicOperationProcessing> processings = new HashMap<>();
	private final static HashMap<String, OperationStatistics> statistics = new HashMap<>();
	private final static HashMap<String, Delay> delays = new HashMap<>();

	public BasicProcessingManager() {
		List<String> opNames = config.getList(String.class, "/Processing/Operations/Operation/@Name");
		for (String name : opNames) {
			if (!name.equals("DEFAULT")) {
				try {
					OperationStatistics stat = new OperationStatistics(name);
					statistics.put(name, stat);
					delays.put(name, ConfigHandler.getDelayForOperation(name));
					processings.put(name, new BasicOperationProcessing(name, stat));
				} catch (Exception ex) {
					logger.log(Level.SEVERE, "Unable to add processing for operation: {0}", name);
					ex.printStackTrace();
				}
			}
		}
	}

	public static BasicOperationProcessing getProcessingForOperation(String opName) {
		BasicOperationProcessing out = processings.get(opName);
		if (out == null) {
			logger.log(Level.SEVERE, "Not found processing for operation: {0}", opName);
		}

		return out;
	}

	public static Delay getDelayForOperation(String opName) {
		Delay out = delays.get(opName);
		if (out == null) {
			logger.log(Level.SEVERE, "Not found delay for operation: {0}", opName);
		}

		return out;
	}

	public static void setDelayForOperation(String opName, Delay d) {
		delays.put(opName, d);
	}

	public static Collection<OperationStatistics> getStatistics() {
		return statistics.values();
	}
}
