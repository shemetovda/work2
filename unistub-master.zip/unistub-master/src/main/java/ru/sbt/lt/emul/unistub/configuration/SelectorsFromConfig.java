package ru.sbt.lt.emul.unistub.configuration;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.configuration2.HierarchicalConfiguration;
import org.apache.commons.configuration2.XMLConfiguration;
import org.apache.commons.configuration2.tree.ImmutableNode;
import ru.sbt.lt.emul.unistub.connections.Selector;

/**
 *
 * @author sbt-chernov-dv
 */
public class SelectorsFromConfig {
	private static final Logger logger = Logger.getLogger(SelectorsFromConfig.class.getName());

	private static List<Selector> selectors;

	public SelectorsFromConfig(XMLConfiguration config) throws Exception {
		selectors = new LinkedList<>();
		List<HierarchicalConfiguration<ImmutableNode>> selectorNodes = config.configurationsAt("Selectors/Selector");
		for (HierarchicalConfiguration s : selectorNodes) {
			String property = s.getString("Property");
			String value = s.getString("Value");
			int input = 1;
			try {
				input = Integer.valueOf(s.getString("InputCount"));
			} catch (NumberFormatException ex) {
				if (s.getString("InputCount") != null) {
					logger.log(Level.SEVERE, "InputCount must be a number!");
					throw new Exception();
				}
			}
			selectors.add(new Selector(property, value, input));
		}

		if (selectors.isEmpty()) {
			selectors.add(new Selector(null, null, 1));
		}
	}

	public static List<Selector> getSelectors() {
		return selectors;
	}
}
