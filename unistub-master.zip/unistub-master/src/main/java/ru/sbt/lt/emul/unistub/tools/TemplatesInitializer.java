package ru.sbt.lt.emul.unistub.tools;

import java.io.File;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class TemplatesInitializer {
    private static final Logger logger = Logger.getLogger(TemplatesInitializer.class.getName());
    private static ConcurrentHashMap<String, File> templates;
		
    public static ConcurrentHashMap<String, File> getTemplates(String templatesPath) {
        templates = new ConcurrentHashMap<>();
		
	File folder = new File(templatesPath);
        File[] listOfFiles = folder.listFiles();

        for (File f: listOfFiles) {
			String tname = f.getName();
			templates.put(tname, f);
			logger.log(Level.INFO, "Loading template: {0} ...", tname);
		}
        
        return templates;
    }

}
