package ru.sbt.lt.emul.unistub.processing.postextractors;

import ru.sbt.lt.emul.unistub.processing.postextractors.IPostExtractor;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.connections.database.DBService;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExtractBySqlQuery implements IPostExtractor{

    private HashMap<String, String> extractors;

    private final String extractorName;
    private final String dataBaseName;
    private final String sqlQuery;
    private final List<String> extractedNames;
    private Integer timeout = 60;
    private final String defaultValue;
	
	private boolean valueExtracted = false;
	private String value = null;

    public ExtractBySqlQuery(String extractorName
			, String dataBaseName
			, String sqlQuery
			, List<String> extractedNames
			, Integer timeout
			, String defaultValue) {

        this.extractorName = extractorName;
        this.dataBaseName = dataBaseName;
        this.sqlQuery = sqlQuery;
        this.extractedNames = extractedNames;
        if(timeout != null) {
            this.timeout = timeout;
        }
        this.defaultValue = defaultValue;
    }

    @Override
    public String extractFrom(UnifiedMessage message) {
        DBService dbService = StubRunner.dbServicesFromConfig.getDBService(dataBaseName);
        List<String> parameters = new ArrayList<>();
		extractedNames.forEach((extractName) -> {
			parameters.add(extractors.get(extractName));
		});
        
		String result;
		if (!valueExtracted) {
			result = dbService.doSqlQuery(sqlQuery, parameters, timeout);
			valueExtracted = true;
			value = result;
		} else {
			result = value;
		}
		
		if(result == null)
            return defaultValue;
		
        return result;
    }

    @Override
    public String getName() {
        return extractorName;
    }

    @Override
    public void setExtractorsMap(HashMap<String, String> extractors) {
        this.extractors = extractors;
    }
}
