package ru.sbt.lt.emul.unistub.connections;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;
import javax.jms.JMSException;
import ru.sbt.lt.emul.unistub.core.QParams;
import ru.sbt.lt.emul.unistub.connections.Selector;
import ru.sbt.lt.emul.unistub.core.MessagePool;
import ru.sbt.lt.emul.unistub.core.PoolPushers.IPusher;
import ru.sbt.lt.emul.unistub.core.PoolPushers.QueuePusher;

/**
 *
 * @author sbt-chernov-dv
 */
public class Receiving {
	private static final Logger logger = Logger.getLogger(MessagePool.class.getName());

	private final List<PoolUpdater> poolFiller = new LinkedList<>();

	public Receiving(QParams inQueue, MessagePool inPool, List<Selector> selectors) throws JMSException {
		for (Selector s : selectors) {
			IPusher pusher;
			for (int i = 0; i < s.getInputCount(); i++) {
				pusher = new QueuePusher(inQueue, s);
				poolFiller.add(new PoolUpdater(inPool, pusher));
			}
		}
	}

	public void start() {
		poolFiller.forEach(updater -> {
			updater.start();
		});
	}
}
