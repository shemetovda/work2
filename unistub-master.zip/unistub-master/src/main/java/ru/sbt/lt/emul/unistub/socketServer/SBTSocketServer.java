package ru.sbt.lt.emul.unistub.socketServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Класс обвертка над socket server-ом - запускает сервер
 *
 * @author SBT-Pugachev-VV
 */
public class SBTSocketServer extends Thread {


    private static final Logger logger = Logger.getLogger(SBTSocketServer.class.getName());
    private final int port;

    public SBTSocketServer(int _port) {
        this.port = _port;

    }

    @Override
    public void run() {

        try (ServerSocket serverSocket = new ServerSocket(port)) {

            // запускаем сервер
            while (true) {
                
                SocketHandler socketHandler = new SocketHandler(serverSocket.accept());
                socketHandler.start();
            }
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Problems with starting socket Server or accepting sokect connection", ex);
        }
    }
}