package ru.sbt.lt.emul.unistub.processing.extractors;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;


public class ExtractMatchingRegexp implements IExtractor {
    
    private final String _extractorName;
    private final String _regexp;
    private final String _ifTrue;
    private final String  _ifFalse;
    private final Pattern pattern;
    
    public ExtractMatchingRegexp(String extractorName, String regexp, String ifTrue, String ifFalse){
        _extractorName = extractorName;
        _regexp = regexp;
        pattern = Pattern.compile(".*"+regexp+".*", Pattern.DOTALL);
        _ifTrue = ifTrue;
		
		if (ifFalse == null)
			_ifFalse = "";
		else 
			_ifFalse = ifFalse;
                
    }
    @Override
    public String extractFrom(UnifiedMessage message) {

        String out;
        String body = message.getBody();
        HashMap<String, String> headers = message.getAdditionalProperties();
        
        //header search
        for (Map.Entry<String,String> hp : headers.entrySet()) {
            
            String headerkey = hp.getKey();
            String headervalue = hp.getValue();
            
            Matcher hkmatcher = pattern.matcher(headerkey);
            Matcher hvmatcher = pattern.matcher(headervalue);
            
            boolean hkmatch = hkmatcher.matches();
            boolean hvmatch = hvmatcher.matches();
            if (hkmatch || hvmatch){
                out = _ifTrue;
                return out;
            }
        }
        //body search
        Matcher matcher = pattern.matcher(body);
        
        boolean match = matcher.matches();

        if (match){
            out = _ifTrue;
        }
        else{
            out = _ifFalse;
        }
        return out;
        
    }

    @Override
    public String getName() {
        return _extractorName;
    }
    
}
