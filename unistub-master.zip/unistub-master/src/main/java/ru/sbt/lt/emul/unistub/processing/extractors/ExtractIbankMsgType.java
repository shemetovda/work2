package ru.sbt.lt.emul.unistub.processing.extractors;

import java.math.BigInteger;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ExtractIbankMsgType implements IExtractor{
    private final String _extractorName;
    
    public ExtractIbankMsgType(String extractorName){        
        _extractorName = extractorName;
    }

    @Override
    public String extractFrom(UnifiedMessage message) {
        String body = message.getBody();
        byte[] b = new BigInteger(body, 16).toByteArray();
        String out = new String(b, 0, 4);
        return out;
    }

    @Override
    public String getName() {
        return _extractorName;
    }
}

