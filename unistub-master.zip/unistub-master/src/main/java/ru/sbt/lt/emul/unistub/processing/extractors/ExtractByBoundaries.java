package ru.sbt.lt.emul.unistub.processing.extractors;

import org.apache.commons.lang3.StringUtils;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ExtractByBoundaries implements IExtractor{
    
    private final String _extractorName;
    private final String _LB;
    private final String _RB;
    
    public ExtractByBoundaries(String extractorName, String LB, String RB){
        _extractorName = extractorName;
        _LB = LB;
        _RB = RB;
    }
    @Override
    public String extractFrom(UnifiedMessage message) {
        String body = message.getBody();
        String val = StringUtils.substringBetween(body, _LB, _RB);
        return val;
    }

    @Override
    public String getName() {
        return _extractorName;
    }
}
