package ru.sbt.lt.emul.unistub.processing.replacers;

import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ReplaceByBoundaries implements IReplacer {
	private final String LB;
	private final String RB;
	private final String extractedName;

	public ReplaceByBoundaries(String LB, String RB, String extractedName) {
		this.extractedName = extractedName;
		this.LB = LB;
		this.RB = RB;
	}

	@Override
	public String replace(String message, String replaceWith) {
		String toReplace = StringUtils.substringBetween(message, LB, RB);
		String outgoingString = StringUtils.replace(message, toReplace, replaceWith);
		return outgoingString;
	}

	@Override
	public String getExtractedName() {
		return extractedName;
	}
}
