package ru.sbt.lt.emul.unistub.stats;

import ru.sbt.lt.emul.unistub.core.QParams;

/**
 *
 * @author sbt-chernov-dv
 */
public interface IStatsSender {
	public void addStats(QParams params, String step, long timestamp, String opName);
}
