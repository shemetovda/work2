package ru.sbt.lt.emul.unistub.configuration;

import java.util.HashMap;
import java.util.List;
import org.apache.commons.configuration2.HierarchicalConfiguration;
import org.apache.commons.configuration2.XMLConfiguration;
import org.apache.commons.configuration2.tree.ImmutableNode;
import ru.sbt.lt.emul.unistub.core.QParams;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class QueuesFromConfig {
	private static HashMap<String, QParams> qList;
	private static QParams inputQueue;
	private static String selectorProperty = null;
	private static String selectorValue = null;

	public static QParams getQ(String qName) {
		QParams out = qList.get(qName);
		return out;
	}

	public static HashMap<String, QParams> getQueues() {
		return qList;
	}

	public static QParams getInputQueue() {
		return inputQueue;
	}

	public static String getSelectorString() {
		if (selectorProperty != null && selectorValue != null) {
			return selectorProperty + " = '" + selectorValue + "'";
		} else {
			return null;
		}
	}

	public QueuesFromConfig(XMLConfiguration config, String inputQLabel) {
		qList = new HashMap<>();
		List<HierarchicalConfiguration<ImmutableNode>> queues = config.configurationsAt("Queues/Queue");
		for (HierarchicalConfiguration q : queues) {
			String label = q.getString("Label");
			String server = q.getString("Server");
			int port = q.getInt("Port");
			String qmanager = q.getString("Qmanager");
			String channel = q.getString("Channel");
			String queue = q.getString("Queue");
			String user = q.getString("User");
			String password = q.getString("Password");

			QParams qParams = new QParams(server, port, qmanager, channel, queue, user, password);
			if (label.equals(inputQLabel)) {
				inputQueue = qParams;
			} else {
				qList.put(label, qParams);
			}
		}
	}
}
