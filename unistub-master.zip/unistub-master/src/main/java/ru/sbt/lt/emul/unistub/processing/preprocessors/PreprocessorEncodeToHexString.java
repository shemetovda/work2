package ru.sbt.lt.emul.unistub.processing.preprocessors;

import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.codec.binary.Hex;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;


/**
 *
 *  @author SBT-Pugachev-VV
 */
public class PreprocessorEncodeToHexString implements IPreprocessor  {
       
        
    public PreprocessorEncodeToHexString(){
        
    }
    
    @Override
    public UnifiedMessage preprocess(UnifiedMessage message)  {
        String body = message.getBody();
        
        String encodedBody = "";               
        try {
            encodedBody = Hex.encodeHexString(body.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(PreprocessorEncodeToHexString.class.getName())
                    .log(Level.SEVERE, "Problems with PreprocessorEncodeToHexString\n", ex);
        } 
        
        message.setBody(encodedBody);
        
        return message;
    }    
}
