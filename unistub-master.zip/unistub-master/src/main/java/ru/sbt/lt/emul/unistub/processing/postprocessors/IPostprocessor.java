package ru.sbt.lt.emul.unistub.processing.postprocessors;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author Sbt-verbovskiy-dm
 */
public interface IPostprocessor {
    public UnifiedMessage postprocess(UnifiedMessage message);
}
