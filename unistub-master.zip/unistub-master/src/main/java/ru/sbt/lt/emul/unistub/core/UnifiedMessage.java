package ru.sbt.lt.emul.unistub.core;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.BytesMessage;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.TextMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class UnifiedMessage {
	private static final Logger logger = Logger.getLogger(UnifiedMessage.class.getName());

	private String opName;
	private String body;
	private String correlationId;
	private String messageId;
	private Queue replyToQ;
	private String replyTo;
	private Destination dest;
	private long delay = 0;
	private HashMap<String, String> additionalProperties = new HashMap<>();
	private boolean isSecondSender = false;
	private boolean bypassDestination = false;
	private boolean bypassReplyTo = false;
	private boolean copyReplyTo = false;
	private boolean isHttpMessage = false;

	// This class is used to store and pass messages throught processing.
	public UnifiedMessage(String s) {
		body = s;
	}

	public UnifiedMessage(javax.jms.Message m) {
		try {
			correlationId = m.getJMSCorrelationID();
			messageId = m.getJMSMessageID();
			replyToQ = (Queue) m.getJMSReplyTo();
			dest = m.getJMSReplyTo();
			for (Enumeration<String> en = m.getPropertyNames(); en.hasMoreElements();) {
				String curProperty = en.nextElement();
				additionalProperties.put(curProperty, m.getStringProperty(curProperty));
			}

			if (replyToQ != null) {
				replyTo = replyToQ.toString();
			} else {
				replyTo = "NA";
			}

			if (m instanceof TextMessage) {
				body = ((TextMessage) m).getText();
			} else if (m instanceof BytesMessage) {
				BytesMessage bm = (BytesMessage) m;
				byte[] bArr = new byte[(int) bm.getBodyLength()];
				bm.readBytes(bArr);
				body = new String(bArr);
			}
		} catch (JMSException ex) {
			logger.log(Level.SEVERE, "Failed to parse incoming message!");
		}
	}

	public boolean isSecondSender() {
		return isSecondSender;
	}

	public void secondSender() {
		isSecondSender = true;
	}

	public void addAdditionalProperty(String key, String value) {
		this.additionalProperties.put(key, value);
	}

	public void setAdditionalProperties(HashMap<String, String> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

	public void setInReplyTo(String replyTo) {
		this.replyTo = replyTo;
	}

	public String getInReplyTo() {
		return replyTo;
	}

	public void setDestination(Destination dest) {
		this.dest = dest;
	}

	public Destination getDestination() {
		return dest;
	}

	public void setBody(String newBody) {
		body = newBody;
	}

	public String getBody() {
		return body;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getCorrelationId() {
		if (correlationId != null) {
			return correlationId;
		} else {
			return "NA";
		}
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getMessageId() {
		return messageId;
	}

	public HashMap<String, String> getAdditionalProperties() {
		return additionalProperties;
	}

	public String getOpName() {
		return opName;
	}

	public void setOpName(String name) {
		opName = name;
	}

	public long getDelay() {
		return delay;
	}

	public void setDelay(long delay) {
		this.delay = delay;
	}

	public void setBypassDestination(boolean flag) {
		bypassDestination = flag;
	}

	public void setBypassReplyTo(boolean flag) {
		bypassReplyTo = flag;
	}

	public void setCopyReplyTo(boolean flag) {
		copyReplyTo = flag;
	}

	public void setHttpMessage(boolean flag) {
		isHttpMessage = flag;
	}

	public boolean isBypassDestination() {
		return bypassDestination;
	}

	public boolean isBypassReplyTo() {
		return bypassReplyTo;
	}

	public boolean isCopyReplyTo() {
		return copyReplyTo;
	}

	public boolean isHttpMessage() {
		return isHttpMessage;
	}
}
