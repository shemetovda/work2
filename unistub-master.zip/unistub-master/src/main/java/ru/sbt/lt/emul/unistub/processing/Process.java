package ru.sbt.lt.emul.unistub.processing;

import java.util.logging.Level;
import java.util.logging.Logger;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.configuration.ConfigHandler;
import ru.sbt.lt.emul.unistub.core.DelayedMessagePool;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class Process implements Runnable {
	private static final Logger logger = Logger.getLogger(Process.class.getName());
	UnifiedMessage raw;
	DelayedMessagePool outPool;

	public Process(UnifiedMessage m, DelayedMessagePool out) {
		raw = m;
		outPool = out;
	}

	@Override
	public void run() {
		logger.log(Level.FINE, "_______________________");
		logger.log(Level.FINE, "INCOMING: {0}", raw.getBody());
		StubRunner.global_incoming_count.getAndIncrement();
		String opName = IncomingNameExtractor.extractFrom(raw);
		logger.log(Level.FINE, "INCOMING OPERATION NAME: {0}", opName);
		try {
			BasicOperationProcessing p = BasicProcessingManager.getProcessingForOperation(opName);
			Delay d = BasicProcessingManager.getDelayForOperation(opName);
			UnifiedMessage out = p.process(raw);
			out.setOpName(opName);
			out.setBypassDestination(ConfigHandler.getBypassDestination(opName));
			out.setBypassReplyTo(ConfigHandler.getBypassReplyTo(opName));
			out.setCopyReplyTo(ConfigHandler.getCopyReplyTo(opName));
			outPool.put(d.getDelayTime(), out);
			d.sumDelayStats();
		} catch (NullPointerException ex) {
			StubRunner.global_failed_count.getAndIncrement();
		}
	}
}
