package ru.sbt.lt.emul.unistub.processing;

import java.io.File;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class GetTemplate {
    
    public static File byName(ConcurrentHashMap<String, File> templates, String name) throws Exception {
        File out = templates.get(name);
        if (out == null){
            Logger.getLogger(GetTemplate.class.getName()).log(Level.SEVERE, "Template not found: {0}", name);
            throw new Exception();
        }
        
        return out;
    }
}
