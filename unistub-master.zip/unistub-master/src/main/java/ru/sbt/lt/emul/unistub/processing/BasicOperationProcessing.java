package ru.sbt.lt.emul.unistub.processing;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.transform.TransformerException;
import org.w3c.dom.Document;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.configuration.ConfigHandler;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;
import ru.sbt.lt.emul.unistub.inserters.IInserter;
import ru.sbt.lt.emul.unistub.processing.extractors.IExtractor;
import ru.sbt.lt.emul.unistub.processing.postextractors.IPostExtractor;
import ru.sbt.lt.emul.unistub.processing.postprocessors.IPostprocessor;
import ru.sbt.lt.emul.unistub.processing.preprocessors.IPreprocessor;
import ru.sbt.lt.emul.unistub.processing.replacers.IDomReplacer;
import ru.sbt.lt.emul.unistub.processing.replacers.IReplacer;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class BasicOperationProcessing {
	private static final Logger logger = Logger.getLogger(BasicOperationProcessing.class.getName());

	final private List<IExtractor> extractors;
	final private List<IPreprocessor> preprocessors;
	final private List<IPostprocessor> postprocessors;
	final private List<IInserter> inserters;
	final private List<IPostExtractor> postextractors;

	final private OperationStatistics statistics;
	final private MessageTransformer messageTransformer;
	final private String tName;
	final private boolean jmsCopy;

	private List<IDomReplacer> domReplacers = new LinkedList<>();
	private List<IReplacer> stringReplacers = new LinkedList<>();
	public Document domMessage;
	private String template;

	public BasicOperationProcessing(String operName, OperationStatistics stat) throws Exception {
		tName = ConfigHandler.getTemplateForOperation(operName);
		messageTransformer = new MessageTransformer();
		domMessage = messageTransformer.toDOMDocument(GetTemplate.byName(StubRunner.templates, tName));
		template = messageTransformer.toStringMessage(GetTemplate.byName(StubRunner.templates, tName));
		getReplacers(operName);

		preprocessors = ConfigHandler.getPreprocessorsForOperation(operName);
		extractors = ConfigHandler.getExtractorsForOperation(operName);
		postextractors = ConfigHandler.getPostExtractorsForOperation(operName);

		inserters = ConfigHandler.getInsertersForOperation(operName);
		postprocessors = ConfigHandler.getPostprocessorsForOperation(operName);
		statistics = stat;
		jmsCopy = ConfigHandler.getHeaderCopyNeeded(operName);
	}

	public UnifiedMessage process(UnifiedMessage inMsg) {
		for (IPreprocessor p : preprocessors) {
			try {
				inMsg = p.preprocess(inMsg);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "Preprocessing failed!\n");
				logger.log(Level.SEVERE, ex.getMessage());
				StubRunner.global_failed_count.getAndIncrement();
				statistics.incrementFailed(1);
			}
		}
		if (!preprocessors.isEmpty()) {
			logger.log(Level.CONFIG, "PREPROCESSED:\n{0}", inMsg.getBody());
		}

		HashMap<String, String> extracted = ExtractAllFrom(inMsg);
		try {
			ReplaceAllInTemplate(extracted);
		} catch (TransformerException ex) {
			logger.log(Level.SEVERE, "Processing failed!\n");
			logger.log(Level.SEVERE, ex.getMessage());
			StubRunner.global_failed_count.getAndIncrement();
			statistics.incrementFailed(1);
		}

		UnifiedMessage outMsg = saveJMSHeaders(extracted, inMsg, template);

		for (IPostprocessor p : postprocessors) {
			try {
				outMsg = p.postprocess(outMsg);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "Postprocessing failed!\n");
				logger.log(Level.SEVERE, ex.getMessage());
				StubRunner.global_failed_count.getAndIncrement();
				statistics.incrementFailed(1);
			}
		}
		if (!postprocessors.isEmpty()) {
			logger.log(Level.CONFIG, "POSTPROCESSED:\n{0}", outMsg.getBody());
		}

		StubRunner.global_processed_count.getAndIncrement();
		statistics.incrementProcessed(1);
		return outMsg;
	}

	private HashMap<String, String> ExtractAllFrom(UnifiedMessage message) {
		HashMap<String, String> extracted = new HashMap<>();
		extractors.forEach((e) -> {
			String name = e.getName();
			String val = e.extractFrom(message);
			extracted.put(name, val);
		});
		postextractors.forEach((e) -> {
			e.setExtractorsMap(extracted);
			String name = e.getName();
			String val = e.extractFrom(message);
			extracted.put(name, val);
		});

		return extracted;
	}

	private void ReplaceAllInTemplate(HashMap<String, String> extracted) throws TransformerException {
		domReplacers.forEach((r) -> {
			String newVal = extracted.get(r.getExtractedName());
			r.replace(newVal);
		});

		template = messageTransformer.toStringMessage(domMessage);
		stringReplacers.forEach((r) -> {
			String newVal = extracted.get(r.getExtractedName());
			template = r.replace(template, newVal);
		});
	}

	private UnifiedMessage saveJMSHeaders(HashMap<String, String> extracted, UnifiedMessage inMsg, String out) {
		UnifiedMessage outMsg = new UnifiedMessage(out);

		/// Because headers needed for mq messages
		if (inMsg.isHttpMessage()) {
			return outMsg;
		}

		outMsg.setCorrelationId(inMsg.getMessageId());
		outMsg.setInReplyTo(inMsg.getInReplyTo());
		if (jmsCopy) {
			outMsg.setAdditionalProperties(inMsg.getAdditionalProperties());
		}

		inserters.forEach((IInserter i) -> {
			String newVal = extracted.get(i.getExtractedName());
			if (newVal != null) {
				i.insertTo(outMsg, newVal);
			} else {
				i.insertTo(outMsg);
			}
		});
		return outMsg;
	}

	public OperationStatistics getStatistics() {
		return statistics;
	}

	private void getReplacers(String operName) {
		stringReplacers = ConfigHandler.getStringReplacersForOperation(operName);
		domReplacers = ConfigHandler.getDomReplacersForOperation(operName);
		domReplacers.forEach(r -> {
			r.initDOM(domMessage);
		});
	}
}
