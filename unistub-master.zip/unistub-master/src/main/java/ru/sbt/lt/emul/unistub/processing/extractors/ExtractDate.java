package ru.sbt.lt.emul.unistub.processing.extractors;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ExtractDate implements IExtractor{ 
    
    private final String _extractorName;
    private final String _dateFormat;
    private final int _shift;
    
    public ExtractDate(String extractorName, String dateFormat, int shift){        
        _extractorName = extractorName;
        _dateFormat = dateFormat;
        _shift = shift;
    }

    @Override
    public String extractFrom(UnifiedMessage message) {
        
        DateFormat dateFormat = new SimpleDateFormat(_dateFormat);
        Date date = new Date();
        long time  = date.getTime();
        time += 1000L*60*_shift;
        date.setTime(time);
        String out = dateFormat.format(date);
        return out;
    }

    @Override
    public String getName() {
        return _extractorName;
    }
}
