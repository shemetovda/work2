package ru.sbt.lt.emul.unistub.processing.postprocessors;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.lang3.RandomStringUtils;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;
import ru.sbt.lt.emul.unistub.processing.IncomingNameExtractor;
import ru.sbt.lt.emul.unistub.tools.Reader;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class PostprocessorFolderInOut implements IPostprocessor{
    private static final Logger logger = Logger.getLogger(PostprocessorFolderInOut.class.getName());
    String _inputFolderPath = "";
    String _outputFolderPath = "";
    int _timeout;
        
    public PostprocessorFolderInOut(String inputFolderPath, String outputFolderPath, int timeout){
        _inputFolderPath = inputFolderPath;
        _outputFolderPath = outputFolderPath;
        _timeout = timeout;
    }
    
    @Override
    public UnifiedMessage postprocess(UnifiedMessage message) {
        String body = message.getBody();
        String opName = IncomingNameExtractor.extractFrom(message);
        

        
        long start = System.currentTimeMillis();
        long end = start + _timeout*1000;
        
        
        String msgID = opName + "_" + start + "_" + RandomStringUtils.randomAlphabetic(5);
                        
        String newBody = "No answer from external system processing, timeout is reached";
        
        File inFolder = new File(_inputFolderPath);
        
        File inFile = new File(inFolder, msgID+".lck");
            
        try {
                inFile.createNewFile();
            } catch (IOException ex) {
                logger.log(Level.SEVERE, "Unable to create file in external system input folder: {0}\n",ex);
            }
      
        try (FileWriter writer = new FileWriter(inFile)){
            writer.write(body);
            writer.close();
            File readyFile = new File(inFolder, msgID+".dump");
            inFile.renameTo(readyFile);
            
        }
        catch (IOException ex){
            logger.log(Level.SEVERE, "Unable to write in file in external input folder : {0}\n",ex);
        }
               
        
        File outFolder = new File(_outputFolderPath);
        
        boolean run = true;
        while(run && System.currentTimeMillis() < end){

            File[] listOfFiles = outFolder.listFiles();
             
            for (File f: listOfFiles) {
                File processedFile = new File(outFolder, msgID+".out");          
                if (f.getName().equals(processedFile.getName())){
                    try {
                        newBody = Reader.readFile(f.getAbsolutePath(), StandardCharsets.UTF_8);
                    } catch (IOException ex) {
                        Logger.getLogger(PostprocessorFolderInOut.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    f.delete();
                    run = false;
                }
            }
            
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                logger.log(Level.SEVERE, "Thread is dead");
            }
        }

            message.setBody(newBody);
            return message;
    }
}
