package ru.sbt.lt.emul.unistub.processing.extractors;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ExtractWholeMessage implements IExtractor{
    private final String _extractorName;
    public ExtractWholeMessage(String extractorName){
        _extractorName = extractorName;
    }
    @Override
    public String extractFrom(UnifiedMessage message) {
        return message.getBody();
    }

    @Override
    public String getName() {
        return _extractorName;
    }
    
    
}
