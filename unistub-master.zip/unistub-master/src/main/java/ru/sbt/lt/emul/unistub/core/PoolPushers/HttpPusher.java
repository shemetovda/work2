package ru.sbt.lt.emul.unistub.core.PoolPushers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.codec.binary.Base64;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.AbstractHandler;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;
import ru.sbt.lt.emul.unistub.processing.BasicOperationProcessing;
import ru.sbt.lt.emul.unistub.processing.BasicProcessingManager;
import ru.sbt.lt.emul.unistub.processing.Delay;
import ru.sbt.lt.emul.unistub.processing.IncomingNameExtractor;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public  class HttpPusher extends AbstractHandler{
    private static final Logger logger = Logger.getLogger(HttpPusher.class.getName());

    @Override
    public void handle( String target,
                        Request baseRequest,
                        HttpServletRequest request,
                        HttpServletResponse response ) throws IOException,
                                                      ServletException
    {
        InputStream is = request.getInputStream();   
        ByteArrayOutputStream os = new ByteArrayOutputStream();  
        byte[] buffer = new byte[0xFFFF];
        for (int len; (len = is.read(buffer)) != -1;){
            os.write(buffer, 0, len);
        }
        os.flush();
        byte[] b = os.toByteArray();
     
        if (Base64.isBase64(b)){
            b = Base64.decodeBase64(b);
        }
  
        if (request.getParameter("delay") != null) {
			String from = request.getParameter("from");
			String to = request.getParameter("to");
			String delayOpName = request.getParameter("opName");
			Delay d = null;
			try {
				d = new Delay(delayOpName,Integer.parseInt(from),Integer.parseInt(to));
				String responseBody = "Delay changed!";
				logger.log(Level.INFO, responseBody);
			} catch (NumberFormatException e){
				String responseBody = "Invalid delay format!";
				logger.log(Level.INFO, responseBody);
			}
			if (d!=null){
				BasicProcessingManager.setDelayForOperation(delayOpName, d);
				return;
			}
		}
        String requestBody = new String(b);
		UnifiedMessage raw = new UnifiedMessage(requestBody);
		raw.setHttpMessage(true);

		logger.log(Level.INFO, "_______________________");
		logger.log(Level.INFO, "INCOMING: {0}", raw.getBody());
		StubRunner.global_incoming_count.getAndIncrement();
		String opName = IncomingNameExtractor.extractFrom(raw);

		logger.log(Level.INFO, "INCOMING OPERATION NAME: {0}", opName);

		BasicOperationProcessing p = BasicProcessingManager.getProcessingForOperation(opName);
		UnifiedMessage processed = p.process(raw);
		
		try {
			BasicProcessingManager.getDelayForOperation(opName).sumDelayStats();
		} catch (NullPointerException ex) { }

		String responseBody = processed.getBody();

		logger.log(Level.INFO, "PREPARED RESPONSE BODY FOR OPERATION: {0}", responseBody);

		PrintWriter outWriter = response.getWriter();
		outWriter.print(responseBody);
		response.setContentType("text/html;charset=UTF-8");
        response.setStatus(HttpServletResponse.SC_OK);
        baseRequest.setHandled(true);
    }
}
