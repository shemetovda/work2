package ru.sbt.lt.emul.unistub.stats;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class Status {
    String _name;
    int _incomingCount = 0;
    int _outgoingCount = 0;
    float _successRate = 0;
    
    public Status(String name, int inc, int outg){
        _name = name;
        _incomingCount = inc;
        _outgoingCount = outg;
        _successRate = outg/(inc/100);
    }
    
    @Override
    public String toString(){
    return  ("<Operation>"+
            "<opName>"+_name+"</opName>"+	
            "<Params>"+
                "<Param name=\"Incoming messages count\">"+_incomingCount+"</Param>"+	
                "<Param name=\"Outgoing messages count\">"+_outgoingCount+"</Param>"+	
                "<Param name=\"Success rate\">"+_successRate+"</Param>"+	
            "</Params>"+	
            "</Operation>"); 
    }
}
