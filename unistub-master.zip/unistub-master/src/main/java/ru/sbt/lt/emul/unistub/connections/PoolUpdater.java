package ru.sbt.lt.emul.unistub.connections;

import ru.sbt.lt.emul.unistub.core.MessagePool;
import ru.sbt.lt.emul.unistub.core.PoolPushers.IPusher;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class PoolUpdater extends Thread {
	IPusher _pusher;
	MessagePool _pool;

	public PoolUpdater(MessagePool pool, IPusher pusher) {
		_pool = pool;
		_pusher = pusher;
	}

	@Override
	public void run() {
		while (true) {
			_pool.update(_pusher);
		}
	}
}
