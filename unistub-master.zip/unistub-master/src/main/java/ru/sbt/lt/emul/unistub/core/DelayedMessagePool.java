package ru.sbt.lt.emul.unistub.core;


import java.util.concurrent.DelayQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class DelayedMessagePool {
    private static final Logger logger = Logger.getLogger(MessagePool.class.getName());
	private final DelayQueue<DelayedUnifiedMessage<UnifiedMessage>> _q = new DelayQueue<>();
    
    public void put(long delay, UnifiedMessage m) {
		_q.put(new DelayedUnifiedMessage<>(delay, m));
    }
      
    public UnifiedMessage take() {
        UnifiedMessage m = null;
		try {
			DelayedUnifiedMessage<UnifiedMessage> dmsg = _q.take();
			m = dmsg.getData();
		} catch (InterruptedException ex) {
			logger.log(Level.SEVERE, "DelayedMessagePool was interrupted!");
		}
        return m;
    }

    public int getSize() { 
        return _q.size();
    } 
   
    
}
