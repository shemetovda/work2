package ru.sbt.lt.emul.unistub.processing;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import ru.sbt.lt.emul.unistub.core.DelayedMessagePool;
import ru.sbt.lt.emul.unistub.core.MessagePool;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class Processing implements Runnable {
  
    MessagePool inPool; 
	DelayedMessagePool outPool; 
    Thread p;
        
    public Processing(MessagePool in, DelayedMessagePool out) {
        inPool = in; 
		outPool = out; 
    }
    
    @Override
    public void run() {  
        ExecutorService threadPool = new ThreadPoolExecutor(100, 300, 6L, TimeUnit.SECONDS, new SynchronousQueue<Runnable>());
        while (true){
            threadPool.execute(new Process(inPool.take(), outPool));                        
        }
    }
}
