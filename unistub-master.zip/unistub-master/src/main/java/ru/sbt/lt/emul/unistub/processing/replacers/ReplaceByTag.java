package ru.sbt.lt.emul.unistub.processing.replacers;

import java.util.logging.Logger;
import org.w3c.dom.Document;

import org.w3c.dom.NodeList;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class ReplaceByTag implements IDomReplacer {
	private static final Logger logger = Logger.getLogger(ReplaceByTag.class.getName());

	private String tagName;
	private String extractedName;

	private NodeList nodes = null;

	public ReplaceByTag(String tagName, String extractedName) {
		this.extractedName = extractedName;
		this.tagName = tagName;
	}

	@Override
	public void replace(String replaceWith) {
		for (int i = 0; i < nodes.getLength(); i++) {
			nodes.item(i).setTextContent(replaceWith);
		}
	}

	@Override
	public String getExtractedName() {
		return extractedName;
	}

	@Override
	public void initDOM(Document template) {
		nodes = template.getElementsByTagName(tagName);
	}

	@Override
	public String replace(String message, String replaceWith) {
		return message;
	}

	@Override
	public IDomReplacer clone() {
		return new ReplaceByTag(tagName, extractedName);
	}
}
