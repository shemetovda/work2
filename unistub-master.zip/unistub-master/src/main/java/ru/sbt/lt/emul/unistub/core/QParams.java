package ru.sbt.lt.emul.unistub.core;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class QParams {
    private final String _server;
    private final int _port;
    private final String _qmanager;
    private final String _channel;
    private final String _queue;
    private final String _user;
    private final String _password;
    
	// This class is used to store parameters of mq connection.
    public QParams(String server, int port, String qmanager, String channel, String queue, String user, String password){
        _server = server;
        _port = port;
        _qmanager = qmanager;
        _channel = channel;
        _queue = queue;
        _user = user;
        _password = password;
    }

    public String getServer() {
        return _server;
    }

    public int getPort() {
        return _port;
    }

    public String getQmanager() {
        return _qmanager;
    }

    public String getChannel() {
        return _channel;
    }

    public String getQueue() {
        return _queue;
    }
    
	public String getUser() {
        return _user;
    }
        
	public String getPassword() {
        return _password;
    }
}
