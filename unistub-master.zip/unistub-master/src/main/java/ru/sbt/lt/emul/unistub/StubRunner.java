package ru.sbt.lt.emul.unistub;

import java.io.File;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;

import org.apache.commons.configuration2.XMLConfiguration;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.eclipse.jetty.http.HttpVersion;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.HttpConfiguration;
import org.eclipse.jetty.server.HttpConnectionFactory;
import org.eclipse.jetty.server.SecureRequestCustomizer;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.server.SslConnectionFactory;
import org.eclipse.jetty.util.ssl.SslContextFactory;
import ru.sbt.lt.emul.unistub.configuration.ConfigHandler;
import ru.sbt.lt.emul.unistub.configuration.DBServicesFromConfig;
import ru.sbt.lt.emul.unistub.configuration.QueuesFromConfig;
import ru.sbt.lt.emul.unistub.configuration.SelectorsFromConfig;
import ru.sbt.lt.emul.unistub.configuration.XMLConfig;
import ru.sbt.lt.emul.unistub.core.QParams;
import ru.sbt.lt.emul.unistub.core.DelayedMessagePool;
import ru.sbt.lt.emul.unistub.core.MessagePool;
import ru.sbt.lt.emul.unistub.core.PoolPushers.HttpPusher;
import ru.sbt.lt.emul.unistub.connections.PoolSender;
import ru.sbt.lt.emul.unistub.processing.BasicProcessingManager;
import ru.sbt.lt.emul.unistub.processing.IncomingNameExtractor;
import ru.sbt.lt.emul.unistub.processing.Processing;
import ru.sbt.lt.emul.unistub.socketServer.SBTSocketServer;
import ru.sbt.lt.emul.unistub.stats.InnerStatsSender;
import ru.sbt.lt.emul.unistub.tools.TemplatesInitializer;
import ru.sbt.lt.emul.unistub.connections.Receiving;

/**
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class StubRunner implements Runnable {
	private static final Logger logger = Logger.getLogger(StubRunner.class.getName());

	public static AtomicInteger global_incoming_count = new AtomicInteger(0);
	public static AtomicInteger global_processed_count = new AtomicInteger(0);
	public static AtomicInteger global_failed_count = new AtomicInteger(0);

	public static XMLConfiguration config;
	public static String configFileName;
	public static ConcurrentHashMap<String, File> templates;
	public static ConcurrentHashMap<String, Integer> global_delayStats = new ConcurrentHashMap<>();
	public static ConcurrentHashMap<String, Integer> global_op_delay_min = new ConcurrentHashMap<>();
	public static ConcurrentHashMap<String, Integer> global_op_delay_max = new ConcurrentHashMap<>();
	public static IncomingNameExtractor incomingOpNameExtractor;
	public static BasicProcessingManager processings;
	//Подключения к БД
	public static DBServicesFromConfig dbServicesFromConfig;

	private Thread statsSenderThread; // Отправка статистики по работе заглушки
	private Thread processingThread; // Обработка сообщений пула и отправка ответа в пул отправки
	private Thread senderThread; // Отправка обработанных сообщений
	private Receiving receivingThreads;  // Вычитка сообщений из заданного источника в пул обработки
	// Используется для socket заглушки
	private Server server;
	private SBTSocketServer serverSocket;
	private String inqName; // Имя входящей очереди

	public StubRunner(String configPath) {
		logger.log(Level.INFO, "Stub initialization started...");

		// Подготовка конфигурации
		File configFile = new File(configPath);
		try {
			config = XMLConfig.getConfig(configFile);
			logger.log(Level.INFO, "Config: {0}", configFile.toString());
		} catch (ConfigurationException ex) {
			ex.printStackTrace();
			logger.log(Level.SEVERE, "Error occured when parsing config: {0}.\n{1}", new Object[]{
				configPath, ex});
			System.exit(-1);
		}

		configFileName = configFile.getName();
		//Загрузка шаблонов в память
		String templatesPath = config.getString("Processing/TemplatesPath");
		templates = TemplatesInitializer.getTemplates(templatesPath);
		if (templates.isEmpty()) {
			logger.log(Level.INFO, "Templates not found in specified folder: {0}!", templatesPath);
		} else {
			logger.log(Level.INFO, "Templates loaded from: {0}", templatesPath);
		}

		inqName = config.getString("Queues/StubInputQLabel"); // Получение имени очереди входящих сообщений, которые будет обрабатывать заглушка
		try {
			QueuesFromConfig q = new QueuesFromConfig(config, inqName);
		} catch (NullPointerException ex) {
			ex.printStackTrace();
			logger.log(Level.SEVERE, "No one out queue specified!");
			System.exit(-1);
		}

		try {
			SelectorsFromConfig q = new SelectorsFromConfig(config);
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.log(Level.SEVERE, "Selectors parse error!");
			System.exit(-1);
		}

		if (inqName != null) {
			MessagePool incomingMessagesPool = null;
			try {
				incomingMessagesPool = new MessagePool();// Пул входящих сообщений для обработки
				QParams inq = QueuesFromConfig.getInputQueue(); //получение параметров очереди по имени из конфига
				receivingThreads = new Receiving(inq, incomingMessagesPool, SelectorsFromConfig.getSelectors());
			} catch (JMSException ex) {
				ex.printStackTrace();
				logger.log(Level.SEVERE, "Can't connect to input queue!\n{0}", ex);
			}
			// Поток отправки обработанных сообщений из пула обработанных
			DelayedMessagePool outgoingMessagesPool = new DelayedMessagePool();// Пул исходящих сообщений после обработки
			try {
				PoolSender sender = new PoolSender(outgoingMessagesPool); // Опорожнение пула и отсылка исходящих сообщений
				senderThread = new Thread(sender);
				senderThread.setName("PoolSender");
			} catch (Exception ex) {
				ex.printStackTrace();
				logger.log(Level.SEVERE, "Sender initialization failed! Exiting...");
				System.exit(-1);
			}
			// Поток отправки сообщений из пула на обработку
			Processing processing = new Processing(incomingMessagesPool, outgoingMessagesPool);
			processingThread = new Thread(processing);
			processingThread.setName("Processing");
		}

		incomingOpNameExtractor = new IncomingNameExtractor(ConfigHandler.getIncomingOperationNameExtractors());
		// Подготовка обработчиков для операций из конфига
		processings = new BasicProcessingManager();
		// Поток отправки статистики по операциям в логгеры
		InnerStatsSender statsSender = new InnerStatsSender(60, configFile.getName());
		statsSenderThread = new Thread(statsSender);
		statsSenderThread.setName("Inner stat sender");

		if (config.getString("GetIncomingFrom").equals("HTTP")) {
			logger.log(Level.INFO, "Socket!! at Port : {0}", config.getInt("Port"));
			server = new Server(config.getInt("Port"));
			server.setHandler(new HttpPusher());
		} else if (config.getString("GetIncomingFrom").equals("HTTPS")) {
			logger.log(Level.INFO, "Socket!! at Port : {0}", config.getInt("Port"));
			File keyStoreFile = new File(config.getString("SslKeyStore"));
			if (!keyStoreFile.exists()) {
				logger.log(Level.SEVERE, "Problems with getting SSL KeyStore file", config.getString("SslKeyStore"));
			}

			server = new Server(config.getInt("Port"));
			//Set Context Factory for HTTPS
			SslContextFactory sslContexFactory = new SslContextFactory();
			sslContexFactory.setKeyStorePath(config.getString("SslKeyStore"));
			sslContexFactory.setKeyStorePassword(config.getString("SslKeyStorePassword"));
			sslContexFactory.setKeyManagerPassword(config.getString("SslKeyStorePassword"));
			//HTTPS Configuration
			HttpConfiguration https_config = new HttpConfiguration();
			https_config.addCustomizer(new SecureRequestCustomizer());
			//HTTPS Connection
			ServerConnector https = new ServerConnector(server,
					new SslConnectionFactory(sslContexFactory, HttpVersion.HTTP_1_1.asString()),
					new HttpConnectionFactory(https_config));
			https.setPort(config.getInt("Port"));
			//Defining Connector and Handler
			server.setConnectors(new Connector[]{https});
			server.setHandler(new HttpPusher());
		} else if (config.getString("GetIncomingFrom").equals("Socket")) {
			logger.log(Level.INFO, "Socket!! at Port : {0}", config.getInt("Port"));
			serverSocket = new SBTSocketServer(config.getInt("Port"));
		} else if (inqName == null) {
			logger.log(Level.SEVERE, "No input specified!");
			System.exit(-1);
		}
		//DB connection
		try {
			dbServicesFromConfig = new DBServicesFromConfig(config);
		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			System.exit(-1);
		}
	}

	@Override
	public void run() {
		// Running working threads
		if (inqName != null) {
			receivingThreads.start();
			processingThread.start();
			senderThread.start();
		}
		// Running stats thread
		statsSenderThread.start();
		// Running Jetty HTTP
		if (server != null) {
			try {
				server.start();
				server.join();
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "Problems with starting/ending http server thread", ex);
			}
		}
		// Running Sockets
		if (serverSocket != null) {
			serverSocket.start();
			try {
				serverSocket.join();
			} catch (InterruptedException ex) {
				logger.log(Level.SEVERE, "Problems with ending soсket server thread", ex);
			}
		}
	}

}
