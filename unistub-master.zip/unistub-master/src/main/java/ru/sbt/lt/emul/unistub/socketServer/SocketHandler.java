package ru.sbt.lt.emul.unistub.socketServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.codec.binary.Hex;
import ru.sbt.lt.emul.unistub.StubRunner;
import static ru.sbt.lt.emul.unistub.StubRunner.processings;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;
import ru.sbt.lt.emul.unistub.processing.BasicOperationProcessing;
import ru.sbt.lt.emul.unistub.processing.IncomingNameExtractor;

/**
 * Класс осуществляет чтение и запись данных из/в socket
 *
 * @author SBT-Pugachev-VV
 */
public class SocketHandler extends Thread {

    private static final Logger logger = Logger.getLogger(SocketHandler.class.getName());
    private final Socket socket;

    public SocketHandler(Socket _socket) {
        this.socket = _socket;

    }

    @Override
    public void run() {


        UnifiedMessage raw;

        try {
            // из сокета клиента берём поток входящих и выходных данных
            InputStream is = socket.getInputStream();
            OutputStream os = socket.getOutputStream();


            
            byte[] size = new byte[2];
            size[0] = (byte) is.read();
            size[1] = (byte) is.read();  
            
            int size_recieved = ((size[1] & 0xFF) << 8) | (size[0] & 0xFF);
            
            byte buffer[] = new byte[size_recieved];
            
            int receivedDataInt = is.read(buffer);

            //оставляем тоько принятые данные
            byte msgBytes[] = new byte[receivedDataInt];
            System.arraycopy(buffer, 0, msgBytes, 0, receivedDataInt);

 
            // создаём строку, содержащую полученную от клиента информацию
             String BytesEncoded2HexString = Hex.encodeHexString(msgBytes);  
                       
            // создаем UnifiedMessage(
            raw = new UnifiedMessage(BytesEncoded2HexString);

 
            //Info Section    
            logger.log(Level.INFO, "_______________________");
            logger.log(Level.INFO, "INCOMING: {0}", BytesEncoded2HexString);
            StubRunner.global_incoming_count.getAndIncrement();
            String opName = IncomingNameExtractor.extractFrom(raw);

            logger.log(Level.INFO, "INCOMING OPERATION NAME: {0}", opName);

            //Processing session 
            BasicOperationProcessing p = processings.getProcessingForOperation(opName);
            UnifiedMessage processed = p.process(raw);
            String responseBody = processed.getBody();
            byte[] b = new BigInteger(responseBody, 16).toByteArray();
            // отправляем ответ

            os.write(b);
            os.flush();

            // завершаем соединение
            socket.close();
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Problems with reading/writing data from socket", ex);
            try {
                socket.close();
            } catch (IOException ex1) {
                logger.log(Level.SEVERE, "Problems with  socket.closing", ex1);
            }
        }
    }

}
