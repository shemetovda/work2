/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.sbt.lt.emul.unistub.stats;

import java.util.LinkedList;
import ru.sbt.lt.emul.unistub.core.QParams;

/**
 *
 * @author sbt-chernov-dv
 */
public class DBStatsSender implements IStatsSender {
	LinkedList<IStatsSender> senders = new LinkedList<>();

	@Override
	public void addStats(QParams params, String step, long timestamp, String opName) {
		senders.forEach((sender) -> {
			sender.addStats(params, step, timestamp, opName);
		});
	}
	
	public void addStatsSender(IStatsSender sS) {
		senders.add(sS);
	}
	
}
