package ru.sbt.lt.emul.unistub.processing.extractors;

import org.apache.commons.lang3.StringUtils;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;


public class ExtractReplyTo implements IExtractor {

    private final String _extractorName;
    private final String _type;
    
    public ExtractReplyTo(String extractorName, String type){
        _extractorName = extractorName;
        _type = type;
    };
        
    @Override
    public String extractFrom(UnifiedMessage message) {
        String full = message.getInReplyTo();
        //expect queue://M99.ESB.MDM1/ESB.MDM.RESPONSE?targetClient=1 
        
        String out = StringUtils.substringBetween(full,"queue://" , "?");
		if (out == null){
			out = StringUtils.substringAfter(full,"queue://");
		}
        
        switch (_type) {
            case "Queue":
                out =  StringUtils.substringAfter(out,"/");
                break;
            case "Manager":
                out =  StringUtils.substringBefore(out,"/");
                break;
        }

        if (out != null){
            return out;
        }
        else{
            return "NA";
        }
    }

    @Override
    public String getName() {
        return _extractorName;
    }
    
}
