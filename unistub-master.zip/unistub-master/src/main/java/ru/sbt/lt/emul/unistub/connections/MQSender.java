package ru.sbt.lt.emul.unistub.connections;

import ru.sbt.lt.emul.unistub.core.QParams;
import com.ibm.mq.jms.MQQueue;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.common.CommonConstants;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import static ru.sbt.lt.emul.unistub.StubRunner.config;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class MQSender {
	private static final Logger logger = Logger.getLogger(MQSender.class.getName());

	Connection connection;

	private final QParams q;
	private final ExecutorService threadPool = new ThreadPoolExecutor(1, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, new SynchronousQueue<>());

	private int DELIVERY_MODE = DeliveryMode.NON_PERSISTENT;

	public ExecutorService getExecutor() {
		return threadPool;
	}

	// This class is used to send messages to output queue
	public MQSender(QParams qparams) throws JMSException {
		try {
			if (config.getString("Persistence").equals("PERSISTENT")) {
				DELIVERY_MODE = DeliveryMode.PERSISTENT;
			}
		} catch (NullPointerException ex) {
		}

		q = qparams;
		MQQueueConnectionFactory cf = new MQQueueConnectionFactory();
		cf.setHostName(q.getServer());
		cf.setPort(q.getPort());
		cf.setQueueManager(q.getQmanager());
		cf.setChannel(q.getChannel());
		cf.setCCSID(866);
		cf.setTransportType(DELIVERY_MODE);
		connection = cf.createConnection();
		connection.start();
	}

	public void send(UnifiedMessage message) throws JMSException, RejectedExecutionException {

		threadPool.submit(() -> {
			String queueName;
			if (!message.isSecondSender() && message.isBypassDestination()) {
				String tempDest = message.getInReplyTo();
				queueName = tempDest.contains("?") ? tempDest.substring(0, tempDest.indexOf("?")) : tempDest;
			} else {
				queueName = q.getQueue();
			}

			try (Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE)) {
				Queue queue = session.createQueue(queueName);
				((MQQueue) queue).setPutAsyncAllowed(CommonConstants.WMQ_PUT_ASYNC_ALLOWED_ENABLED);
				TextMessage outJMSMsg = session.createTextMessage();
				outJMSMsg.setText(message.getBody());
				fillProperties(message, outJMSMsg);
				if (message.getInReplyTo() != null) {
					outJMSMsg.setJMSDestination(session.createQueue(message.getInReplyTo()));
				}

				logger.log(Level.CONFIG, "msg sent to:\n{0}", queue.getQueueName());
				logger.log(Level.FINEST, "OUTGOING JMS: {0}", outJMSMsg.toString());
				try (MessageProducer sender = session.createProducer(queue)) {
					sender.setDeliveryMode(DELIVERY_MODE);
					sender.send(outJMSMsg);
				} catch (JMSException ex) {
					logger.log(Level.SEVERE, "Msg sending failed! Queue: {0}", queueName);
					logger.log(Level.SEVERE, "Exception occured: \n{0}", ex.getMessage());
					ex.printStackTrace();
				}
			} catch (JMSException ex) {
				logger.log(Level.SEVERE, "Connecting for sending failed! QManager: {0}", q.getQmanager());
				logger.log(Level.SEVERE, "Exception occured: \n{0}", ex.getMessage());
				ex.printStackTrace();
			}
		});
	}

	private void fillProperties(UnifiedMessage message, TextMessage outJMSMsg) throws JMSException {

		for (Map.Entry<String, String> property : message.getAdditionalProperties().entrySet()) {
			String key = property.getKey();
			if (outJMSMsg.propertyExists(key)) {
				continue;
			}
			switch (key) {
				case "JMSExpiration":
					outJMSMsg.setJMSExpiration(Long.valueOf(property.getValue()));
					break;
				case "JMSPriority":
					outJMSMsg.setJMSPriority(Integer.valueOf(property.getValue()));
					break;
				case "JMSRedelivered":
					outJMSMsg.setJMSRedelivered(Boolean.valueOf(property.getValue()));
					break;
				case "JMSTimestamp":
					outJMSMsg.setJMSTimestamp(Long.valueOf(property.getValue()));
					break;
				case "JMSType":
					outJMSMsg.setJMSType(property.getValue());
					break;
				case "JMS_IBM_MsgType":
					outJMSMsg.setIntProperty(key, Integer.valueOf(property.getValue()));
					break;
				case "JMS_IBM_Encoding":
					outJMSMsg.setIntProperty(key, Integer.valueOf(property.getValue()));
					break;
				case "JMS_IBM_PutApplType":
					outJMSMsg.setIntProperty(key, Integer.valueOf(property.getValue()));
					break;
				case "JMSCorrelationID":
					break;
				default:
					outJMSMsg.setStringProperty(key, property.getValue());
			}
		}

		outJMSMsg.setIntProperty("CodedCharSetId", 1251);
		if (message.isBypassReplyTo()) {
			outJMSMsg.setJMSCorrelationID(message.getCorrelationId());
		}

		if (message.isCopyReplyTo()) {
			MQQueue q = new MQQueue(message.getInReplyTo());
			outJMSMsg.setJMSReplyTo(q);
		} else {
			outJMSMsg.setJMSReplyTo(null);
		}
	}
}
