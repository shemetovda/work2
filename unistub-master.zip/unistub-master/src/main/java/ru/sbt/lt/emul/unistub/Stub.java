package ru.sbt.lt.emul.unistub;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import javax.jms.JMSException;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class Stub {
	private static final Logger logger = Logger.getLogger(Stub.class.getName());

	public static void main(String[] args) throws JMSException, InterruptedException, IllegalAccessException {
		String confPath = "";
		String SMS_confPath = "";

		try {
			LogManager.getLogManager().reset();
			LogManager.getLogManager().readConfiguration(
					new FileInputStream("Configs/StubLogging.properties"));
			logger.setUseParentHandlers(true);

		} catch (SecurityException | IOException ex) {
			logger.log(Level.SEVERE, "Exception: Problem with applying logging.properties file", ex);
			logger.log(Level.SEVERE, "File not valid or not exist!", ex);
			System.exit(-1);
		}

		if (args.length == 0 || args.length > 2) {
			logger.log(Level.SEVERE, String.format("Incorrect argument count (%d), exiting...", args.length));
			logger.log(Level.SEVERE, "Run uStub like this: java -jar \"unistub.jar\" \"config_filename.xml\"");
			logger.log(Level.SEVERE, "or: java -jar \"unistub.jar\" \"config_filename.xml\" \"sms_config_filename.xml\"");
			System.exit(-1);
		}
		switch (args.length) {
			case 1:
				confPath = args[0];
				break;
			case 2:
				confPath = args[0];
				SMS_confPath = args[1];
		}

		StubRunner R = new StubRunner(confPath);
		Thread t1 = new Thread(R);
		t1.start();

		if (!SMS_confPath.isEmpty()) {
			SMS_AgentAdapter AA = new SMS_AgentAdapter(SMS_confPath);
			Thread tAA = new Thread(AA);
			tAA.start();
		}
	}
}
