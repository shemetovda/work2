package ru.sbt.lt.emul.unistub.processing.extractors;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 *
 * @author sbt-kupriyanov-ia
 */
public class SAXErrorHandler implements ErrorHandler {
    
    private static final Logger logger = Logger.getLogger(SAXErrorHandler.class.getName());
    
    @Override
    public void warning(SAXParseException e) throws SAXException {
        logger.log(Level.WARNING, e.getMessage());
    }

    @Override
    public void error(SAXParseException e) throws SAXException {
        logger.log(Level.WARNING, e.getMessage());
    }

    @Override
    public void fatalError(SAXParseException e) throws SAXException {
        logger.log(Level.SEVERE, e.getMessage());
    }
}

