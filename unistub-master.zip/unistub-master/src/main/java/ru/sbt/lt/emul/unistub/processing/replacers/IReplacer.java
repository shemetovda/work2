package ru.sbt.lt.emul.unistub.processing.replacers;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public interface IReplacer {

	public String replace(String message, String replaceWith);

	public String getExtractedName();
}
