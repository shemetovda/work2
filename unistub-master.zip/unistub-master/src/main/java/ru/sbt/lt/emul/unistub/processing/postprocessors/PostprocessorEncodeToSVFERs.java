package ru.sbt.lt.emul.unistub.processing.postprocessors;


import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 * Класс конвертирует данные в нужный формат перед отправкой SVFE 
 *  @author SBT-Pugachev-VV
 */
public class PostprocessorEncodeToSVFERs implements IPostprocessor  {
       
        
    public PostprocessorEncodeToSVFERs(){
        
    }
    
    @Override
    public UnifiedMessage postprocess(UnifiedMessage message)  {
        String body = message.getBody();        
                
        int len = body.length();
        byte[] data = new byte[len / 2];
        
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(body.charAt(i), 16) << 4) + Character.digit(body.charAt(i + 1), 16));
        }
        
        message.setBody(new String(data));    
        
        return message;
    }
}
