package ru.sbt.lt.emul.unistub.configuration;

import ru.sbt.lt.emul.unistub.processing.postextractors.ExtractBySqlQuery;
import java.util.*;
import java.util.logging.Logger;

import org.apache.commons.configuration2.HierarchicalConfiguration;
import org.apache.commons.configuration2.tree.ImmutableNode;

import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.processing.Delay;
import ru.sbt.lt.emul.unistub.processing.extractors.*;
import ru.sbt.lt.emul.unistub.processing.postprocessors.*;
import ru.sbt.lt.emul.unistub.processing.preprocessors.*;
import ru.sbt.lt.emul.unistub.processing.replacers.*;
import ru.sbt.lt.emul.unistub.inserters.*;
import ru.sbt.lt.emul.unistub.processing.postextractors.ExtractByConcat;
import ru.sbt.lt.emul.unistub.processing.postextractors.IPostExtractor;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class ConfigHandler {
	private static final Logger logger = Logger.getLogger(ConfigHandler.class.getName());

	private final static HashMap<String, List<IExtractor>> extractors = new HashMap();
	private final static HashMap<String, List<IPostExtractor>> postextractors = new HashMap();
	private final static HashMap<String, List<IReplacer>> replacers = new HashMap();
	private final static HashMap<String, List<IDomReplacer>> domreplacers = new HashMap();
	private final static HashMap<String, List<IInserter>> inserters = new HashMap();
	private final static HashMap<String, List<IPreprocessor>> preprocessors = new HashMap();
	private final static HashMap<String, List<IPostprocessor>> postprocessors = new HashMap();

	private final static HashMap<String, String> templates = new HashMap();
	private final static HashMap<String, String> queues = new HashMap();
	private final static HashMap<String, String> secondqueues = new HashMap();
	private final static HashMap<String, Boolean> bypassDestinations = new HashMap();
	private final static HashMap<String, Boolean> bypassReplies = new HashMap();
	private final static HashMap<String, Boolean> copyReplies = new HashMap();
	private final static HashMap<String, Boolean> jmsHeaderCopies = new HashMap();

	private static List<IExtractor> defaultExtractors = null;
	private static List<IPostExtractor> defaultPostextractors = null;
	private static List<IReplacer> defaultReplacers = null;
	private static List<IInserter> defaultInserters = null;
	private static List<IPreprocessor> defaultPreprocessors = null;
	private static List<IPostprocessor> defaultPostprocessors = null;

	private static List<IExtractor> incomingNameExtractors = null;

	public static String getConfigFileName() {
		return StubRunner.configFileName;
	}

	public static boolean getIsReconnectionNeeded() {
		return StubRunner.config.getBoolean("Reconnect", false);
	}

	public static boolean getInfluxSendNeeded() {
		return StubRunner.config.getBoolean("InfluxDB", false);
	}

	public static String getInfluxDBConnectString() {
		return StubRunner.config.getString("InfluxDBConnect");
	}

	public static String getTemplateForOperation(String opName) {
		if (templates.get(opName) != null) {
			return templates.get(opName);
		} else {
			String templateName = StubRunner.config.getString("Processing/Operations/Operation[@Name='" + opName + "']/@Template");
			templates.put(opName, templateName);
			return templateName;
		}
	}

	public static Boolean getBypassDestination(String opName) {
		if (bypassDestinations.get(opName) != null) {
			return bypassDestinations.get(opName);
		} else {
			String destLabel = StubRunner.config.getString("Processing/Operations/Operation[@Name='" + opName + "']/BypassDestination");
			if (destLabel != null) {
				Boolean bypassDest = StubRunner.config.getBoolean("Processing/Operations/Operation[@Name='" + opName + "']/BypassDestination", false);
				bypassDestinations.put(opName, bypassDest);
				return bypassDest;
			} else {
				Boolean bypassDest = StubRunner.config.getBoolean("Processing/Operations/Operation[@Name='DEFAULT']/BypassDestination", false);
				bypassDestinations.put(opName, bypassDest);
				return bypassDest;
			}
		}
	}

	public static boolean getCopyReplyTo(String opName) {
		if (copyReplies.get(opName) != null) {
			return copyReplies.get(opName);
		} else {
			String replyToLabel = StubRunner.config.getString("Processing/Operations/Operation[@Name='" + opName + "']/CopyReplyTo");
			if (replyToLabel != null) {
				Boolean replyTo = StubRunner.config.getBoolean("Processing/Operations/Operation[@Name='" + opName + "']/CopyReplyTo", false);
				copyReplies.put(opName, replyTo);
				return replyTo;
			} else {
				Boolean replyTo = StubRunner.config.getBoolean("Processing/Operations/Operation[@Name='DEFAULT']/CopyReplyTo", false);
				copyReplies.put(opName, replyTo);
				return replyTo;
			}
		}
	}

	public static boolean getBypassReplyTo(String opName) {
		if (bypassReplies.get(opName) != null) {
			return bypassReplies.get(opName);
		} else {
			String replyToLabel = StubRunner.config.getString("Processing/Operations/Operation[@Name='" + opName + "']/BypassReplyTo");
			if (replyToLabel != null) {
				Boolean replyTo = StubRunner.config.getBoolean("Processing/Operations/Operation[@Name='" + opName + "']/BypassReplyTo", false);
				bypassReplies.put(opName, replyTo);
				return replyTo;
			} else {
				Boolean replyTo = StubRunner.config.getBoolean("Processing/Operations/Operation[@Name='DEFAULT']/BypassReplyTo", false);
				bypassReplies.put(opName, replyTo);
				return replyTo;
			}
		}
	}

	public static boolean getHeaderCopyNeeded(String opName) {
		if (jmsHeaderCopies.get(opName) != null) {
			return jmsHeaderCopies.get(opName);
		} else {
			String copyLabel = StubRunner.config.getString("Processing/Operations/Operation[@Name='DEFAULT']/CopyJMSHeader");
			if (copyLabel != null) {
				Boolean copy = StubRunner.config.getBoolean("Processing/Operations/Operation[@Name='DEFAULT']/CopyJMSHeader", false);
				jmsHeaderCopies.put(opName, copy);
				return copy;
			} else {
				Boolean copy = StubRunner.config.getBoolean("Processing/Operations/Operation[@Name='DEFAULT']/CopyJMSHeader", false);
				jmsHeaderCopies.put(opName, copy);
				return copy;
			}
		}
	}

	public static String getQueueForOperation(String opName) {
		if (queues.get(opName) != null) {
			return queues.get(opName);
		} else {
			String qLabel = StubRunner.config.getString("Processing/Operations/Operation[@Name='" + opName + "']/Respond2Queue");
			if (qLabel == null) {
				qLabel = StubRunner.config.getString("Processing/Operations/Operation[@Name='DEFAULT']/Respond2Queue");
			}
			queues.put(opName, qLabel);
			return qLabel;
		}
	}

	public static String getSecondQueueForOperation(String opName) {
		if (secondqueues.get(opName) != null) {
			return secondqueues.get(opName);
		} else {
			String qLabel = StubRunner.config.getString("Processing/Operations/Operation[@Name='" + opName + "']/Respond2SecondQueue");
			if (qLabel == null) {
				qLabel = StubRunner.config.getString("Processing/Operations/Operation[@Name='DEFAULT']/Respond2SecondQueue");
			}
			secondqueues.put(opName, qLabel);
			return qLabel;
		}
	}

	public static List<IPreprocessor> getGlobalPreprocessorsForInputStreamEncoding() {
		List<IPreprocessor> eList = new LinkedList<>();
		IPreprocessor preprocessor = null;
		String type = StubRunner.config.getString("InputStreamEncodeType");
		switch (type) {
			case "EncodeToHexString":
				preprocessor = new PreprocessorEncodeToHexString();
				break;
		}
		eList.add(preprocessor);

		return eList;
	}

	public static Delay getDelayForOperation(String opName) {
		List<HierarchicalConfiguration<ImmutableNode>> delayParams = StubRunner.config
				.configurationsAt("Processing/Operations/Operation[@Name='" + opName + "']/Delay");
		if (delayParams.isEmpty()) {
			delayParams = StubRunner.config.configurationsAt("Processing/Operations/Operation[@Name='DEFAULT']/Delay");
		}
		int from = 0;
		int to = 0;
		for (HierarchicalConfiguration d : delayParams) {
			from = d.getInt("Min");
			to = d.getInt("Max");
		}
		Delay delay = new Delay(opName, from, to);

		return delay;
	}

	public static List<IExtractor> getIncomingOperationNameExtractors() {
		if (incomingNameExtractors != null) {
			return incomingNameExtractors;
		} else {
			List<IExtractor> eList = new LinkedList<>();
			List<HierarchicalConfiguration<ImmutableNode>> opnameExtractorNodes = StubRunner.config
					.configurationsAt("Processing/IncomingOperationNameExtractors/Extractor");
			opnameExtractorNodes.forEach((e) -> {
				eList.add(getExtractor(e));
			});

			incomingNameExtractors = eList;

			return eList;
		}
	}

	public static List<IExtractor> getExtractorsForOperation(String opName) {
		if (extractors.get(opName) != null) {
			return extractors.get(opName);
		} else {
			List<IExtractor> eList = new LinkedList<>();
			List<HierarchicalConfiguration<ImmutableNode>> extractorNodes = StubRunner.config
					.configurationsAt("Processing/Operations/Operation[@Name='" + opName + "']/Extractors/Extractor");
			if (extractorNodes.isEmpty()) {
				if (defaultExtractors == null) {
					initDefaultExtractors();
				}

				return defaultExtractors;
			}
			extractorNodes.forEach((e) -> {
				eList.add(getExtractor(e));
			});

			extractors.put(opName, eList);
			return eList;
		}
	}

	public static void initDefaultExtractors() {
		defaultExtractors = new LinkedList();
		List<HierarchicalConfiguration<ImmutableNode>> extractorNodes = StubRunner.config
				.configurationsAt("Processing/Operations/Operation[@Name='DEFAULT']/Extractors/Extractor");
		extractorNodes.forEach((e) -> {
			defaultExtractors.add(getExtractor(e));
		});
	}

	public static IExtractor getExtractor(HierarchicalConfiguration e) {
		IExtractor extractor = null;
		String type = e.getString("Type");
		switch (type) {
			case "ExtractIbankMsgType":
				extractor = new ExtractIbankMsgType(e.getString("ExtractedName"));
				break;
			case "ReplyTo":
				extractor = new ExtractReplyTo(e.getString("ExtractedName"),
						e.getString("Part"));
				break;
			case "RegexpMatcher":
				extractor = new ExtractMatchingRegexp(e.getString("ExtractedName"),
						e.getString("Regexp"),
						e.getString("ValueIfTrue"),
						e.getString("ValueIfFalse"));
				break;
			case "CorrelationId":
				extractor = new ExtractCorrelationID(e.getString("ExtractedName"),
						e.getBoolean("ExcludeID"));
				break;
			case "MessageId":
				extractor = new ExtractMessageID(e.getString("ExtractedName"),
						e.getBoolean("ExcludeID"));
				break;
			case "ByTagName":
				extractor = new ExtractByTag(e.getString("ExtractedName"),
						e.getString("TagName"));
				break;
			case "ByTagAttribute":
				extractor = new ExtractByTagAttr(e.getString("ExtractedName"),
						e.getString("TagName"),
						e.getString("AttributeName"));
				break;
			case "ByXpath":
				extractor = new ExtractByXpath(e.getString("ExtractedName"),
						e.getString("Xpath"));
				break;
			case "RootTag":
				extractor = new ExtractRootTag(e.getString("ExtractedName"));
				break;
			case "ByBoundaries":
				extractor = new ExtractByBoundaries(e.getString("ExtractedName"),
						e.getString("LB"),
						e.getString("RB"));
				break;
			case "RandSequence":
				extractor = new ExtractRandSequence(e.getString("ExtractedName"),
						e.getString("Prefix"),
						e.getString("Charset"),
						e.getInt("Length"));
				break;
			case "Date":
				extractor = new ExtractDate(e.getString("ExtractedName"),
						e.getString("DateFormat"),
						e.getInt("ShiftMin"));
				break;
			case "HardcodedString":
				extractor = new ExtractString(e.getString("ExtractedName"),
						e.getString("Value"));
				break;
			case "WholeMessage":
				extractor = new ExtractWholeMessage(e.getString("ExtractedName"));
				break;
			case "JMSProperty":
				extractor = new ExtractJMSProperty(e.getString("ExtractedName"),
						e.getString("TagName"));
				break;
		}

		return extractor;
	}

	public static List<IPostExtractor> getPostExtractorsForOperation(String opName) {
		if (postextractors.get(opName) != null) {
			return postextractors.get(opName);
		} else {
			List<IPostExtractor> eList = new LinkedList<>();
			List<HierarchicalConfiguration<ImmutableNode>> extractorNodes = StubRunner.config
					.configurationsAt("Processing/Operations/Operation[@Name='" + opName + "']/Extractors/PostExtractor");
			if (extractorNodes.isEmpty()) {
				if (defaultPostextractors == null) {
					initDefaultPostExtractors();
				}

				return defaultPostextractors;
			}
			extractorNodes.forEach((e) -> {
				eList.add(getPostExtractor(e));
			});

			postextractors.put(opName, eList);
			return eList;
		}
	}

	public static void initDefaultPostExtractors() {
		defaultPostextractors = new LinkedList();
		List<HierarchicalConfiguration<ImmutableNode>> extractorNodes = StubRunner.config
				.configurationsAt("Processing/Operations/Operation[@Name='DEFAULT']/Extractors/PostExtractor");
		extractorNodes.forEach((e) -> {
			defaultPostextractors.add(getPostExtractor(e));
		});
	}

	public static IPostExtractor getPostExtractor(HierarchicalConfiguration e) {
		IPostExtractor extractor = null;
		String type = e.getString("Type");
		switch (type) {
			case "BySqlQuery":
				List<String> parameters = new ArrayList<>();
				/// Takes current node from NodeModel (ImmutableNode) which contains xml attributes as childs
				ImmutableNode immutableNode = e.getNodeModel().getInMemoryRepresentation();
				for (ImmutableNode node : immutableNode.getChildren()) {
					if (node.getNodeName().equals("SqlQuery")) {
						Map nodeAttributes = node.getAttributes();
						String attributeValue = nodeAttributes.get("parameters").toString();
						String[] paramsArray = attributeValue.split(",");
						for (String param : paramsArray) {
							parameters.add(param.trim());
						}

						break;
					}
				}
				extractor = new ExtractBySqlQuery(e.getString("ExtractedName"),
						e.getString("DataBase"),
						e.getString("SqlQuery"),
						parameters, e.getInt("Timeout"),
						e.getString("DefaultValue"));
				break;
			case "ByConcat":
				extractor = new ExtractByConcat(e.getString("ExtractedName"),
						e.getString("Left"),
						e.getString("Right"));
				break;
		}

		return extractor;
	}

	public static List<IPreprocessor> getPreprocessorsForOperation(String opName) {
		if (preprocessors.get(opName) != null) {
			return preprocessors.get(opName);
		} else {
			List<IPreprocessor> pList = new LinkedList<>();
			List<HierarchicalConfiguration<ImmutableNode>> preprocessorNodes = StubRunner.config
					.configurationsAt("Processing/Operations/Operation[@Name='" + opName + "']/Preprocessors/Preprocessor");
			if (preprocessorNodes.isEmpty()) {
				if (defaultPreprocessors == null) {
					initDefaultPreprocessors();
				}

				return defaultPreprocessors;
			}
			preprocessorNodes.forEach((p) -> {
				pList.add(getPreprocessor(p));
			});

			preprocessors.put(opName, pList);
			return pList;
		}
	}

	public static void initDefaultPreprocessors() {
		defaultPreprocessors = new LinkedList();
		List<HierarchicalConfiguration<ImmutableNode>> preprocessorNodes = StubRunner.config
				.configurationsAt("Processing/Operations/Operation[@Name='DEFAULT']/Preprocessors/Preprocessor");
		preprocessorNodes.forEach((p) -> {
			defaultPreprocessors.add(getPreprocessor(p));
		});
	}

	public static IPreprocessor getPreprocessor(HierarchicalConfiguration e) {
		IPreprocessor preprocessor = null;
		String type = e.getString("Type");
		switch (type) {
			case "External_jar":
				String path = e.getString("Jar_Path");
				String name = e.getString("Class_name");
				preprocessor = new PreprocessorExternal(path, name);
				break;
			case "Decode":
				preprocessor = new PreprocessorDecodeByBoundaries(e.getString("LB"), e.getString("RB"));
				break;
			case "EncodeToHexString":
				preprocessor = new PreprocessorEncodeToHexString();
				break;
		}
		return preprocessor;
	}

	public static List<IPostprocessor> getPostprocessorsForOperation(String opName) {
		if (postprocessors.get(opName) != null) {
			return postprocessors.get(opName);
		} else {
			List<IPostprocessor> pList = new LinkedList<>();
			List<HierarchicalConfiguration<ImmutableNode>> postprocessorNodes = StubRunner.config
					.configurationsAt("Processing/Operations/Operation[@Name='" + opName + "']/Postprocessors/Postprocessor");
			if (postprocessorNodes.isEmpty()) {
				if (defaultPostprocessors == null) {
					initDefaultPostprocessors();
				}

				return defaultPostprocessors;
			}
			postprocessorNodes.forEach((p) -> {
				pList.add(getPostprocessor(p));
			});

			postprocessors.put(opName, pList);
			return pList;
		}
	}

	public static void initDefaultPostprocessors() {
		defaultPostprocessors = new LinkedList();
		List<HierarchicalConfiguration<ImmutableNode>> postprocessorNodes = StubRunner.config
				.configurationsAt("Processing/Operations/Operation[@Name='DEFAULT']/Postprocessors/Postprocessor");
		postprocessorNodes.forEach((p) -> {
			defaultPostprocessors.add(getPostprocessor(p));
		});
	}

	public static IPostprocessor getPostprocessor(HierarchicalConfiguration e) {
		IPostprocessor postprocessor;
		String type = e.getString("Type");
		switch (type) {
			case "External_jar":
				String path = e.getString("Jar_Path");
				String name = e.getString("Class_name");
				postprocessor = new PostprocessorExternal(path, name);
				return postprocessor;
			case "Encode":
				postprocessor = new PostprocessorEncodeByBoundaries(e.getString("LB"), e.getString("RB"));
				return postprocessor;
			case "SignFPSU":
				postprocessor = new PostprocessorSignFPSU(e.getString("LB"),
						e.getString("RB"),
						e.getString("SignTemplateTag"),
						e.getString("Host"),
						e.getInt("Port"));
				return postprocessor;
			case "EncodeToSVFERs":
				postprocessor = new PostprocessorEncodeToSVFERs();
				return postprocessor;
			case "FolderInOut":
				postprocessor = new PostprocessorFolderInOut(e.getString("InputFolderPath"), e.getString("OutputFolderPath"), e.getInt("Timeout"));
				return postprocessor;
			case "JMSProperty":
				postprocessor = new PostprocessorJMSProperty(e.getString("PropertyName"), e.getString("SetValue"));
				return postprocessor;
		}

		return null;
	}

	public static List<IReplacer> getReplacersForOperation(String opName) {
		List<IReplacer> rList = new LinkedList<>();
		List<HierarchicalConfiguration<ImmutableNode>> replacerNodes = StubRunner.config
				.configurationsAt("Processing/Operations/Operation[@Name='" + opName + "']/Replacers/Replacer");
		if (replacerNodes.isEmpty()) {
			if (defaultReplacers == null) {
				initDefaultReplacers();
			}

			return defaultReplacers;
		} else {
			replacerNodes.forEach((i) -> {
				IReplacer replacer = getReplacer(i);
				rList.add(replacer);
			});

			return rList;
		}
	}

	public static List<IReplacer> getStringReplacersForOperation(String opName) {
		if (replacers.get(opName) == null) {
			List<IReplacer> stringReplacers = new LinkedList<>();
			getReplacersForOperation(opName).forEach(s -> {
				if (!(s instanceof IDomReplacer)) {
					stringReplacers.add(s);
				}
			});
			replacers.put(opName, stringReplacers);
		}

		return replacers.get(opName);
	}

	public static List<IDomReplacer> getDomReplacersForOperation(String opName) {
		if (domreplacers.get(opName) == null) {
			List<IDomReplacer> domReplacers = new LinkedList<>();
			getReplacersForOperation(opName).forEach(s -> {
				if (s instanceof IDomReplacer) {
					domReplacers.add(((IDomReplacer) s).clone());
				}
			});
			domreplacers.put(opName, domReplacers);
		}

		return domreplacers.get(opName);
	}

	public static void initDefaultReplacers() {
		defaultReplacers = new LinkedList();
		List<HierarchicalConfiguration<ImmutableNode>> replacerNodes = StubRunner.config
				.configurationsAt("Processing/Operations/Operation[@Name='DEFAULT']/Replacers/Replacer");
		replacerNodes.forEach((i) -> {
			defaultReplacers.add(getReplacer(i));
		});
	}

	public static IReplacer getReplacer(HierarchicalConfiguration r) {
		IReplacer replacer;
		String type = r.getString("Type");
		String extractedName = r.getString("ExtractedName");
		switch (type) {
			case "ByTagName":
				replacer = new ReplaceByTag(r.getString("TagName"), extractedName);
				return replacer;
			case "ByTagAttribute":
				replacer = new ReplaceByTagAttribute(r.getString("TagName"), r.getString("AttributeName"), extractedName);
				return replacer;
			case "ByBoundaries":
				replacer = new ReplaceByBoundaries(r.getString("LB"), r.getString("RB"), extractedName);
				return replacer;
			case "AllTemplate":
				replacer = new ReplaceAllTemplate(extractedName);
				return replacer;
		}

		return null;
	}

	public static List<IInserter> getInsertersForOperation(String opName) {
		if (inserters.get(opName) != null) {
			return inserters.get(opName);
		} else {
			List<IInserter> iList = new LinkedList<>();
			List<HierarchicalConfiguration<ImmutableNode>> inserterNodes = StubRunner.config
					.configurationsAt("Processing/Operations/Operation[@Name='" + opName + "']/Inserters/Inserter");
			if (inserterNodes.isEmpty()) {
				if (defaultInserters == null) {
					initDefaultInserters();
				}

				return defaultInserters;
			}
			inserterNodes.forEach((i) -> {
				iList.add(getInserter(i));
			});

			inserters.put(opName, iList);
			return iList;
		}
	}

	public static void initDefaultInserters() {
		defaultInserters = new LinkedList();
		List<HierarchicalConfiguration<ImmutableNode>> inserterNodes = StubRunner.config
				.configurationsAt("Processing/Operations/Operation[@Name='DEFAULT']/Inserters/Inserter");
		inserterNodes.forEach((i) -> {
			defaultInserters.add(getInserter(i));
		});
	}

	public static IInserter getInserter(HierarchicalConfiguration i) {
		IInserter inserter;
		String type = i.getString("Type");
		switch (type) {
			case "JMSHeader":
				inserter = new InsertJMSHeader(i.getString("ExtractedName"), i.getString("Property"), i.getString("Value"));
				return inserter;
		}

		return null;
	}
}
