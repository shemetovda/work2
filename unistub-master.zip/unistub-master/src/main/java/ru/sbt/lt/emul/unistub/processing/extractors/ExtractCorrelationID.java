package ru.sbt.lt.emul.unistub.processing.extractors;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ExtractCorrelationID implements IExtractor {

    private final String _extractorName;
    private final boolean _excludeID;
    
    public ExtractCorrelationID(String extractorName, boolean excludeID){
        _extractorName = extractorName;
        _excludeID = excludeID;
    }
        
    @Override
    public String extractFrom(UnifiedMessage message) {
        String out = message.getCorrelationId();
        if (_excludeID){
            
            return out.replaceFirst("ID:", "");
        }
        else return out;
    }

    @Override
    public String getName() {
        return _extractorName;
    }
    
}
