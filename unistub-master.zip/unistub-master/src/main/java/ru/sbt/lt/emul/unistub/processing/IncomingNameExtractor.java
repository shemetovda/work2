package ru.sbt.lt.emul.unistub.processing;

import java.util.List;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;
import ru.sbt.lt.emul.unistub.processing.extractors.IExtractor;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class IncomingNameExtractor {
    static List<IExtractor> _extractors;
    
    public static String extractFrom(UnifiedMessage message){
        StringBuilder sb = new StringBuilder();
        for (IExtractor e : _extractors){
            sb.append(e.extractFrom(message));
        }
        
        return sb.toString();
    }
    
    public IncomingNameExtractor(List<IExtractor> extractors){
        _extractors = extractors;        
    }
}
