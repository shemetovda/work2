package ru.sbt.lt.emul.unistub.processing.postprocessors;

import org.apache.commons.lang3.StringUtils;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class PostprocessorSignFPSU implements IPostprocessor{
        String _LB = "";
        String _RB = "";
        String _SignTag;
        String _host;
        int _port;
        
    public PostprocessorSignFPSU(String LB, String RB, String SignatureTag, String host, int port){
        _LB = LB;
        _RB = RB;
        _SignTag = SignatureTag;
        _host = host;
        _port = port;
    }
    @Override
    public UnifiedMessage postprocess(UnifiedMessage message) {
        String body = message.getBody();
        
        String toSign = _LB + StringUtils.substringBetween(body, _LB, _RB) + _RB;
        
        String TemplateSignature = StringUtils.substringBetween(body, "<"+_SignTag+">", "</"+_SignTag+">");
        
        String NewSignature = ru.sbt.lt.emul.unistub.FPSU.Signer.Sign(toSign, _host, _port);
        
        String newBody = StringUtils.replace(body, TemplateSignature, NewSignature);
        message.setBody(newBody);
        return message;
    }
}
