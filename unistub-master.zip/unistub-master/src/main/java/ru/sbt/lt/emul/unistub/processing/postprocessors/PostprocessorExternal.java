package ru.sbt.lt.emul.unistub.processing.postprocessors;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.logging.Level;
import java.util.logging.Logger;
import ru.sbt.lt.emul.unistub.configuration.ConfigHandler;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author SBT-Verbovskiy-DM
 */
public class PostprocessorExternal implements IPostprocessor {
    Class externalPostprocessor;
    
    
    public PostprocessorExternal(String path, String name){
        
        File file = new File(path);
        URL url;
        try {
            url = file.toURI().toURL();
            URLClassLoader classLoader = URLClassLoader.newInstance(new URL[] {url});
            externalPostprocessor = Class.forName(name, true, classLoader);
           

        } catch (MalformedURLException | ClassNotFoundException ex) {
            Logger.getLogger(ConfigHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
        
    @Override
    public UnifiedMessage postprocess(UnifiedMessage message)  {
        String body = message.getBody();
        
        String processedBody = externalProcess(body);
        
        message.setBody(processedBody);
        
        return message;
    }    



    private String externalProcess(String body){
        String newBody = "";
        try {
            Method m = externalPostprocessor.getDeclaredMethod("process", new Class[] {String.class});
            newBody = (String) m.invoke(null, body);
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(PostprocessorExternal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return newBody;
    }
}