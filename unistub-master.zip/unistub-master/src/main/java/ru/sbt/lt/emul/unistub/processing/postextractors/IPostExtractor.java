package ru.sbt.lt.emul.unistub.processing.postextractors;

import java.util.HashMap;
import ru.sbt.lt.emul.unistub.processing.extractors.IExtractor;

public interface IPostExtractor extends IExtractor {
    void setExtractorsMap(HashMap<String, String> extractors);
}
