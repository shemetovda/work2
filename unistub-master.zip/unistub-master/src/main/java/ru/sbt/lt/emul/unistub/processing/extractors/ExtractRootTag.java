package ru.sbt.lt.emul.unistub.processing.extractors;

import java.io.IOException;
import java.io.StringReader;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-kupriyanov-ia
 */
public class ExtractRootTag implements IExtractor{
    
    private static final Logger logger = Logger.getLogger(ExtractRootTag.class.getName());
    private final String _extractorName;
    
    public ExtractRootTag(String extractorName){
        _extractorName = extractorName;
    }
    @Override
    public String extractFrom(UnifiedMessage message) {
        
        String val = null;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//        SAXErrorHandler eh = new SAXErrorHandler(); /*Xml validation turned off for better performance*/
        DocumentBuilder db;
        Document doc;
        
        dbf.setValidating(false);/*Xml validation turned off for better performance*/
        dbf.setNamespaceAware(true);
        dbf.setExpandEntityReferences(false);
        
        try {
            
            db = dbf.newDocumentBuilder();
//            db.setErrorHandler(eh);/*Xml validation turned off for better performance*/
            
            doc = db.parse(new InputSource(new StringReader(message.getBody())));
            doc.normalizeDocument();
            //getting rootTag without namespace
            val = ((doc.getDocumentElement() != null) ? (doc.getDocumentElement().getLocalName()) : null);
            
        } catch (ParserConfigurationException | SAXException | IOException ex) {
        }
        
        return val;
}

//            old one    
//        String val = null;
//        String body = message.getBody();
//        if (StringUtils.substringBetween(body, "<?", "?>") == null){
//            val = StringUtils.substringBetween(body, "<", ">");
//        }
//        else {
//            val = StringUtils.substringBetween(body, "?><", ">");
//        }
//        
//        if(val != null && !val.isEmpty()){
//            return val;}
//        else return "";

    @Override
    public String getName() {
        return _extractorName;
    }
}