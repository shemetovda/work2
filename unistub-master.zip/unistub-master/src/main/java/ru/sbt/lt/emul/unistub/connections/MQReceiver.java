package ru.sbt.lt.emul.unistub.connections;

import ru.sbt.lt.emul.unistub.core.QParams;
import com.ibm.mq.jms.MQQueue;
import com.ibm.mq.jms.MQQueueConnection;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.mq.jms.MQQueueSession;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public final class MQReceiver {
	private static final Logger logger = Logger.getLogger(MQReceiver.class.getName());

	private final MQQueueConnectionFactory cf;
	private final QParams params;
	private final Selector selector;

	private MessageConsumer receiver;

	// This class is used to read messages from input queue
	public MQReceiver(QParams params, Selector selector) throws JMSException {
		this.params = params;
		this.selector = selector;

		cf = new MQQueueConnectionFactory();
		cf.setHostName(params.getServer());
		cf.setPort(params.getPort());
		cf.setQueueManager(params.getQmanager());
		cf.setChannel(params.getChannel());
		cf.setCCSID(866);
		cf.setTransportType(1);
		cf.setUseConnectionPooling(true);

		connect();
	}

	public Message receive() throws JMSException {
		Message m = receiver.receive();
		logger.log(Level.FINEST, "Received with selectors: {0}", selector.getSelector());
		logger.log(Level.FINEST, "INCOMING JMS: {0}", m.toString());
		return m;
	}

	private void connect() throws JMSException {
		MQQueueConnection connection = (MQQueueConnection) cf.createQueueConnection();
		MQQueueSession session = (MQQueueSession) connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
		MQQueue queue = (MQQueue) session.createQueue(params.getQueue());
		if (selector.getSelector() != null) {
			receiver = session.createConsumer(queue, selector.getSelector());
		} else {
			receiver = session.createConsumer(queue);
		}
		connection.start();
	}

	// Endless loop until reconnnected
	public void reconnect() {
		while (true) {
			try {
				Logger.getLogger(MQSender.class.getName()).log(Level.INFO, "Trying to reconnect...", "");
				connect();
				return;
			} catch (JMSException ex) {
				try {
					Thread.sleep(5000L);
				} catch (InterruptedException ex1) {
					logger.log(Level.SEVERE, "Reciever thread interrupted while waiting to reconnect!");
				}
			}
		}
	}

}
