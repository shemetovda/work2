package ru.sbt.lt.emul.unistub.processing.extractors;

import java.io.IOException;
import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ExtractByXpath implements IExtractor {
	private final String _extractorName;
	private final String _xpathString;

	public ExtractByXpath(String extractorName, String xpathString) {
		_extractorName = extractorName;
		_xpathString = xpathString;

	}

	@Override
	public String extractFrom(UnifiedMessage message) {
		String body = message.getBody();
		DocumentBuilderFactory domF = DocumentBuilderFactory.newInstance();
		domF.setNamespaceAware(true);

		String result = "";

		DocumentBuilder builder = null;
		try {
			builder = domF.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(body));
			Document doc = builder.parse(is);
			XPath xpath = XPathFactory.newInstance().newXPath();
			XPathExpression expr = xpath.compile(_xpathString);
			result = expr.evaluate(doc, XPathConstants.STRING).toString();
		} catch (IOException | ParserConfigurationException | SAXException
				| XPathExpressionException ex) {
			Logger.getLogger(ExtractByXpath.class.getName()).log(Level.SEVERE, null, ex);
		}

		return result;
	}

	@Override
	public String getName() {
		return _extractorName;
	}

}
