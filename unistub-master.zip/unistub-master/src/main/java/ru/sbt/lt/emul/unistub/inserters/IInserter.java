/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.sbt.lt.emul.unistub.inserters;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-chernov-dv
 */
public interface IInserter {
    public void insertTo(UnifiedMessage message);
	public void insertTo(UnifiedMessage message, String value);
    public String getExtractedName();
}

