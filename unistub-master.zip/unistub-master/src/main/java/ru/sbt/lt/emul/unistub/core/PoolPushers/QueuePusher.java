package ru.sbt.lt.emul.unistub.core.PoolPushers;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.configuration.ConfigHandler;
import ru.sbt.lt.emul.unistub.connections.MQReceiver;
import ru.sbt.lt.emul.unistub.core.QParams;
import ru.sbt.lt.emul.unistub.connections.Selector;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class QueuePusher implements IPusher {
	private static final Logger logger = Logger.getLogger(StubRunner.class.getName());

	QParams queue;
	MQReceiver receiver;

	public QueuePusher(QParams targetQ, Selector selector) throws JMSException {
		queue = targetQ;
		receiver = new MQReceiver(queue, selector);
	}

	@Override
	public UnifiedMessage getNewMessage() {
		Message msg = null;
		try {
			msg = receiver.receive();
			return new UnifiedMessage(msg);
		} catch (JMSException ex) {
			if (ConfigHandler.getIsReconnectionNeeded()) {
				receiver.reconnect();
			} else {
				logger.log(Level.SEVERE, "Can't recieve messages from input queue {0}\n{1}!", new Object[]{
					queue.getQueue(), ex});
				System.exit(-1);
			}
		}
		return null;
	}
}
