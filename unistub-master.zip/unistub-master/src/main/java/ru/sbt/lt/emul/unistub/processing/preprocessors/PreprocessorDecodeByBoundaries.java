package ru.sbt.lt.emul.unistub.processing.preprocessors;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author Sbt-verbovskiy-dm
 */
public class PreprocessorDecodeByBoundaries implements IPreprocessor{
        String _LB = "";
        String _RB = "";
        
    public PreprocessorDecodeByBoundaries(String LB, String RB){
        _LB = LB;
        _RB = RB;
    }
    @Override
    public UnifiedMessage preprocess(UnifiedMessage message) {
        String body = message.getBody();
        String encoded = StringUtils.substringBetween(body, _LB, _RB);
        
        byte[] Bdecoded = Base64.decodeBase64(encoded);
        String decoded = new String(Bdecoded);
        
        String newBody = StringUtils.replace(body, encoded, decoded);
        message.setBody(newBody);
        return message;
    }
    
}
