package ru.sbt.lt.emul.unistub.stats;

import java.util.ArrayList;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class StatusComposer {
    public static String compose(ArrayList<Status> statusList){
        StringBuilder sb = new StringBuilder();
        
        for (Status s : statusList){
            sb.append(s.toString());
        }
        String statusMessage = sb.toString();
        return statusMessage;
    }
    
}
