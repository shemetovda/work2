/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.sbt.lt.emul.unistub.inserters;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-chernov-dv
 */
public class InsertJMSHeader implements IInserter{
	private final String _propertyName;
	private final String _propertyValue;
	private final String _extractedName;
	
	public InsertJMSHeader(String extractedName, String propertyName, String propertyValue) {
		_propertyName = propertyName;
		_propertyValue = propertyValue;
		_extractedName = extractedName;
	}

	@Override
	public void insertTo(UnifiedMessage message) {
		message.addAdditionalProperty(_propertyName, _propertyValue);
	}
	
	@Override
	public void insertTo(UnifiedMessage message, String value) {
		message.addAdditionalProperty(_propertyName, value);
	}

	@Override
	public String getExtractedName() {
		return _extractedName;
	}
}