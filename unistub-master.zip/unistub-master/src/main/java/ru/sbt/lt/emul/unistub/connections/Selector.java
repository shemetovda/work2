/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.sbt.lt.emul.unistub.connections;

/**
 *
 * @author sbt-chernov-dv
 */
public class Selector {
	private final String selectionString;
	private final int inputCount;

	public Selector(String property, String value, int inputCount) throws Exception {
		this.inputCount = inputCount;
		if (property != null && value != null) {
			selectionString = property + " = '" + value + "'";
		} else if (property == null && value == null) {
			selectionString = null;
		} else if (property == null) {
			throw new Exception("Property was not defined!");
		} else {
			throw new Exception("Value of property " + property + " was not defined!");
		}
	}

	public String getSelector() {
		return selectionString;
	}

	public int getInputCount() {
		return inputCount;
	}
}
