package ru.sbt.lt.emul.unistub.processing.preprocessors;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author Sbt-verbovskiy-dm
 */
public interface IPreprocessor {
    public UnifiedMessage preprocess(UnifiedMessage message);
}
