package ru.sbt.lt.emul.unistub.connections.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnectionFactory {

    static public Connection createConnectionByDBType(String type, String host, int port, String schema, String login, String password) 
			throws ClassNotFoundException, SQLException {
        Connection connection = null;
        String url;
        switch (type){
            case "Oracle":
                Class.forName("oracle.jdbc.driver.OracleDriver");
                url = "jdbc:oracle:thin:@" + host + ":" + port + ":" + schema;
                connection = DriverManager.getConnection(url, login, password);
                break;
				/// TODO: need to test this ones
//            case "MySQL":
//                Class.forName("com.mysql.jdbc.Driver");
//                url = "jdbc:mysql://" + host + ":" + port + "/" + schema;
//                connection = DriverManager.getConnection(url, login, password);
//                break;
//            case "PostgreSQL":
//                Class.forName("org.postgresql.Driver");
//                url = "jdbc:postgresql://" + host + ":" + port + "/" + schema;
//                connection = DriverManager.getConnection(url, login, password);
//                break;
        }
        return connection;
    }
}
