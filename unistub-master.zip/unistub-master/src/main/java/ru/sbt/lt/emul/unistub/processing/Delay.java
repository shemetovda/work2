package ru.sbt.lt.emul.unistub.processing;

import java.util.Random;
import java.util.logging.Logger;
import ru.sbt.lt.emul.unistub.StubRunner;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class Delay {
	private static final Logger logger = Logger.getLogger(Delay.class.getName());
	
    private final Random rand = new Random();
    private final int from;
    private final int to;
    private final String opname;
    private int delaytime;

    public Delay(String opName, int delayFrom, int delayTo){
        if (delayFrom < delayTo) {
            from = delayFrom;
            to = delayTo;
		} else {
            from = delayTo;
            to = delayFrom;    
        }
        opname = opName;
    }
    
    public void sumDelayStats() throws NullPointerException {
		/* Opname and total delays that were successfully processed */
        int sumdelay = 0;
        int mindelay = 0;
        int maxdelay = 0;
        
        if (StubRunner.global_delayStats.containsKey(opname)) {
            sumdelay = StubRunner.global_delayStats.get(opname);
        } else {
            StubRunner.global_delayStats.put(opname, 0);
        }
        
        sumdelay += delaytime;
        StubRunner.global_delayStats.put(opname, sumdelay);
        
        if (StubRunner.global_op_delay_min.containsKey(opname)) {
            mindelay = StubRunner.global_op_delay_min.get(opname);
        } else {
            StubRunner.global_op_delay_min.put(opname, 0);
        }
        if (delaytime < mindelay || mindelay == 0) {
            StubRunner.global_op_delay_min.put(opname, delaytime);
        }
        if (StubRunner.global_op_delay_max.containsKey(opname)) {
            maxdelay = StubRunner.global_op_delay_max.get(opname);
        } else {
            StubRunner.global_op_delay_max.put(opname, 0);
        }        
        
        if (delaytime > maxdelay || maxdelay == 0) {
            StubRunner.global_op_delay_max.put(opname, delaytime);
        }        
    }

    public String getOpname(){
        return opname;
    }
    
    public int getDelayTime(){
		delaytime = rand.nextInt((to - from) + 1) + from;
		return delaytime;
    }
 
}
