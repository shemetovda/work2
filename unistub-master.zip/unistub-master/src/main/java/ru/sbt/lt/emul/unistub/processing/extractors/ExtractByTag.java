package ru.sbt.lt.emul.unistub.processing.extractors;

import java.util.logging.Logger;
import org.apache.commons.lang3.StringUtils;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class ExtractByTag implements IExtractor {
	private static final Logger logger = Logger.getLogger(ExtractByTag.class.getName());

	private final String _tagName;
	private final String _extractorName;

	public ExtractByTag(String extractorName, String tagName) {
		_tagName = tagName;
		_extractorName = extractorName;
	}

	@Override
	public String extractFrom(UnifiedMessage message) {
		String body = message.getBody();
		String tagVal = StringUtils.substringBetween(body, "<" + _tagName + ">", "</" + _tagName + ">");
		if (tagVal != null && !tagVal.isEmpty()) {
			return tagVal;
		} else {
			return "";
		}

	}

	@Override
	public String getName() {
		return _extractorName;
	}

}
