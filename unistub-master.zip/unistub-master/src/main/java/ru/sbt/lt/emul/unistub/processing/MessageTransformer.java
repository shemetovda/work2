package ru.sbt.lt.emul.unistub.processing;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;

import javax.xml.parsers.ParserConfigurationException;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.logging.Logger;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.io.FileUtils;
import org.xml.sax.SAXException;

/**
 *
 * @author sbt-chernov-dv
 */
public class MessageTransformer {
	private static final Logger logger = Logger.getLogger(BasicOperationProcessing.class.getName());

	private final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	private final TransformerFactory tfactory = TransformerFactory.newInstance();
	private final DocumentBuilder builder;
	private final Transformer transformer;

	public MessageTransformer() throws ParserConfigurationException, TransformerConfigurationException {
		builder = factory.newDocumentBuilder();
		transformer = tfactory.newTransformer();
	}

	public Document toDOMDocument(File input) throws SAXException, IOException {
		String a = new String(FileUtils.readFileToByteArray(input));
		a = a.trim().replaceFirst("^([\\W]+)<", "<");
		Document document = builder.parse(new ByteArrayInputStream(a.getBytes(Charset.forName("UTF-8"))));
		return document;
	}

	public String toStringMessage(Document document) throws TransformerConfigurationException, TransformerException {
		StringWriter writer = new StringWriter();
		transformer.transform(new DOMSource(document), new StreamResult(writer));
		String outgoingString = writer.toString();
		return outgoingString;
	}

	public String toStringMessage(File input) throws IOException {
		return FileUtils.readFileToString(input, "UTF-8");
	}
}
