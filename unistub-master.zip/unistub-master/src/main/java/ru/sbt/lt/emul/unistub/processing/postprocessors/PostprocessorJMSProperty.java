package ru.sbt.lt.emul.unistub.processing.postprocessors;


import ru.sbt.lt.emul.unistub.core.UnifiedMessage;


/**
 *
 *  @author SBT-Pugachev-VV
 */
public class PostprocessorJMSProperty implements IPostprocessor  {
    
     private final String _propertyname;
     private String _value;
        
    public PostprocessorJMSProperty(String propertyname, String value){
        _propertyname = propertyname;
        _value = value;
        
    }
    
    @Override
    public UnifiedMessage postprocess(UnifiedMessage message) {
        
        message.getAdditionalProperties().put(_propertyname, _value);
        
        return message;
    }

    public String getProperty(){
        return _propertyname;
    }

    public String getValue() {
        return _value;
    }

    public void setValue(String value) {
        _value = value;
    }

}
