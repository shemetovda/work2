package ru.sbt.lt.emul.unistub.stats;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.processing.OperationStatistics;


/**
 *
 * @author sbt-verbovskiy-dm
 */
public class InnerStatsSender implements Runnable {
    private static final Logger logger = Logger.getLogger(InnerStatsSender.class.getName());
	private static final String LOG_FOLDER = "log";

    public static String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss.SSS");
        Date now = new Date();
        String sDate = sdf.format(now);
        return sDate;
    }
    int _sendDelayMs;
    
    int prevIncoming = 0;
    int prevProcessed = 0;
    int prevFailed = 0;
    
    FileHandler fh;
 
    public InnerStatsSender(int sendDelaySec, String configFileName){
		try {
			File logDir = new File(LOG_FOLDER);
			if (!logDir.exists()) {
				if (!logDir.mkdir()) {
					logger.log(Level.SEVERE, "Can't create log directory!");
				}
			}
            fh = new FileHandler("./" + LOG_FOLDER + "/" + configFileName.replace(".xml", "_") +getTime()+"_stats.log");
            logger.addHandler(fh);
        } catch (IOException | SecurityException ex) {
            Logger.getLogger(InnerStatsSender.class.getName()).log(Level.SEVERE, null, ex);
        }
      
        _sendDelayMs = sendDelaySec*1000;  
      
    }
        
    public void sendStats(){
		try {
			logger.log(Level.INFO, compose());
			prevIncoming = ru.sbt.lt.emul.unistub.StubRunner.global_incoming_count.get();
			prevProcessed = ru.sbt.lt.emul.unistub.StubRunner.global_processed_count.get();
			prevFailed = ru.sbt.lt.emul.unistub.StubRunner.global_failed_count.get();
		} catch (NullPointerException ex) {
			logger.log(Level.WARNING, "Something went wrong with stats composing :( {0}", ex.getMessage());
		}
    }

    @Override
    public void run(){
        while (true){
            sendStats();
            try {
                Thread.sleep(_sendDelayMs);
            } catch (InterruptedException ex) {
                logger.log(Level.SEVERE, null, ex);
            }
        }
    }

    public String compose() throws NullPointerException {
        StringBuilder sb = new StringBuilder();
        
        int inc = ru.sbt.lt.emul.unistub.StubRunner.global_incoming_count.get();
        int proc = ru.sbt.lt.emul.unistub.StubRunner.global_processed_count.get();
        int fld = ru.sbt.lt.emul.unistub.StubRunner.global_failed_count.get();
        sb.append("\nTotal incoming count: ").append(inc).append("(+ ").append(inc - prevIncoming).append(" from last call)\n");
        sb.append("Total processed count: ").append(proc).append("(+ ").append(proc - prevProcessed).append(" from last call)\n");
        sb.append("Total failed count: ").append(fld).append("(+ ").append(fld - prevFailed).append(" from last call)\n");
        sb.append("___________Per operation_____________\n");
        
        for (OperationStatistics stat: StubRunner.processings.getStatistics()){
            sb.append(stat.toString());
			if (logger.getParent().getLevel().intValue() <= Level.CONFIG.intValue()) {
				sb.append(stat.toFullString());
			}
        }
        return sb.toString();
    }
    
}
   
