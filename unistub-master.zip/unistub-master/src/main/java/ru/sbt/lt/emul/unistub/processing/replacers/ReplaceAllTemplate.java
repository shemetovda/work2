package ru.sbt.lt.emul.unistub.processing.replacers;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class ReplaceAllTemplate implements IReplacer {
	private final String extractedName;

	public ReplaceAllTemplate(String extractedName) {
		this.extractedName = extractedName;
	}

	@Override
	public String replace(String message, String replaceWith) {
		return replaceWith;
	}

	@Override
	public String getExtractedName() {
		return extractedName;
	}
}
