package ru.sbt.lt.emul.unistub.processing.extractors;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public interface IExtractor {
    public String extractFrom(UnifiedMessage message);
    public String getName();
}
