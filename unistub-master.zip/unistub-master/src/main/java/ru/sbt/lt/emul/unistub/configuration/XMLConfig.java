package ru.sbt.lt.emul.unistub.configuration;

import java.io.File;
import org.apache.commons.configuration2.XMLConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.builder.fluent.XMLBuilderParameters;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.configuration2.tree.xpath.XPathExpressionEngine;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class XMLConfig {
    private static XMLConfiguration config;

    public static XMLConfiguration getConfig(File configFile) throws ConfigurationException {
		if (config != null)
			return config;	
		Parameters params = new Parameters();
		XPathExpressionEngine engine = new XPathExpressionEngine();
		XMLBuilderParameters xmlParams = params.xml().setFile(configFile).setExpressionEngine(engine);     
		FileBasedConfigurationBuilder<XMLConfiguration> builder =
			new FileBasedConfigurationBuilder<>(XMLConfiguration.class).configure(xmlParams);
		config = builder.getConfiguration();
        
        return config;
    }
}

