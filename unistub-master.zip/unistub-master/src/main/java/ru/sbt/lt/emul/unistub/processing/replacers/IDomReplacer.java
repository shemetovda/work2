package ru.sbt.lt.emul.unistub.processing.replacers;

import org.w3c.dom.Document;

/**
 *
 * @author sbt-chernov-dv
 */
public interface IDomReplacer extends IReplacer {

	public void replace(String replaceWith);

	public void initDOM(Document template);

	public IDomReplacer clone();
}
