package ru.sbt.lt.emul.unistub.stats;

import com.ibm.mq.jms.MQQueue;
import com.ibm.mq.jms.MQQueueConnection;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.mq.jms.MQQueueSender;
import com.ibm.mq.jms.MQQueueSession;
import java.util.LinkedList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;
import ru.sbt.lt.emul.unistub.core.QParams;

public class MQBrokerStatsSender implements IStatsSender, Runnable {
	private static final Logger logger = Logger.getLogger(MQBrokerStatsSender.class.getName());
	
	private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private LinkedList<String> statsList = new LinkedList();
	
	MQQueueSender sender;
	MQQueueConnectionFactory cf;
	MQQueueSession session;
	QParams params;
        

    public MQBrokerStatsSender(QParams q, long delay) throws JMSException {
		params = q;
		connect();
		scheduler.scheduleAtFixedRate(this, delay, delay, TimeUnit.SECONDS);
    }
	
	@Override
    public void addStats(QParams params, String step, long timestamp, String opName) {
		TextMessage outJMSMsg;
		try {
			outJMSMsg = session.createTextMessage();
			outJMSMsg.setText("");
			outJMSMsg.setStringProperty("EventDate", step);
			outJMSMsg.setStringProperty("EventSource", step);
			outJMSMsg.setStringProperty("EventReciever", step);
			outJMSMsg.setStringProperty("Operation", step);
			outJMSMsg.setStringProperty("SourceQueue", step);
			outJMSMsg.setStringProperty("SourceQM", step);
			outJMSMsg.setStringProperty("TargetQueue", step);
			outJMSMsg.setStringProperty("TargetQM", step);
			outJMSMsg.setStringProperty("ReplyQueue", step);
			outJMSMsg.setStringProperty("ReplyQM", step);
			outJMSMsg.setStringProperty("Version", step);
			outJMSMsg.setStringProperty("ProcStatus", step);
			outJMSMsg.setStringProperty("ErrorText", step);
			outJMSMsg.setStringProperty("RqUID", step);
		} catch (JMSException ex) {
			logger.log(Level.INFO, "Exception occured when sending a logging message! {0}", ex);
		}
		
    }
    
    public void send(String message){
    }
    
    @Override
    public void run(){
        try {
			String metrics = "";
			boolean haveData = false; 
			while(!statsList.isEmpty()) {
				String res = statsList.pollFirst();
				if (haveData==false) {
					haveData=true;
				} else {
					metrics += ";\n";
				}     		
				metrics += res;
			}
			if (haveData) {
				send(metrics);
			}
		} catch (Exception ex) {
			logger.log(Level.SEVERE, "SQLException occured when inserting data: {}", ex);
		}
	}
	
	private void connect() throws JMSException {
		MQQueueConnection connection = (MQQueueConnection) cf.createQueueConnection();
		session =  (MQQueueSession) connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
		MQQueue queue = (MQQueue)  session.createQueue(params.getQueue());
		sender = (MQQueueSender) session.createSender(queue);
		
		connection.start();
	}
	
	private void initConnect() throws JMSException {
		cf = new MQQueueConnectionFactory();
		cf.setHostName(params.getServer());
		cf.setPort(params.getPort());
		cf.setQueueManager(params.getQmanager());
		cf.setChannel(params.getChannel());
		cf.setCCSID(866);
		cf.setTransportType(1);
		cf.setUseConnectionPooling(true);
	}
}