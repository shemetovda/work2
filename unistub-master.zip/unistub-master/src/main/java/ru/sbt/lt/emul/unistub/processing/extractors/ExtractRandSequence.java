package ru.sbt.lt.emul.unistub.processing.extractors;

import java.util.Random;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public class ExtractRandSequence implements IExtractor{
    
    private final String _extractorName;
    private final String _prefix;
    private final char[] _charSet;
    private final int _length;
    Random rnd = new Random();
    
    public ExtractRandSequence(String extractorName, String prefix, String charSet, int length){
        _extractorName = extractorName;
        _charSet = charSet.toCharArray();
        _length = length;
        _prefix = prefix;
        
    }

    @Override
    public String extractFrom(UnifiedMessage message) {
        StringBuilder sb = new StringBuilder(_prefix);
        for (int i = 0; i < _length; i++){
            sb.append(_charSet[rnd.nextInt(_charSet.length)]);
        }
        String s = sb.toString();
        return s;
    }

    @Override
    public String getName() {
        return _extractorName;
    }
    
}
