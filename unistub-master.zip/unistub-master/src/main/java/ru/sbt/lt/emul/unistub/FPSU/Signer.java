package ru.sbt.lt.emul.unistub.FPSU;


import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;

 /**
 *
 * @author sbt-verbovskiy-dm
 */
public class Signer {
    public static String Sign(String toSign, String host, int port){
        
        
        String signature = post(toSign, host, port);
        return signature;
    }
    

    public static String post(String toSign, String host, int port){
        String response = "NA";
        
        final String url = "http://"+host+":"+port;

        try {
            response = Request.Post(url).bodyString(toSign, ContentType.DEFAULT_TEXT).execute().returnContent().asString().trim();                
        } catch (IOException ex) {
            Logger.getLogger(Signer.class.getName()).log(Level.SEVERE, ex.getLocalizedMessage(), ex);
        }
       
        return response;
    }
    
}

