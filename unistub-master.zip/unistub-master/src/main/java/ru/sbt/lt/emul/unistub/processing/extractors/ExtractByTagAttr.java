package ru.sbt.lt.emul.unistub.processing.extractors;

import org.apache.commons.lang3.StringUtils;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class ExtractByTagAttr implements IExtractor{
    private final String _tagName;
    private final String _attributeName;
    private final String _extractorName;

    public ExtractByTagAttr(String extractorName, String tagName, String attrName){
        
        _tagName = tagName;
        _attributeName = attrName;
        _extractorName = extractorName;
    }
    
    @Override
    public String extractFrom(UnifiedMessage message) {
        String body = message.getBody();
        String _LB = "<"+_tagName;
        String _RB = ">";
        
        String tagString = _LB + StringUtils.substringBetween(body, _LB, _RB) + _RB;
        
        
        String attrVal=  StringUtils.substringBetween(tagString, _attributeName+"=\"", "\"");
        return attrVal;
    }

    @Override
    public String getName() {
        return _extractorName;
    }
    
}
