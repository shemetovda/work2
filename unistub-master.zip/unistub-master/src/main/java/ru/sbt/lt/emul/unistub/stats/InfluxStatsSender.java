package ru.sbt.lt.emul.unistub.stats;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.core.QParams;

public class InfluxStatsSender implements IStatsSender, Runnable {
	private static final Logger logger = Logger.getLogger(InfluxStatsSender.class.getName());
	
	private final String stubName;
	private final ScheduledExecutorService sender = Executors.newSingleThreadScheduledExecutor();
    private URL url;
    private HttpURLConnection httpConn;
    private LinkedList<String> statsList = new LinkedList();
        

    public InfluxStatsSender(String InfluxURL, long delay) {
		stubName = StubRunner.configFileName ;
		try {
            url = new URL(InfluxURL);
        } catch (MalformedURLException ex) {
			logger.log(Level.SEVERE, "URL for influx is invalid: {0}", InfluxURL);
        }
		sender.scheduleAtFixedRate(this, delay, delay, TimeUnit.SECONDS);
    }
    
	@Override
    public void addStats(QParams params, String step, long timestamp, String opName) {
		String metric = "Emulator,Emul_host=" + params.getServer() 
			+ ",Emul_name=" + stubName
			+ ",Service=" + opName 
			+ ",Step=send"
			+ " " 
			+ timestamp*1000000L 
			+ "\n";
        statsList.add(metric);
    }
    
    public void send(String message){
        try {
            OutputStream os;
            BufferedWriter osw;
            httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setRequestMethod("POST");
            httpConn.setDoInput(true);
            httpConn.setDoOutput(true);
            os = httpConn.getOutputStream();
            osw = new BufferedWriter(new OutputStreamWriter(os));
            osw.write(message);
            osw.flush();
            osw.close();
            os.close();
            int state = httpConn.getResponseCode();
            if (state != 204) {
                logger.log(Level.SEVERE, "Error occured when sending message to influx; code = {0}", state);
                logger.log(Level.SEVERE, message);
            }
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Server: {0} is not responding!", this.url.getRef());
        }
    }
    
    @Override
    public void run(){
        try {
			String metrics = "";
			boolean haveData = false; 
			while(!statsList.isEmpty()) {
				String res = statsList.pollFirst();
				if (haveData==false) {
					haveData=true;
				} else {
					metrics += "\n";
				}     		
				metrics += res;
			}
			if (haveData) {
				send(metrics);
			}
		} catch (Exception ex) {
			logger.log(Level.SEVERE, "SQLException occured when inserting data: {}", ex);
		}
	}
}