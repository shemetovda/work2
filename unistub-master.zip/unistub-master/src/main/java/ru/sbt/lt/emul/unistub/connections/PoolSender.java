package ru.sbt.lt.emul.unistub.connections;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.RejectedExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.configuration.ConfigHandler;
import ru.sbt.lt.emul.unistub.configuration.QueuesFromConfig;
import ru.sbt.lt.emul.unistub.connections.MQSender;
import ru.sbt.lt.emul.unistub.core.QParams;
import ru.sbt.lt.emul.unistub.core.DelayedMessagePool;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

 /**
 *
 * @author sbt-chernov-dv
 */
public class PoolSender implements Runnable {
	private static final Logger logger = Logger.getLogger(PoolSender.class.getName());
	
    private final DelayedMessagePool outPool;
	private final Map<String, MQSender> senders;

    public PoolSender(DelayedMessagePool outPool) throws Exception {
        this.outPool = outPool;
		
		senders = new HashMap<>();
		HashMap<String, QParams> queues = QueuesFromConfig.getQueues();
		for (String q : queues.keySet()) {
			try {
				senders.put(q, new MQSender(queues.get(q)));
			} catch (JMSException ex) {
				logger.log(Level.SEVERE, "Exception occured when connecting to {0}!\n{1}", new Object[]{q, ex});
				throw new Exception();
			}
		}
    }
    
    @Override
    public void run() {  
        while (true){
			UnifiedMessage msg = outPool.take();
			String name = msg.getOpName();
			String q1 = ConfigHandler.getQueueForOperation(name);
			String q2 = ConfigHandler.getSecondQueueForOperation(name);
			MQSender sender = senders.get(q1);
			MQSender sender2 = senders.get(q2);
			logger.log(Level.CONFIG, "Sending msg...\n{0}", msg.getBody());
			
			if (sender != null) {
				try {
					sender.send(msg);
				} catch (JMSException ex) {
					logger.log(Level.SEVERE, "Failed to send message ({0}) to queue {1}: !\n{2}", new Object[]{name, q1, ex.getMessage()});
					StubRunner.global_failed_count.getAndIncrement();
					Exception linkedException = ex.getLinkedException();
					if (linkedException != null) {
						logger.log(Level.SEVERE, linkedException.getMessage());
					}
					return;
				} catch (RejectedExecutionException ex) {
					outPool.put(5, msg);
					continue;
				}
				if (sender2 != null) {
					try {
						msg.secondSender();
						sender2.send(msg);
					} catch (JMSException ex) {
						logger.log(Level.SEVERE, "Failed to send message ({0}) to second queue {1}: !\n{2}", new Object[]{name, q2, ex.getMessage()});
						StubRunner.global_failed_count.getAndIncrement();
						Exception linkedException = ex.getLinkedException();
						if (linkedException != null) {
							logger.log(Level.SEVERE, linkedException.getMessage());
						}
					}
				}
			}
        }
    }
    
}
