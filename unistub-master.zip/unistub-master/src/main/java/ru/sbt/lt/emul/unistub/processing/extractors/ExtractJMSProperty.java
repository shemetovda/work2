package ru.sbt.lt.emul.unistub.processing.extractors;

import java.util.HashMap;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

public class ExtractJMSProperty implements IExtractor {

	private final String _extractorName;
	private final String _additionalPropertyName;

	public ExtractJMSProperty(String extractorName, String additionalPropertyName) {
		_extractorName = extractorName;
		_additionalPropertyName = additionalPropertyName;
	}

	@Override
	public String extractFrom(UnifiedMessage message) {
		HashMap<String, String> addp = message.getAdditionalProperties();
		String propertyValue = addp.get(_additionalPropertyName);

		if (propertyValue == null) {
			return "";
		}

		return propertyValue;
	}

	@Override
	public String getName() {
		return _extractorName;
	}

}
