package ru.sbt.lt.emul.unistub.processing;

import ru.sbt.lt.emul.unistub.StubRunner;

 /**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class OperationStatistics {
    private volatile int processed = 0;
    private volatile int failed = 0;
    private final String opName;
    
    public OperationStatistics(String name){
        opName = name;
    }
    
    public void incrementProcessed(int increment){
        processed += increment;
    }
    
    public void incrementFailed(int increment){
        failed += increment;
    }    
    
    public int get_processed_count(){
        return processed;
    }
    
    public int get_failed_count(){
        return failed;
    }    
    
    public String get_op_name(){
        return opName;
    }
    
    @Override
    public String toString(){
        StringBuilder rtn = new StringBuilder();
        rtn.append(opName).append(" processed : ").append(processed).append("\n");

        return (rtn.toString());
    }
	
	public String toFullString() throws NullPointerException {
        
        StringBuilder rtn = new StringBuilder();
        rtn.append(opName).append(" failed : ").append(failed).append("\n");
        rtn.append(opName).append(" min delay, ms : ").append((processed != 0) 
				? (StubRunner.global_op_delay_min.get(opName)) 
				: "0").append("\n");
        rtn.append(opName).append(" avg delay, ms : ").append((processed != 0) 
				? (StubRunner.global_delayStats.get(opName)/processed) 
				: "0").append("\n");
        rtn.append(opName).append(" max delay, ms : ").append((processed != 0) 
				? (StubRunner.global_op_delay_max.get(opName)) 
				: "0").append("\n");
        rtn.append("-----------------------------------------\n");

        return (rtn.toString());
    }
}
