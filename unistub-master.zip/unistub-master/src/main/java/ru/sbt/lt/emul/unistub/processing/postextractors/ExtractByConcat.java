package ru.sbt.lt.emul.unistub.processing.postextractors;

import java.util.HashMap;
import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-chernov-dv
 */
public class ExtractByConcat implements IPostExtractor {
	private HashMap<String, String> extractors;
	private final String extractorName;
	private final String leftString;
	private final String rightString;

	public ExtractByConcat(String extractorName, String leftString, String rightString) {
		this.extractorName = extractorName;
		this.leftString = leftString;
		this.rightString = rightString;
	}

	@Override
	public void setExtractorsMap(HashMap<String, String> extractors) {
		this.extractors = extractors;
	}

	@Override
	public String extractFrom(UnifiedMessage message) {
		return extractors.get(leftString) + extractors.get(rightString);
	}

	@Override
	public String getName() {
		return extractorName;
	}

}
