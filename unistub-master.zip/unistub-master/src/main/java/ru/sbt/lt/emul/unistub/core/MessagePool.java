package ru.sbt.lt.emul.unistub.core;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import ru.sbt.lt.emul.unistub.core.PoolPushers.IPusher;

/**
 *
 * @author sbt-verbovskiy-dm
 * @author sbt-chernov-dv
 */
public class MessagePool {
	private static final Logger logger = Logger.getLogger(MessagePool.class.getName());
	private final BlockingQueue<UnifiedMessage> _q = new LinkedBlockingQueue<>();

	public void update(IPusher pusher) {
		UnifiedMessage toPut = pusher.getNewMessage();
		try {
			if (toPut != null) {
				_q.put(toPut);
			}
		} catch (InterruptedException ex) {
			logger.log(Level.SEVERE, "Interrupted when updating pool\n{0}", ex);
		}
	}

	public void put(UnifiedMessage m) {
		try {
			_q.put(m);
		} catch (InterruptedException ex) {
			logger.log(Level.SEVERE, "Interrupted when putting msg in pool\n{0}", ex);
		}
	}

	public UnifiedMessage take() {
		UnifiedMessage m = null;
		try {
			m = _q.take();
		} catch (InterruptedException ex) {
			logger.log(Level.SEVERE, "Interrupted when taking msg from pool\n{0}", ex);
		}
		return m;
	}

	public int getSize() {
		return _q.size();
	}

}
