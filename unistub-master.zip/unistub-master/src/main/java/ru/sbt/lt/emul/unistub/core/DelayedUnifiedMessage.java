package ru.sbt.lt.emul.unistub.core;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author sbt-chernov-dv
 */
public class DelayedUnifiedMessage<T> implements Delayed {
	private final long expireTime;
	private final T data;
	
	public DelayedUnifiedMessage(long delay, T data) {
		this.expireTime = System.currentTimeMillis() + delay;
		this.data = data;
	}
	
	public T getData() {
		return data;
	}

	@Override
	public long getDelay(TimeUnit unit) {
		return unit.convert(expireTime - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
	}

	@Override
	public int compareTo(Delayed o) {
		return o == this ? 0 :
			Long.compare(expireTime, ((DelayedUnifiedMessage)o).getExpireTime());
	}
	
	public long getExpireTime() {
		return expireTime;
	}
	
}
