package ru.sbt.lt.emul.unistub.core.PoolPushers;

import ru.sbt.lt.emul.unistub.core.UnifiedMessage;

/**
 *
 * @author sbt-verbovskiy-dm
 */
public interface IPusher {
    public UnifiedMessage getNewMessage();
}
