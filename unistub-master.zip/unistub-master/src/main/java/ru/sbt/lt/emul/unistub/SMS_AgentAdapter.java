package ru.sbt.lt.emul.unistub;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.configuration2.ex.ConfigurationException;
import static ru.sbt.lt.emul.unistub.StubRunner.config;
import ru.sbt.lt.emul.unistub.configuration.XMLConfig;
import ru.sbt.lt.emul.unistub.stats.StatsSender;

 /**
 *
 * @author sbt-verbovskiy-dm
 */
public class SMS_AgentAdapter implements Runnable{
    
    private static final Logger logger = Logger.getLogger(SMS_AgentAdapter.class.getName());
    
    public static String SessionId;
    public static String InitialTaskID;
    public static String AgentName;
    public static String StubName;
    Thread statsSenderThread; //Отправка статистики по работе заглушки
    Thread stubStopperThread; //Ожидание команды остановки заглушки из внешнего источника

    
    public SMS_AgentAdapter(String configPath) {
        File configFile = new File(configPath);
		try {
			config = XMLConfig.getConfig(configFile);
		} catch (ConfigurationException ex) {
			logger.log(Level.SEVERE, "Error occured when parsing SMS Adapter config: {0}", configPath);
			System.exit(-1);
		}
        
        logger.log(Level.INFO, "SMS Adapter config: {0}", configPath);
        
        SessionId = config.getString("SMSParams/SessionId");
        AgentName = config.getString("SMSParams/AgentName");
        StubName = config.getString("SMSParams/StubName");
        InitialTaskID = config.getString("SMSParams/InitialTaskID");
                
        //Поток отправки статистики о работе заглушки
        StatsSender sender = new StatsSender(config.getInt("Statistic/CallIntervalSec"),
                                             config.getString("Statistic/CallPath"));
        statsSenderThread = new Thread(sender);
        statsSenderThread.setName("StatsSender");

        //Поток, ожидающий команду на остановку заглушки
        int callIntervalSec = config.getInt("StubStopper/CallIntervalSec");//Частота опроса
        String checkPath = config.getString("StubStopper/CallPath");//Адрес опроса
        
        
        StubStopper stopper = new StubStopper(callIntervalSec, checkPath);
        
        stubStopperThread = new Thread(stopper);
        stubStopperThread.setName("StubStopper");
    }

    @Override
    public void run() {
        statsSenderThread.start();
        stubStopperThread.start();
    }
}
