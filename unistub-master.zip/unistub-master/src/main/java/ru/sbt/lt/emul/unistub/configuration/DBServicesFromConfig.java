package ru.sbt.lt.emul.unistub.configuration;

import org.apache.commons.configuration2.HierarchicalConfiguration;
import org.apache.commons.configuration2.XMLConfiguration;
import org.apache.commons.configuration2.tree.ImmutableNode;
import ru.sbt.lt.emul.unistub.StubRunner;
import ru.sbt.lt.emul.unistub.connections.database.DBService;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBServicesFromConfig {
	private static final Logger logger = Logger.getLogger(StubRunner.class.getName());

	private final HashMap<String, DBService> dbList = new HashMap();

	public DBService getDBService(String name) {
		return dbList.get(name);
	}

	public DBServicesFromConfig(XMLConfiguration config) throws Exception {
		List<HierarchicalConfiguration<ImmutableNode>> databases = StubRunner.config
				.configurationsAt("Databases/Database");
		for (HierarchicalConfiguration e : databases) {
			DBService dbService = null;
			String name = e.getString("Label");
			String type = e.getString("Type");
			String host = e.getString("Host");
			int port = e.getInt("Port");
			String schema = e.getString("Schema");
			String login = e.getString("Login");
			String password = e.getString("Password");

			try {
				dbService = new DBService(type, host, port, schema, login, password);
				dbList.put(name, dbService);
			} catch (ClassNotFoundException ex) {
				logger.log(Level.SEVERE, "Error: not found class for db(Name: " + name + ") connection.\n{0}", ex);
				throw new Exception("Error: database config is not valid");
			} catch (SQLException ex) {
				logger.log(Level.SEVERE, "Error database connection.\n{0}", ex);
				throw new Exception("Error: database config is not valid");
			}
		}
	}
}
