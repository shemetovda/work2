export const svg = 'svg';
